# Pit Wall Crew – instrukcja

**Instrukcja ze zdjęciami** (co do czego służy w aplikacji i na pit wallu): otwórz plik `web/instrukcja.html`
albo w aplikacji **Pomoc → Instrukcja → Instrukcja ze zdjęciami**.

Pit Wall Crew to głosowy inżynier wyścigowy do Le Mans Ultimate (program na Twoim komputerze) i **pit wall**:
strona w przeglądarce, na której cały zespół widzi na żywo stan auta, rywali, pogodę i grafik zmian kierowców.
Możesz jeździć sam (tryb **Solo**) albo w zespole.

## Czego potrzebujesz

- Windows 10 lub 11 i Le Mans Ultimate.
- Słuchawki z mikrofonem i wolny przycisk na kierownicy (albo klawisz).
- Internet.
- Opcjonalnie: darmowy klucz Groq (rozpoznawanie mowy i odpowiedzi AI).

## 1. Instalacja (5 minut)

1. Przed rozpakowaniem paczki: prawy przycisk na pliku → **Właściwości → Odblokuj** → OK.
2. Rozpakuj do folderu, np. `Dokumenty\Pit Wall Crew`.
3. Kliknij dwa razy **INSTALUJ_KIEROWCA.bat** – instalator pobierze składniki, zapyta o zespół, mikrofon i przycisk
   mówienia i utworzy ikonę **Pit Wall Crew** na pulpicie.
4. W LMU raz: **Settings → Gameplay → Enable Plugins = ON**.

Aktualizacje instalują się same przy starcie aplikacji (nigdy w trakcie jazdy). Ustawienia zostają. Testerzy z kodem od autora (Zaawansowane → Kod testera) dostają nowe wersje przed wszystkimi.

## 2. Aplikacja

Ikona **Pit Wall Crew** otwiera aplikację, inżynier startuje sam. Na górze widać stan (inżynier, gra, zespół, AI –
zielone = w porządku), pod spodem najważniejsze liczby i wszystkie komunikaty. **Test bez gry** uruchamia symulowany
wyścig – sprawdzisz głos, mikrofon i pit wall bez LMU.

Ustawienia (pasek po lewej; po zmianie: **Zapisz i uruchom ponownie**):

- **Zespół** – *Solo* albo *Zespół*. W zespole jedna osoba klika **Utwórz nowy zespół…** i dostaje kod (6 znaków);
  pozostali wpisują kod i hasło, **Sprawdź połączenie** i wybierają, kim są. Kod i hasło podawajcie sobie tylko prywatnie.
- **Mikrofon i przycisk** – wybierz mikrofon, **Test 3 s**, potem **Ustaw: naciśnij przycisk…** i naciśnij przycisk na kierownicy.
- **Głos** – głos, tempo, głośność, efekt radia, imię inżyniera; **▶ Odsłuchaj**.
- **Ostrzeżenia** – co inżynier mówi bez pytania (dublowanie, flagi, trener, porównania, komentarze, sugestie).
- **Zaawansowane** – zmiana kompletu opon, automatyczny start, skróty, aktualizacje, własny klucz Groq.

## 3. Rozmowa z inżynierem

**Trzymaj przycisk, mów, puść.** Naciśnięcie przerywa też mowę inżyniera. Przykłady: „ile paliwa?”, „kiedy zjazd?”,
„które opony zmienić?”, „kto przede mną?”, „gdzie tracę?”, „jaka pogoda?”, „cisza”, „tylko pilne”, „powtórz”.
Pełna lista: **Pomoc → Komendy**. Pytanie spoza listy trafia do AI (z kluczem Groq) razem z danymi wyścigu.

## 4. AI – klucz Groq (jedna osoba, 2 minuty)

1. Darmowe konto na https://console.groq.com → **API Keys → Create API Key** → skopiuj.
2. Pit wall → **Zespół → AI zespołu (Groq)** → wklej → **Zapisz klucz** (w trybie Solo: aplikacja → Zaawansowane → Własny klucz Groq).
3. W aplikacji pojawi się zielone **AI: Groq**.

## 5. Pit wall

Przycisk **Pit wall** w aplikacji albo https://zepansrpl-creator.github.io/Pit-Wall-Crew/ (kod i hasło zespołu).

- **Na żywo** – wyścig, następny postój, opony i auto, pogoda, kierowca, rywale w klasie, grafik stintów, mapa toru,
  radio zespołu: „Do kierowcy” (inżynier przeczyta), „Zapytaj inżyniera” (odpowiedź głosem), „Zapytaj (tylko tekst)”, „Do pamięci”.
- **Grafik i plan** – start, długość, czas okrążenia i liczba opon; plan stintów rozpisywany automatycznie
  (kierowcy, okrążenia, zmiana lewych/prawych opon, równe zużycie opon). Inżynier zjeżdża i zmienia opony według planu.
- **Zespół** – kod i QR, kierowcy i powiadomienia, klucz Groq, link dla widzów (sam podgląd).
- **Okrążenia**, **Pamięć** (notatki dla AI), **Pomoc** (w tym zgłaszanie problemów).

## 6. Powiadomienia na telefon (każdy, 2 minuty)

1. Zainstaluj darmową aplikację **ntfy**.
2. Pit wall → **Zespół** → **📱** przy swoim imieniu → temat i kod QR.
3. W ntfy **+** → wpisz temat → **Subskrybuj**; na pit wallu kliknij **Test**.

Powiadomienie przychodzi ok. 30 minut przed Twoją zmianą, drugie – gdy zmiana przesunie się o 10 minut lub więcej, i gdy zacznie padać.

## 7. Długi wyścig (np. 24 h)

- Kierowca, który jedzie, ma włączony Pit Wall Crew przez cały stint.
- Pozostali mogą wyłączyć grę, program i komputer; po powiadomieniu włączcie wszystko **przed** wejściem do auta.
- Plan, grafik, wiadomości, pamięć i odprawa od poprzedniego kierowcy są w bazie zespołu – program pobierze je sam.
- Próba przed wyścigiem: wszyscy włączają aplikację (zielone Zespół i AI), jeden klika **Test bez gry**, pozostali patrzą
  na pit wall, kierowca pyta „ile paliwa?”, z pit walla idzie wiadomość „Do kierowcy”.

## 8. Gdy coś nie działa

| Objaw | Co zrobić |
| --- | --- |
| „Czekam na LMU” mimo włączonej gry | LMU: Settings → Gameplay → Enable Plugins = ON, uruchom grę ponownie |
| „Nie słyszę Cię” / inżynier nie słyszy | Mikrofon i przycisk → Test 3 s; wyciszenie na słuchawkach; Windows → Prywatność → Mikrofon |
| „Zły kod albo hasło zespołu” | Zespół → popraw → Sprawdź połączenie → Zapisz |
| Pit wall: „brak danych z gry” | U kierowcy działa aplikacja z zielonym „Zespół”? |
| „AI: Groq – zły klucz” | Wklej klucz ponownie |
| Każdy komunikat podwójnie | Zamknij aplikację, w Menedżerze zadań zakończ „pythonw”, uruchom raz |
| Brak powiadomień | Start wyścigu i kierowcy w planie, temat w ntfy, przycisk Test |
| Gra się przycina | Zwykle brak pamięci karty: niższe tekstury, mniej aut i cieni, zamknij inne programy |
| Windows blokuje pliki | Przed rozpakowaniem: Właściwości → Odblokuj |
| Przeniesienie programu | Przenieś cały folder i uruchom `skroty.bat` |

**Problem albo pomysł?** Aplikacja: **Pomoc → Zgłoś problem**, pit wall: zakładka **Pomoc**. Zgłoszenie trafia prosto do autora. Za Twoją zgodą (pytanie przy pierwszym starcie) program sam wysyła raport, gdy się zepsuje – opis błędu i dziennik ostatniej sesji, bez nagrań głosu, kluczy i haseł. Co i dokąd wysyła program: strona **Prywatność** (link na dole pit walla).

---

Pit Wall Crew – stworzone przez **Maciej Szczepaniak from FR Mods**. Podziękowania dla Retta i Barnego za pomoc w testach.
