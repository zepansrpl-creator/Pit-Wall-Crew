# Pit Wall Crew – instrukcja dla zespołu

Trzy części:

| Część | Gdzie | Kto |
| --- | --- | --- |
| **Ściana boksów** (strona na telefon i komputer, baza Firebase) | https://zepansrpl-creator.github.io/Pit-Wall-Crew/ | ktoś z zespołu zakłada zespół, raz |
| **Inżynier** (program kierowcy, bez AI – nie obciąża gry) | komputer każdego kierowcy | Maciej, Patryk, Amadeusz |
| **AI w chmurze (Groq, darmowe)** – rozpoznawanie mowy i odpowiedzi AI | klucz wklejony raz na ścianie boksów | jedna osoba, raz |

---

## 1. Zespół i ściana boksów (jedna osoba, 5 minut)

1. Otwórz **https://zepansrpl-creator.github.io/Pit-Wall-Crew/** → **Nowy zespół**: wpisz nazwę i hasło zespołu (min. 6 znaków) → **Utwórz zespół**.
   (Można też w programie: okno ustawień → zakładka Zespół → **Utwórz nowy zespół…**.)
2. Dostaniesz **kod zespołu** (6 znaków, zakładka **Zespół**). Kod i hasło wyślij kolegom **prywatnie** – kto je zna, widzi stan auta i może pisać do kierowcy.
3. Zakładka **Zespół** → **+ kierowca**: wpisz imiona kierowców i zapisz. Temat ntfy jest wpisany sam (można zmienić).
4. Zakładka **Grafik i plan**:
   - **Start wyścigu** (data i godzina, czas polski) i pozostałe ustawienia → **Zapisz ustawienia**,
   - **Plan stintów**: kto jedzie który stint, ile okrążeń, co na postoju → **Zapisz plan**.
     Plan ze starego arkusza: „Wklej plan z arkusza Google” – skopiuj wiersze z zakładki Plan (kolumny A–W) i wklej.

**Link do ściany boksów** dla zespołu jest w zakładce **Zespół** (także jako kod QR – zeskanuj telefonem; hasło wpisuje się raz, telefon je zapamięta).
**Link dla obserwatorów** (tylko podgląd na żywo, bez radia i planu) – też w zakładce **Zespół**, można go dać każdemu.

## 2. Powiadomienia na telefon (każdy, 2 minuty)

1. Zainstaluj darmową aplikację **ntfy** (Android: Google Play, iPhone: App Store).
2. **+ → Subskrybuj temat** i wpisz swój temat z zakładki **Zespół** na ścianie boksów (np. `pwc-k7m2qp`).
3. Na ścianie boksów przy swoim imieniu kliknij **Test** – powinno przyjść „Pit Wall Crew – test”.

Powiadomienie przychodzi ok. **30 minut przed Twoją zmianą** (liczba minut do zmiany w ustawieniach).
Grafik przelicza co minutę jedna z włączonych aplikacji zespołu (najlepiej ta u kierowcy, który jedzie) – serwer nie jest potrzebny.
Jeśli zmiana przesunie się o 10 minut lub więcej (naprawa, deszcz), dostaniesz drugie powiadomienie z nową godziną.

## 3. Program kierowcy (każdy z Was)

1. Rozpakuj paczkę do folderu, np. `Dokumenty\LMU-Inzynier-v2`.
2. Kliknij dwa razy **INSTALUJ_KIEROWCA.bat**. Instalator:
   - zainstaluje Pythona i biblioteki (bez AI – nic nie zabiera grze karty graficznej),
   - poprosi o **kod i hasło zespołu** i zapyta, kim jesteś,
   - poprosi o wciśnięcie **przycisku mówienia** na kierownicy i sprawdzi mikrofon,
   - utworzy skrót **Pit Wall Crew** (test bez gry i ustawienia są w aplikacji).

Aktualizacje: od wersji 3.4.0 aplikacja aktualizuje się sama przy starcie (nigdy w trakcie jazdy); serwer AI też, przy uruchomieniu. Ustawienia i dane zostają.

Aktualizacja ze starszej wersji (raz, ręcznie): rozpakuj nową paczkę do tego samego folderu (zastąp pliki), uruchom **Pit Wall Crew**, w oknie ustawień w zakładce **Zespół** wpisz kod i hasło zespołu → **Zapisz**. Stare skróty „Inżynier LMU” możesz usunąć z pulpitu.
3. W LMU raz: **Ustawienia → Rozgrywka → Enable Plugins = ON**.

Skrót **Pit Wall Crew** otwiera aplikację: inżynier startuje sam, a w oknie widać jego komunikaty, stan połączeń i najważniejsze liczby (pytanie można też wpisać). Ustawienia są w pasku po lewej.

W trakcie wyścigu każdy ma włączony skrót **Pit Wall Crew** – także gdy nie jedzie. Program sam rozpoznaje, kto prowadzi auto:
mówi tylko do kierowcy, który jedzie, a stan auta na ścianę boksów wysyła ten, kto jedzie.

## 3b. AI zespołu – Groq (jedna osoba, 2 minuty)

1. Załóż darmowe konto na https://console.groq.com i utwórz klucz (**API Keys → Create API Key**).
2. Na ścianie boksów: **Zespół → AI zespołu (Groq)** → wklej klucz → **Zapisz klucz**. Klucz widzą tylko członkowie zespołu.
3. W aplikacji pojawi się zielone **AI: Groq**. Mowę rozpoznaje Whisper w chmurze, a pytania spoza reguł – AI. Komputery graczy nic nie liczą.

**Radio zespołu:** kto nie jedzie, a ma włączoną aplikację Pit Wall Crew, słyszy komunikaty inżyniera (bez pilnych – te są tylko dla kierowcy). Na telefonie: ściana boksów → **🔊 Słuchaj inżyniera**. Na Discordzie rozmawiacie już tylko między sobą.

## 4. Bot Discord (opcjonalnie)

1. Wejdź na https://discord.com/developers/applications → **New Application** (np. „Inżynier”).
2. Zakładka **Bot** → **Reset Token** → skopiuj token (nikomu go nie pokazuj, wkleisz go tylko w instalatorze serwera AI zespołu).
   Na tej samej stronie włącz **Message Content Intent** i zapisz.
3. Zakładka **OAuth2 → URL Generator**: zaznacz **bot**, a niżej uprawnienia: View Channels, Send Messages,
   Add Reactions, Read Message History, **Connect**, **Speak**. Otwórz wygenerowany link i dodaj bota do Waszego serwera.

## 5. Serwer AI zespołu (opcjonalnie – zamiast Groq albo dla bota Discord)

1. Rozpakuj paczkę na komputerze, który będzie serwerem AI zespołu, kliknij **INSTALUJ_SERWER.bat** (pobiera ok. 8–9 GB: biblioteki karty graficznej,
   Whisper i model Bielik). Na koniec zapyta o kod i hasło zespołu, **token bota** i nazwę kanału głosowego.
2. W dniu wyścigu: komputer serwera AI **na ładowarce**, w Windows tryb zasilania **Najlepsza wydajność**, uruchom skrót
   **Pit Wall Crew - serwer AI** i zostaw włączony. Bot sam wejdzie na kanał głosowy.
   Klapę możesz zamknąć, jeśli w Windows ustawisz „Po zamknięciu pokrywy: Nic nie rób”.

Gdy serwer AI zespołu jest wyłączony, wszystko dalej działa, tylko prościej: inżynier mówi u kierowcy (bez Discorda),
mowę rozpoznaje Google przez internet, a pytania spoza standardowych tematów zostają bez odpowiedzi AI.

## 6. Próba przed wyścigiem (15 minut, wszyscy razem na Discordzie)

1. Wszyscy uruchamiają **Pit Wall Crew** – w aplikacji zielone **Zespół** i **AI: Groq**.
2. Jeden z kierowców: w aplikacji **Test bez gry** (symulowany wyścig).
3. Otwórzcie ścianę boksów na telefonach – powinny być dane „na żywo”.
4. Kierowca: przytrzymaj przycisk i zapytaj „ile mam paliwa?” – odpowiedź usłyszą wszyscy w swoich aplikacjach (radio zespołu).
5. Na ścianie boksów „Zapytaj inżyniera” i „Do kierowcy” – inżynier odpowie / przeczyta głosem.
6. Ze ściany boksów wyślijcie wiadomość „Do kierowcy”.

## 6b. Test w LMU z nagrywaniem (dostrojenie inżyniera)

1. Uruchom LMU, wejdź na trening na Le Mans (Ferrari, jak w wyścigu).
2. Kliknij **test_nagrywanie.bat** – inżynier działa normalnie i dodatkowo zapisuje dane z gry (folder `recordings`).
3. W garażu i potem na torze kliknij **sprawdz_lmu.bat** – sprawdza wewnętrzny interfejs gry (tylko odczyt):
   prognozę pogody, hamulce, menu boksu. Wyniki w folderze `lmu_api`.
4. Przejedź 30–40 minut: kilka czystych okrążeń, jeden postój (zjedź na okrążeniu, kiedy inżynier powie „box, box”),
   kawałek za innym autem (temperatury), jeśli się da – trochę deszczu.
5. Zamknij inżyniera („koniec” albo zamknij okno) i kliknij **spakuj_wyniki.bat** → plik `wyniki_testu.zip`.

## 7. W trakcie wyścigu

**Kierowca słyszy bez pytania tylko to, co coś zmienia:**
- pilne: dublowanie (z klasą), auto stojące na torze, flagi, kary – zawsze u siebie, bez opóźnienia,
- plan postoju 3 okrążenia przed zjazdem, na początku okrążenia zjazdowego przypomnienie, a ok. 25 s przed metą „Box, box”,
- gdy zużycie paliwa/energii albo opon odbiega od planu i przesuwa zjazd,
- rywal blisko, który wyraźnie odrabia albo ucieka, neutralizacja (FCY), koszt uszkodzenia,
- deszcz: kiedy opłaca się zmienić na deszczowe / slicki, zmiany temperatury toru,
- oznaki zmęczenia (spadek tempa, gorsza powtarzalność, błędy),
- wiadomości od zespołu.

**Oszczędzanie** – gdy zmniejszenie zużycia energii o kilka procent daje o jeden postój mniej (albo metę bez postoju), inżynier poda cel na okrążenie i po każdym okrążeniu powie, czy się mieścisz. Pytanie: „ile oszczędzać”.

**Zmiana kierowcy** – kto wsiada, słyszy odprawę (pozycja, czas do mety, energia, opony, uszkodzenia), a potem odprawę od inżyniera poprzedniego kierowcy (plan, zużycie, ciśnienia, uwagi). Na ścianie boksów pojawia się podsumowanie stintu (tempo, równość, zużycie, wyjazdy poza tor). 

**Noc i ciśnienia** – gdy ciepłe ciśnienia opon odbiegają od tych z pierwszego stintu (np. zimniejszy tor w nocy), inżynier poda, o ile kliknąć ciśnienie przód/tył na następnym postoju.

**„Cisza”, „cicho” albo „Inżynier cicho”** – inżynier odpowiada „Ok.” i milknie całkowicie (także ostrzeżenia i wiadomości ze ściany boksów; widać je tylko w oknie i na ścianie). Odzywa się znowu po następnym naciśnięciu przycisku mówienia. **„Tylko pilne”** – mówi tylko ostrzeżenia i odpowiedzi na pytania.

**Porównanie z najlepszym okrążeniem** (komendy „porównanie” / „bez porównania”, domyślnie włączone): przed zakrętem,
w którym na ostatnim okrążeniu straciłeś najwięcej, inżynier poda konkret, np. „T5: hamujesz 15 metrów wcześniej niż na najlepszym”.

**Komentarze po wyprzedzeniu** („komentarze” / „bez komentarzy”): gdy zyskasz albo stracisz pozycję w klasie i utrzyma się ona
30 sekund (bez postojów), inżynier krótko to skomentuje w swoim stylu (Głos → Styl).

**Sugestie** (komendy „sugestie” / „bez sugestii”, domyślnie włączone): gdy na 3 z 4 okrążeń powtarza się
blokowanie kół, buksowanie, ABS albo TC pracujący przez większość zakrętu, podsterowność lub nadsterowność,
inżynier podpowie jedną zmianę – w wyścigu tylko z kokpitu (balans hamulców, TC) albo technikę jazdy,
w treningu także zmiany w garażu. Po zmianie ustawienia sprawdzi, czy pomogło. Najwyżej raz na 12 minut.

Czasu okrążenia, stanu paliwa i opon inżynier sam nie podaje – zapytaj: „jaki czas?”, „ile paliwa?”, „jak opony?”,
„jak się zmienia zużycie?”, „czy tracę tempo?”, „jaka pogoda?”, „gdzie tracę?”, „co z te pięć?”.

**Komendy na Discordzie:** `!i pytanie` (do inżyniera, odpowiedź głosem), `!w tekst` (do kierowcy),
`!z tekst` (notatka do pamięci zespołu), `!stan`.

**Pamięć zespołu** (zakładka „Pamięć” na ścianie boksów): notatki, które AI inżyniera czyta przy każdym pytaniu,
np. „ABS 9 za mocny w deszczu”, „na nowych oponach pierwsze okrążenie ostrożnie w T1”. Dodajesz je głosem
(„zapamiętaj …”), przyciskiem „Do pamięci” na ścianie boksów, komendą `!z` albo w zakładce „Pamięć”.
Inżynier sam zapisuje też zmiany setupu zgłoszone głosem, odczucia kierowcy i to, czy zmiana pomogła.

**Ściana boksów:** mapa toru z autami na żywo, pozycja, odstępy, następny postój i plan, opony, uszkodzenia, pogoda, zmęczenie kierowcy,
grafik stintów z prognozą („vs plan” = o ile minut zmiana jest później/wcześniej niż w planie), radio zespołu.

Grafik liczy się z bieżącej sytuacji: prawdziwego tempa (mediana ostatnich okrążeń), zużycia paliwa/energii
i planu z zakładki **Grafik i plan**. Gdy numer stintu się rozjedzie (np. po karze drive-through), wpisz
„Korekta numeru stintu” (+1 albo −1) w tej samej zakładce.

## 8. Gdy coś nie działa

| Objaw | Co zrobić |
| --- | --- |
| Ściana boksów: „brak danych z gry” | U kierowcy włączony Pit Wall Crew? W oknie „Połączono ze ścianą boksów”? |
| W oknie inżyniera „zły kod albo hasło zespołu” | Okno ustawień → Zespół → popraw kod/hasło → Sprawdź połączenie → Zapisz |
| Bot nie mówi | Na serwerze AI zespołu okno serwera: czy bot jest na kanale? Nazwa kanału w `serwer.toml` |
| Nie ma powiadomień | Start wyścigu i kierowcy w planie (zakładka Grafik i plan), temat w ntfy, przycisk Test; włączona aplikacja u kogokolwiek z zespołu |
| Mikrofon | `test_mikrofonu.bat` |
| Głos inżyniera | `wybierz_glos.bat` (głosy, efekt radia, muzyka w tle) |

Ściana boksów działa na darmowym planie Firebase (Google): stan auta przychodzi co ok. 4 s, strona odświeża się sama od razu.
Gdy brakuje internetu, w oknie inżyniera pojawi się „brak połączenia ze ścianą boksów” –
inżynier u kierowcy działa wtedy dalej sam i połączy się ponownie automatycznie.
