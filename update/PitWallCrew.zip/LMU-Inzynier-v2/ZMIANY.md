# Zmiany w Pit Wall Crew

Numer wersji widać w oknie inżyniera, w tytule okna ustawień i na ścianie boksów (przy „jedzie: …”).

## 3.9.1 (22.10.2026)
- Naprawione (główna przyczyna wielu błędów): zapisane „najlepsze okrążenie” z poprzednich sesji było uszkodzone
  (dziura w danych – 177 s na Le Mans). Przez nie: fałszywe „Hypercar, 1 sekunda” o autach kilkaset metrów z tyłu,
  „Wolne auto” o autach daleko przed Tobą, „Box, box” w połowie okrążenia i „302 sekundy do znalezienia”.
  Teraz okrążenie wzorcowe jest sprawdzane (czas rośnie wzdłuż toru, nigdzie ponad 420 km/h); uszkodzone jest
  odkładane (best_lap_uszkodzone.json) razem z zakrętami, a czasy dojazdu mają zabezpieczenie.
- „Wolne auto”: nie ostrzega o autach zjeżdżających do boksu ani o autach w wolnym zakręcie (szykana Forda) –
  wolne to dopiero poniżej 55% typowej prędkości w tym miejscu.
- Koniec wyścigu: brak „zjedź na tym okrążeniu”, gdy energii starczy do mety (wcześniej zapas +0,2 okrążenia),
  i żadnych komunikatów o postoju po fladze w szachownicę („Box, box”, „Nie było zjazdu”).
- Przelicznik paliwa: komunikat tylko gdy paliwa naprawdę starczy na nie więcej okrążeń niż energii, z liczbami
  („Paliwa starczy na 2,0 okrążenia, energii na 1,9…”). Wcześniej mówił „paliwo skończy się przed energią”,
  gdy paliwa było więcej.
- „Pięć hypercarów” (zamiast „pięć hypercary”).
- AI: modele aut w danych („Jakim autem jedzie Light?”); do AI trafiają też pytania z nazwiskiem rywala
  („Czy Mateo był w boksie?”), o grill i chłodzenie, „jakie muszę mieć zużycie, żeby…”.
- Ściana boksów: lider klasy Hypercar na mapie toru (złota obwódka i „1”).
- Dziennik przycięć: bez „System Idle Process” na liście programów.

## 3.9.0 (22.10.2026)
- Link dla obserwatorów: gdy nie ma wyścigu, pokazuje trening / kwalifikacje kierowcy, który jedzie (wcześniej
  stary wyścig). Gdy nikt nie jedzie od 3 minut – „brak wyścigu na żywo · ostatnio …” zamiast starych danych.

## 3.8.9 (22.10.2026)
- Szybsze odpowiedzi głosem: długie pierwsze zdanie zaczyna się krótkim fragmentem (do pierwszego przecinka),
  a kolejne zdania są przygotowywane od razu równolegle, nie dopiero w trakcie mówienia poprzedniego.
- „Radiotest” (pisane łącznie przez rozpoznawanie mowy) rozpoznawany jako test radia.
- Dziennik: czas przygotowania każdego zdania (synteza głosu).

## 3.8.8 (22.10.2026)
- Dziennik przycięć: obciążenie karty graficznej (3D %, maksimum z 5 s, zajęta pamięć karty i które programy
  najbardziej ją używają) przy każdym zdarzeniu i w podsumowaniu co 5 minut – z liczników Windows, bez instalacji.

## 3.8.7 (22.10.2026)
- Wymowa: „hajperkar” zamiast angielskiego „hypercar” (w mowie; na ekranie bez zmian).

## 3.8.6 (22.10.2026)
- Dublowanie: brak ostrzeżenia „LMP 2, 1 sekunda” o aucie szybszej klasy, które stoi albo wlecze się na torze
  (wypadek, poza torem) i które właśnie minąłeś. Ostrzeżenie wraca, gdy to auto znów jedzie szybko i dojeżdża.

## 3.8.5 (22.10.2026)
- Poprawna odmiana liczb w mowie, także w odpowiedziach AI: „524 stopni” czytane jako „pięćset dwadzieścia cztery
  stopnie”, „od 3 do 5 okrążeń” jako „od trzech do pięciu”, „ponad 5 sekund” jako „ponad pięć”; zakresy „11-12”,
  skróty (ok., okr., km/h, %, pit stop) i nawiasy czytane naturalnie.
- AI: odpowiada dokładnie na pytanie, bez doklejanej rady „trzymaj tempo, obserwuj temperatury opon”;
  przy niezrozumiałym pytaniu prosi o powtórzenie zamiast zgadywać; zna liczbę okrążeń w stincie.
- Odpowiedzi bez wtrąceń „Hmm, dobra,”. „Uderzenie, mierzę stratę” raz zamiast dwa razy.
- „Temperatura toru?” – krótko: tor i powietrze (bez całej prognozy). Hamulce: „zużycie klocków jeszcze niewielkie”
  zamiast „zostało najmniej 100 procent”.
- Prędkość maksymalna rywala nie liczy okrążenia z postojem (wcześniej np. 201 km/h zamiast 280).
- Lepsze rozpoznawanie słów: zużycie, temperatura toru, prędkość maksymalna, flat spot.

## 3.8.4 (22.10.2026)
- Gdy nagranie z przycisku mówienia jest ciszą (mikrofon wyciszony na słuchawkach albo wybrany inny),
  inżynier mówi „Nie słyszę Cię. Sprawdź, czy mikrofon nie jest wyciszony.” zamiast odpowiadać na zmyślone
  przez rozpoznawanie mowy „Dziękuję.”.

## 3.8.3 (22.10.2026)
- Naprawione: błąd „[głos] WinError 32 – plik używany przez inny proces” przy zapisie gotowego komunikatu
  (gdy ten sam komunikat był właśnie odtwarzany) – teraz program po prostu używa gotowego pliku.

## 3.8.2 (22.10.2026)
- Naprawione: dwa inżyniery naraz (np. drugie uruchomienie aplikacji, gdy pierwsza działała w tle) – każdy komunikat
  było słychać podwójnie. Teraz działa tylko jedna aplikacja (drugie uruchomienie pokazuje okno już otwartej),
  a nowy inżynier zamyka poprzedniego, jeśli ten jeszcze działa.

## 3.8.1 (21.10.2026)
- Pełny dziennik diagnostyczny (tylko wersja testowa): nagrania wszystkiego, co mówi inżynier, i pytań kierowcy
  (recordings/glos_*/ ze spisem), pełne zapytania i odpowiedzi AI, stan auta co 2 s.

## 3.8.0 (21.10.2026)
- AI odpowiada na (prawie) wszystkie pytania o wyścig, także te, których program nie przewidział. Gdy Groq działa,
  każde pytanie (poza komendami: cisza, powtórz, zapamiętaj, przełączniki…) trafia do AI z pełnymi danymi,
  a odpowiedź programu AI dostaje jako pewne liczby. Gdy AI nie zdąży w ok. 4 s – inżynier mówi odpowiedź programu.
  Wyłączysz to w Zaawansowanych („AI odpowiada na wszystkie pytania”).
- AI widzi znacznie więcej: całą stawkę (pozycje, odstępy, najlepsze czasy, postoje, boks, kary), postoje rywali,
  szczegóły ostatnich 10 okrążeń (paliwo, energia, zużycie opon, wyjazdy, uderzenia, kierowca), flagi i kary,
  uszkodzenia, zużycie hamulców i prognozę pogody z gry.

## 3.7.7 (21.10.2026)
- Pytania wymagające analizy („jaka różnica vmax aut przede mną”, „porównaj…”, „dlaczego…”, „kto najszybszy…”,
  „o ile…”) – gdy Groq działa, odpowiada AI z pełnymi danymi, a odpowiedź programu dostaje jako pewne liczby.
  Gdy Groq nie odpowie, zostaje odpowiedź programu. Proste pytania („ile paliwa”) dalej od razu z programu.
- AI dostaje więcej danych: auta w klasie (4 przed, 4 za) z pozycją, odstępem, prędkością maksymalną, energią
  i ostatnim okrążeniem, najwyższą vmax w innych klasach i kiedy dojadą auta szybszej klasy.

## 3.7.6 (21.10.2026)
- Naprawione: zapytania do wewnętrznego interfejsu gry szły na „localhost” – Windows najpierw próbował IPv6
  i każde zapytanie czekało 1,5–2 s (część się nie udawała). Teraz 127.0.0.1, jak w menu gry: dane z gry
  (hamulce, energia rywali, menu boksu) są pewniejsze.
- Dziennik przycięć: przy każdym zdarzeniu także programy, które najbardziej zajmują procesor, i auta w promieniu
  150 m (sprawdzenie, czy przycina, gdy dojeżdża szybsze auto). Doinstaluje się mała biblioteka psutil.

## 3.7.5 (21.10.2026)
- Gdy do planowanej długości stintu brakuje energii (paliwa) tylko trochę (oszczędzanie do 3%), inżynier i ściana
  boksów trzymają się zjazdu z planu i podają cel zużycia, np. „za 10 okr. – wg planu zużycie max 9,07% / okr.”,
  zamiast skracać stint o okrążenie.

## 3.7.4 (21.10.2026)
- Zjazd do boksu bez dużego zapasu: inżynier wskazuje ostatnie okrążenie, na które starczy energii (paliwa),
  tak żeby przy wjeździe do boksu zostało cokolwiek (0,2% energii albo 0,3 l paliwa). Wcześniej zostawiał ok. 0,3
  okrążenia zapasu, przez co zjazd wypadał często o okrążenie za wcześnie.

## 3.7.3 (21.10.2026)
- Ściana boksów, „Rywale w klasie”: nowa kolumna „Energia” – energia wirtualna rywali i nasza w %,
  przy rywalu różnica do nas (np. „42% (+4)”).

## 3.7.2 (21.10.2026)
- „Porównaj temperatury opon i hamulców z tego okrążenia i 4. okrążenia po pitstopie” (także „… z poprzednim stintem”,
  „… z okrążeniem 12”): hamulce przód/tył i opony przód/tył teraz wobec wskazanego okrążenia oraz rada,
  czy przymknąć chłodzenie hamulców. Po zmianie chłodzenia na postoju to samo pytanie porówna z poprzednim stintem.

## 3.7.1 (21.10.2026)
- „Za ile pierwszy hypercar będzie dublował?” / „kiedy dogoni mnie LMP2?”: szacunek bez limitu czasu – pierwsze
  auto szybszej klasy, za ile dojedzie, ile jest za Tobą na torze, i następne (wcześniej tylko najbliższe 12 sekund).

## 3.7.0 (21.10.2026)
- Prędkość maksymalna innych aut: „jaka prędkość maksymalna innych aut?”, „ile ma na prostej auto przede mną / za mną?”,
  „vmax hypercarów?”, „moja prędkość maksymalna?”. Inżynier mierzy maksimum każdego auta na każdym okrążeniu
  i porównuje z Twoim („o 6 szybciej od Ciebie”).

## 3.6.9 (21.10.2026)
- Nowa komenda „jakie mam mieć TC?” / „traction control?” / „ile ABS?”: obecne ustawienie i rada z pomiaru
  (TC pracuje dużo → TC Cut niżej, buksowanie → TC wyżej, blokowanie → ABS wyżej). Działa też bez AI.
- Gdy inżynier nie zna odpowiedzi, a AI nie działa, mówi dlaczego (brak klucza Groq, zły klucz, limit albo
  brak internetu) zamiast samego „Nie zrozumiałem”.

## 3.6.8 (21.10.2026)
- Ściana boksów: dane nie znikają i nie przeskakują – automatyczny wybór podglądu trzyma się jednego
  (wyścig > ktoś jedzie > ktoś w sesji > aplikacja w menu) zamiast przełączać się na ostatnio zapisany.

## 3.6.7 (21.10.2026)
- „Cisza”, „cicho”, „bądź cicho”, „nie gadaj” (także bez imienia inżyniera) = „Ok.” i całkowita cisza, także bez
  ostrzeżeń o dublowaniu, aż do następnego naciśnięcia przycisku. Tryb „tylko pilne ostrzeżenia i odpowiedzi”
  włącza teraz komenda „tylko pilne” / „mów tylko, gdy pytam”.
- Krótkie potwierdzenia komend bez wtrąceń typu „Słuchaj, dobra, …”.

## 3.6.6 (21.10.2026)
- AI odpowiada też na pytania niezwiązane z wyścigiem (wiedza ogólna, historia, luźna rozmowa) zamiast
  „nie mam danych o bieżącym stanie wyścigu”. Liczby o aucie i wyścigu dalej tylko z danych gry.

## 3.6.5 (21.10.2026)
- Naprawione: przed wejściem do sesji połączenie z zespołem zgłaszało błąd „append .json to your request URI”
  (znak „?” w nazwie podglądu) i aplikacja nie odbierała wiadomości ani pytań ze ściany boksów.
- Pytania i wiadomości ze ściany boksów działają też poza wyścigiem (trening, garaż, menu) – odpowiada aplikacja
  osoby, której podgląd jest wybrany na ścianie. W wyścigu jak dotąd odpowiada inżynier kierowcy, który jedzie.

## 3.6.4 (21.10.2026)
- Ściana boksów: mapa toru na samym dole, większa i bez pustego miejsca – tor obraca się dłuższą osią wzdłuż ekranu
  (na komputerze poziomo, na telefonie pionowo).
- Zakładka Zespół: podpisany „Link dla widzów”.
- Poprawione opisy: pytania spoza reguł trafiają do AI Groq, odpowiedzi ze ściany słychać w radiu zespołu.

## 3.6.3 (21.10.2026)
- Po aktualizacji (automatycznej albo ręcznej) aplikacja pokazuje okno „Co nowego” ze wszystkimi zmianami
  od Twojej poprzedniej wersji – także gdy kilka wersji zostało pominiętych. Lista jest też w Pomoc → Co nowego.

## 3.6.2 (21.10.2026)
- Komenda „powiadomienie na telefon <imię>: <treść>” – kolega od razu dostaje powiadomienie ntfy, np.
  „Powiadomienie na telefon Amadeusz: wstawaj, zaraz wsiadasz”. Działa też „powiadom Amadeusza, że …”,
  „wyślij Patrykowi powiadomienie: …” i „powiadomienie dla wszystkich: …”. Inżynier potwierdza, komu wysłał.

## 3.6.1 (21.10.2026)
- Odprawa przy zmianie kierowcy mówi też, ile wyjazdów poza tor i uderzeń miał poprzedni kierowca i czy auto zjechało uszkodzone.
- Nowa komenda „powiedz następnemu, że …” (też „przekaż zmiennikowi …”, „notatka dla następnego kierowcy …”):
  inżynier przeczyta ją następnemu kierowcy na odprawie, np. „Odprawa od Patryka: Notatka dla Ciebie: uważajcie na T5 podczas dublowania przez hypercary.”

## 3.6.0 (21.10.2026)
- Ściana boksów, „Grafik i plan”: prostsze ustawienia wyścigu (start, długość, czas okrążenia jako 3:58), strategia schowana;
  „Szybki plan” rozpisuje cały wyścig sam (okrążeń w stincie, kierowcy po kolei, podwójne stinty, opony co ile stintów).
- Powiadomienia na telefon dla nowych osób: temat tworzy się sam, przycisk 📱 przy kierowcy pokazuje 3 kroki i kod QR.
- Nowa zakładka „Pomoc” na ścianie boksów: pierwsze kroki, powiadomienia, grafik.

## 3.5.2 (21.10.2026)
- Każdy kierowca może mieć własny klucz Groq (Zaawansowane → Własny klucz Groq) = własny limit. Ma pierwszeństwo,
  a po wyczerpaniu limitu program sam przechodzi na klucz zespołu ze ściany boksów.

## 3.5.1 (21.10.2026)
- Groq: aktualne darmowe modele (gpt-oss-120b, Qwen, gpt-oss-20b…). Gdy jeden model wyczerpie dzienny limit,
  AI przechodzi na następny (każdy ma osobny limit) – więcej pytań dziennie.

## 3.5.0 (21.10.2026)
- AI w chmurze Groq (darmowe): rozpoznawanie mowy (Whisper) i odpowiedzi AI prosto z programu kierowcy – bez serwera AI
  i bez obciążania komputera gracza, szybciej niż przez serwer. Klucz wkleja się raz na ścianie boksów (Zespół → AI zespołu).
  Gdy Groq nie odpowiada: serwer AI zespołu (jeśli działa), potem Google.
- Radio zespołu zamiast bota Discord: kto nie jedzie, słyszy komunikaty inżyniera we własnej aplikacji (tym samym głosem);
  pilne ostrzeżenia słyszy tylko kierowca. Na ścianie boksów „🔊 Słuchaj inżyniera” (głos przeglądarki, też na telefonie).
- Grafik i powiadomienia liczy jedna z włączonych aplikacji zespołu – serwer AI nie jest potrzebny nawet przed startem.
- Bot Discord i serwer AI zostają jako opcja (domyślnie wyłączone).
- Na pulpicie tylko jeden skrót „Pit Wall Crew” (test bez gry i ustawienia są w aplikacji).

## 3.4.0 (21.10.2026)
- Automatyczne aktualizacje: aplikacja przy starcie (zanim uruchomi inżyniera, nigdy w trakcie jazdy) sprawdza nową wersję
  na stronie ściany boksów, pobiera ją, sprawdza sumę kontrolną, podmienia pliki i uruchamia się ponownie. Ustawienia,
  dane i nagrania zostają, poprzednie pliki w folderze backup. Serwer AI aktualizuje się przy uruchomieniu.
  Wyłączenie i „Sprawdź aktualizacje teraz”: Zaawansowane.

## 3.3.0 (21.10.2026)
- Aplikacja: nowe strony w sekcji „Pomoc” – Komendy (wszystkie komendy głosowe i z Discorda), Co potrafi, Instrukcja.
- W mikserze głośności Windows inżynier widnieje jako „Pit Wall Crew” z ikoną (zamiast „Python”).

## 3.2.2 (21.10.2026)
- Ściana boksów pobiera tylko zmienione dane auta (zapis różnicowy, pełny co 60 s) – mniej transferu dla każdego
  oglądającego i obserwatora; ukryta karta w telefonie nic nie rysuje (bateria).
- Baza sama sprząta stare wyniki zadań i nieodebrane wiadomości.
- Strona „Ostrzeżenia” w aplikacji: podział na pilne i podpowiedzi, przy każdej opcji komenda głosowa.

## 3.2.1 (21.10.2026)
- Porównanie w zakrętach (i trener) uczciwe dla zużytych opon: wzorcem jest najszybsze okrążenie z podobnym zużyciem
  opon, paliwem, wilgotnością i temperaturą toru. Gdy takiego nie ma – najlepsze z tego stintu i tylko uwagi o technice
  (punkt hamowania, gaz), bez „wolniej w środku”. Bez porównań przy innych warunkach (deszcz, noc) i przy oszczędzaniu.
- Kilkakrotnie mniej transferu z Firebase (trwałe połączenia, zapisy bez odsyłania danych, kierowcy nie pobierają
  całego stanu auta) – więcej zespołów i obserwatorów zmieści się w darmowym planie.

## 3.2.0 (21.10.2026)
- Mapa toru na żywo na ścianie boksów (także u obserwatorów): kształt toru zbiera się sam z położenia aut w pierwszych
  minutach jazdy, potem kropki wszystkich aut (nasza klasa z numerami pozycji, my na czerwono, w alei półprzezroczyste).
  Przycisk „odbij”, gdyby tor wyglądał jak w lustrze.
- Imię i styl inżyniera (Głos → Imię inżyniera, Styl: profesjonalista, kumpel, twardziel, analityk). Inżynier
  przedstawia się na początku jazdy, „<imię>, cicho” działa jak „inżynier, cicho”.
- Komentarz po wyprzedzeniu albo stracie pozycji w klasie – dopiero gdy pozycja utrzyma się 30 s, bez zmian przez
  postoje, najwyżej raz na 45 s (np. „Dobra robota, P4. Moreau 0,8 s za Tobą.”). Głosem: „komentarze” / „bez komentarzy”.
- Porównanie z najlepszym okrążeniem przed zakrętem: „T5: hamujesz 15 metrów wcześniej niż na najlepszym.”
  Raz na okrążenie, ten sam zakręt coraz rzadziej. Głosem: „porównanie” / „bez porównania”.

## 3.1.1 (21.10.2026)
- Nowe logo bez białej obwódki (okno, skróty na pulpicie, ściana boksów).
- Aplikacja sama tworzy skróty „Pit Wall Crew” z ikoną na pulpicie po aktualizacji.

## 3.1.0 (21.10.2026)
- Aplikacja zamiast czarnej konsoli: jedno ciemne okno w stylu Windows 11. Strona „Inżynier” pokazuje stan
  (inżynier, gra, zespół, serwer AI), pozycję, okrążenie, zjazd, energię/paliwo, czasy i czas do mety, kolorowe komunikaty
  (czerwone = pilne, żółte = zespół, niebieskie = Ty) i pole do pytań. Ustawienia w pasku po lewej,
  „Zapisz i uruchom ponownie” restartuje inżyniera bez zamykania okna. „Test bez gry” jednym przyciskiem.
- Nowy wygląd ściany boksów (czcionki, karty, tabele, telefon).

## 3.0.0 (21.10.2026)
- Nowa nazwa: **Pit Wall Crew** (okna, skróty, paczki). Folder instalacji bez zmian.
- Ściana boksów przeniesiona z arkusza Google do Firebase (darmowy plan): strona https://zepansrpl-creator.github.io/Pit-Wall-Crew/,
  zmiany widać od razu, bez limitów Apps Script.
- Zespół = **kod + hasło** (zamiast adresu i klucza). Każdy może założyć własny zespół – na stronie albo w oknie ustawień
  („Utwórz nowy zespół…”). Kod QR i link dla zespołu, osobny link tylko do oglądania dla obserwatorów.
- Na stronie: plan stintów i ustawienia wyścigu (z wklejaniem planu ze starego arkusza), kierowcy i tematy ntfy z przyciskiem Test,
  okrążenia (z pobieraniem CSV), pamięć zespołu.
- Grafik i powiadomienia ntfy przelicza program kierowcy, który jedzie (przed startem – serwer AI zespołu).
- Po aktualizacji: w oknie ustawień, zakładka Zespół, wpisz kod i hasło zespołu i zapisz.

## 2.2.1 (21.10.2026)
- Poprawki wewnętrzne.

## 2.2.0 (21.10.2026)
- Trener na zakręty: krótka podpowiedź 2–3 s przed zakrętem, w którym błąd powtarza się na 2 z 3 okrążeń
  (blokowanie, buksowanie, ABS/TC, wcześniejsze hamowanie, mała prędkość w środku, późny gaz, toczenie),
  potem „T5 lepiej.”; komendy „trener” / „bez trenera”.
- Pogoda: „Tor przesycha. Slicki będą szybsze za około X minut.” (też w odpowiedzi o pogodę).
- Trening: rady camber (z różnicy temperatur krawędzi opon) i kanały hamulców (z temperatur tarcz), osobno przód i tył.
- Wyścig: rady ustawień tylko z kokpitu (balans hamulców, TC, ABS) albo technika – bez stabilizatorów i garażu.

## 2.1.2 (20.10.2026)
- Teksty bez imion naszego zespołu (program dla dowolnych kierowców); ściana boksów przyjmuje do 27 kierowców (wiersze D4:D30).

## 2.1.1 (20.10.2026)
- Okno ustawień od razu pobiera listę kierowców z arkusza (wcześniej dopiero po „Sprawdź połączenie”).

## 2.1.0 (20.10.2026)
- Okno ustawień (zamiast linii komend), otwiera się razem z inżynierem; „Zapisz i uruchom inżyniera”.
- Ikona z logo (okna i skróty; `skroty.bat`).
- Tryb solo: ostrzejszy ton, bez Discorda i zmian kierowców; ściana boksów zostaje.
- Naturalniejsza mowa („Słuchaj,”, „Dobra,”) – nigdy w szybkich i ważnych komunikatach.
- Rywale: tempo każdego kierowcy, kiedy dogoni / dogonisz, najszybszy i najwolniejszy w zespole, zmiana kierowcy u rywala, opony na ostatnim postoju; nowe kolumny na ścianie boksów.
- Przycisk mówienia na kierownicy czytany bez otwierania kierownicy (podejrzenie wysypywania LMU z kierownicą MOZA).
- „Opony w temperaturze” po zmianie na nowe (80°C).
- Oszczędzanie energii, odprawa przy zmianie kierowcy, ciśnienia w nocy, trzy TC w sugestiach, opony 12 s, dziennik przycięć (F9), „Inżynier, cicho”.
