# Zmiany w Pit Wall Crew

Numer wersji widać w oknie inżyniera, w tytule okna ustawień i na ścianie boksów (przy „jedzie: …”).

## 3.6.0 (21.10.2026)
- Ściana boksów, „Grafik i plan”: prostsze ustawienia wyścigu (start, długość, czas okrążenia jako 3:58), strategia schowana;
  „Szybki plan” rozpisuje cały wyścig sam (okrążeń w stincie, kierowcy po kolei, podwójne stinty, opony co ile stintów).
- Powiadomienia na telefon dla nowych osób: temat tworzy się sam, przycisk 📱 przy kierowcy pokazuje 3 kroki i kod QR.
- Nowa zakładka „Pomoc” na ścianie boksów: pierwsze kroki, powiadomienia, grafik.

## 3.5.2 (21.10.2026)
- Każdy kierowca może mieć własny klucz Groq (Zaawansowane → Własny klucz Groq) = własny limit. Ma pierwszeństwo,
  a po wyczerpaniu limitu program sam przechodzi na klucz zespołu ze ściany boksów.

## 3.5.1 (21.10.2026)
- Groq: aktualne darmowe modele (gpt-oss-120b, Qwen, gpt-oss-20b…). Gdy jeden model wyczerpie dzienny limit,
  AI przechodzi na następny (każdy ma osobny limit) – więcej pytań dziennie.

## 3.5.0 (21.10.2026)
- AI w chmurze Groq (darmowe): rozpoznawanie mowy (Whisper) i odpowiedzi AI prosto z programu kierowcy – bez serwera AI
  i bez obciążania komputera gracza, szybciej niż przez serwer. Klucz wkleja się raz na ścianie boksów (Zespół → AI zespołu).
  Gdy Groq nie odpowiada: serwer AI zespołu (jeśli działa), potem Google.
- Radio zespołu zamiast bota Discord: kto nie jedzie, słyszy komunikaty inżyniera we własnej aplikacji (tym samym głosem);
  pilne ostrzeżenia słyszy tylko kierowca. Na ścianie boksów „🔊 Słuchaj inżyniera” (głos przeglądarki, też na telefonie).
- Grafik i powiadomienia liczy jedna z włączonych aplikacji zespołu – serwer AI nie jest potrzebny nawet przed startem.
- Bot Discord i serwer AI zostają jako opcja (domyślnie wyłączone).
- Na pulpicie tylko jeden skrót „Pit Wall Crew” (test bez gry i ustawienia są w aplikacji).

## 3.4.0 (21.10.2026)
- Automatyczne aktualizacje: aplikacja przy starcie (zanim uruchomi inżyniera, nigdy w trakcie jazdy) sprawdza nową wersję
  na stronie ściany boksów, pobiera ją, sprawdza sumę kontrolną, podmienia pliki i uruchamia się ponownie. Ustawienia,
  dane i nagrania zostają, poprzednie pliki w folderze backup. Serwer AI aktualizuje się przy uruchomieniu.
  Wyłączenie i „Sprawdź aktualizacje teraz”: Zaawansowane.

## 3.3.0 (21.10.2026)
- Aplikacja: nowe strony w sekcji „Pomoc” – Komendy (wszystkie komendy głosowe i z Discorda), Co potrafi, Instrukcja.
- W mikserze głośności Windows inżynier widnieje jako „Pit Wall Crew” z ikoną (zamiast „Python”).

## 3.2.2 (21.10.2026)
- Ściana boksów pobiera tylko zmienione dane auta (zapis różnicowy, pełny co 60 s) – mniej transferu dla każdego
  oglądającego i obserwatora; ukryta karta w telefonie nic nie rysuje (bateria).
- Baza sama sprząta stare wyniki zadań i nieodebrane wiadomości.
- Strona „Ostrzeżenia” w aplikacji: podział na pilne i podpowiedzi, przy każdej opcji komenda głosowa.

## 3.2.1 (21.10.2026)
- Porównanie w zakrętach (i trener) uczciwe dla zużytych opon: wzorcem jest najszybsze okrążenie z podobnym zużyciem
  opon, paliwem, wilgotnością i temperaturą toru. Gdy takiego nie ma – najlepsze z tego stintu i tylko uwagi o technice
  (punkt hamowania, gaz), bez „wolniej w środku”. Bez porównań przy innych warunkach (deszcz, noc) i przy oszczędzaniu.
- Kilkakrotnie mniej transferu z Firebase (trwałe połączenia, zapisy bez odsyłania danych, kierowcy nie pobierają
  całego stanu auta) – więcej zespołów i obserwatorów zmieści się w darmowym planie.

## 3.2.0 (21.10.2026)
- Mapa toru na żywo na ścianie boksów (także u obserwatorów): kształt toru zbiera się sam z położenia aut w pierwszych
  minutach jazdy, potem kropki wszystkich aut (nasza klasa z numerami pozycji, my na czerwono, w alei półprzezroczyste).
  Przycisk „odbij”, gdyby tor wyglądał jak w lustrze.
- Imię i styl inżyniera (Głos → Imię inżyniera, Styl: profesjonalista, kumpel, twardziel, analityk). Inżynier
  przedstawia się na początku jazdy, „<imię>, cicho” działa jak „inżynier, cicho”.
- Komentarz po wyprzedzeniu albo stracie pozycji w klasie – dopiero gdy pozycja utrzyma się 30 s, bez zmian przez
  postoje, najwyżej raz na 45 s (np. „Dobra robota, P4. Moreau 0,8 s za Tobą.”). Głosem: „komentarze” / „bez komentarzy”.
- Porównanie z najlepszym okrążeniem przed zakrętem: „T5: hamujesz 15 metrów wcześniej niż na najlepszym.”
  Raz na okrążenie, ten sam zakręt coraz rzadziej. Głosem: „porównanie” / „bez porównania”.

## 3.1.1 (21.10.2026)
- Nowe logo bez białej obwódki (okno, skróty na pulpicie, ściana boksów).
- Aplikacja sama tworzy skróty „Pit Wall Crew” z ikoną na pulpicie po aktualizacji.

## 3.1.0 (21.10.2026)
- Aplikacja zamiast czarnej konsoli: jedno ciemne okno w stylu Windows 11. Strona „Inżynier” pokazuje stan
  (inżynier, gra, zespół, serwer AI), pozycję, okrążenie, zjazd, energię/paliwo, czasy i czas do mety, kolorowe komunikaty
  (czerwone = pilne, żółte = zespół, niebieskie = Ty) i pole do pytań. Ustawienia w pasku po lewej,
  „Zapisz i uruchom ponownie” restartuje inżyniera bez zamykania okna. „Test bez gry” jednym przyciskiem.
- Nowy wygląd ściany boksów (czcionki, karty, tabele, telefon).

## 3.0.0 (21.10.2026)
- Nowa nazwa: **Pit Wall Crew** (okna, skróty, paczki). Folder instalacji bez zmian.
- Ściana boksów przeniesiona z arkusza Google do Firebase (darmowy plan): strona https://zepansrpl-creator.github.io/Pit-Wall-Crew/,
  zmiany widać od razu, bez limitów Apps Script.
- Zespół = **kod + hasło** (zamiast adresu i klucza). Każdy może założyć własny zespół – na stronie albo w oknie ustawień
  („Utwórz nowy zespół…”). Kod QR i link dla zespołu, osobny link tylko do oglądania dla obserwatorów.
- Na stronie: plan stintów i ustawienia wyścigu (z wklejaniem planu ze starego arkusza), kierowcy i tematy ntfy z przyciskiem Test,
  okrążenia (z pobieraniem CSV), pamięć zespołu.
- Grafik i powiadomienia ntfy przelicza program kierowcy, który jedzie (przed startem – serwer AI zespołu).
- Po aktualizacji: w oknie ustawień, zakładka Zespół, wpisz kod i hasło zespołu i zapisz.

## 2.2.1 (21.10.2026)
- Poprawki wewnętrzne.

## 2.2.0 (21.10.2026)
- Trener na zakręty: krótka podpowiedź 2–3 s przed zakrętem, w którym błąd powtarza się na 2 z 3 okrążeń
  (blokowanie, buksowanie, ABS/TC, wcześniejsze hamowanie, mała prędkość w środku, późny gaz, toczenie),
  potem „T5 lepiej.”; komendy „trener” / „bez trenera”.
- Pogoda: „Tor przesycha. Slicki będą szybsze za około X minut.” (też w odpowiedzi o pogodę).
- Trening: rady camber (z różnicy temperatur krawędzi opon) i kanały hamulców (z temperatur tarcz), osobno przód i tył.
- Wyścig: rady ustawień tylko z kokpitu (balans hamulców, TC, ABS) albo technika – bez stabilizatorów i garażu.

## 2.1.2 (20.10.2026)
- Teksty bez imion naszego zespołu (program dla dowolnych kierowców); ściana boksów przyjmuje do 27 kierowców (wiersze D4:D30).

## 2.1.1 (20.10.2026)
- Okno ustawień od razu pobiera listę kierowców z arkusza (wcześniej dopiero po „Sprawdź połączenie”).

## 2.1.0 (20.10.2026)
- Okno ustawień (zamiast linii komend), otwiera się razem z inżynierem; „Zapisz i uruchom inżyniera”.
- Ikona z logo (okna i skróty; `skroty.bat`).
- Tryb solo: ostrzejszy ton, bez Discorda i zmian kierowców; ściana boksów zostaje.
- Naturalniejsza mowa („Słuchaj,”, „Dobra,”) – nigdy w szybkich i ważnych komunikatach.
- Rywale: tempo każdego kierowcy, kiedy dogoni / dogonisz, najszybszy i najwolniejszy w zespole, zmiana kierowcy u rywala, opony na ostatnim postoju; nowe kolumny na ścianie boksów.
- Przycisk mówienia na kierownicy czytany bez otwierania kierownicy (podejrzenie wysypywania LMU z kierownicą MOZA).
- „Opony w temperaturze” po zmianie na nowe (80°C).
- Oszczędzanie energii, odprawa przy zmianie kierowcy, ciśnienia w nocy, trzy TC w sugestiach, opony 12 s, dziennik przycięć (F9), „Inżynier, cicho”.
