@echo off
chcp 65001 >nul
cd /d "%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -File "tools\skroty.ps1"
echo Skroty z ikona sa na pulpicie.
pause
