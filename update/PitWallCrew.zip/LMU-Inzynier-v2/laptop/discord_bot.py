"""Bot Discord: mówi głosem inżyniera na kanale głosowym zespołu i przyjmuje komendy tekstowe.

Komendy na kanale tekstowym (domyślnie każdy kanał, na którym bot widzi wiadomości):
  !i <pytanie>      – pytanie do inżyniera (odpowiedź głosem na kanale głosowym), np. „!i ile paliwa”
  !w <wiadomość>    – wiadomość do kierowcy (inżynier przeczyta ją przez radio)
  !stan             – krótki stan auta tekstem
"""

from __future__ import annotations

import asyncio
import io
import threading
from typing import Callable, Optional


class DiscordBot:
    def __init__(self, token: str, voice_channel: str, text_channel: str = "", guild: str = "",
                 on_ask: Optional[Callable[[str, str], None]] = None,
                 on_msg: Optional[Callable[[str, str], None]] = None,
                 on_status: Optional[Callable[[], str]] = None,
                 on_note: Optional[Callable[[str, str], None]] = None) -> None:
        self.on_note = on_note
        self.token = token.strip()
        self.voice_channel = voice_channel.strip()
        self.text_channel = text_channel.strip().lstrip("#")
        self.guild = guild.strip()
        self.on_ask, self.on_msg, self.on_status = on_ask, on_msg, on_status
        self.loop: Optional[asyncio.AbstractEventLoop] = None
        self.client = None
        self.vc = None
        self.queue: Optional[asyncio.Queue] = None
        self.status = "uruchamiam"

    @property
    def ready(self) -> bool:
        return self.vc is not None and self.vc.is_connected()

    def start(self) -> None:
        threading.Thread(target=self._run, daemon=True).start()

    def say_pcm(self, pcm: bytes) -> bool:
        """Kolejkuje dźwięk (PCM 48 kHz stereo s16le) do odtworzenia na kanale głosowym."""
        if self.loop is None or self.queue is None:
            return False
        asyncio.run_coroutine_threadsafe(self.queue.put(pcm), self.loop)
        return True

    # ------------------------------------------------------------------ wnętrze
    def _run(self) -> None:
        import discord
        intents = discord.Intents.default()
        intents.message_content = True
        intents.voice_states = True
        client = discord.Client(intents=intents)
        self.client = client
        self.loop = asyncio.new_event_loop()
        asyncio.set_event_loop(self.loop)
        self.queue = asyncio.Queue()

        def find_voice():
            for g in client.guilds:
                if self.guild and self.guild.lower() not in g.name.lower():
                    continue
                for ch in g.voice_channels:
                    if ch.name.lower() == self.voice_channel.lower() or str(ch.id) == self.voice_channel:
                        return ch
            return None

        async def connect():
            while True:
                if not self.ready:
                    ch = find_voice()
                    if ch is None:
                        self.status = f"nie widzę kanału głosowego „{self.voice_channel}”"
                    else:
                        try:
                            if self.vc is not None:
                                await self.vc.disconnect(force=True)
                            self.vc = await ch.connect(reconnect=True, self_deaf=True)
                            self.status = f"na kanale {ch.name}"
                            print(f"[discord] Połączony z kanałem głosowym {ch.name}.")
                        except Exception as e:
                            self.status = f"błąd połączenia głosowego: {e}"
                            print(f"[discord] {self.status}")
                await asyncio.sleep(20)

        async def player():
            while True:
                pcm = await self.queue.get()
                for _ in range(40):
                    if self.ready:
                        break
                    await asyncio.sleep(0.25)
                if not self.ready:
                    continue
                done = asyncio.Event()
                src = discord.PCMAudio(io.BytesIO(pcm))
                try:
                    self.vc.play(src, after=lambda e: self.loop.call_soon_threadsafe(done.set))
                    await done.wait()
                except Exception as e:
                    print(f"[discord] odtwarzanie: {e}")

        started = {"done": False}

        @client.event
        async def on_ready():
            print(f"[discord] Bot zalogowany jako {client.user}.")
            if not started["done"]:  # on_ready przychodzi też po każdym ponownym połączeniu
                started["done"] = True
                asyncio.get_running_loop().create_task(connect())
                asyncio.get_running_loop().create_task(player())

        @client.event
        async def on_message(message):
            if message.author.bot:
                return
            if self.text_channel and message.channel.name.lower() != self.text_channel.lower():
                return
            text = message.content.strip()
            who = message.author.display_name
            low = text.lower()
            try:
                if low.startswith(("!i ", "!inż ", "!inz ", "!inżynier ", "!inzynier ")):
                    q = text.split(" ", 1)[1].strip()
                    if self.on_ask:
                        await asyncio.to_thread(self.on_ask, who, q)
                    await message.add_reaction("📻")
                elif low.startswith(("!w ", "!wiadomość ", "!wiadomosc ")):
                    m = text.split(" ", 1)[1].strip()
                    if self.on_msg:
                        await asyncio.to_thread(self.on_msg, who, m)
                    await message.add_reaction("✅")
                elif low.startswith(("!z ", "!zapamiętaj ", "!zapamietaj ", "!notatka ")):
                    m = text.split(" ", 1)[1].strip()
                    if self.on_note:
                        await asyncio.to_thread(self.on_note, who, m)
                    await message.add_reaction("📝")
                elif low in ("!stan", "!status"):
                    txt = await asyncio.to_thread(self.on_status) if self.on_status else "brak danych"
                    await message.channel.send(txt[:1900])
                elif low in ("!pomoc", "!help"):
                    await message.channel.send("`!i pytanie` – pytanie do inżyniera (odpowiedź głosem), "
                                               "`!w tekst` – wiadomość do kierowcy, `!z tekst` – notatka do pamięci zespołu, `!stan` – stan auta.")
            except Exception as e:
                await message.channel.send(f"Błąd: {e}")

        try:
            self.loop.run_until_complete(client.start(self.token))
        except Exception as e:
            self.status = f"bot nie wystartował: {e}"
            print(f"[discord] {self.status}")
