"""Rozpoznawanie mowy na laptopie: faster-whisper na karcie NVIDIA (duży model), awaryjnie na procesorze."""

from __future__ import annotations

import glob
import os
import site
import sys

from engineer.listen import VOCAB


def _cuda_dlls() -> None:
    """Biblioteki CUDA z pakietów pip (nvidia-cublas-cu12, nvidia-cudnn-cu12) muszą być widoczne dla Windows."""
    if sys.platform != "win32":
        return
    roots = site.getsitepackages() + [site.getusersitepackages()]
    for root in roots:
        for d in glob.glob(os.path.join(root, "nvidia", "*", "bin")):
            try:
                os.add_dll_directory(d)
            except OSError:
                pass
            os.environ["PATH"] = d + os.pathsep + os.environ.get("PATH", "")


class WhisperSTT:
    def __init__(self, model: str = "large-v3-turbo", device: str = "auto", cpu_model: str = "small") -> None:
        from faster_whisper import WhisperModel
        _cuda_dlls()
        self.model = None
        self.name = ""
        if device in ("auto", "cuda"):
            try:
                self.model = WhisperModel(model, device="cuda", compute_type="int8_float16")
                self._probe()
                self.name = f"Whisper {model} (karta graficzna)"
            except Exception as e:
                print(f"[mowa] Karta graficzna niedostępna dla Whisper ({e}); przechodzę na procesor.")
                self.model = None
        if self.model is None:
            self.model = WhisperModel(cpu_model, device="cpu", compute_type="int8", cpu_threads=8)
            self.name = f"Whisper {cpu_model} (procesor)"

    def _probe(self) -> None:
        import numpy as np
        list(self.model.transcribe(np.zeros(16000, dtype=np.float32), language="pl")[0])

    def transcribe(self, audio_int16, rate: int = 16000) -> str:
        import numpy as np
        pcm = audio_int16.astype(np.float32) / 32768.0
        if rate != 16000:
            from engineer.listen import _resample
            pcm = _resample(pcm, rate, 16000).astype(np.float32)
        segments, _ = self.model.transcribe(pcm, language="pl", initial_prompt=VOCAB, beam_size=5,
                                            vad_filter=True, condition_on_previous_text=False)
        return " ".join(s.text.strip() for s in segments).strip()
