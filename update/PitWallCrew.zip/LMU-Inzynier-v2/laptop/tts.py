"""Głos inżyniera na Discordzie: edge-tts (polski głos) + poprawne liczby + efekt radia -> PCM 48 kHz stereo."""

from __future__ import annotations

import asyncio
import os
import tempfile

import numpy as np

from engineer import radio
from engineer.plnum import speak

DISCORD_RATE = 48000


def _decode_mp3(path: str) -> np.ndarray:
    """Dekodowanie mp3 przez pygame (bez ffmpeg). Zwraca mono float -1..1 w 48 kHz."""
    os.environ.setdefault("SDL_AUDIODRIVER", "dummy")
    import pygame
    if not pygame.mixer.get_init():
        pygame.mixer.init(frequency=DISCORD_RATE, size=-16, channels=1)
    freq, _, ch = pygame.mixer.get_init()
    arr = pygame.sndarray.array(pygame.mixer.Sound(path)).astype(np.float64)
    if arr.ndim > 1:
        arr = arr.mean(axis=1)
    x = arr / 32768.0
    if freq != DISCORD_RATE:
        n = int(len(x) * DISCORD_RATE / freq)
        x = np.interp(np.arange(n) * freq / DISCORD_RATE, np.arange(len(x)), x)
    return x


class TTS:
    def __init__(self, voice: str = "pl-PL-MarekNeural", rate: str = "+10%", pitch: str = "+0Hz",
                 radio_on: bool = True, radio_strength: float = 1.0, music: str = "", music_volume: float = 0.18,
                 volume: float = 0.9) -> None:
        self.voice, self.rate, self.pitch = voice, rate, pitch
        self.radio_on, self.radio_strength = radio_on, radio_strength
        self.music, self.music_volume, self.volume = music, music_volume, volume
        self._loop = None

    def pcm(self, text: str) -> bytes:
        """Tekst -> surowe PCM s16le 48 kHz stereo (format Discorda)."""
        import edge_tts
        spoken = speak(text)
        fd, path = tempfile.mkstemp(suffix=".mp3")
        os.close(fd)
        try:
            asyncio.run(edge_tts.Communicate(spoken, self.voice, rate=self.rate, pitch=self.pitch).save(path))
            x = _decode_mp3(path)
        finally:
            try:
                os.remove(path)
            except OSError:
                pass
        if self.music:
            from engineer import music as mus
            loop = mus.load(self.music, DISCORD_RATE, "cache")
            if loop is not None:
                x = mus.mix(x, DISCORD_RATE, loop, self.music_volume, key=hash(text) & 0xFFFF)
        if self.radio_on:
            x = radio.apply(x, DISCORD_RATE, self.radio_strength)
        x = np.clip(x * self.volume, -1, 1)
        mono = (x * 32767).astype("<i2")
        return np.repeat(mono[:, None], 2, axis=1).tobytes()
