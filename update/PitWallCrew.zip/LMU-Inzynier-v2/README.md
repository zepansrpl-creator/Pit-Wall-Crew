# Pit Wall Crew

Polski inżynier wyścigowy dla Le Mans Ultimate + ściana boksów dla zespołu w wyścigu długodystansowym.

- **Program kierowcy** (`kierowca.py`, skrót „Pit Wall Crew”): telemetria LMU, ostrzeżenia, strategia, okrążenie zjazdowe
  i „box, box”, komunikaty tylko o zmianach, odpowiedzi na pytania. Bez AI na komputerze z grą.
- **Ściana boksów** (`web/index.html`, GitHub Pages + Firebase Realtime Database): strona na telefon – stan auta, odstępy,
  grafik stintów przeliczany na żywo, plan, powiadomienia ntfy przed zmianą, wiadomości do kierowcy, okrążenia, pamięć zespołu.
  Zespół = kod + hasło (konto Firebase `<kod>@pitwallcrew.team`). Reguły bazy: `web/database.rules.json`.
  Budowanie strony z konfiguracją: `python tools/build_web.py`.
- **Serwer AI zespołu** (`serwer.py`): rozpoznawanie mowy Whisper, AI (Bielik w Ollamie), bot Discord mówiący
  głosem inżyniera na kanale zespołu.

Instalacja i obsługa krok po kroku: **INSTRUKCJA.md**.

Testy (bez gry i bez internetu):

```
python tests/test_demo.py          # inżynier na symulowanym wyścigu
python tests/test_analysis.py      # deszcz, zmęczenie, odczyt liczb po polsku
python tests/test_team.py          # cały zespół: centrum testowe + serwer AI + kierowca
python tests/test_firebase.py      # Firebase na atrapie bazy: grafik, powiadomienia, wiadomości, serwer AI
```
