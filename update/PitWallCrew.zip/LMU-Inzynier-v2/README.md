# Pit Wall Crew

Polski inżynier wyścigowy dla Le Mans Ultimate + ściana boksów dla zespołu w wyścigu długodystansowym.

- **Program kierowcy** (`kierowca.py`, skrót „Pit Wall Crew”): telemetria LMU, ostrzeżenia, strategia, okrążenie zjazdowe
  i „box, box”, komunikaty tylko o zmianach, odpowiedzi na pytania. Bez AI na komputerze z grą.
- **Ściana boksów** (`web/index.html`, GitHub Pages + Firebase Realtime Database): strona na telefon – stan auta, odstępy,
  grafik stintów przeliczany na żywo, plan, powiadomienia ntfy przed zmianą, wiadomości do kierowcy, okrążenia, pamięć zespołu.
  Zespół = kod + hasło (konto Firebase `<kod>@pitwallcrew.team`). Reguły bazy: `web/database.rules.json`.
  Budowanie strony z konfiguracją: `python tools/build_web.py`.
- **AI i rozpoznawanie mowy**: Groq (darmowa chmura, klucz zespołu na ścianie boksów); radio zespołu w aplikacji
  każdego z Was – bez serwera i bez bota.

Instalacja i obsługa krok po kroku: **INSTRUKCJA.md**.

Testy (bez gry i bez internetu):

```
python tests/test_demo.py          # inżynier na symulowanym wyścigu
python tests/test_analysis.py      # deszcz, zmęczenie, odczyt liczb po polsku
python tests/test_firebase.py      # Firebase na atrapie bazy: grafik, powiadomienia, wiadomości, odprawa
```
