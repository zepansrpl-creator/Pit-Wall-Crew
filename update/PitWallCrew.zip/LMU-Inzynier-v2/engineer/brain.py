"""Wybór, kto odpowiada kierowcy: reguły (darmowe), lokalny model (Ollama) albo Claude (klucz API).

Tryby (config.toml -> [ai] mode):
- "free"   : tylko inżynier bez AI — zero kosztów, zero kluczy, działa offline
- "local"  : reguły + lokalny model na pytania, których reguły nie rozumieją
- "claude" : reguły + Claude (płatny klucz API)
"""

from __future__ import annotations

from typing import Callable, Optional

from . import setup_rules
from .intents import RuleEngineer

NOT_UNDERSTOOD = ("Nie zrozumiałem. Zapytaj o paliwo, energię, zjazd, czasy, zakręty, rywali, opony "
                  "albo powiedz, co czujesz w aucie.")


class Brain:
    def __init__(self, eng, cfg: dict) -> None:
        self.eng = eng
        self.rules = RuleEngineer(eng)
        self.mode = cfg.get("mode", "free")
        self.llm = None
        self.llm_name = ""
        if self.mode == "local":
            from .local_ai import DEFAULT_MODEL, OllamaEngineer
            llm = OllamaEngineer(model=cfg.get("local_model") or DEFAULT_MODEL,
                                 url=cfg.get("ollama_url", "http://localhost:11434"),
                                 use_gpu=cfg.get("local_gpu", True))
            llm.ensure_running()
            if llm.available():
                llm.warm_up()
                self.llm, self.llm_name = llm, f"lokalny model {llm.model}"
            else:
                print(f"[AI] Lokalny model niedostępny: {llm.status}. Działam bez AI.")
        elif self.mode == "claude":
            from .ai import AIEngineer
            llm = AIEngineer(model=cfg.get("model", "claude-haiku-5-5"), api_key=cfg.get("api_key") or None,
                             max_tokens=cfg.get("max_tokens", 300), setup_model=cfg.get("setup_model") or None)
            if llm.online:
                self.llm, self.llm_name = llm, f"Claude ({llm.model})"
            else:
                print("[AI] Brak klucza API Claude. Działam bez AI.")
        # "fallback": model tylko gdy reguły nie rozumieją; "all": model odpowiada na wszystko
        self.answer_with_llm = cfg.get("ai_answers", "all" if self.mode == "claude" else "fallback")

    def describe(self) -> str:
        if self.llm is None:
            return "inżynier bez AI (darmowy, offline)"
        return f"reguły + {self.llm_name}" + (" na wszystkie pytania" if self.answer_with_llm == "all" else
                                               " na pytania spoza reguł")

    def handle(self, text: str) -> tuple[Optional[str], Optional[Callable[[], str]]]:
        """Zwraca (odpowiedź od razu, None) albo (None, zadanie dla AI do wykonania w tle)."""
        rule = self.rules.answer(text)
        control = any(w in text.lower() for w in ("powtórz", "powtorz", "cisza", "zmieniłem", "zmienilem"))
        use_llm = self.llm is not None and not control and (rule is None or self.answer_with_llm == "all")
        if not use_llm:
            return rule or NOT_UNDERSTOOD, None

        setup = setup_rules.is_setup_question(text)
        state = self.eng.summary(setup=setup, question=text)
        llm = self.llm

        def job() -> str:
            try:
                a = llm.ask(text, state, setup=setup)
            except Exception:
                a = None
            if a and not a.startswith("Nie mam połączenia"):
                self.rules.last_answer = a
                return a
            return rule or NOT_UNDERSTOOD

        return None, job
