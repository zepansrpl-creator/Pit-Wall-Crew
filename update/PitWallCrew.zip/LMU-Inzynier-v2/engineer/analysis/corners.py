"""Wykrywanie zakrętów i porównanie okrążenia z referencją."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Optional

from .laps import BIN, LapTrace


@dataclass
class CornerDef:
    name: str
    apex: float     # m
    start: float    # m, początek odcinka porównania
    end: float      # m, koniec odcinka porównania


@dataclass
class CornerDelta:
    corner: CornerDef
    time_loss: float                 # s, dodatnie = strata
    brake_point_diff: Optional[float]  # m, ujemne = hamujesz wcześniej
    min_speed_diff: float            # km/h, ujemne = wolniej
    throttle_point_diff: Optional[float]  # m, dodatnie = pełny gaz później
    coast_diff: float                # m dłużej bez gazu i hamulca
    tc_more: int                     # ile binów więcej z TC
    reasons: list[str]
    gear: Optional[int] = None       # bieg w najwolniejszym miejscu (Ty)
    ref_gear: Optional[int] = None   # bieg w najwolniejszym miejscu (wzorzec)
    brake_peak_diff: float = 0.0     # różnica najmocniejszego hamowania (0..1), ujemne = hamujesz słabiej

    def describe(self) -> str:
        sign = "tracisz" if self.time_loss > 0 else "zyskujesz"
        txt = f"{self.corner.name}: {sign} {abs(self.time_loss):.2f} s"
        if self.reasons:
            txt += " (" + "; ".join(self.reasons) + ")"
        return txt


def _smooth(v: list[float], w: int = 3) -> list[float]:
    n = len(v)
    out = []
    for i in range(n):
        a, b = max(0, i - w), min(n, i + w + 1)
        out.append(sum(v[a:b]) / (b - a))
    return out


def detect_corners(ref: LapTrace, min_drop_kmh: float = 15.0) -> list[CornerDef]:
    """Zakręty = lokalne minima prędkości poprzedzone wyraźnym spadkiem."""
    sp = _smooth(ref.speed)
    n = len(sp)
    if n < 20:
        return []
    win = int(120 / BIN)
    look = int(500 / BIN)
    apexes = []
    for i in range(n):
        lo, hi = max(0, i - win), min(n, i + win + 1)
        if sp[i] > min(sp[lo:hi]) or sp[i] <= 0:
            continue
        if apexes and i - apexes[-1] < win:
            continue
        pre_max = max(sp[max(0, i - look):i + 1])
        post_max = max(sp[i:min(n, i + look)])
        if pre_max - sp[i] >= min_drop_kmh and post_max - sp[i] >= min_drop_kmh * 0.5:
            apexes.append(i)

    corners = []
    for k, a in enumerate(apexes):
        # początek: cofamy się do początku hamowania, a bez hamowania do lokalnego maksimum prędkości
        s = a
        limit = max(0, a - look)
        while s > limit and (ref.brake[s - 1] > 0.05 or sp[s - 1] >= sp[s]):
            s -= 1
        # koniec: pierwszy pełny gaz po wierzchołku
        e = a
        limit_e = min(n - 1, a + look)
        while e < limit_e and ref.throttle[e] < 0.95:
            e += 1
        s = max(0, s - int(40 / BIN))
        e = min(n - 1, e + int(80 / BIN))
        corners.append([s, a, e])

    # rozdziel nachodzące na siebie odcinki
    for k in range(1, len(corners)):
        if corners[k][0] <= corners[k - 1][2]:
            mid = (corners[k - 1][1] + corners[k][1]) // 2
            corners[k - 1][2] = mid
            corners[k][0] = mid + 1
    return [CornerDef(name=f"T{k + 1}", apex=a * BIN, start=s * BIN, end=e * BIN)
            for k, (s, a, e) in enumerate(corners)]


def _first(seq, start: int, end: int, pred) -> Optional[int]:
    for i in range(start, min(end, len(seq))):
        if pred(seq[i]):
            return i
    return None


def _metrics(lap: LapTrace, c: CornerDef) -> dict:
    s, a, e = int(c.start / BIN), int(c.apex / BIN), int(c.end / BIN)
    e = min(e, len(lap.speed) - 1)
    win_a = int(60 / BIN)
    seg_lo, seg_hi = max(s, a - win_a), min(e, a + win_a) + 1
    min_speed = min(lap.speed[seg_lo:seg_hi]) if seg_hi > seg_lo else lap.speed[a]
    min_idx = seg_lo + lap.speed[seg_lo:seg_hi].index(min_speed) if seg_hi > seg_lo else a
    brake_i = _first(lap.brake, s, min_idx + 1, lambda b: b > 0.15)
    throttle_i = _first(lap.throttle, min_idx, e + 1, lambda t: t >= 0.95)
    coast = sum(1 for i in range(s, e + 1) if lap.throttle[i] < 0.1 and lap.brake[i] < 0.05) * BIN
    tc = sum(lap.tc[s:e + 1]) if lap.tc else 0
    gear = lap.gear[min_idx] if lap.gear and min_idx < len(lap.gear) else None
    bp = max(lap.brake[s:min_idx + 1]) if lap.brake and min_idx >= s else 0.0
    return {
        "gear": gear,
        "brake_peak": bp,
        "time": lap.t[e] - lap.t[s],
        "brake": brake_i * BIN if brake_i is not None else None,
        "min_speed": min_speed,
        "throttle": throttle_i * BIN if throttle_i is not None else None,
        "coast": coast,
        "tc": tc,
    }


def compare(lap: LapTrace, ref: LapTrace, corners: list[CornerDef]) -> list[CornerDelta]:
    out = []
    if not lap.t or not ref.t or len(lap.t) != len(ref.t):
        return out
    for c in corners:
        m, r = _metrics(lap, c), _metrics(ref, c)
        loss = m["time"] - r["time"]
        bdiff = m["brake"] - r["brake"] if m["brake"] is not None and r["brake"] is not None else None
        tdiff = m["throttle"] - r["throttle"] if m["throttle"] is not None and r["throttle"] is not None else None
        sdiff = m["min_speed"] - r["min_speed"]
        cdiff = m["coast"] - r["coast"]
        reasons: list[tuple[float, str]] = []
        if bdiff is not None and bdiff <= -8:
            reasons.append((abs(bdiff) / 8, f"hamujesz {abs(bdiff):.0f} m wcześniej"))
        if bdiff is not None and bdiff >= 8 and sdiff < -2:
            reasons.append((bdiff / 8, f"hamujesz {bdiff:.0f} m później i przestrzeliwujesz wierzchołek"))
        if sdiff <= -3:
            reasons.append((abs(sdiff) / 3, f"minimalna prędkość niższa o {abs(sdiff):.0f} km/h"))
        if tdiff is not None and tdiff >= 10:
            reasons.append((tdiff / 10, f"pełny gaz {tdiff:.0f} m później"))
        if cdiff >= 15:
            reasons.append((cdiff / 15, f"{cdiff:.0f} m bez gazu i hamulca"))
        if m["tc"] - r["tc"] >= 4:
            reasons.append((1.0, "TC częściej tnie moc na wyjściu"))
        reasons.sort(key=lambda x: -x[0])
        out.append(CornerDelta(
            corner=c, time_loss=loss, brake_point_diff=bdiff, min_speed_diff=sdiff,
            throttle_point_diff=tdiff, coast_diff=cdiff, tc_more=m["tc"] - r["tc"],
            reasons=[txt for _, txt in reasons[:2]],
            gear=m["gear"], ref_gear=r["gear"], brake_peak_diff=m["brake_peak"] - r["brake_peak"],
        ))
    return out


def theoretical_best(laps: list[LapTrace], corners: list[CornerDef]) -> Optional[float]:
    """Suma najlepszych odcinków (zakręt + prosta za nim) z czystych okrążeń."""
    clean = [l for l in laps if l.clean and l.t]
    if not clean or not corners:
        return None
    n = len(clean[0].t)
    cuts = sorted({0} | {int(c.start / BIN) for c in corners} | {n - 1})
    total = 0.0
    clean = [l for l in clean if len(l.t) == n and l.plausible()]
    if not clean:
        return None
    for a, b in zip(cuts, cuts[1:]):
        segs = [l.t[b] - l.t[a] for l in clean if l.t[b] - l.t[a] > 0]
        if not segs:
            return None
        total += min(segs)
    # od ostatniego binu do linii mety
    total += min(l.lap_time - l.t[n - 1] for l in clean if len(l.t) == n)
    return total
