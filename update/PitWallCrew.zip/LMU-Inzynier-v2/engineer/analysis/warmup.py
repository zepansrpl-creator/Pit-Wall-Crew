"""Rozgrzewanie nowych opon po postoju: komunikat, gdy osiągną temperaturę roboczą.

Nowe opony = zużycie spadło na postoju. Po wyjeździe z alei sprawdzamy średnią temperaturę bieżnika
zmienionych opon; gdy wszystkie mają co najmniej 80°C (przez kilka sekund) – „Opony w temperaturze”.
Gdy po 4 minutach jazdy dalej są zimne (np. w nocy) – jedno ostrzeżenie.
"""

from __future__ import annotations

from typing import Optional

READY_C = 80.0        # temperatura robocza opon (średnia bieżnika), ustalona przez zespół
HOLD_S = 3.0          # tyle sekund musi się utrzymać
COLD_WARN_S = 240.0
DEFAULT_OPT = 85.0


def _opt_c(p) -> float:
    o = p.tyres[0].optimal_c if p.tyres else 0.0
    if o > 200:            # kelwiny
        o -= 273.15
    return o if 40 < o < 150 else DEFAULT_OPT


class TyreWarmup:
    def __init__(self) -> None:
        self.reset()

    def reset(self) -> None:
        self._prev: Optional[list[float]] = None
        self.pending: set[int] = set()
        self._drive_t = 0.0
        self._last_t: Optional[float] = None
        self._ok_since: Optional[float] = None
        self._cold_told = False

    def update(self, snap) -> Optional[str]:
        p = snap.player
        if p is None or len(p.tyres) != 4:
            return None
        wear = [t.wear for t in p.tyres]
        if self._prev is not None:
            fresh = {i for i in range(4) if self._prev[i] - wear[i] > 0.03}
            if fresh:
                self.pending, self._drive_t, self._ok_since, self._cold_told = fresh, 0.0, None, False
        self._prev = wear
        dt = 0.0 if self._last_t is None else max(0.0, min(1.0, snap.t - self._last_t))
        self._last_t = snap.t
        if not self.pending or p.in_pits or p.speed_kmh < 50:
            self._ok_since = None
            return None
        self._drive_t += dt
        temps = {i: sum(p.tyres[i].temp_c) / 3 for i in self.pending}
        if all(v >= READY_C for v in temps.values()):
            if self._ok_since is None:
                self._ok_since = self._drive_t
            elif self._drive_t - self._ok_since >= HOLD_S:
                self.pending = set()
                return "Opony w temperaturze, możesz cisnąć."
        else:
            self._ok_since = None
            if self._drive_t > COLD_WARN_S and not self._cold_told:
                self._cold_told = True
                return (f"Opony wciąż zimne, {min(temps.values()):.0f} stopni. "
                        "Ostrożnie na hamowaniach.")
        return None
