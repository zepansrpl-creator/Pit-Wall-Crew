"""Porównanie z kolegą z zespołu: jego najszybsze okrążenia w podobnych warunkach (baza zespołu).

Każdy kierowca po czystym okrążeniu wysyła do bazy zespołu przebieg okrążenia (co 5 m: czas, prędkość, gaz,
hamulec, bieg, TC), ale tylko gdy to jego najszybsze okrążenie w danym „koszyku” warunków: mieszanka, mokro/sucho,
zużycie opon (co 10%), paliwo (co 30 l), temperatura toru (co 5°C). Jedno okrążenie to ok. 15 KB.

Inżynier wybiera okrążenie kolegi w najbardziej podobnych warunkach (ta sama mieszanka, wilgotność ±8 pkt %,
temperatura toru ±5°C, zużycie opon ±12 pkt %, paliwo ±30 l) i porównuje zakręt po zakręcie:
gdzie kolega jest szybszy i co robi inaczej (hamuje później, ma większą prędkość w środku, wcześniej pełny gaz,
inny bieg, mocniej hamuje, krócej toczy się bez gazu).
"""

from __future__ import annotations

import base64
import json
import re
import threading
import time
import zlib
from typing import Callable, Optional

from .corners import CornerDef, CornerDelta, compare
from .laps import LapTrace

STRICT = {"wet": 0.08, "rain": 0.08, "temp": 5.0, "wear": 0.12, "fuel": 30.0}
LOOSE = {"wet": 0.12, "rain": 0.12, "temp": 9.0, "wear": 0.25, "fuel": 60.0}
MIN_GAIN = 0.12        # s – zakręt, w którym kolega jest szybszy, warto wymienić


def _fold(s: str) -> str:
    tr = str.maketrans("ąćęłńóśźżĄĆĘŁŃÓŚŹŻ", "acelnoszzACELNOSZZ")
    return (s or "").translate(tr).lower()


def key(s: str) -> str:
    """Bezpieczny klucz Firebase (bez . $ # [ ] /)."""
    return re.sub(r"[^A-Za-z0-9_-]+", "_", _fold(s)).strip("_")[:60] or "x"


def wear(l) -> Optional[float]:
    w = l.get("wear") if isinstance(l, dict) else (sum(l.wear_tyres) / len(l.wear_tyres) if l.wear_tyres else None)
    return w


def meta(lap: LapTrace) -> dict:
    return {"driver": lap.driver, "lap_time": round(lap.lap_time, 3), "lap": lap.lap, "car": lap.car,
            "track": lap.track, "compound": lap.compound or "", "wear": round(wear(lap), 3) if wear(lap) is not None else None,
            "fuel": round(lap.fuel_start or 0, 1), "ve": round(lap.ve_start, 3) if lap.ve_start is not None else None,
            "wet": round(lap.wetness, 3), "rain": round(lap.rain, 3), "temp": round(lap.track_temp or 0, 1),
            "stint_lap": lap.stint_lap, "n": len(lap.t), "len": lap.track_length, "t": int(time.time())}


def bucket(m: dict) -> str:
    w = m.get("wet") or 0
    wet = 0 if w < 0.1 else (1 if w < 0.4 else 2)
    wr = int((m.get("wear") or 0) * 10)
    return key(f"{m.get('compound') or 'x'}-{wet}-{wr}-{int((m.get('fuel') or 0) // 30)}-{int((m.get('temp') or 0) // 5)}")


def pack(lap: LapTrace) -> str:
    ms = [int(round(x * 1000)) for x in lap.t]
    d = {"t": [ms[0]] + [b - a for a, b in zip(ms, ms[1:])],
         "v": [int(round(x)) for x in lap.speed], "g": [int(round(x * 100)) for x in lap.throttle],
         "b": [int(round(x * 100)) for x in lap.brake], "n": list(lap.gear), "c": list(lap.tc)}
    return base64.b64encode(zlib.compress(json.dumps(d, separators=(",", ":")).encode(), 9)).decode("ascii")


def unpack(m: dict, z: str) -> LapTrace:
    d = json.loads(zlib.decompress(base64.b64decode(z)).decode())
    t, acc = [], 0
    for x in d["t"]:
        acc += x
        t.append(acc / 1000.0)
    lap = LapTrace(lap=int(m.get("lap") or 0), track=m.get("track") or "", car=m.get("car") or "",
                   track_length=float(m.get("len") or 0), lap_time=float(m.get("lap_time") or 0))
    lap.driver, lap.compound = m.get("driver") or "", m.get("compound") or ""
    lap.wetness, lap.rain, lap.track_temp = float(m.get("wet") or 0), float(m.get("rain") or 0), float(m.get("temp") or 0)
    lap.fuel_start = float(m.get("fuel") or 0)
    lap.t, lap.speed = t, [float(x) for x in d["v"]]
    lap.throttle, lap.brake = [x / 100 for x in d["g"]], [x / 100 for x in d["b"]]
    lap.gear, lap.tc = list(d["n"]), list(d["c"])
    return lap


def differences(lap: LapTrace, m: dict) -> list[str]:
    """Czym warunki okrążenia kolegi różnią się od Twoich (do uczciwego komentarza)."""
    out = []
    if lap.compound and m.get("compound") and lap.compound != m["compound"]:
        out.append(f"inna mieszanka ({m['compound']})")
    if abs((lap.wetness or 0) - (m.get("wet") or 0)) > STRICT["wet"]:
        out.append("inna wilgotność toru")
    if lap.track_temp and m.get("temp") and abs(lap.track_temp - m["temp"]) > STRICT["temp"]:
        out.append(f"tor {abs(lap.track_temp - m['temp']):.0f} stopni {'cieplejszy' if m['temp'] > lap.track_temp else 'zimniejszy'}")
    w0 = wear(lap)
    if w0 is not None and m.get("wear") is not None and abs(w0 - m["wear"]) > STRICT["wear"]:
        out.append("świeższe opony" if m["wear"] < w0 else "bardziej zużyte opony")
    if abs((lap.fuel_start or 0) - (m.get("fuel") or 0)) > STRICT["fuel"]:
        out.append("mniej paliwa" if (m.get("fuel") or 0) < (lap.fuel_start or 0) else "więcej paliwa")
    return out


def _fits(lap: LapTrace, m: dict, lim: dict) -> bool:
    if lap.car and m.get("car") and lap.car != m["car"]:
        return False
    if lap.compound and m.get("compound") and lap.compound != m["compound"]:
        return False
    if abs((lap.wetness or 0) - (m.get("wet") or 0)) > lim["wet"] or abs((lap.rain or 0) - (m.get("rain") or 0)) > lim["rain"]:
        return False
    if lap.track_temp and m.get("temp") and abs(lap.track_temp - m["temp"]) > lim["temp"]:
        return False
    w0 = wear(lap)
    if w0 is not None and m.get("wear") is not None and abs(w0 - m["wear"]) > lim["wear"]:
        return False
    return abs((lap.fuel_start or 0) - (m.get("fuel") or 0)) <= lim["fuel"]


def name_match(q: str, driver: str) -> bool:
    """„Patrykiem”, „Patryka”, „Jaskulskiego” → Patryk Jaskulski."""
    words = re.findall(r"[a-z]{3,}", _fold(q))
    for part in _fold(driver).split():
        if len(part) < 3:
            continue
        # odmiana: do 5 liter całe imię, 6–7 liter bez ostatniej, dłuższe bez dwóch („Wieczorkiem”, „Patrykiem”)
        stem = part if len(part) <= 5 else (part[:-1] if len(part) <= 7 else part[:-2])
        if any(w.startswith(stem) for w in words):
            return True
    return False


def first_name(driver: str) -> str:
    return (driver or "").split()[0] if driver else "kolega"


def _sd(x: float) -> str:
    from ..fmt import spoken_delta
    return spoken_delta(abs(x)).replace("plus ", "")


def _m(x: float) -> int:
    return int(5 * round(abs(x) / 5)) or 5


def mate_reasons(d: CornerDelta, name: str, speed_ok: bool = True) -> list[str]:
    """Co kolega robi inaczej w zakręcie, w którym jest szybszy (d = Ty względem kolegi)."""
    r: list[tuple[float, str]] = []
    if d.brake_point_diff is not None and d.brake_point_diff <= -8:
        r.append((abs(d.brake_point_diff) / 8, f"{name} hamuje {_m(d.brake_point_diff)} metrów później"))
    if d.brake_point_diff is not None and d.brake_point_diff >= 8 and d.min_speed_diff < -2:
        r.append((d.brake_point_diff / 8, f"{name} hamuje {_m(d.brake_point_diff)} metrów wcześniej, a ma więcej prędkości w środku"))
    if speed_ok and d.min_speed_diff <= -3:
        r.append((abs(d.min_speed_diff) / 3, f"ma o {round(abs(d.min_speed_diff))} km/h więcej w najwolniejszym miejscu"))
    if d.throttle_point_diff is not None and d.throttle_point_diff >= 10:
        r.append((d.throttle_point_diff / 10, f"pełny gaz {_m(d.throttle_point_diff)} metrów wcześniej"))
    if d.coast_diff >= 15:
        r.append((d.coast_diff / 15, f"krócej jedzie bez gazu i hamulca, o {_m(d.coast_diff)} metrów"))
    if d.gear and d.ref_gear and d.gear != d.ref_gear:
        r.append((0.9, f"w najwolniejszym miejscu jedzie na {d.ref_gear} biegu, Ty na {d.gear}"))
    if d.brake_peak_diff <= -0.15:
        r.append((abs(d.brake_peak_diff) / 0.15, "hamuje mocniej na początku"))
    if d.tc_more >= 4:
        r.append((0.8, "rzadziej włącza mu się TC na wyjściu"))
    r.sort(key=lambda x: -x[0])
    return [t for _, t in r[:2]]


def advice(reasons: list[str]) -> str:
    """Jedna rada z najważniejszej różnicy."""
    if not reasons:
        return ""
    t = reasons[0]
    if "metrów później" in t and "hamuje" in t:
        return "spróbuj hamować później"
    if "wcześniej, a ma więcej" in t:
        return "zahamuj wcześniej i wnieś więcej prędkości w zakręt"
    if "km/h więcej" in t:
        return "wnieś więcej prędkości w środek zakrętu"
    if "pełny gaz" in t:
        return "wcześniej otwieraj gaz"
    if "bez gazu" in t:
        return "skróć toczenie: szybciej z hamulca na gaz, bez przerwy"
    if "biegu" in t:
        return "spróbuj jego biegu"
    if "mocniej" in t:
        return "mocniej naciśnij hamulec na początku"
    if "TC" in t:
        return "łagodniej otwieraj gaz na wyjściu"
    return ""


class TeamLaps:
    """Wysyłanie najlepszych okrążeń do bazy zespołu i wybór okrążenia kolegi do porównania.

    call(payload) -> dict – wywołanie centrum zespołu (hub.call); None = bez zespołu."""

    def __init__(self, call: Optional[Callable[[dict], dict]] = None, me: str = "") -> None:
        self.call = call
        self.index: dict = {}           # kierowca -> koszyk -> meta
        self._idx_t: Optional[float] = None   # kiedy pobrano listę okrążeń (None = jeszcze nie)
        self._cache: dict = {}          # (kierowca, koszyk, t) -> LapTrace
        self.match: Optional[tuple] = None   # (meta, LapTrace, ścisłe dopasowanie)
        self._lock = threading.Lock()
        self.uploaded = 0
        self.errors = ""

    # ------------------------------------------------------------ baza
    def _trk(self, lap: LapTrace) -> str:
        return key(lap.track)

    def refresh(self, lap: LapTrace, force: bool = False) -> None:
        if self.call is None or (not force and self._idx_t is not None and time.monotonic() - self._idx_t < 180):
            return
        try:
            out = self.call({"op": "tlap_index", "trk": self._trk(lap)}) or {}
            self.index = out.get("index") or {}
            self._idx_t = time.monotonic()
        except Exception as e:
            self.errors = str(e)[:100]

    def upload(self, lap: LapTrace) -> bool:
        """Wyślij okrążenie, gdy to najszybsze okrążenie kierowcy w tym koszyku warunków."""
        if self.call is None or not lap.driver or not lap.clean or lap.incomplete or lap.impact or not lap.plausible():
            return False
        m = meta(lap)
        b = bucket(m)
        old = (self.index.get(key(lap.driver)) or {}).get(b)
        if old and float(old.get("lap_time") or 1e9) <= lap.lap_time:
            return False
        try:
            out = self.call({"op": "tlap_put", "trk": self._trk(lap), "drv": key(lap.driver), "bucket": b,
                             "meta": m, "z": pack(lap)}) or {}
            if out.get("stored"):
                self.index.setdefault(key(lap.driver), {})[b] = m
                self.uploaded += 1
                return True
        except Exception as e:
            self.errors = str(e)[:100]
        return False

    def _load(self, drv: str, b: str, m: dict) -> Optional[LapTrace]:
        ck = (drv, b, m.get("t"))
        if ck in self._cache:
            return self._cache[ck]
        try:
            out = self.call({"op": "tlap_get", "trk": key(m.get("track") or ""), "drv": drv, "bucket": b}) or {}
            rec = out.get("lap") or {}
            if not rec.get("z"):
                return None
            lap = unpack(rec.get("meta") or m, rec["z"])
        except Exception as e:
            self.errors = str(e)[:100]
            return None
        self._cache[ck] = lap
        return lap

    # ------------------------------------------------------------ wybór
    def candidates(self, lap: LapTrace, who: str = "") -> list[tuple[dict, str, str, bool]]:
        """Okrążenia kolegów pasujące do Twoich warunków: (meta, kierowca, koszyk, ścisłe), od najszybszego."""
        mine = key(lap.driver)
        out = []
        for drv, bs in (self.index or {}).items():
            if drv == mine or not isinstance(bs, dict):
                continue
            for b, m in bs.items():
                if not isinstance(m, dict) or (who and not name_match(who, m.get("driver") or "")):
                    continue
                if _fits(lap, m, STRICT):
                    out.append((m, drv, b, True))
                elif _fits(lap, m, LOOSE):
                    out.append((m, drv, b, False))
        out.sort(key=lambda x: (not x[3], float(x[0].get("lap_time") or 1e9)))
        return out

    def teammates(self) -> list[str]:
        names = []
        for bs in (self.index or {}).values():
            for m in (bs or {}).values():
                if isinstance(m, dict) and m.get("driver"):
                    names.append(m["driver"])
                    break
        return names

    def find(self, lap: LapTrace, who: str = "") -> Optional[tuple[dict, LapTrace, bool]]:
        for m, drv, b, strict in self.candidates(lap, who)[:3]:
            ref = self._load(drv, b, m)
            if ref is not None and len(ref.t) >= len(lap.t) * 0.95:
                return m, _fit_len(ref, len(lap.t)), strict
        return None

    def prepare(self, lap: LapTrace) -> None:
        """Po okrążeniu (w tle): wyślij swoje, odśwież listę i przygotuj okrążenie kolegi do porównań."""
        if self.call is None:
            return
        with self._lock:
            self.refresh(lap)
            self.upload(lap)
            if lap.clean and lap.t:
                f = self.find(lap)
                if f is not None and f[1].lap_time < lap.lap_time + 1.5:
                    self.match = f
                elif f is None:
                    self.match = None


def _fit_len(ref: LapTrace, n: int) -> LapTrace:
    """Ten sam tor, ale długość zapisu może się różnić o kilka binów – wyrównaj do n."""
    if len(ref.t) == n:
        return ref
    import copy
    r = copy.copy(ref)
    for f in ("t", "speed", "throttle", "brake", "gear", "tc"):
        v = list(getattr(ref, f))
        v = v[:n] + [v[-1]] * max(0, n - len(v)) if v else v
        setattr(r, f, v)
    return r


def mate_deltas(lap: LapTrace, ref: LapTrace, corners: list[CornerDef]) -> list[CornerDelta]:
    return compare(lap, _fit_len(ref, len(lap.t)), corners) if lap.t and ref.t and corners else []


def describe(lap: LapTrace, m: dict, ref: LapTrace, strict: bool, corners: list[CornerDef], fmt_time) -> tuple[str, str]:
    """(krótka odpowiedź głosem, pełna lista) – gdzie kolega jest szybszy i co robi inaczej."""
    name = first_name(m.get("driver") or "")
    deltas = mate_deltas(lap, ref, corners)
    if not deltas:
        return f"Nie mogę porównać z okrążeniem {name}, brak mapy zakrętów.", ""
    gains = sorted([d for d in deltas if d.time_loss >= MIN_GAIN], key=lambda d: -d.time_loss)
    total = sum(d.time_loss for d in gains)
    diff = lap.lap_time - ref.lap_time
    cond = "w podobnych warunkach" if strict else "w trochę innych warunkach: " + ", ".join(differences(lap, m))
    head = (f"{name}: {fmt_time(ref.lap_time)}, {cond}. ")
    if not gains:
        return head + f"Nigdzie nie jest wyraźnie szybszy od Twojego ostatniego okrążenia.", ""
    parts = []
    for d in gains[:2]:
        rs = mate_reasons(d, name, speed_ok=strict)
        tip = advice(rs)
        parts.append(f"{d.corner.name} {_sd(d.time_loss)}" +
                     ((": " + " i ".join(rs)) if rs else "") + ((". Rada: " + tip) if tip else ""))
    full = "; ".join(f"{d.corner.name} {d.time_loss:.2f} s".replace(".", ",") +
                     ((" – " + ", ".join(mate_reasons(d, name, strict))) if mate_reasons(d, name, strict) else "")
                     for d in gains)
    more = f"Szybszy w {len(gains)} zakrętach, razem {_sd(total)}. Najwięcej: " \
        if len(gains) > 2 else "Najwięcej zyskuje: "
    if diff < 0:
        head = head.replace(f"{fmt_time(ref.lap_time)}", f"{fmt_time(ref.lap_time)}, Ty byłeś szybszy na okrążeniu")
    return head + more + ". ".join(parts) + ".", full
