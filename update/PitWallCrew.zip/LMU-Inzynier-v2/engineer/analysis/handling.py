"""Prowadzenie auta: balans w zakrętach, opony, przełożenia — dane do porad setupowych.

Balans liczymy z kątów poślizgu opon: średni poślizg przodu minus średni poślizg tyłu (w stopniach).
Dodatni = przód ślizga się bardziej (podsterowność), ujemny = tył ślizga się bardziej (nadsterowność).
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional

from .corners import CornerDef
from .laps import BIN, LapTrace

UNDER = 0.8   # stopnie: powyżej = wyraźna podsterowność
OVER = -0.8   # poniżej = wyraźna nadsterowność


def label(bal: Optional[float]) -> str:
    if bal is None:
        return "brak danych"
    if bal >= UNDER:
        return "podsterowność"
    if bal <= OVER:
        return "nadsterowność"
    return "neutralnie"


@dataclass
class CornerHandling:
    name: str
    min_speed: float
    speed_class: str           # wolny / średni / szybki
    entry: Optional[float]     # balans w stopniach
    mid: Optional[float]
    exit: Optional[float]
    tc_exit: float             # średnio metrów z TC na wyjściu
    position: int              # 1 = pierwszy zakręt
    is_last: bool = False

    def describe(self) -> str:
        def f(x):
            return f"{label(x)} ({x:+.1f}°)" if x is not None else "brak danych"
        last = ", OSTATNI zakręt okrążenia" if self.is_last else ""
        tc = f", TC na wyjściu {self.tc_exit:.0f} m" if self.tc_exit >= 5 else ""
        return (f"{self.name} ({self.speed_class}, min. {self.min_speed:.0f} km/h{last}): "
                f"wejście {f(self.entry)}, środek {f(self.mid)}, wyjście {f(self.exit)}{tc}")


@dataclass
class TyreFinding:
    wheel: str
    inner: float
    middle: float
    outer: float
    pressure: float
    brake_max: float
    notes: list[str] = field(default_factory=list)


@dataclass
class HandlingReport:
    corners: list[CornerHandling]
    tyres: list[TyreFinding]
    optimal_temp: float
    gearing: list[str]
    laps_used: int

    def by_class(self) -> dict[str, dict[str, Optional[float]]]:
        """Średni balans w fazach dla wolnych / średnich / szybkich zakrętów."""
        out = {}
        for cls in ("wolny", "średni", "szybki"):
            cs = [c for c in self.corners if c.speed_class == cls]
            if not cs:
                continue
            row = {}
            for ph in ("entry", "mid", "exit"):
                vals = [getattr(c, ph) for c in cs if getattr(c, ph) is not None]
                row[ph] = sum(vals) / len(vals) if vals else None
            out[cls] = row
        return out

    def describe(self) -> str:
        lines = [f"(średnia z {self.laps_used} ostatnich czystych okrążeń; balans = poślizg przodu minus tyłu, "
                 f"+ podsterowność, - nadsterowność, próg ±{UNDER}°)"]
        for c in self.corners:
            lines.append("  " + c.describe())
        names = {"entry": "wejście", "mid": "środek", "exit": "wyjście"}
        for cls, row in self.by_class().items():
            parts = [f"{names[k]} {label(v)} ({v:+.1f}°)" for k, v in row.items() if v is not None]
            plural = {"wolny": "wolne", "średni": "średnie", "szybki": "szybkie"}[cls]
            lines.append(f"  Zakręty {plural} razem: " + ", ".join(parts))
        if self.tyres:
            lines.append(f"  Opony (średnio przy >80 km/h, wewnątrz/środek/zewnątrz, optimum ok. {self.optimal_temp:.0f}°C):")
            for t in self.tyres:
                n = ("; " + "; ".join(t.notes)) if t.notes else ""
                lines.append(f"    {t.wheel}: {t.inner:.0f}/{t.middle:.0f}/{t.outer:.0f}°C, {t.pressure:.0f} kPa, "
                             f"hamulec max {t.brake_max:.0f}°C{n}")
        for g in self.gearing:
            lines.append("  Przełożenia: " + g)
        return "\n".join(lines)


def _phase_avg(laps: list[LapTrace], lo: int, hi: int) -> Optional[float]:
    vals = []
    for lap in laps:
        for i in range(max(0, lo), min(hi, len(lap.bal))):
            if lap.latg[i] >= 0.4 and lap.speed[i] > 60:
                vals.append(lap.bal[i])
    if len(vals) < 3:
        return None
    return sum(vals) / len(vals)


def _speed_class(v: float) -> str:
    if v < 110:
        return "wolny"
    if v < 170:
        return "średni"
    return "szybki"


def analyze(laps: list[LapTrace], corners: list[CornerDef], n_laps: int = 3) -> Optional[HandlingReport]:
    clean = [l for l in laps if l.clean and l.bal][-n_laps:]
    if not clean or not corners:
        return None
    n = len(clean[0].bal)
    clean = [l for l in clean if len(l.bal) == n]
    mid_w = int(15 / BIN)

    out = []
    for k, c in enumerate(corners):
        s, a, e = int(c.start / BIN), int(c.apex / BIN), int(c.end / BIN)
        min_speed = sum(min(l.speed[max(0, a - 8):a + 9]) for l in clean) / len(clean)
        tc_exit = sum(sum(l.tc[a:e + 1]) for l in clean) / len(clean) * BIN if clean[0].tc else 0.0
        out.append(CornerHandling(
            name=c.name, min_speed=min_speed, speed_class=_speed_class(min_speed),
            entry=_phase_avg(clean, s, a - mid_w), mid=_phase_avg(clean, a - mid_w, a + mid_w + 1),
            exit=_phase_avg(clean, a + mid_w + 1, e + 1), tc_exit=tc_exit, position=k + 1,
            is_last=(k == len(corners) - 1),
        ))

    # opony z ostatniego czystego okrążenia z danymi
    tyres = []
    last = next((l for l in reversed(clean) if l.tyre_temps), None)
    opt = last.tyre_optimal if last else 0.0
    if last:
        for name, tt, pr, bm in zip(["LP", "PP", "LT", "PT"], last.tyre_temps, last.tyre_pressures, last.brake_max):
            inner, middle, outer = tt
            notes = []
            if inner - outer > 10:
                notes.append(f"wewnętrzna krawędź gorętsza o {inner - outer:.0f}°C (dużo negatywnego camberu)")
            elif outer - inner > 3:
                notes.append(f"zewnętrzna krawędź gorętsza o {outer - inner:.0f}°C (za mało negatywnego camberu)")
            edges = (inner + outer) / 2
            if middle - edges > 5:
                notes.append("środek gorętszy od krawędzi (ciśnienie za wysokie)")
            elif edges - middle > 5:
                notes.append("środek chłodniejszy od krawędzi (ciśnienie za niskie)")
            avg = (inner + middle + outer) / 3
            if opt > 0 and avg > opt + 10:
                notes.append(f"opona przegrzana (średnio {avg:.0f}°C)")
            elif opt > 0 and avg < opt - 10:
                notes.append(f"opona za zimna (średnio {avg:.0f}°C)")
            tyres.append(TyreFinding(name, inner, middle, outer, pr, bm, notes))

    # przełożenia: odcinanie w najwyższym biegu przed hamowaniem
    gearing = []
    ref = min(clean, key=lambda l: l.lap_time)
    if ref.rpmf and ref.gear:
        top = max(ref.gear)
        run, best_run, best_at = 0, 0, 0
        for i in range(n + 1):
            if i < n and ref.rpmf[i] >= 0.985 and ref.gear[i] == top and ref.brake[i] < 0.05:
                run += 1
            else:
                if run > best_run:
                    best_run, best_at = run, i
                run = 0
        if best_run * BIN >= 40:
            nxt = next((c.name for c in corners if c.start / BIN >= best_at - 2), corners[0].name)
            gearing.append(f"odcinanie na najwyższym biegu przez {best_run * BIN:.0f} m przed {nxt} "
                           f"(ostatni bieg za krótki)")
        if not gearing:
            peak = max(ref.rpmf)
            if 0 < peak < 0.93:
                gearing.append(f"na najszybszej prostej maks. {peak * 100:.0f}% obrotów: ostatni bieg może być za długi")
    return HandlingReport(corners=out, tyres=tyres, optimal_temp=opt, gearing=gearing, laps_used=len(clean))
