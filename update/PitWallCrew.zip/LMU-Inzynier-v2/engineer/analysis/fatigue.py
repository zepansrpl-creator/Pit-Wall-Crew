"""Wykrywanie zmęczenia kierowcy w długim stincie.

Porównujemy koniec stintu z jego początkiem (ten sam kierowca, podobne warunki):
- tempo: mediana 3 ostatnich czystych okrążeń vs mediana okrążeń 2–4 stintu,
- powtarzalność: rozrzut 5 ostatnich czystych okrążeń vs rozrzut na początku,
- błędy: wyjazdy poza tor, kroki za limity toru, nieważne okrążenia, uderzenia w ostatnich 5 okrążeniach,
- czas za kierownicą.
Zużycie opon i paliwa też zmienia tempo, dlatego sam spadek tempa ma ograniczoną wagę;
alarm wymaga spadku tempa razem z gorszą powtarzalnością albo błędami.
"""

from __future__ import annotations

import statistics
from dataclasses import dataclass, field
from typing import Optional

from ..plnum import plural
from .laps import LapTrace


@dataclass
class FatigueReport:
    score: int                    # 0..100
    level: str                    # "ok" / "uwaga" / "zmęczenie" / "za mało danych"
    pace_drop: Optional[float]    # s/okr. względem początku stintu
    spread_ratio: Optional[float] # rozrzut teraz / rozrzut na początku
    mistakes: int                 # błędy w ostatnich 5 okrążeniach
    minutes: float                # czas za kierownicą (min)
    reasons: list[str] = field(default_factory=list)

    def describe(self) -> str:
        if self.level == "za mało danych":
            return f"za kierownicą {self.minutes:.0f} min, za mało okrążeń do oceny zmęczenia"
        txt = f"zmęczenie {self.score}/100 ({self.level}), za kierownicą {self.minutes:.0f} min"
        if self.reasons:
            txt += ": " + ", ".join(self.reasons)
        return txt

    def to_dict(self) -> dict:
        return {"score": self.score, "level": self.level, "pace_drop": self.pace_drop,
                "spread_ratio": self.spread_ratio, "mistakes": self.mistakes,
                "minutes": round(self.minutes), "text": self.describe()}


def _mistakes(lap: LapTrace) -> int:
    return lap.off_tracks + (1 if lap.tl_steps > 0 else 0) + (1 if (not lap.valid and not lap.incomplete) else 0) \
        + (2 if lap.impact else 0)


class FatigueMonitor:
    def __init__(self, cfg: Optional[dict] = None) -> None:
        cfg = cfg or {}
        self.warn_score = int(cfg.get("fatigue_warn_score", 60))
        self.cooldown_min = float(cfg.get("fatigue_cooldown_min", 20))
        self.stint_laps: list[LapTrace] = []
        self.driver_start_t: Optional[float] = None
        self._warned_t: Optional[float] = None
        self.last: Optional[FatigueReport] = None

    def reset_driver(self, t: float) -> None:
        """Nowy kierowca w aucie (albo program włączony na początku jazdy)."""
        self.driver_start_t = t
        self.stint_laps.clear()
        self._warned_t = None

    def new_stint(self) -> None:
        """Po postoju ten sam kierowca jedzie dalej: zmęczenie się nie zeruje (czas, tempo i błędy liczą się dalej).
        Zerujemy tylko przy zmianie kierowcy (reset_driver)."""
        return

    def add_lap(self, lap: LapTrace, t: float) -> Optional[str]:
        if self.driver_start_t is None:
            self.driver_start_t = t
        self.stint_laps.append(lap)
        if len(self.stint_laps) > 60:      # długie przejazdy (podwójne stinty): porównujemy z ostatnią godziną–dwiema
            del self.stint_laps[:-60]
        rep = self.report(t)
        self.last = rep
        if rep.level == "zmęczenie" and (self._warned_t is None or t - self._warned_t > self.cooldown_min * 60):
            self._warned_t = t
            if getattr(self, "solo", False):
                d = f" o {rep.pace_drop:.1f} sekundy".replace(".", ",") if rep.pace_drop and rep.pace_drop > 0.2 else ""
                return f"Pobudka, nie śpij! Tempo Ci spadło{d} i sypią się błędy. Ogarnij się, skup się."
            return "Tempo spada i jest więcej błędów. Jeśli jesteś zmęczony, zgłoś zmianę."
        return None

    def report(self, t: float) -> FatigueReport:
        minutes = (t - self.driver_start_t) / 60 if self.driver_start_t is not None else 0.0
        clean = [l for l in self.stint_laps if l.clean]
        if len(clean) < 7:
            return FatigueReport(0, "za mało danych", None, None, 0, minutes)
        base = clean[1:4]  # pierwsze czyste okrążenie bywa jeszcze na zimnych oponach
        recent = clean[-3:]
        # zmiana warunków (deszcz) psuje porównanie
        if abs(statistics.mean(l.wetness for l in recent) - statistics.mean(l.wetness for l in base)) > 0.05:
            return FatigueReport(0, "za mało danych", None, None, 0, minutes, ["zmieniły się warunki na torze"])
        drop = statistics.median(l.lap_time for l in recent) - statistics.median(l.lap_time for l in base)
        sp_base = max(0.15, statistics.pstdev([l.lap_time for l in clean[1:5]]))
        sp_now = statistics.pstdev([l.lap_time for l in clean[-5:]])
        ratio = sp_now / sp_base
        mistakes = sum(_mistakes(l) for l in [l for l in self.stint_laps if not l.pit][-5:])

        pace_pts = max(0.0, min(40.0, (drop - 0.3) / 1.2 * 40))
        spread_pts = max(0.0, min(30.0, (ratio - 1.2) / 1.3 * 30))
        mist_pts = min(25.0, mistakes * 8.0)
        time_pts = 5.0 if minutes > 90 else 0.0
        score = pace_pts + spread_pts + mist_pts + time_pts
        # sam spadek tempa to najczęściej opony; bez innych objawów nie ogłaszamy zmęczenia
        if spread_pts < 5 and mist_pts == 0:
            score = min(score, 45)
        reasons = []
        if drop >= 0.5:
            reasons.append(f"tempo słabsze o {drop:.1f} s na okrążenie niż na początku stintu")
        if ratio >= 1.8:
            reasons.append("czasy okrążeń są dużo mniej równe niż na początku stintu")
        if mistakes:
            reasons.append(f"{mistakes} {plural(mistakes, 'błąd', 'błędy', 'błędów')} w ostatnich 5 okrążeniach")
        level = "zmęczenie" if score >= self.warn_score else ("uwaga" if score >= 35 else "ok")
        return FatigueReport(int(round(score)), level, round(drop, 2), round(ratio, 2), mistakes, minutes, reasons)
