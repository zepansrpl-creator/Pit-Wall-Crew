"""Paliwo i virtual energy: zużycie, zasięg, ile dolać do mety."""

from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Optional

from ..model import Snapshot
from .laps import LapTrace


@dataclass
class FuelReport:
    fuel_l: float
    capacity_l: float
    per_lap_l: Optional[float]
    laps_in_tank: Optional[float]
    ve: Optional[float]                # 0..1
    ve_per_lap: Optional[float]
    laps_on_ve: Optional[float]
    laps_to_finish: Optional[float]
    fuel_needed_to_finish: Optional[float]   # łącznie, z zapasem
    fuel_to_add: Optional[float]             # ile brakuje w baku do mety
    stops_needed: Optional[int]
    ve_needed_to_finish: Optional[float]     # ułamek
    limiting: str                            # "paliwo" / "VE" / ""
    stint_laps_left: Optional[float]
    samples: int

    def describe(self) -> str:
        parts = []
        if self.per_lap_l:
            parts.append(f"paliwo {self.fuel_l:.1f} l, zużycie {self.per_lap_l:.2f} l/okr., starczy na {self.laps_in_tank:.1f} okr.")
        else:
            parts.append(f"paliwo {self.fuel_l:.1f} l (za mało okrążeń, by policzyć zużycie)")
        if self.ve is not None:
            if self.ve_per_lap:
                parts.append(f"VE {self.ve * 100:.0f}%, zużycie {self.ve_per_lap * 100:.1f}%/okr., starczy na {self.laps_on_ve:.1f} okr.")
            else:
                parts.append(f"VE {self.ve * 100:.0f}%")
        if self.laps_to_finish is not None:
            parts.append(f"do mety ok. {self.laps_to_finish:.1f} okr.")
        if self.fuel_to_add is not None:
            if self.fuel_to_add <= 0:
                parts.append("paliwa wystarczy do mety")
            else:
                parts.append(f"do mety brakuje {self.fuel_to_add:.1f} l, postojów potrzebnych: {self.stops_needed}")
        if self.ve_needed_to_finish is not None and self.ve is not None:
            missing = self.ve_needed_to_finish - self.ve
            if missing > 0:
                parts.append(f"VE do mety potrzeba {self.ve_needed_to_finish * 100:.0f}% (brakuje {missing * 100:.0f} pkt %)")
        if self.limiting:
            parts.append(f"stint ogranicza: {self.limiting}")
        return "; ".join(parts)


def _avg_recent(values: list[float], n: int = 4) -> Optional[float]:
    vals = values[-n:]
    if not vals:
        return None
    # odrzuć wartości odstające (> 25% od mediany)
    med = sorted(vals)[len(vals) // 2]
    good = [v for v in vals if med > 0 and abs(v - med) / med < 0.25]
    return sum(good) / len(good) if good else med


def laps_to_finish(snap: Snapshot, avg_lap: Optional[float]) -> Optional[float]:
    ps = snap.player_scoring()
    if ps is None or snap.session != "race":
        return None
    frac = (ps.lap_dist / snap.track_length) if snap.track_length > 0 else 0.0
    if snap.max_laps:
        return max(0.0, snap.max_laps - ps.laps_done - frac)
    if snap.time_remaining is not None and avg_lap:
        # wyścig na czas: po upływie czasu kończysz bieżące okrążenie lidera, +1 dla bezpieczeństwa uproszczenia
        total = math.ceil(snap.time_remaining / avg_lap + frac)
        return max(0.0, total - frac)
    return None


def fuel_report(snap: Snapshot, laps: list[LapTrace], margin_laps: float = 0.5) -> Optional[FuelReport]:
    p = snap.player
    if p is None:
        return None
    usable = [l for l in laps if l.clean and l.fuel_used > 0]
    per_lap = _avg_recent([l.fuel_used for l in usable])
    ve_laps = [l.ve_used for l in usable if l.ve_used is not None and l.ve_used > 0]
    ve_per_lap = _avg_recent(ve_laps)
    avg_lap = _avg_recent([l.lap_time for l in usable], 3)

    laps_in_tank = p.fuel_l / per_lap if per_lap else None
    laps_on_ve = (p.virtual_energy / ve_per_lap) if (ve_per_lap and p.virtual_energy is not None) else None
    ltf = laps_to_finish(snap, avg_lap)

    needed = to_add = None
    stops = None
    ve_needed = None
    if ltf is not None and per_lap:
        needed = (ltf + margin_laps) * per_lap
        to_add = needed - p.fuel_l
        cap = p.fuel_capacity_l or 0
        stops = 0 if to_add <= 0 else (math.ceil(to_add / cap) if cap > 0 else 1)
    if ltf is not None and ve_per_lap:
        ve_needed = (ltf + margin_laps) * ve_per_lap

    limiting = ""
    stint_left = laps_in_tank
    if laps_in_tank is not None and laps_on_ve is not None:
        if laps_on_ve < laps_in_tank:
            limiting, stint_left = "VE", laps_on_ve
        else:
            limiting = "paliwo"
    elif laps_on_ve is not None:
        limiting, stint_left = "VE", laps_on_ve

    return FuelReport(
        fuel_l=p.fuel_l, capacity_l=p.fuel_capacity_l, per_lap_l=per_lap, laps_in_tank=laps_in_tank,
        ve=p.virtual_energy, ve_per_lap=ve_per_lap, laps_on_ve=laps_on_ve, laps_to_finish=ltf,
        fuel_needed_to_finish=needed, fuel_to_add=to_add, stops_needed=stops, ve_needed_to_finish=ve_needed,
        limiting=limiting, stint_laps_left=stint_left, samples=len(usable),
    )
