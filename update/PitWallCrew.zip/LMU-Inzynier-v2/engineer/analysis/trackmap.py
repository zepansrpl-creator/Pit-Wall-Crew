"""Mapa toru dla pit walla.

Kształt toru zbiera się sam z położenia aut (wszystkich, nie tylko naszego): dla każdego odcinka okrążenia
(co ok. 1/400 długości) średnie położenie aut poza aleją. Gdy zebrane jest ≥ 97% odcinków, braki
są uzupełniane i mapa jest gotowa (zapis w data/tracks/, wysyłka raz do bazy zespołu).
Na żywo wysyłamy tylko ułamek okrążenia każdego auta – pit wall rysuje je na kształcie toru.
"""

from __future__ import annotations

import json
import os
import re
from typing import Optional

BINS = 400


def track_key(name: str) -> str:
    k = re.sub(r"[^a-z0-9]+", "_", (name or "").lower()).strip("_")
    return k[:60] or "tor"


class TrackMap:
    def __init__(self, data_dir: str = "data") -> None:
        self.dir = os.path.join(data_dir, "tracks")
        self.track = ""
        self.key = ""
        self.points: Optional[list[list[float]]] = None
        self._sx = [0.0] * BINS
        self._sz = [0.0] * BINS
        self._n = [0] * BINS
        self.uploaded = 0.0          # kiedy wysłano kształt do bazy zespołu (monotonic)

    # ------------------------------------------------------------ zbieranie
    def _path(self) -> str:
        return os.path.join(self.dir, self.key + ".json")

    def _reset(self, track: str) -> None:
        self.track, self.key = track, track_key(track)
        self._sx, self._sz, self._n = [0.0] * BINS, [0.0] * BINS, [0] * BINS
        self.points, self.uploaded = None, 0.0
        try:
            with open(self._path(), encoding="utf-8") as f:
                pts = json.load(f).get("points")
            if isinstance(pts, list) and len(pts) >= 50:
                self.points = pts
        except (OSError, ValueError):
            pass

    def update(self, snap) -> Optional[list[list[float]]]:
        """Zbiera położenia; zwraca kształt toru w chwili, gdy właśnie powstał (raz)."""
        if snap.track != self.track:
            self._reset(snap.track)
        if self.points is not None or not snap.track_length or snap.track_length < 500:
            return None
        L = snap.track_length
        for c in snap.cars:
            if c.in_pits or (c.x == 0.0 and c.z == 0.0) or c.speed_kmh < 30 or abs(c.path_lateral) > 12:
                continue
            i = int((c.lap_dist % L) / L * BINS) % BINS
            if self._n[i] < 30:
                self._sx[i] += c.x
                self._sz[i] += c.z
                self._n[i] += 1
        filled = sum(1 for n in self._n if n)
        if filled < BINS * 0.97:
            return None
        pts = self._finish()
        if pts is None:
            return None
        self.points = pts
        try:
            os.makedirs(self.dir, exist_ok=True)
            with open(self._path(), "w", encoding="utf-8") as f:
                json.dump({"track": self.track, "points": pts}, f)
        except OSError:
            pass
        return pts

    def _finish(self) -> Optional[list[list[float]]]:
        raw = [(self._sx[i] / self._n[i], self._sz[i] / self._n[i]) if self._n[i] else None for i in range(BINS)]
        known = [i for i, p in enumerate(raw) if p is not None]
        if len(known) < 10:
            return None
        out = []
        for i in range(BINS):
            if raw[i] is not None:
                out.append(raw[i])
                continue
            a = max((k for k in known if k < i), default=known[-1])        # poprzedni znany (z zawinięciem)
            b = min((k for k in known if k > i), default=known[0])         # następny znany
            span = (b - a) % BINS or BINS
            f = ((i - a) % BINS) / span
            (ax, az), (bx, bz) = raw[a], raw[b]
            out.append((ax + (bx - ax) * f, az + (bz - az) * f))
        # lekkie wygładzenie (średnia z 5 sąsiadów)
        sm = []
        for i in range(BINS):
            xs = [out[(i + d) % BINS] for d in (-2, -1, 0, 1, 2)]
            sm.append([round(sum(p[0] for p in xs) / 5, 1), round(sum(p[1] for p in xs) / 5, 1)])
        return sm

    # ------------------------------------------------------------ na żywo
    @staticmethod
    def live(snap, my_class: str) -> dict:
        """Położenie aut dla pit walla: [ułamek okrążenia, nr klasy, poz. w klasie, w alei, czas okrążenia, my]."""
        L = snap.track_length or 0
        if not L:
            return {}
        classes: list[str] = []
        by_cls: dict[str, list] = {}
        for c in snap.cars:
            by_cls.setdefault(c.car_class, []).append(c)
        for k in sorted(by_cls, key=lambda k: (k != my_class, k)):
            classes.append(k)
        cars = []
        for k, lst in by_cls.items():
            ci = classes.index(k)
            for pos, c in enumerate(sorted(lst, key=lambda c: c.place), start=1):
                lap = c.last_lap if 30 < (c.last_lap or 0) < 900 else (c.best_lap if 30 < (c.best_lap or 0) < 900 else 0)
                cars.append([round((c.lap_dist % L) / L, 4), ci, pos, 1 if c.in_pits else 0, round(lap, 1),
                             1 if c.is_player else 0])
        return {"cls": classes, "cars": cars}
