"""Temperatury silnika i rada o grillu (osłonie chłodnicy) na postoju.

Gra podaje temperaturę wody, oleju i to, czy pokazuje ikonę przegrzania. Granice zależą od auta,
więc startujemy od wartości z config.toml ([engine]), a gdy gra pokaże przegrzanie, przyjmujemy
tę temperaturę jako prawdziwą granicę dla tego auta.

- Ostrzeżenie pilne: gra pokazuje przegrzanie.
- Komunikat o zmianie: woda wyraźnie rośnie z okrążenia na okrążenie i zbliża się do granicy.
- Rada na postój: grill otworzyć (stale za gorąco) albo przymknąć (stale chłodno, np. nocą – mniej oporu powietrza).
"""

from __future__ import annotations

import statistics
from dataclasses import dataclass
from typing import Optional


@dataclass
class EngineReport:
    water: float
    oil: float
    water_max_lap: Optional[float]   # najwyższa woda na ostatnim okrążeniu
    trend: Optional[float]           # zmiana maksimum wody °C/okr. (ostatnie 4 okrążenia)
    water_warn: float
    grille: str                      # "" / "otwórz" / "przymknij"
    text: str

    def to_dict(self) -> dict:
        return {k: (round(v, 1) if isinstance(v, float) else v) for k, v in self.__dict__.items()}


class EngineMonitor:
    def __init__(self, cfg: Optional[dict] = None) -> None:
        cfg = cfg or {}
        self.water_warn = float(cfg.get("water_warn_c", 105))   # powyżej: za gorąco
        self.water_low = float(cfg.get("water_low_c", 82))      # poniżej przez cały stint: można przymknąć grill
        self.oil_warn = float(cfg.get("oil_warn_c", 135))
        self.margin = float(cfg.get("grille_margin_c", 3))
        self.lap_max: list[float] = []     # maksimum wody na każdym okrążeniu
        self.lap_oil: list[float] = []
        self._cur_max = 0.0
        self._cur_oil = 0.0
        self._said: dict[str, float] = {}
        self._overheat_on = False
        self.learned = False
        self.last: Optional[EngineReport] = None
        self.water = self.oil = 0.0
        self.grille_now: Optional[str] = None   # bieżące ustawienie grilla z menu boksu (interfejs gry)

    def reset_stint(self) -> None:
        self.lap_max.clear()
        self.lap_oil.clear()

    def sample(self, water: float, oil: float, overheating: bool, in_pits: bool, t: float) -> Optional[str]:
        """Wołane przy każdym odczycie. Zwraca pilne ostrzeżenie (tylko na początku przegrzania)."""
        if water <= 0:
            return None
        self.water, self.oil = water, oil
        if not in_pits:
            self._cur_max = max(self._cur_max, water)
            self._cur_oil = max(self._cur_oil, oil)
        if overheating and not self._overheat_on:
            self._overheat_on = True
            # gra zna prawdziwą granicę tego auta – uczymy się jej
            if not self.learned or water - 2 < self.water_warn:
                self.water_warn = water - 2
                self.learned = True
            if self._once("overheat", t, 60):
                return "Przegrzanie silnika, wyjdź z cienia, czyste powietrze."
        if not overheating:
            self._overheat_on = False
        return None

    def end_lap(self, pit_lap: bool) -> None:
        if self._cur_max > 0 and not pit_lap:
            self.lap_max.append(self._cur_max)
            self.lap_oil.append(self._cur_oil)
        self._cur_max = self._cur_oil = 0.0

    def _once(self, key: str, t: float, gap: float) -> bool:
        last = self._said.get(key)
        if last is not None and t - last < gap:
            return False
        self._said[key] = t
        return True

    def trend(self) -> Optional[float]:
        w = self.lap_max[-4:]
        if len(w) < 3:
            return None
        return (w[-1] - w[0]) / (len(w) - 1)

    def grille_advice(self) -> str:
        """Rada na najbliższy postój na podstawie stintu."""
        w = self.lap_max[-6:]
        if len(w) < 3:
            return ""
        hot = statistics.median(w) >= self.water_warn - self.margin or max(w) >= self.water_warn
        oil_hot = bool(self.lap_oil) and max(self.lap_oil[-6:]) >= self.oil_warn
        if hot or oil_hot:
            return "otwórz"
        tr = self.trend() or 0.0
        if max(w) <= self.water_low and tr <= 0.3:
            return "przymknij"
        return ""

    def proactive(self, t: float) -> Optional[str]:
        """Komunikat bez pytania, gdy woda wyraźnie rośnie i zbliża się do granicy (najwyżej co 10 min)."""
        tr = self.trend()
        if tr is None or not self.lap_max:
            return None
        last = self.lap_max[-1]
        if tr >= 0.8 and last >= self.water_warn - 8 and self._once("rising", t, 600):
            return f"Woda {last:.0f}°C i rośnie, szukaj czystego powietrza."
        return None

    def report(self) -> EngineReport:
        g = self.grille_advice()
        tr = self.trend()
        last = self.lap_max[-1] if self.lap_max else None
        parts = [f"woda {self.water:.0f}°C, olej {self.oil:.0f}°C"]
        if last is not None:
            parts.append(f"najwyżej na ostatnim okrążeniu {last:.0f}°C")
        if tr is not None and abs(tr) >= 0.3:
            parts.append(("rośnie" if tr > 0 else "spada") + f" o {abs(tr):.1f}°C na okrążenie")
        parts.append(f"granica około {self.water_warn:.0f}°C" + (" (z gry)" if self.learned else ""))
        if g == "otwórz":
            parts.append("na postoju otwórz grill o jeden stopień")
        elif g == "przymknij":
            parts.append("silnik chłodny, na postoju możesz przymknąć grill o jeden stopień, mniej oporu na prostych")
        rep = EngineReport(self.water, self.oil, last, tr, self.water_warn, g, ", ".join(parts))
        self.last = rep
        return rep

    def pit_phrase(self, short: bool = False) -> str:
        """Dodatek do planu postoju."""
        g = self.grille_advice()
        now = f", teraz {self.grille_now}" if self.grille_now else ""
        if g == "otwórz":
            return f"grill otwórz o stopień{now}" if short else f"grill otwórz o jeden stopień{now}, silnik był za gorący"
        if g == "przymknij":
            return (f"grill przymknij o stopień{now}" if short
                    else f"grill możesz przymknąć o jeden stopień{now}, silnik jest chłodny")
        return ""
