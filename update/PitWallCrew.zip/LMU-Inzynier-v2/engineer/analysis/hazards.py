"""Pilne ostrzeżenia: dublowanie przez szybszą klasę, auto stojące lub wolne przed Tobą, flagi, kary.

Wszystkie odległości są zamieniane na sekundy. Komunikaty mają stałe szablony (z liczbami całkowitymi),
dzięki czemu głos może je nagrać raz i odtwarzać bez opóźnienia.
Zasady gadatliwości:
- dublowanie: jedno ostrzeżenie na podjazd danego auta, grupowanie aut dojeżdżających razem,
  przerwa między ostrzeżeniami o dublowaniu min. `lapping_gap_s`
- przeszkoda: dwa ostrzeżenia na przeszkodę (daleko i blisko)
- nic poza flagami i przeszkodami w ciągu 3 s po ostrzeżeniu o przeszkodzie
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Optional

from ..model import CarScoring, Snapshot

# kolejność od najszybszej klasy; nieznane klasy porównujemy po najlepszych czasach
CLASS_RANK = [("hyper", "Hypercar"), ("lmh", "Hypercar"), ("lmdh", "Hypercar"), ("lmp1", "LMP1"),
              ("lmp2", "LMP2"), ("lmp3", "LMP3"), ("gte", "GTE"), ("gt3", "GT3"), ("gt4", "GT4")]
SPOKEN_CLASS = {"Hypercar": "Hypercar", "LMP1": "LMP 1", "LMP2": "LMP 2", "LMP3": "LMP 3",
                "GTE": "GTE", "GT3": "GT3", "GT4": "GT4"}
PLURAL_CLASS = {"Hypercar": "Hypercary", "LMP1": "LMP 1", "LMP2": "LMP 2", "LMP3": "LMP 3",
                "GTE": "GTE", "GT3": "GT3", "GT4": "GT4"}
NUM_PL = {2: "Dwa", 3: "Trzy", 4: "Cztery", 5: "Pięć", 6: "Sześć"}


def class_key(name: str) -> tuple[int, str]:
    n = name.lower().replace(" ", "").replace("_", "")
    for i, (key, label) in enumerate(CLASS_RANK):
        if key in n:
            return i, label
    return 99, name


def sec_word(n: int) -> str:
    if n == 1:
        return "sekunda"
    if n % 10 in (2, 3, 4) and n % 100 not in (12, 13, 14):
        return "sekundy"
    return "sekund"


SIDES = ("z prawej", "z lewej", "na środku")


def _side(lat: float) -> str:
    """Strona toru z pozycji bocznej auta (dodatnie = prawa)."""
    if lat > 2.0:
        return "z prawej"
    if lat < -2.0:
        return "z lewej"
    return "na środku"


@dataclass
class Alert:
    text: str
    kind: str          # lapping / hazard / flag / penalty
    urgent: bool = True


def lapping_text(group: list, first_b: float) -> str:
    """„Hypercar, 2 sekundy.” / „Dwa hypercary, 2 sekundy.” / „Hypercar i dwa LMP 2, 1 sekunda.”"""
    counts: dict[str, int] = {}
    for _, _, lab in group:
        counts[lab] = counts.get(lab, 0) + 1
    parts = []
    for lab, cnt in counts.items():
        if cnt == 1:
            parts.append(SPOKEN_CLASS.get(lab, lab))
        else:
            pl = PLURAL_CLASS.get(lab, lab)
            parts.append(f"{NUM_PL.get(cnt, str(cnt)).lower()} {pl.lower() if lab == 'Hypercar' else pl}")
    txt = " i ".join(parts)
    n = max(1, int(round(first_b)))
    return f"{txt[0].upper() + txt[1:]}, {n} {sec_word(n)}."


class HazardMonitor:
    def __init__(self, cfg: Optional[dict] = None) -> None:
        cfg = cfg or {}
        self.lapping_on = cfg.get("lapping", True)
        self.hazards_on = cfg.get("hazards", True)
        self.flags_on = cfg.get("flags", True)
        w = float(cfg.get("lapping_warn_s", 2.0))
        self.lapping_warn_s = 2.0 if w == 4.0 else w      # 4 s było starą wartością domyślną – za wcześnie
        self.lapping_chain_s = float(cfg.get("lapping_chain_s", 1.0))   # kolejne auto do 1 s za poprzednim = grupa
        # każde szybsze auto jest zapowiadane (raz); przerwa tylko, żeby komunikaty na siebie nie wchodziły
        self.lapping_gap_s = min(3.0, float(cfg.get("lapping_gap_s", 3.0)))
        self.hazard_far_s = float(cfg.get("hazard_far_s", 8.0))
        self.hazard_near_s = float(cfg.get("hazard_near_s", 3.0))
        self.slow_kmh = float(cfg.get("slow_kmh", 60.0))
        self.reset()

    def reset(self) -> None:
        self._prev_behind: dict[int, float] = {}
        self._lapping_warned: set[int] = set()
        self._passed_t: dict[int, float] = {}
        self._last_lapping_t = -999.0
        self._last_blue_t = -999.0
        self._hazard_state: dict[int, int] = {}     # 0 nic, 1 daleko, 2 blisko
        self._hazard_seen_t: dict[int, float] = {}
        self._last_hazard_t = -999.0
        self._phase: Optional[str] = None
        self._yellow_state = 0
        self._any_sector_yellow = False
        self._last_sector_yellow_t = -999.0
        self._penalties: Optional[int] = None
        self._tl_steps: Optional[int] = None
        self._flat_warned = False
        self._detached_warned = False

    # ---------------------------------------------------------------- pomocnicze
    @staticmethod
    def _behind_s(me: CarScoring, c: CarScoring, L: float, ref=None) -> Optional[float]:
        """Ile sekund rywal jest za Tobą na torze (jak w tabeli „relative” w grze).

        Z okrążenia referencyjnego: ile Tobie zajmuje odcinek między wami, przeskalowane tempem rywala
        (jego najlepsze okrążenie do Twojego). Sama odległość / chwilowa prędkość zaniżała odstęp,
        gdy szybkie auto jechało prostą przed zakrętem (np. 4 s zamiast 7 s)."""
        d = (me.lap_dist - c.lap_dist) % L
        if d > 2500:
            return None
        if ref is not None and getattr(ref, "t", None) and ref.track_length == L and ref.lap_time > 0:
            n = len(ref.t)
            i0 = min(n - 1, int(c.lap_dist / 5.0))
            i1 = min(n - 1, int(me.lap_dist / 5.0))
            seg = ref.t[i1] - ref.t[i0]
            if seg < 0:
                seg += ref.lap_time
            ratio = (c.best_lap / ref.lap_time) if c.best_lap and c.best_lap > 0 else 0.92
            ratio = max(0.75, min(1.05, ratio))
            if 0 <= seg < 60:
                return seg * ratio
        v = max(c.speed_kmh / 3.6, 25.0)
        return d / v

    def _time_to(self, me: CarScoring, my_speed_kmh: float, target_dist: float, L: float, ref) -> float:
        """Za ile sekund dojedziesz do miejsca na torze (z okrążenia referencyjnego, a bez niego z prędkości)."""
        d = (target_dist - me.lap_dist) % L
        if ref is not None and ref.t and ref.track_length == L:
            n = len(ref.t)
            i0 = min(n - 1, int(me.lap_dist / 5.0))
            i1 = min(n - 1, int(target_dist / 5.0))
            t = ref.t[i1] - ref.t[i0]
            if t < 0:
                t += ref.lap_time
            if 0 <= t < 60:
                return t
        return d / max(my_speed_kmh / 3.6, 30.0)

    @staticmethod
    def _corner_at(dist: float, corners) -> Optional[str]:
        for c in corners or []:
            if c.start <= dist <= c.end:
                return c.name
        return None

    # ---------------------------------------------------------------- główna
    def update(self, snap: Snapshot, ref=None, corners=None) -> list[Alert]:
        out: list[Alert] = []
        me = snap.player_scoring()
        p = snap.player
        if me is None or p is None or snap.track_length <= 0:
            return out
        L = snap.track_length
        t = snap.t

        # --- flagi całego toru
        if self.flags_on:
            if self._phase is not None and snap.phase != self._phase:
                if snap.phase == "fcy":
                    out.append(Alert("Full course yellow, zwolnij.", "flag"))
                elif snap.phase == "green" and self._phase == "fcy":
                    out.append(Alert("Zielona flaga, ścigamy się.", "flag"))
                elif snap.phase == "stopped":
                    out.append(Alert("Czerwona flaga, sesja zatrzymana.", "flag"))
            if snap.phase == "fcy" and snap.yellow_state != self._yellow_state:
                if snap.yellow_state == 4 and self._yellow_state in (1, 2):
                    out.append(Alert("Aleja serwisowa otwarta.", "flag", urgent=False))
                elif snap.yellow_state == 5:
                    out.append(Alert("Ostatnie okrążenie za safety carem, przygotuj się do restartu.", "flag"))
            self._phase, self._yellow_state = snap.phase, snap.yellow_state

        # --- kary, limity toru, uszkodzenia kół
        if self.flags_on:
            if self._penalties is not None and me.penalties > self._penalties:
                out.append(Alert("Dostałeś karę.", "penalty"))
            self._penalties = me.penalties
            if self._tl_steps is not None and p.track_limit_steps > self._tl_steps and snap.tl_steps_per_point:
                pts = p.track_limit_steps // snap.tl_steps_per_point
                limit = snap.tl_steps_per_penalty // snap.tl_steps_per_point if snap.tl_steps_per_penalty else 0
                if pts > self._tl_steps // snap.tl_steps_per_point:
                    txt = f"Limity toru, {pts} z {limit}." if limit else "Ostrzeżenie za limity toru."
                    out.append(Alert(txt, "penalty", urgent=False))
            self._tl_steps = p.track_limit_steps
            if any(p.wheel_flat) and not self._flat_warned:
                names = ["lewa przednia", "prawa przednia", "lewa tylna", "prawa tylna"]
                which = [n for n, f in zip(names, p.wheel_flat) if f]
                out.append(Alert(f"Kapeć, {which[0]}. Zjeżdżaj do boksu.", "penalty"))
                self._flat_warned = True
            if not any(p.wheel_flat):
                self._flat_warned = False

        if p.in_pits or snap.phase not in ("green", "fcy"):
            self._prev_behind.clear()
            return out

        # --- przeszkoda: auto stojące albo bardzo wolne przed Tobą
        if self.hazards_on and snap.phase == "green" and p.speed_kmh > 80:
            found = []
            for c in snap.cars:
                if c.is_player or c.in_pits or c.pit_state in (2, 3, 4) or c.finished:
                    continue
                if c.speed_kmh >= self.slow_kmh:
                    if t - self._hazard_seen_t.get(c.car_id, -99) > 20:
                        self._hazard_state.pop(c.car_id, None)  # odjechał: przy kolejnym zdarzeniu ostrzeż od nowa
                    continue
                ahead = (c.lap_dist - me.lap_dist) % L
                if ahead > 2500:
                    continue
                eta = self._time_to(me, p.speed_kmh, c.lap_dist, L, ref)
                found.append((eta, c))
            found.sort(key=lambda x: x[0])
            for eta, c in found[:1]:
                state = self._hazard_state.get(c.car_id, 0)
                self._hazard_seen_t[c.car_id] = t
                # kilka wolnych aut blisko siebie (karambol, start, wyjazd z alei): jedno ostrzeżenie dla grupy
                group = [x for _, x in found if (x.lap_dist - c.lap_dist) % L < 300]
                if state == 0 and t - self._last_hazard_t < 6:
                    for x in group:
                        self._hazard_state[x.car_id] = max(self._hazard_state.get(x.car_id, 0), 1)
                    continue
                stopped = c.speed_kmh < 15
                side = _side(c.path_lateral)
                if len(group) >= 2 and not c.off_track:
                    what = "Kilka wolnych aut"
                elif c.off_track:
                    what = "Auto poza torem"
                else:
                    what = "Stoi auto" if stopped else "Wolne auto"
                yellow = "Żółta! " if any(snap.sector_yellow) else ""
                if state == 0 and self.hazard_near_s < eta <= self.hazard_far_s:
                    out.append(Alert(f"{yellow}{what} {side}.", "hazard"))
                    for x in group:
                        self._hazard_state[x.car_id] = 1
                    self._last_hazard_t = t
                elif state < 2 and eta <= self.hazard_near_s:
                    # tuż przed przeszkodą: najkrócej, tylko strona
                    out.append(Alert(("Uważaj, " + side + "!") if state == 1 else f"{what} {side}!", "hazard"))
                    for x in group:
                        self._hazard_state[x.car_id] = 2
                    self._last_hazard_t = t
            # Żółta flaga gdzieś daleko na torze: bez komunikatu. Mówimy tylko o konkretnym aucie blisko przed Tobą
            # (wyżej: "Żółta! Stoi auto z prawej."), bo tylko to coś zmienia dla kierowcy.
            self._any_sector_yellow = any(snap.sector_yellow)

        # --- dublowanie przez szybszą klasę
        if self.lapping_on and t - self._last_hazard_t > 3:
            my_rank, _ = class_key(me.car_class)
            closing = []
            near_known = False   # szybsze auto tuż za Tobą, o którym już wiesz
            for c in snap.cars:
                if c.is_player or c.in_pits or c.car_class == me.car_class:
                    continue
                rank, label = class_key(c.car_class)
                faster = rank < my_rank if (rank < 99 and my_rank < 99) else \
                    (c.best_lap > 0 and me.best_lap > 0 and c.best_lap < me.best_lap * 0.97)
                if not faster:
                    continue
                my_v = snap.player.speed_kmh if snap.player is not None else me.speed_kmh
                if c.speed_kmh < max(60.0, 0.7 * my_v) or c.off_track:
                    # stoi albo wlecze się (wypadek, poza torem) – właśnie go minąłeś, nie dojeżdża do Ciebie
                    self._lapping_warned.discard(c.car_id)
                    continue
                b = self._behind_s(me, c, L, ref)
                prev = self._prev_behind.get(c.car_id)
                if b is None:
                    if prev is not None and prev < 3:
                        self._passed_t[c.car_id] = t   # właśnie Cię wyprzedził
                    self._prev_behind.pop(c.car_id, None)
                    self._lapping_warned.discard(c.car_id)
                    continue
                if t - self._passed_t.get(c.car_id, -999) < 45:
                    # przed chwilą Cię wyprzedził; jeśli jedziecie łeb w łeb, nie ostrzegamy ponownie
                    self._prev_behind[c.car_id] = b
                    near_known = near_known or b <= 3
                    continue
                if b <= 3 and c.car_id in self._lapping_warned:
                    near_known = True
                self._prev_behind[c.car_id] = b
                if prev is not None and b > prev + 2:      # przejechał obok albo odpadł
                    self._lapping_warned.discard(c.car_id)
                if b > self.lapping_warn_s + 10:
                    self._lapping_warned.discard(c.car_id)
                # szybsza klasa zawsze się zbliża — nie czekamy, aż chwilowa przewaga zacznie maleć
                # (na prostej Ty bywasz szybszy, więc chwilowo może rosnąć)
                if b <= self.lapping_warn_s + 8:
                    closing.append((b, c, label))
            closing.sort(key=lambda x: x[0])
            new = [x for x in closing if x[0] <= self.lapping_warn_s and x[1].car_id not in self._lapping_warned]
            if me.laps_done < 1:
                # start wyścigu: wszyscy blisko siebie, ostrzeżenia nie mają sensu
                for _, c, _ in new:
                    self._lapping_warned.add(c.car_id)
                new = []
            if new and t - self._last_lapping_t >= self.lapping_gap_s:
                first_b = new[0][0]
                # grupa: pierwsze auto i każde kolejne, które jedzie do 1 s za poprzednim (łańcuch)
                k = next(i for i, x in enumerate(closing) if x[1].car_id == new[0][1].car_id)
                group = [closing[k]]
                for x in closing[k + 1:]:
                    if x[0] - group[-1][0] > self.lapping_chain_s:
                        break
                    group.append(x)
                out.append(Alert(lapping_text(group, first_b), "lapping"))
                self._last_lapping_t = t
                for _, c, _ in group:
                    self._lapping_warned.add(c.car_id)
            # auta, które pojawiły się w krótkiej przerwie, zapowiemy zaraz po niej

            # niebieska flaga z gry: tylko gdy żadne z aut tuż za Tobą nie zostało wcześniej zapowiedziane
            if me.blue_flag and t - self._last_blue_t > 60 and not near_known \
                    and t - self._last_lapping_t > 15:
                out.append(Alert("Niebieska flaga, przepuść.", "lapping"))
                self._last_blue_t = t
        return out

    def phrases(self, classes: list[str]) -> list[str]:
        """Wszystkie zdania, które monitor może powiedzieć — do nagrania z wyprzedzeniem."""
        out = ["Full course yellow, zwolnij.", "Zielona flaga, ścigamy się.", "Czerwona flaga, sesja zatrzymana.",
               "Ostatnie okrążenie za safety carem, przygotuj się do restartu.", "Dostałeś karę.",
               "Niebieska flaga, przepuść.", "Żółta flaga na torze.", "Aleja serwisowa otwarta."]
        labels = []
        for c in classes:
            _, lab = class_key(c)
            if lab not in labels:
                labels.append(lab)
        for n in range(1, int(self.lapping_warn_s) + 1):
            for lab in labels:
                for k in (1, 2, 3):
                    out.append(lapping_text([(0, None, lab)] * k, n))
        for side in SIDES:
            out.append(f"Uważaj, {side}!")
            for what in ("Stoi auto", "Wolne auto", "Auto poza torem", "Kilka wolnych aut"):
                for yellow in ("", "Żółta! "):
                    out.append(f"{yellow}{what} {side}.")
                out.append(f"{what} {side}!")
        return out
