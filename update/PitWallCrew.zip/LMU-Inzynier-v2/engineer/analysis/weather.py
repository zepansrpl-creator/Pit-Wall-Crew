"""Doradca deszczu i ewolucji toru.

Gra podaje wilgotność toru (0..1) i intensywność deszczu. Dokładnej zależności czasu okrążenia od
wilgotności dla każdej mieszanki nie znamy, więc startujemy od prostego modelu (do zmiany w ustawieniach)
i poprawiamy go pomiarami z wyścigu:
- slicki tracą ok. slick_k * wilgotność czasu okrążenia (domyślnie 0,30: przy 20% wilgotności ~6%),
- deszczowe tracą na suchym ok. wet_base (6%), a z wilgotnością coraz mniej (do 1,5%).
Gdy jedziemy na danej mieszance, mierzymy prawdziwą stratę względem suchego tempa i skalujemy jej model.
Opłacalność zmiany: zysk na okrążenie × okrążenia do planowanego postoju vs koszt dodatkowego zjazdu.
"""

from __future__ import annotations

import statistics
from dataclasses import dataclass
from typing import Optional

from ..plnum import plural
from .laps import LapTrace

WET_WORDS = ("wet", "rain", "deszcz", "inter")


def _s(x: float) -> str:
    """Sekundy do odczytu: powyżej 10 s bez ułamka."""
    return f"{x:.0f}" if abs(x) >= 10 else f"{x:.1f}"


def is_wet_compound(name: str) -> bool:
    n = (name or "").lower()
    return any(w in n for w in WET_WORDS)


@dataclass
class WeatherAdvice:
    rain: float
    wetness: float
    trend_per_lap: float           # zmiana wilgotności na okrążenie
    on_wets: bool
    current_loss: Optional[float]  # s/okr. straty względem suchego tempa na obecnych oponach (pomiar)
    gain_per_lap: Optional[float]  # s/okr. zysku po zmianie mieszanki (szacunek, + = opłaca się zmienić)
    action: str                    # "" / "zostań" / "na najbliższym postoju" / "zjedź teraz"
    text: str
    track_temp: float = 0.0
    track_temp_trend_h: Optional[float] = None   # °C na godzinę
    lap_trend: Optional[float] = None            # zmiana czasu okrążenia s/okr. (czyste, suche okrążenia)

    def to_dict(self) -> dict:
        return {k: (round(v, 3) if isinstance(v, float) else v) for k, v in self.__dict__.items()}


class WeatherAdvisor:
    def __init__(self, cfg: Optional[dict] = None) -> None:
        cfg = cfg or {}
        self.dry_eta: Optional[float] = None   # za ile minut slicki będą szybsze (tor przesycha)
        self.slick_k = float(cfg.get("rain_slick_k", 0.30))
        self.wet_base = float(cfg.get("rain_wet_base", 0.06))
        self.wet_k = float(cfg.get("rain_wet_k", 0.12))
        self.wet_floor = float(cfg.get("rain_wet_floor", 0.015))
        self.pit_cost = float(cfg.get("rain_pit_cost_s", 47.0))  # aleja + zmiana 4 opon
        self.laps: list[LapTrace] = []
        self.dry_ref: Optional[float] = None
        self._said: dict[str, float] = {}
        self.last: Optional[WeatherAdvice] = None
        self.samples: list[tuple[float, float, float, float]] = []   # (czas, deszcz, chmury, wilgotność) co 30 s
        self._raining = False

    # -------------------------------------------------------------- model
    def pen_slick(self, w: float) -> float:
        return self.slick_k * w

    def pen_wet(self, w: float) -> float:
        return max(self.wet_floor, self.wet_base - self.wet_k * w)

    def crossover(self) -> float:
        """Wilgotność, przy której deszczowe zaczynają być szybsze."""
        return (self.wet_base) / (self.slick_k + self.wet_k)

    # -------------------------------------------------------------- dane
    def add_lap(self, lap: LapTrace) -> None:
        self.laps.append(lap)
        if lap.clean and lap.wetness < 0.03 and not is_wet_compound(lap.compound):
            dry = [l.lap_time for l in self.laps[-20:] if l.clean and l.wetness < 0.03
                   and not is_wet_compound(l.compound)]
            self.dry_ref = statistics.median(dry)

    def _trend(self) -> float:
        w = [l.wetness for l in self.laps[-4:]]
        if len(w) < 2:
            return 0.0
        return (w[-1] - w[0]) / (len(w) - 1)

    def _temp_trend(self) -> Optional[float]:
        pts = [(i, l.track_temp, l.lap_time) for i, l in enumerate(self.laps[-15:]) if l.lap_time > 0]
        if len(pts) < 6:
            return None
        dur_h = sum(p[2] for p in pts) / 3600
        return (pts[-1][1] - pts[0][1]) / dur_h if dur_h > 0 else None

    def _lap_trend(self) -> Optional[float]:
        clean = [l.lap_time for l in self.laps[-12:] if l.clean and l.wetness < 0.03]
        if len(clean) < 8:
            return None
        return (statistics.median(clean[-4:]) - statistics.median(clean[:4])) / (len(clean) - 4)

    # -------------------------------------------------------------- ocena
    def advise(self, rain: float, wetness: float, compound: str, laps_to_stop: Optional[float],
               track_temp: float = 0.0, ref_lap: Optional[float] = None) -> WeatherAdvice:
        on_wets = is_wet_compound(compound)
        trend = self._trend()
        base = self.dry_ref or ref_lap
        w_soon = max(0.0, min(1.0, wetness + trend * 3))  # za ok. 3 okrążenia

        # skalowanie modelu obecnej mieszanki pomiarem
        scale = 1.0
        loss = None
        recent = [l for l in self.laps[-3:] if l.clean]
        if base and recent and abs(statistics.mean(l.wetness for l in recent) - wetness) < 0.08:
            loss = statistics.mean(l.lap_time for l in recent) - base
            model = (self.pen_wet(wetness) if on_wets else self.pen_slick(wetness)) * base
            if model > 1.0 and loss > 0:
                scale = max(0.5, min(2.0, loss / model))

        gain = None
        action, text = "", ""
        if base:
            if on_wets:
                now = self.pen_wet(w_soon) * scale
                other = self.pen_slick(w_soon)
            else:
                now = self.pen_slick(w_soon) * scale
                other = self.pen_wet(w_soon)
            gain = (now - other) * base
            other_name = "slicki" if on_wets else "deszczowe"
            horizon = min(laps_to_stop if laps_to_stop is not None else 10, 10)
            if gain > 0.3:
                if laps_to_stop is not None and laps_to_stop <= 2.5:
                    action = "na najbliższym postoju"
                    text = (f"Na najbliższym postoju zmień na {other_name}: szacuję zysk {_s(gain)} s na okrążenie "
                            f"przy wilgotności {wetness * 100:.0f}%.")
                elif gain * horizon > self.pit_cost + 5:
                    action = "zjedź teraz"
                    n = max(1, round(self.pit_cost / gain))
                    text = (f"Opłaca się zjechać teraz na {other_name}: zysk około {_s(gain)} s na okrążenie, "
                            f"dodatkowy postój zwróci się po {n} {plural(n, 'okrążeniu', 'okrążeniach', 'okrążeniach')}.")
                else:
                    action = "na najbliższym postoju"
                    text = (f"{other_name.capitalize()} byłyby szybsze o około {_s(gain)} s na okrążenie, "
                            f"ale dodatkowy postój się nie zwróci. Zmień przy planowym zjeździe.")
            else:
                action = "zostań"
                if wetness > 0.02 or rain > 0.05:
                    text = (f"Zostań na {'deszczowych' if on_wets else 'slickach'}: wilgotność {wetness * 100:.0f}%, "
                            f"granica opłacalności zmiany to około {self.crossover() * 100:.0f}%.")
        else:
            text = "Brak suchego okrążenia odniesienia, nie oszacuję jeszcze zysku ze zmiany opon."
        adv = WeatherAdvice(rain=rain, wetness=wetness, trend_per_lap=trend, on_wets=on_wets, current_loss=loss,
                            gain_per_lap=gain, action=action, text=text, track_temp=track_temp,
                            track_temp_trend_h=self._temp_trend(), lap_trend=self._lap_trend())
        self.last = adv
        return adv

    # -------------------------------------------------------------- zmiany pogody w czasie
    def sample(self, t: float, rain: float, cloud: float, wetness: float) -> Optional[str]:
        """Wołane przy każdym odczycie. Zwraca komunikat, gdy pogoda się zmienia (zbliża się deszcz,
        zaczyna/przestaje padać, deszcz się nasila)."""
        if self.samples and t - self.samples[-1][0] < 30:
            return None
        self.samples.append((t, rain, cloud, wetness))
        self.samples = [x for x in self.samples if t - x[0] <= 1800]

        def ago(sec: float):
            old = [x for x in self.samples if t - x[0] >= sec]
            return old[-1] if old else None

        def once(key: str, gap: float) -> bool:
            last = self._said.get(key)
            if last is not None and t - last < gap:
                return False
            self._said[key] = t
            return True

        prev10 = ago(600)
        prev3 = ago(180)
        # zaczęło padać / przestało
        if rain >= 0.05 and not self._raining:
            self._raining = True
            if once("rain_on", 600):
                return "Zaczyna padać" + (f", {rain * 100:.0f}%." if rain >= 0.15 else ", lekko.")
        if rain < 0.02 and self._raining:
            self._raining = False
            if once("rain_off", 600):
                return "Przestało padać."
        # tor przesycha: za ile minut slicki będą szybsze (wilgotność spadnie do granicy opłacalności)
        self.dry_eta = None
        if rain < 0.02 and prev3 is not None and wetness > self.crossover():
            rate = (prev3[3] - wetness) / max(1.0, t - prev3[0])     # spadek wilgotności na sekundę
            if rate > 0:
                eta = (wetness - self.crossover()) / rate / 60
                if eta <= 60:
                    self.dry_eta = eta
                if 2 <= eta <= 30 and once("dry_eta", 600):
                    return f"Tor przesycha. Slicki będą szybsze za około {eta:.0f} minut."
        # deszcz się nasila
        if rain >= 0.05 and prev3 is not None and rain - prev3[1] >= 0.2 and once("rain_up", 600):
            return f"Deszcz się nasila, {rain * 100:.0f}%."
        # zbliża się deszcz: chmury wyraźnie ciemnieją, jeszcze nie pada
        if rain < 0.05 and cloud >= 0.6 and prev10 is not None and cloud - prev10[2] >= 0.15 \
                and once("clouds", 1200):
            return "Chmury ciemnieją, możliwy deszcz."
        return None

    def sky(self) -> dict:
        """Ostatni stan nieba i zmiana chmur w 10 minut – dla pit walla."""
        if not self.samples:
            return {}
        t, rain, cloud, wet = self.samples[-1]
        old = [x for x in self.samples if t - x[0] >= 600]
        return {"cloud": round(cloud, 2), "cloud_trend_10min": round(cloud - old[-1][2], 2) if old else None,
                "dry_eta_min": round(self.dry_eta) if getattr(self, "dry_eta", None) is not None else None}

    def proactive(self, adv: WeatherAdvice, t: float) -> Optional[str]:
        """Komunikat bez pytania: tylko gdy coś się zmienia (raz na zdarzenie, z przerwą)."""
        def once(key: str, gap: float) -> bool:
            last = self._said.get(key)
            if last is not None and t - last < gap:
                return False
            self._said[key] = t
            return True

        if adv.action in ("zjedź teraz", "na najbliższym postoju") and once("change_" + adv.action, 600):
            other = "slicki" if adv.on_wets else "deszczowe"
            if adv.action == "zjedź teraz":
                return f"Zjedź teraz na {other}, zysk {_s(adv.gain_per_lap)} s na okrążenie."
            return f"Na postoju {other}."
        if adv.rain > 0.1 and adv.wetness < 0.05 and not adv.on_wets and once("rain_start", 1800):
            return "Tor jeszcze suchy, zostań na slickach."
        if adv.trend_per_lap < -0.02 and adv.on_wets and once("drying", 900):
            return "Tor wysycha, jedź suchą linią."
        if adv.track_temp_trend_h is not None and abs(adv.track_temp_trend_h) >= 5 and once("temp", 3600):
            return ("Tor się schładza, ciśnienia spadną." if adv.track_temp_trend_h < 0
                    else "Tor się nagrzewa, pilnuj tylnych opon.")
        return None

    def describe(self) -> str:
        a = self.last
        if a is None:
            return "brak danych o pogodzie"
        parts = [f"deszcz {a.rain * 100:.0f}%, wilgotność toru {a.wetness * 100:.0f}%"]
        sky = self.sky()
        if sky.get("cloud") is not None:
            parts.append(f"chmury {sky['cloud'] * 100:.0f}%"
                         + (f" ({sky['cloud_trend_10min'] * 100:+.0f} pkt w 10 min)" if sky.get("cloud_trend_10min") else ""))
        if abs(a.trend_per_lap) >= 0.005:
            parts.append(("rośnie" if a.trend_per_lap > 0 else "spada")
                         + f" o {abs(a.trend_per_lap) * 100:.1f} pkt na okrążenie")
        parts.append("na deszczowych" if a.on_wets else "na slickach")
        if a.current_loss is not None:
            parts.append(f"strata do suchego tempa {a.current_loss:.1f} s")
        if a.text:
            parts.append(a.text)
        if a.track_temp_trend_h is not None:
            parts.append(f"temperatura toru {a.track_temp:.0f}°C, zmiana {a.track_temp_trend_h:+.0f}°C/h")
        if a.lap_trend is not None:
            parts.append(f"tempo na czystych okrążeniach zmienia się o {a.lap_trend:+.2f} s/okr.")
        return "; ".join(parts)
