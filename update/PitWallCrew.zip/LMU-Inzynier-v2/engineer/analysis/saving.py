"""Oszczędzanie energii (albo paliwa), żeby zrobić o jeden postój mniej.

Liczymy, ile postojów potrzeba do mety przy obecnym zużyciu (każdy postój = pełne uzupełnienie).
Jeśli zmniejszenie zużycia o najwyżej kilka procent zabiera jeden postój, inżynier podaje cel na
okrążenie i pilnuje go: po każdym okrążeniu porównuje zużycie z celem. Cel przelicza na bieżąco
z tego, co zostało w baku i ile okrążeń do mety. Gdy oszczędzanie przestaje być potrzebne albo
możliwe – mówi, żeby jechać normalnie.
"""

from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Optional

MAX_SAVE = 0.06        # więcej niż 6% oszczędzania na okrążenie kosztuje zbyt dużo tempa
MARGIN_LAPS = 0.3      # zapas na końcu (część okrążenia)
TIP = "Zdejmuj gaz chwilę przed hamowaniem na końcu długich prostych."


@dataclass
class SaveState:
    goal_stops: int            # ile postojów do mety chcemy zrobić
    baseline: float            # zużycie na okrążenie bez oszczędzania (jednostki: ułamek energii albo litry)
    target: float              # aktualny cel na okrążenie
    unit_ve: bool
    gain_s: float


def _units(fr):
    """(zużycie na okrążenie, ile jest teraz, pojemność, czy energia)"""
    if fr.ve is not None and fr.ve_per_lap:
        return fr.ve_per_lap, fr.ve, 1.0, True
    if fr.per_lap_l and fr.capacity_l:
        return fr.per_lap_l, fr.fuel_l, fr.capacity_l, False
    return None


def stops_needed(per: float, now: float, tank: float, ltf: float) -> int:
    need = (ltf + MARGIN_LAPS) * per - now
    return 0 if need <= 0 else math.ceil(need / tank - 1e-9)


def required_per_lap(goal: int, now: float, tank: float, ltf: float) -> float:
    return (goal * tank + now) / (ltf + MARGIN_LAPS)


def fmt(v: float, ve: bool) -> str:
    return (f"{v * 100:.1f}".replace(".", ",") + "%") if ve else (f"{v:.2f}".replace(".", ",") + " l")


class SaveCoach:
    def __init__(self) -> None:
        self.state: Optional[SaveState] = None
        self._laps_over = 0
        self._praised = False

    def reset(self) -> None:
        self.state = None
        self._laps_over = 0
        self._praised = False

    def text(self) -> str:
        """Do planu na ścianie boksów i odpowiedzi o strategię."""
        s = self.state
        if s is None:
            return ""
        what = "bez postoju do mety" if s.goal_stops == 0 else "o jeden postój mniej"
        return f"Oszczędzanie: cel {fmt(s.target, s.unit_ve)} na okrążenie ({what})."

    def on_lap(self, fr, ltf: Optional[float], lane_loss_s: float, last_used: Optional[float]) -> list[str]:
        """Wywoływane po każdym okrążeniu wyścigu. Zwraca komunikaty dla kierowcy."""
        if fr is None or ltf is None or ltf <= 1.0:
            if self.state is not None:
                self.reset()
            return []
        u = _units(fr)
        if u is None:
            return []
        per, now, tank, ve = u
        out: list[str] = []
        s = self.state
        if s is None:
            cur = stops_needed(per, now, tank, ltf)
            if cur == 0:
                return []
            goal = cur - 1
            req = required_per_lap(goal, now, tank, ltf)
            save = 1 - req / per
            if 0 < save <= MAX_SAVE:
                target = req * 0.995           # mały zapas
                gain = lane_loss_s
                self.state = SaveState(goal, per, target, ve, gain)
                self._laps_over, self._praised = 0, False
                what = "dojedziesz do mety bez postoju" if goal == 0 else "do mety o jeden postój mniej"
                out.append(f"Oszczędzaj: {fmt(target, ve)} zamiast {fmt(per, ve)} na okrążenie, "
                           f"wtedy {what}, zysk około {gain:.0f} sekund. {TIP}")
            return out
        # oszczędzanie trwa: przelicz cel z tego, co jest w baku
        req = required_per_lap(s.goal_stops, now, tank, ltf)
        s.target = req * 0.995
        if req >= s.baseline:
            out.append("Oszczędzanie wystarczy, jedź normalnie.")
            self.reset()
            return out
        if 1 - req / s.baseline > MAX_SAVE + 0.02:
            out.append("Nie damy rady zaoszczędzić postoju, jedź normalnie.")
            self.reset()
            return out
        if last_used is not None and last_used > 0:
            if last_used > s.target * 1.015:
                self._laps_over += 1
                if self._laps_over in (1, 3) or self._laps_over % 4 == 0:
                    out.append(f"Za dużo: {fmt(last_used, s.unit_ve)}, cel {fmt(s.target, s.unit_ve)}. Oszczędzaj trochę więcej.")
            else:
                if self._laps_over or not self._praised:
                    out.append(f"Dobrze, {fmt(last_used, s.unit_ve)}, cel {fmt(s.target, s.unit_ve)}.")
                    self._praised = True
                self._laps_over = 0
        return out
