"""Strateg: kiedy zjechać, ile zatankować, które opony zmienić, czy naprawiać uszkodzenia, gdzie wyjedziesz.

Czasy postoju (przejazd aleją, tankowanie, zmiana opony) mają wartości startowe z konfiguracji,
a program poprawia je sam po każdym Twoim postoju (zapis per tor i auto).
"""

from __future__ import annotations

import json
import math
import os
from dataclasses import dataclass, field
from typing import Optional

from ..plnum import ordinal
from ..model import Snapshot
from .fuel import FuelReport, fuel_report
from .laps import LapTrace, safe_name

WHEELS = ["lewa przednia", "prawa przednia", "lewa tylna", "prawa tylna"]
OPTIONS = {
    "bez zmiany opon": (),
    # tylko przód albo tylko tył zaburza balans auta – zmieniamy wszystkie albo jedną stronę
    "lewe": (0, 2),
    "prawe": (1, 3),
    "wszystkie cztery": (0, 1, 2, 3),
}


# ----------------------------------------------------------------------------- model postoju
@dataclass
class PitParams:
    lane_loss_s: float = 30.0        # strata na przejazd aleją (bez postoju)
    refuel_l_per_s: float = 2.5      # tankowanie paliwa
    ve_pct_per_s: float = 3.0        # uzupełnianie energii (punkty procentowe na sekundę)
    tyre_s: float = 6.0              # zmiana jednej opony
    base_s: float = 2.0              # zatrzymanie i ruszenie
    fcy_factor: float = 0.45         # pod FCY strata na aleję jest mniejsza (wszyscy jadą wolno)
    pit_entry_m: float = 0.0         # gdzie na okrążeniu zaczyna się aleja (zmierzone przy wjeździe), 0 = nie wiadomo
    tyre_fixed: bool = False         # czas zmiany opon podany przez zespół – nie zgadujemy go z postojów
    tyres_parallel: Optional[bool] = None   # gra zmienia opony w trakcie tankowania (z szacunku postoju w grze)
    learned: list = field(default_factory=list)

    def sanitize(self) -> None:
        """Odrzuca bzdurne wartości (np. nauczone z wizyty w garażu w treningu) – wraca do startowych."""
        d = PitParams()
        if not 10 <= self.lane_loss_s <= 90:
            self.lane_loss_s = d.lane_loss_s
        if not 0.5 <= self.refuel_l_per_s <= 10:
            self.refuel_l_per_s = d.refuel_l_per_s
        if not 0.5 <= self.ve_pct_per_s <= 10:
            self.ve_pct_per_s = d.ve_pct_per_s
        if not 1.5 <= self.tyre_s <= 15:
            self.tyre_s = d.tyre_s
        self.learned = [x for x in (self.learned or []) if 3 <= x.get("stop_s", 0) <= 150
                        and 15 <= x.get("lane_s", 0) <= 300][-20:]

    def stationary(self, fuel_l: float, ve_pct: float, tyres: int, repair_s: float = 0.0) -> float:
        refuel = max(fuel_l / self.refuel_l_per_s if fuel_l > 0 else 0.0,
                     ve_pct / self.ve_pct_per_s if ve_pct > 0 else 0.0)
        if self.tyres_parallel:
            return self.base_s + max(refuel, tyres * self.tyre_s) + repair_s
        return self.base_s + refuel + tyres * self.tyre_s + repair_s


class PitLearner:
    """Mierzy Twoje postoje i poprawia parametry."""

    def __init__(self) -> None:
        self._in = False
        self._t_in = 0.0
        self._d_in = 0.0
        self._stop_s = 0.0
        self._fuel0 = self._fuel_max = 0.0
        self._ve0 = self._ve_max = 0.0
        self._wear0: list[float] = []
        self._last_t: Optional[float] = None

    def update(self, snap: Snapshot, params: PitParams, ref: Optional[LapTrace]) -> Optional[str]:
        p, me = snap.player, snap.player_scoring()
        if p is None or me is None:
            return None
        dt = 0.0 if self._last_t is None else max(0.0, min(1.0, snap.t - self._last_t))
        self._last_t = snap.t
        if p.in_pits and not self._in:
            self._in, self._t_in, self._d_in, self._stop_s = True, snap.t, me.lap_dist, 0.0
            # gra zgłasza „w alei” dopiero kawałek za białą linią wjazdu (Le Mans: ~700 m) – zapas 800 m;
            # dokładne miejsce i tak bierzemy z interfejsu gry, gdy działa
            if snap.track_length > 0 and me.lap_dist > snap.track_length * 0.5 and not params.pit_entry_m:
                params.pit_entry_m = round(max(snap.track_length * 0.5, me.lap_dist - 800), 0)
            self._fuel0 = self._fuel_max = p.fuel_l
            self._ve0 = self._ve_max = p.virtual_energy or 0.0
            self._wear0 = [t.wear for t in p.tyres]
            return None
        if self._in and p.in_pits:
            if p.speed_kmh < 1.0:
                self._stop_s += dt
            self._fuel_max = max(self._fuel_max, p.fuel_l)
            self._ve_max = max(self._ve_max, p.virtual_energy or 0.0)
            return None
        if self._in and not p.in_pits:
            self._in = False
            lane = snap.t - self._t_in
            fuel = max(0.0, self._fuel_max - self._fuel0)
            ve = max(0.0, self._ve_max - self._ve0) * 100
            changed = sum(1 for w0, t in zip(self._wear0, p.tyres) if w0 - t.wear > 0.03)
            if self._stop_s < 3:
                return None  # przejazd bez zatrzymania (np. kara drive-through) — nie uczymy się z tego
            if snap.session != "race" or self._stop_s > 150 or not (15 < lane < 300):
                return None  # wizyta w garażu, powrót do boksu w treningu itp. — nie jest to postój wyścigowy
            # strata na aleję = czas w alei - postój - czas, jaki ten odcinek zajmuje w tempie wyścigowym
            if ref is not None and ref.t and snap.track_length == ref.track_length:
                n = len(ref.t)
                t_ref = ref.t[min(n - 1, int(me.lap_dist / 5))] - ref.t[min(n - 1, int(self._d_in / 5))]
                if t_ref < 0:
                    t_ref += ref.lap_time
                lane_loss = lane - self._stop_s - t_ref
                if 5 < lane_loss < 90:
                    params.lane_loss_s = round(0.5 * params.lane_loss_s + 0.5 * lane_loss, 1) \
                        if params.learned else round(lane_loss, 1)
            service = self._stop_s - params.base_s
            if changed == 0 and (fuel > 2 or ve > 2) and service > 1:
                if ve > 2:      # auto z energią: czas tankowania wyznacza energia (paliwo leci razem z nią)
                    params.ve_pct_per_s = round(ve / service, 2)
                else:
                    params.refuel_l_per_s = round(fuel / service, 2)
            elif changed and service > 1 and params.tyre_fixed:
                # czas opon znany: reszta postoju to tankowanie / energia
                fill = service - changed * params.tyre_s
                if fill > 1:
                    if ve > 2:
                        params.ve_pct_per_s = round(ve / fill, 2)
                    elif fuel > 2:
                        params.refuel_l_per_s = round(fuel / fill, 2)
            elif changed and service > 1:
                refuel = max(fuel / params.refuel_l_per_s, ve / params.ve_pct_per_s)
                per = (service - refuel) / changed
                if 1.5 < per < 30:
                    params.tyre_s = round(per, 1)
                else:
                    # jeden postój z tankowaniem i oponami nie pozwala rozdzielić obu czasów:
                    # skalujemy oba tak, żeby suma zgadzała się z pomiarem
                    predicted = refuel + changed * params.tyre_s
                    if predicted > 0:
                        f = service / predicted
                        params.tyre_s = round(params.tyre_s * f, 1)
                        params.refuel_l_per_s = round(params.refuel_l_per_s / f, 2)
                        params.ve_pct_per_s = round(params.ve_pct_per_s / f, 2)
            params.learned.append({"stop_s": round(self._stop_s, 1), "lane_s": round(lane, 1), "fuel": round(fuel, 1),
                                   "ve": round(ve, 1), "tyres": changed})
            params.sanitize()
            return (f"Postój {self._stop_s:.0f} sekund, cały przejazd aleją {lane:.0f} sekund. "
                    f"Zapamiętałem czasy do kolejnych planów.")
        return None


# ----------------------------------------------------------------------------- opony
@dataclass
class TyreAdvice:
    option: str
    reason: str
    wear_now: list[float]
    wear_rate: list[float]
    deg_s_per_lap: Optional[float]
    stint_laps: int


def _stint_laps(laps: list[LapTrace]) -> list[LapTrace]:
    """Okrążenia od ostatniej zmiany opon."""
    out: list[LapTrace] = []
    prev = None
    for l in laps:
        if not l.wear_tyres:
            continue
        if prev is not None and any(p - w > 0.03 for p, w in zip(prev, l.wear_tyres)):
            out = []
        out.append(l)
        prev = l.wear_tyres
    return out


def degradation(stint: list[LapTrace], fuel_s_per_l: float) -> Optional[float]:
    """Ile sekund na okrążenie przybywa z każdym okrążeniem na tych oponach (z poprawką na spalone paliwo)."""
    pts = []
    burned = 0.0
    for k, l in enumerate(stint):
        burned += max(0.0, l.fuel_used)
        if l.clean and not l.impact:
            pts.append((k, l.lap_time + fuel_s_per_l * burned))
    if len(pts) < 4:
        return None
    best = min(y for _, y in pts)
    pts = [(x, y) for x, y in pts if y < best + 2.0]
    if len(pts) < 4:
        return None
    mx = sum(x for x, _ in pts) / len(pts)
    my = sum(y for _, y in pts) / len(pts)
    den = sum((x - mx) ** 2 for x, _ in pts)
    if den == 0:
        return None
    slope = sum((x - mx) * (y - my) for x, y in pts) / den
    return max(0.0, min(0.5, slope))


# gdy spadku tempa na zużytych oponach nie da się jeszcze zmierzyć: typowo dla GT3 ok. 0,03 s na okrążenie
# z każdym okrążeniem wieku opony
DEFAULT_DEG = 0.03


def tyre_advice(laps: list[LapTrace], stint_left: float, next_stint: float, params: PitParams,
                max_wear: float, fuel_s_per_l: float, tyre_cost=None,
                new_available: Optional[bool] = None) -> Optional[TyreAdvice]:
    """Które opony zmienić. tyre_cost(n) = o ile dłużej stoi auto przy zmianie n opon (z tankowaniem
    równolegle może być 0). new_available=False: w menu boksu nie ma już nowych opon."""
    stint = _stint_laps(laps)
    if len(stint) < 2:
        return None
    wear_now = stint[-1].wear_tyres
    n = len(stint) - 1
    wear_rate = [max(0.0, (stint[-1].wear_tyres[i] - stint[0].wear_tyres[i]) / n) for i in range(4)]
    slope = degradation(stint, fuel_s_per_l)
    deg = slope if slope is not None else DEFAULT_DEG
    age_at_stop = len(stint) + stint_left
    best = None
    for name, changed in OPTIONS.items():
        if changed and new_available is False:
            continue
        ok = True
        for i in range(4):
            if i in changed:
                continue
            w_end = wear_now[i] + wear_rate[i] * (stint_left + next_stint)
            if w_end > max_wear:
                ok = False
        if not ok:
            continue
        old = 4 - len(changed)
        pace_loss = max(0.0, deg) * next_stint * (old * age_at_stop) / 4
        cost = (tyre_cost(len(changed)) if tyre_cost else len(changed) * params.tyre_s) + pace_loss
        if best is None or cost < best[0] - 0.01:
            best = (cost, name, changed, pace_loss)
    if best is None and new_available is False:
        return TyreAdvice("bez zmiany opon", "w menu boksu nie ma już nowych opon", wear_now, wear_rate, slope, len(stint))
    if best is None:
        return TyreAdvice("wszystkie cztery", "bez zmiany opony nie dojadą do końca kolejnego stintu",
                          wear_now, wear_rate, slope, len(stint))
    cost, name, changed, pace_loss = best
    if not changed:
        reason = "zużycie pozwala dojechać do końca następnego stintu"
        if slope:
            reason += f", a zmiana kosztowałaby więcej niż spadek tempa ({slope:.2f} s na okrążenie z każdym okrążeniem)"
    else:
        worst = max(range(4), key=lambda i: wear_now[i] + wear_rate[i] * (stint_left + next_stint))
        w_end = wear_now[worst] + wear_rate[worst] * (stint_left + next_stint)
        reason = f"najbardziej zużywa się {WHEELS[worst]}, bez zmiany zostałoby jej {max(0.0, 1 - w_end) * 100:.0f} procent"
        if len(changed) < 4:
            extra = (tyre_cost(4) - tyre_cost(len(changed))) if tyre_cost else (4 - len(changed)) * params.tyre_s
            reason += f"; zmiana jednej strony zamiast czterech oszczędza około {extra:.0f} sekund postoju"
        elif tyre_cost and tyre_cost(4) < 1:
            reason += "; zmiana mieści się w czasie tankowania"
    return TyreAdvice(name, reason, wear_now, wear_rate, slope, len(stint))


# ----------------------------------------------------------------------------- uszkodzenia
@dataclass
class DamageReport:
    lap: int                    # okrążenie z uderzeniem
    loss_per_lap: Optional[float]
    laps_measured: int
    damage_level: int


def damage_report(laps: list[LapTrace], fuel_s_per_l: float) -> Optional[DamageReport]:
    idx = None
    for k in range(len(laps) - 1, -1, -1):
        l = laps[k]
        prev_dmg = laps[k - 1].damage_end if k > 0 else 0
        if l.impact or l.damage_end > prev_dmg:
            idx = k
            break
    if idx is None:
        return None
    # uszkodzenie naprawione w boksie = brak uszkodzenia
    if laps[-1].damage_end == 0 and not laps[-1].impact and idx < len(laps) - 1:
        return None
    before = [l for l in laps[:idx] if l.clean and not l.pit][-3:]
    # po uderzeniu bierzemy okrążenia do najbliższego postoju (te same opony i podobny bak)
    after: list[LapTrace] = []
    for l in laps[idx + 1:]:
        if l.pit:
            if len(after) >= 2:
                break
            after = []
            continue
        if l.clean and not l.impact:
            after.append(l)
    level = laps[-1].damage_end
    if len(after) < 2 or not before:
        return DamageReport(laps[idx].lap, None, len(after), level)
    after = after[:3]
    b = sum(l.lap_time for l in before) / len(before)
    a = sum(l.lap_time for l in after) / len(after)
    # poprawka na różnicę w ilości paliwa (cięższe auto jest wolniejsze)
    fb = sum(l.fuel_start for l in before) / len(before)
    fa = sum(l.fuel_start for l in after) / len(after)
    loss = a - b - fuel_s_per_l * (fa - fb)
    # poprawka na zużycie opon między pomiarami (gdy to ten sam komplet opon)
    stint_before = _stint_laps(laps[:idx])
    slope = degradation(stint_before, fuel_s_per_l) if len(stint_before) >= 4 else None
    same_set = all(not l.pit for l in laps[idx - len(before):idx + 1 + len(after)]) if before else False
    if slope and same_set:
        age_gap = sum(l.lap for l in after) / len(after) - sum(l.lap for l in before) / len(before)
        loss -= slope * age_gap
    return DamageReport(laps[idx].lap, max(0.0, loss), len(after), level)


# ----------------------------------------------------------------------------- plan
@dataclass
class StrategyPlan:
    stop_needed: bool
    laps_to_stop: Optional[int]
    fuel_add_l: float
    ve_target_pct: Optional[float]
    tyres: Optional[TyreAdvice]
    damage: Optional[DamageReport]
    repair_s: Optional[float]
    repair_worth: Optional[bool]
    stationary_s: float
    total_loss_s: float
    rejoin: str
    two_stops: bool
    notes: list[str] = field(default_factory=list)
    rejoin_pos: Optional[int] = None
    outline: str = ""            # plan do mety: liczba postojów i długości stintów

    def speech(self) -> str:
        parts = []
        if not self.stop_needed:
            parts.append("Do mety bez postoju")
        elif self.laps_to_stop is not None:
            if self.laps_to_stop <= 0:
                parts.append("Zjeżdżaj na tym okrążeniu")
            else:
                n = self.laps_to_stop
                w = "okrążenie" if n == 1 else ("okrążenia" if n % 10 in (2, 3, 4) and n % 100 not in (12, 13, 14) else "okrążeń")
                parts.append(f"Zjazd za {n} {w}")
        if self.stop_needed:
            fuel = []
            if self.fuel_add_l > 0.5:
                fuel.append(f"zatankuj {self.fuel_add_l:.0f} litrów")
            if self.ve_target_pct is not None:
                fuel.append("energia do pełna" if self.ve_target_pct >= 99 else f"energia do {self.ve_target_pct:.0f} procent")
            if fuel:
                parts.append(", ".join(fuel))
            if self.two_stops and not self.outline:
                parts.append("do mety potrzebne będą jeszcze co najmniej dwa postoje")
            if self.tyres:
                opt = self.tyres.option
                parts.append("opony zostają" if opt == "bez zmiany opon" else
                             ("zmień wszystkie cztery opony" if opt == "wszystkie cztery" else f"zmień {opt} opony"))
            if self.repair_worth is not None:
                parts.append("naprawa się opłaca" if self.repair_worth else "naprawa się nie opłaca")
            parts.append(f"postój około {self.stationary_s:.0f} sekund, razem z aleją {self.total_loss_s:.0f}")
            if self.rejoin:
                parts.append(self.rejoin)
        txt = ". ".join(p[0].upper() + p[1:] for p in parts if p) + "."
        return txt

    def short(self) -> str:
        """Wersja radiowa (bez pytania): kiedy zjazd, co na postoju, gdzie wyjedziesz."""
        if not self.stop_needed or self.laps_to_stop is None:
            return ""
        n = self.laps_to_stop
        w = "okrążenie" if n == 1 else ("okrążenia" if n % 10 in (2, 3, 4) and n % 100 not in (12, 13, 14) else "okrążeń")
        parts = [f"Zjazd za {n} {w}" if n > 0 else "Zjazd w tym okrążeniu"]
        what = []
        if self.ve_target_pct is not None:
            what.append("energia do pełna" if self.ve_target_pct >= 99 else f"energia {self.ve_target_pct:.0f}%")
        elif self.fuel_add_l > 0.5:
            what.append(f"paliwo {self.fuel_add_l:.0f} l")
        if self.tyres:
            opt = self.tyres.option
            what.append("bez opon" if opt == "bez zmiany opon" else
                        ("cztery opony" if opt == "wszystkie cztery" else f"{opt} opony"))
        if self.repair_worth:
            what.append("naprawa")
        if what:
            parts.append(", ".join(what))
        if self.rejoin_pos:
            parts.append(f"wyjazd na P{self.rejoin_pos}")
        return ". ".join(p[0].upper() + p[1:] for p in parts) + "."

    def describe(self) -> str:
        lines = [self.speech()]
        if self.tyres:
            t = self.tyres
            wear = ", ".join(f"{w} {x * 100:.0f}% (+{r * 100:.1f}/okr.)" for w, x, r in zip(WHEELS, t.wear_now, t.wear_rate))
            deg = f"{t.deg_s_per_lap:.2f} s/okr. na okrążenie" if t.deg_s_per_lap is not None else "za mało okrążeń"
            lines.append(f"OPONY: {t.option} — {t.reason}. Zużycie: {wear}. Degradacja tempa: {deg}. "
                         f"Okrążeń na tych oponach: {t.stint_laps}.")
        if self.damage:
            d = self.damage
            if d.loss_per_lap is None:
                lines.append(f"USZKODZENIE: uderzenie na okrążeniu {d.lap}, poziom {d.damage_level}; za mało okrążeń po nim, "
                             f"żeby zmierzyć stratę ({d.laps_measured}/2).")
            else:
                lines.append(f"USZKODZENIE: od okrążenia {d.lap} tracisz około {d.loss_per_lap:.2f} s na okrążenie. "
                             + (f"Czas naprawy {self.repair_s:.0f} s." if self.repair_s else "Czas naprawy nieznany "
                                "(kierowca może go podać: 'naprawa trwa 40 sekund')."))
        lines += self.notes
        return "\n".join(lines)


def _laps_w(n: int) -> str:
    if n == 1:
        return "okrążenie"
    return "okrążenia" if n % 10 in (2, 3, 4) and n % 100 not in (12, 13, 14) else "okrążeń"


def _stops_word(n: int) -> str:
    if n == 1:
        return "postój"
    return "postoje" if n % 10 in (2, 3, 4) and n % 100 not in (12, 13, 14) else "postojów"


def race_outline(ltf, stop_needed, laps_to_stop, full_stint, ve_per_lap, fuel_per_lap, capacity, margin) -> str:
    """Plan do mety liczony z czasu do końca wyścigu (gra) i prawdziwego zużycia: postoje i długości stintów."""
    if ltf is None:
        return ""
    total = int(round(ltf))
    if not stop_needed:
        return f"Do mety {total} {_laps_w(total)}, bez postoju."
    if not full_stint or laps_to_stop is None:
        return ""
    first = laps_to_stop + 1
    rest = max(0.0, ltf - first)
    per = max(1, math.floor(full_stint - 0.3))
    k = max(1, math.ceil(rest / per - 1e-6))
    base, extra = divmod(int(math.ceil(rest)), k)
    stints = [base + (1 if i < extra else 0) for i in range(k)]
    txt = f"Do mety {total} {_laps_w(total)}, {k} {_stops_word(k)}. Stinty: {first} teraz"
    txt += "".join(f", {s}" for s in stints) + "."
    return txt


class Strategist:
    def __init__(self, cfg: Optional[dict] = None, data_dir: str = "data") -> None:
        cfg = cfg or {}
        self.cfg = cfg
        self.data_dir = data_dir
        self.max_wear = float(cfg.get("tyre_max_wear", 0.75))
        self.new_tyres: Optional[bool] = None   # z menu boksu: czy są jeszcze nowe opony (None = nie wiadomo)
        self.fuel_s_per_l = float(cfg.get("fuel_s_per_litre", 0.025))
        self.params = PitParams(
            lane_loss_s=float(cfg.get("pit_lane_loss_s", 30.0)), refuel_l_per_s=float(cfg.get("refuel_l_per_s", 2.5)),
            ve_pct_per_s=float(cfg.get("ve_pct_per_s", 3.0)), tyre_s=float(cfg.get("tyre_change_s", 6.0)),
        )
        # czas zmiany kompletu 4 nowych opon (zmierzony przez zespół): 12 s
        self.tyre_set_s = float(cfg.get("tyre_set_s", 12.0)) if cfg.get("tyre_set_s", 12.0) else None
        self._fix_tyres()
        self.learner = PitLearner()
        self.repair_s: Optional[float] = None
        self._key: Optional[tuple] = None
        self._announced_stint: Optional[int] = None
        self._damage_announced: Optional[int] = None

    def _fix_tyres(self) -> None:
        if self.tyre_set_s:
            self.params.tyre_s = self.tyre_set_s / 4
            self.params.tyre_fixed = True

    # -- zapis nauczonych parametrów per tor i auto
    def _path(self, track: str, car: str) -> str:
        return os.path.join(self.data_dir, safe_name(track), safe_name(car), "pit.json")

    def new_session(self, snap: Snapshot) -> None:
        self._key = (snap.track, snap.car_name)
        self.repair_s = None
        self._announced_stint = None
        self._damage_announced = None
        path = self._path(*self._key)
        if os.path.exists(path):
            try:
                with open(path, encoding="utf-8") as f:
                    d = json.load(f)
                for k, v in d.items():
                    if hasattr(self.params, k):
                        setattr(self.params, k, v)
                self.params.sanitize()
            except (OSError, ValueError):
                pass
        self._fix_tyres()

    def _save(self) -> None:
        if not self._key:
            return
        path = self._path(*self._key)
        os.makedirs(os.path.dirname(path), exist_ok=True)
        with open(path, "w", encoding="utf-8") as f:
            json.dump(self.params.__dict__, f, indent=1)

    def update(self, snap: Snapshot, ref: Optional[LapTrace]) -> Optional[str]:
        msg = self.learner.update(snap, self.params, ref)
        if msg:
            self._save()
        return msg

    # -- plan
    def plan(self, snap: Snapshot, laps: list[LapTrace], rivals, fuel_margin: float, will_pit=None) -> Optional[StrategyPlan]:
        p = snap.player
        if p is None:
            return None
        fr: Optional[FuelReport] = fuel_report(snap, laps, fuel_margin)
        if fr is None or fr.stint_laps_left is None:
            return None
        ltf = fr.laps_to_finish
        stint_left = fr.stint_laps_left
        stop_needed = ltf is None or stint_left < ltf + 0.2
        # stint_left liczone od bieżącego miejsca: najpierw trzeba dojechać do końca tego okrążenia,
        # dopiero reszta to pełne okrążenia przed zjazdem (np. 1,57 na starcie okrążenia = zjazd na końcu tego).
        ps0 = snap.player_scoring()
        frac = (ps0.lap_dist / snap.track_length) if (ps0 is not None and snap.track_length > 0) else 0.0
        frac = min(max(frac, 0.0), 1.0)
        laps_to_stop = max(0, math.floor(stint_left - (1.0 - frac) - 0.3)) if stop_needed else None
        to_stop = (laps_to_stop or 0) + (1.0 - frac)     # okrążenia jazdy do chwili zjazdu

        # paliwo i energia na postoju (szacunek stanu w chwili zjazdu)
        fuel_add, ve_target, two = 0.0, None, False
        after = max(0.0, (ltf - to_stop) if ltf is not None else 0.0)
        if stop_needed and ltf is not None:
            if fr.per_lap_l:
                fuel_at_stop = max(0.0, p.fuel_l - fr.per_lap_l * to_stop)
                need = (after + fuel_margin) * fr.per_lap_l
                cap_room = (fr.capacity_l or need) - fuel_at_stop
                fuel_add = max(0.0, min(need - fuel_at_stop, cap_room))
                two = need - fuel_at_stop > cap_room + 0.5
            if fr.ve_per_lap and fr.ve is not None:
                ve_at_stop = max(0.0, fr.ve - fr.ve_per_lap * to_stop)
                target = min(1.0, ve_at_stop + (after + fuel_margin) * fr.ve_per_lap)
                ve_target = target * 100
                two = two or (after + fuel_margin) * fr.ve_per_lap > 1.0
        elif stop_needed:   # trening / brak informacji o mecie: do pełna
            if fr.per_lap_l:
                fuel_add = max(0.0, (fr.capacity_l or 0) - max(0.0, p.fuel_l - fr.per_lap_l * to_stop))
            if fr.ve is not None:
                ve_target = 100.0

        # Auta z wirtualną energią (GT3/Hypercar w LMU): paliwo tankuje się razem z energią (przelicznik
        # FUEL RATIO w menu boksu), więc o ilości decyduje tylko energia (najwyżej 100%). Litrów nie podajemy.
        has_ve = fr.ve is not None and bool(fr.ve_per_lap)
        if has_ve:
            fuel_add = 0.0
            two = stop_needed and ltf is not None and (after + fuel_margin) * fr.ve_per_lap > 1.0

        # długość następnego stintu (do mety albo do pełnego baku)
        full_stint = None
        if fr.per_lap_l and fr.capacity_l and not has_ve:
            full_stint = fr.capacity_l / fr.per_lap_l
        if fr.ve_per_lap:
            full_stint = min(full_stint or 1e9, 1.0 / fr.ve_per_lap)
        next_stint = min(after, full_stint) if (ltf is not None and full_stint) else (full_stint or 10)

        ve_add0 = 0.0
        if ve_target is not None and fr.ve is not None and fr.ve_per_lap:
            ve_add0 = max(0.0, ve_target - (fr.ve - fr.ve_per_lap * to_stop) * 100)
        base0 = self.params.stationary(fuel_add, ve_add0, 0)
        tyre_cost = lambda n: self.params.stationary(fuel_add, ve_add0, n) - base0
        tyres = tyre_advice(laps, to_stop, next_stint, self.params, self.max_wear, self.fuel_s_per_l,
                            tyre_cost, self.new_tyres) if stop_needed else None
        dmg = damage_report(laps, self.fuel_s_per_l)
        repair_worth = None
        if dmg and dmg.loss_per_lap is not None and self.repair_s and ltf is not None:
            gain = dmg.loss_per_lap * max(0.0, ltf - to_stop)
            cost = self.repair_s + (0 if stop_needed else self.params.lane_loss_s)
            repair_worth = gain > cost

        n_tyres = len(OPTIONS[tyres.option]) if tyres else 0
        ve_add = 0.0
        if ve_target is not None and fr.ve is not None and fr.ve_per_lap:
            ve_add = max(0.0, ve_target - (fr.ve - fr.ve_per_lap * to_stop) * 100)
        stationary = self.params.stationary(fuel_add, ve_add, n_tyres, self.repair_s if repair_worth else 0.0)
        total = stationary + self.params.lane_loss_s
        # rywale, którzy i tak zjadą przed nami albo razem z nami, nie wyprzedzą nas na postoju
        skip = (lambda c: c.in_pits or (will_pit is not None and will_pit(c, (laps_to_stop or 0) + 1)))
        rejoin, rpos = self._rejoin(snap, rivals, total, skip) if (stop_needed and snap.session == "race") else ("", None)

        notes = [f"POSTÓJ (parametry {'zmierzone' if self.params.learned else 'startowe z konfiguracji'}): "
                 f"aleja {self.params.lane_loss_s:.0f} s, tankowanie {self.params.refuel_l_per_s:.1f} l/s, "
                 f"energia {self.params.ve_pct_per_s:.1f} %/s, komplet opon {self.params.tyre_s * 4:.0f} s."]
        outline = race_outline(ltf, stop_needed, laps_to_stop, full_stint, fr.ve_per_lap, fr.per_lap_l,
                               fr.capacity_l, fuel_margin)
        return StrategyPlan(stop_needed, laps_to_stop, fuel_add, ve_target, tyres, dmg, self.repair_s, repair_worth,
                            stationary, total, rejoin, two, notes, rpos, outline)

    @staticmethod
    def _rejoin(snap: Snapshot, rivals, loss: float, skip=None) -> tuple[str, Optional[int]]:
        me = snap.player_scoring()
        if me is None or rivals is None:
            return "", None
        same = [c for c in snap.cars if c.car_class == me.car_class and not c.is_player and not (skip and skip(c))]
        gaps = []
        for c in same:
            g, laps_diff = rivals._gap(snap, me, c)
            if g is not None and laps_diff == 0:
                gaps.append((g, c))   # + = rywal za Tobą (sekundy)
        cp, _ = rivals.class_position(snap)
        passed = [(g, c) for g, c in gaps if 0 < g < loss]
        new_pos = cp + len(passed)
        ahead = max(passed, key=lambda x: x[0], default=None)        # ostatni, który Cię wyprzedzi
        behind = min([(g, c) for g, c in gaps if g >= loss], key=lambda x: x[0], default=None)
        txt = f"wyjedziesz na {ordinal(new_pos, 'n', 'loc')} miejscu w klasie"
        if ahead:
            txt += f", najbliżej przed Tobą {ahead[1].driver.split()[-1]}, około {loss - ahead[0]:.0f} sekund"
        elif behind:
            txt += f", najbliżej za Tobą {behind[1].driver.split()[-1]}, około {behind[0] - loss:.0f} sekund"
        return txt, new_pos
