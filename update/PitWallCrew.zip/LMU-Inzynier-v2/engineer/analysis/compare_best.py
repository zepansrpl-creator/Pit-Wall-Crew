"""Porównanie z najlepszym okrążeniem w zakrętach – konkretne liczby tuż przed zakrętem.

Po każdym czystym okrążeniu wybieramy zakręt z największą stratą do najlepszego okrążenia (≥ MIN_LOSS s),
w którym widać konkretną przyczynę (wcześniejsze hamowanie, mniejsza prędkość w środku, późniejszy gaz).
Wzorzec jest uczciwy dla opon i warunków (Engineer._fair_ref): najszybsze okrążenie z podobnym zużyciem opon,
paliwem, wilgotnością i temperaturą toru; gdy takiego nie ma – najlepsze z tego stintu i wtedy tylko uwagi o
technice (punkt hamowania, gaz), bez prędkości w zakręcie. Bez porównań w innych warunkach i przy oszczędzaniu.
Na następnym okrążeniu, ok. 2–3 s przed tym zakrętem, inżynier mówi np.:
„T5: hamujesz 15 metrów wcześniej niż na najlepszym.”
Najwyżej raz na okrążenie i tylko gdy trener (powtarzające się błędy) nic nie powiedział.
Ten sam zakręt najwcześniej po 3 okrążeniach (bez poprawy coraz rzadziej: 3, 6, 9…). Komendy: „porównanie” / „bez porównania”.
"""

from __future__ import annotations

from typing import Optional

MIN_LOSS = 0.2


def _round5(x: float) -> int:
    return int(5 * round(abs(x) / 5)) or 5


class BestCompare:
    def __init__(self, cfg: Optional[dict] = None) -> None:
        cfg = cfg or {}
        self.enabled = bool(cfg.get("compare_best", True))
        self.lead_s = float(cfg.get("coach_lead_s", 2.5))
        self.reset()

    def reset(self) -> None:
        self.pending: Optional[tuple[str, str]] = None    # (zakręt, tekst) na następne okrążenie
        self.lap_no = 0
        self._last: dict[str, tuple[int, int]] = {}       # zakręt -> (okrążenie, ile razy z rzędu)
        self._said_this_lap = False

    @staticmethod
    def phrase(d, speed_ok: bool = True) -> Optional[str]:
        """Najważniejsza konkretna przyczyna straty w zakręcie (CornerDelta) jako krótkie zdanie."""
        n = d.corner.name
        cands = []
        if d.brake_point_diff is not None and d.brake_point_diff <= -10:
            cands.append((abs(d.brake_point_diff) / 10,
                          f"{n}: hamujesz {_round5(d.brake_point_diff)} metrów wcześniej niż na najlepszym."))
        if speed_ok and d.min_speed_diff <= -4:
            cands.append((abs(d.min_speed_diff) / 4,
                          f"{n}: w środku o {round(abs(d.min_speed_diff))} km/h wolniej niż na podobnych oponach."))
        if d.throttle_point_diff is not None and d.throttle_point_diff >= 15:
            cands.append((d.throttle_point_diff / 15,
                          f"{n}: gaz {_round5(d.throttle_point_diff)} metrów później niż na najlepszym."))
        if not cands:
            return None
        return max(cands)[1]

    def end_lap(self, deltas: list, pit: bool, speed_ok: bool = True) -> None:
        self.lap_no += 1
        self._said_this_lap = False
        self.pending = None
        if pit or not deltas:
            return
        for d in sorted(deltas, key=lambda d: -d.time_loss):
            if d.time_loss < MIN_LOSS:
                break
            last = self._last.get(d.corner.name)
            if last is not None and self.lap_no - last[0] < 3 * last[1]:     # bez poprawy: coraz rzadziej
                continue
            txt = self.phrase(d, speed_ok)
            if txt:
                self.pending = (d.corner.name, txt)
                return

    def update(self, snap, corners, coach_said: bool, coach_corner=None) -> Optional[str]:
        if not self.enabled or self.pending is None or self._said_this_lap or coach_said:
            return None
        if coach_corner is not None and coach_corner(self.pending[0]):     # tym zakrętem zajmuje się trener
            self.pending = None
            return None
        p = snap.player
        if p is None or p.in_pits or p.speed_kmh < 60:
            return None
        name, txt = self.pending
        c = next((c for c in corners or [] if c.name == name), None)
        if c is None:
            self.pending = None
            return None
        L = snap.track_length or 0
        dist = c.start - p.lap_dist
        if L and dist < 0:
            dist += L
        t_to = dist / max(10.0, p.speed_kmh / 3.6)
        if not (1.0 <= t_to <= self.lead_s + 0.8):
            return None
        self.pending = None
        self._said_this_lap = True
        prev = self._last.get(name)
        self._last[name] = (self.lap_no, (prev[1] + 1) if prev else 1)
        return txt
