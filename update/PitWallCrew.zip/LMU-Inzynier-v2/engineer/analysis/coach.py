"""Trener na zakręty: krótka podpowiedź tuż przed zakrętem, w którym powtarza się błąd.

Źródła (dla każdego zakrętu, ostatnie 3 okrążenia):
- błędy z telemetrii (SuggestMonitor): blokowanie przodu / tyłu, buksowanie, ABS lub TC pracuje bardzo długo,
- porównanie z najlepszym okrążeniem (corners.compare): wcześniejsze hamowanie, mniejsza prędkość w zakręcie,
  późniejszy gaz, toczenie się bez gazu – tylko gdy strata w tym zakręcie ≥ 0,15 s.
Podpowiedź pada, gdy ten sam błąd był na 2 z 3 ostatnich okrążeń; najwyżej jedna na okrążenie, ten sam zakręt
najwcześniej co 3 okrążenia. Do 8 słów, ok. 2–3 s przed zakrętem. Gdy błąd zniknie na 2 okrążenia po podpowiedzi
– krótkie „T5 lepiej.” na końcu okrążenia.
"""

from __future__ import annotations

import collections
from typing import Optional

from .suggest import ABS_HEAVY, LOCK, LOCK_REAR, SPIN, TC_HEAVY

TIPS = {
    LOCK: "łagodniej pod koniec hamowania",
    LOCK_REAR: "tył blokuje, delikatniej z hamulcem",
    SPIN: "spokojniej z gazem na wyjściu",
    ABS_HEAVY: "lżej na hamulec, ABS cały czas",
    TC_HEAVY: "płynniej z gazem, TC tnie",
    "brake_early": "możesz hamować później",
    "slow_mid": "więcej prędkości w środku",
    "late_throttle": "wcześniej na gaz",
    "coast": "bez toczenia, szybciej na gaz",
}
ORDER = [LOCK, LOCK_REAR, SPIN, ABS_HEAVY, TC_HEAVY, "brake_early", "late_throttle", "slow_mid", "coast"]


class CornerCoach:
    def __init__(self, cfg: Optional[dict] = None) -> None:
        cfg = cfg or {}
        self.enabled = bool(cfg.get("coach", True))
        self.in_race = bool(cfg.get("coach_race", True))
        self.lead_s = float(cfg.get("coach_lead_s", 2.5))      # na ile sekund przed zakrętem mówić
        self.reset()

    def reset(self) -> None:
        self.laps: collections.deque[dict[str, set]] = collections.deque(maxlen=3)   # zakręt -> rodzaje błędów
        self.lap_no = 0
        self._told: dict[str, tuple[int, str, int]] = {}     # zakręt -> (okrążenie, rodzaj, ile razy z rzędu)
        self._said_this_lap = False
        self._watch: dict[str, tuple[str, int]] = {}         # po podpowiedzi: zakręt -> (rodzaj, okrążenie)

    # ------------------------------------------------------------ po okrążeniu
    def end_lap(self, faults: Optional[dict], deltas: list, pit: bool) -> Optional[str]:
        """faults: {(rodzaj, zakręt): wartość} z SuggestMonitor; deltas: CornerDelta z porównania z najlepszym."""
        self._said_this_lap = False
        if pit:
            self.laps.clear()
            self._watch.clear()
            return None
        lap: dict[str, set] = collections.defaultdict(set)
        for (kind, name) in (faults or {}):
            lap[name].add(kind)
        for d in deltas or []:
            if d.time_loss < 0.15:
                continue
            n = d.corner.name
            if d.brake_point_diff is not None and d.brake_point_diff <= -10:
                lap[n].add("brake_early")
            if d.throttle_point_diff is not None and d.throttle_point_diff >= 15:
                lap[n].add("late_throttle")
            if d.min_speed_diff <= -3:
                lap[n].add("slow_mid")
            if d.coast_diff >= 15:
                lap[n].add("coast")
        self.laps.append(dict(lap))
        self.lap_no += 1
        # „lepiej”: błąd, o którym mówiliśmy, nie pojawił się na 2 ostatnich okrążeniach
        better = []
        for name, (kind, at) in list(self._watch.items()):
            recent = list(self.laps)[-2:]
            if self.lap_no - at >= 2 and len(recent) == 2 and all(kind not in l.get(name, set()) for l in recent):
                better.append(name)
                del self._watch[name]
                self._told.pop(name, None)
            elif self.lap_no - at > 8:
                del self._watch[name]
        if better:
            return " i ".join(better[:2]) + " lepiej."
        return None

    def _active(self, name: str) -> Optional[str]:
        cnt: collections.Counter = collections.Counter()
        for l in self.laps:
            for k in l.get(name, set()):
                cnt[k] += 1
        for k in ORDER:
            if cnt[k] >= 2:
                return k
        return None

    # ------------------------------------------------------------ na torze
    def update(self, snap, corners, ref) -> Optional[str]:
        if not self.enabled or self._said_this_lap or not corners or len(self.laps) < 2:
            return None
        if snap.session == "race" and not self.in_race:
            return None
        p = snap.player
        if p is None or p.in_pits or p.speed_kmh < 60:
            return None
        L = snap.track_length or 0
        v = p.speed_kmh / 3.6
        for c in corners:
            dist = c.start - p.lap_dist
            if L and dist < 0:
                dist += L
            t_to = dist / max(10.0, v)
            if not (1.0 <= t_to <= self.lead_s + 0.6):
                continue
            kind = self._active(c.name)
            if kind is None:
                return None
            last = self._told.get(c.name)
            n = last[2] if last is not None and last[1] == kind else 0
            if last is not None and self.lap_no - last[0] < 3 * max(1, n):   # bez poprawy: coraz rzadziej
                return None
            self._told[c.name] = (self.lap_no, kind, n + 1)
            self._watch[c.name] = (kind, self.lap_no)
            self._said_this_lap = True
            return f"{c.name}: {TIPS[kind]}."
        return None
