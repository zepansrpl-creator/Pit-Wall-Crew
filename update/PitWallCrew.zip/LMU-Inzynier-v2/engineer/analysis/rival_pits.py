"""Postoje rywali: kiedy zjadą, ile stali, czy (prawdopodobnie) zmieniali opony.

Źródła:
- wspólna pamięć (wszystkie auta): okrążenia, w alei / nie, prędkość, liczba postojów, ostatnie okrążenie,
- interfejs gry /rest/strategy/usage: energia każdego auta po każdym okrążeniu (dla rywali bywa
  niepełna – zera i skoki odrzucamy).

Za ile zjedzie: energia teraz / zużycie na okrążenie (z historii rywala). Gdy danych o energii brak –
długość typowego stintu (nasza, to ta sama klasa) minus okrążenia od jego ostatniego postoju.
Opony na postoju: czas stania − dolewanie energii (nasze zmierzone tempo) − start/stop, podzielone przez
czas zmiany jednej opony, zaokrąglone do 0 / 2 / 4. To szacunek – na ścianie boksów z „~”.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional


@dataclass
class _Stop:
    n: int                 # który postój
    lap: int               # na którym okrążeniu
    stationary: float      # s stania w miejscu
    ve_in: Optional[float] = None
    ve_out: Optional[float] = None
    tyres: Optional[int] = None


@dataclass
class _Car:
    in_pits: bool = False
    t_in: float = 0.0
    stat: float = 0.0
    last_t: Optional[float] = None
    last_pit_lap: int = 0
    stops: list = field(default_factory=list)
    ve_in: Optional[float] = None


def _ve_series(laps: list) -> list[tuple[int, float, bool]]:
    out = []
    for x in laps or []:
        try:
            ve = float(x.get("ve"))
        except (TypeError, ValueError):
            continue
        if 0.0 < ve <= 1.0:
            out.append((int(x.get("lap", 0)), ve, bool(x.get("pit"))))
    return out


def ve_per_lap(laps: list) -> Optional[float]:
    """Średnie zużycie energii na okrążenie z ostatnich spadków (bez postojów i skoków)."""
    s = _ve_series(laps)
    drops = []
    for (l0, v0, p0), (l1, v1, p1) in zip(s, s[1:]):
        if l1 == l0 + 1 and not p1 and 0.03 < v0 - v1 < 0.2:
            drops.append(v0 - v1)
    drops = drops[-5:]
    return sum(drops) / len(drops) if len(drops) >= 2 else None


class RivalPits:
    def __init__(self) -> None:
        self.cars: dict[int, _Car] = {}

    def update(self, snap, rest=None) -> None:
        for c in snap.cars:
            st = self.cars.setdefault(c.car_id, _Car())
            dt = 0.0 if st.last_t is None else max(0.0, min(1.0, snap.t - st.last_t))
            st.last_t = snap.t
            if c.in_pits and not st.in_pits:
                st.in_pits, st.t_in, st.stat = True, snap.t, 0.0
                st.ve_in = self._ve_now(rest, c)
            elif c.in_pits and st.in_pits:
                if c.speed_kmh < 1.0:
                    st.stat += dt
            elif st.in_pits and not c.in_pits:
                st.in_pits = False
                # wyjazd z garażu na start (okrążenie 0, przed zieloną flagą) to nie postój
                if st.stat >= 3 and c.laps_done >= 1 and snap.phase in ("green", "fcy"):
                    stop = _Stop(len(st.stops) + 1, c.laps_done, round(st.stat, 1), st.ve_in, self._ve_now(rest, c))
                    st.stops.append(stop)
                    st.last_pit_lap = c.laps_done

    @staticmethod
    def _ve_now(rest, c) -> Optional[float]:
        if rest is None:
            return None
        r = rest.standing(c.driver)
        try:
            v = float(r.get("veFraction")) if r else None
        except (TypeError, ValueError):
            v = None
        return v if v is not None and 0.0 < v <= 1.0 else None

    def _estimate_tyres(self, stop: _Stop, rest, c, params) -> None:
        """Liczba zmienionych opon – tylko gdy szacunek jest pewny. Inaczej zostaje None („—” na ścianie).

        Pewny = znamy energię rywala przy wjeździe i wyjeździe (dolewanie, np. mniejsze na ostatnim postoju),
        mamy zmierzone na naszych postojach tempo dolewania i czas opony, a czas, który zostaje na opony,
        wyraźnie pasuje do 0, 2 albo 4 opon."""
        if stop.tyres is not None or params is None or not getattr(params, "learned", None):
            return
        vi, vo = stop.ve_in, stop.ve_out
        if vi is None or vo is None or not (0.0 < vi <= 1.0 and 0.0 < vo <= 1.0) or vo <= vi:
            return
        refill = (vo - vi) * 100 / max(0.5, params.ve_pct_per_s)
        rest_s = stop.stationary - params.base_s - refill
        n = rest_s / max(1.0, params.tyre_s)
        best = min((0, 2, 4), key=lambda k: abs(n - k))
        if abs(n - best) <= 0.6:
            stop.tyres = best

    def pit_in(self, c, rest, typical_stint: Optional[float]) -> Optional[float]:
        """Za ile okrążeń rywal musi zjechać (szacunek)."""
        if rest is not None:
            per = ve_per_lap(rest.usage.get(c.driver, []))
            now = self._ve_now(rest, c)
            if per and now:
                return max(0.0, now / per - 0.3)
        st = self.cars.get(c.car_id)
        if typical_stint:
            since = c.laps_done - (st.last_pit_lap if st else 0)
            return max(0.0, typical_stint - since)
        return None

    def table(self, snap, rivals, rest=None, params=None, typical_stint=None, n: int = 4) -> list[dict]:
        """4 auta przed i 4 za Tobą w klasie: odstęp, ostatnie okrążenie, zjazd za, ostatnia zmiana opon, w alei."""
        me = snap.player_scoring()
        if me is None:
            return []
        same = sorted([c for c in snap.cars if c.car_class == me.car_class], key=lambda c: c.place)
        idx = next((i for i, c in enumerate(same) if c.is_player), None)
        if idx is None:
            return []
        rows = []
        my_pace = rivals.driver_pace(me.car_id, me.driver) if hasattr(rivals, "driver_pace") else None
        for c in same[max(0, idx - n): idx + n + 1]:
            st = self.cars.get(c.car_id)
            g, laps = rivals._gap(snap, me, c) if not c.is_player else (0.0, 0)
            last = st.stops[-1] if st and st.stops else None
            if last is not None:
                self._estimate_tyres(last, rest, c, params)
            tyre_stop = None
            for s in reversed(st.stops if st else []):
                if s.tyres:
                    tyre_stop = s
                    break
            pin = self.pit_in(c, rest, typical_stint)
            pace = rivals.driver_pace(c.car_id, c.driver) if hasattr(rivals, "driver_pace") else None
            catch = None    # za ile okrążeń dojdzie / dojdziesz (gdy różnica tempa to umożliwia)
            if not c.is_player and g is not None and not laps and pace and my_pace and abs(pace - my_pace) > 0.05:
                if (g > 0 and pace < my_pace) or (g < 0 and pace > my_pace):
                    k = abs(g) / abs(pace - my_pace)
                    catch = round(k, 1) if 1 <= k <= 60 else None
            team = rivals.team(c.car_id) if hasattr(rivals, "team") else []
            ve = self._ve_now(rest, c)
            if c.is_player and snap.player is not None and snap.player.virtual_energy is not None:
                ve = snap.player.virtual_energy
            rows.append({
                "ve": None if ve is None else round(ve * 100, 1),
                "pos": idx_pos(same, c), "name": c.driver, "me": c.is_player,
                "gap": None if g is None else round(g, 1), "laps": laps,
                "last": round(c.last_lap, 3) if c.last_lap and c.last_lap > 0 else None,
                "stops": c.pit_stops,
                "pit_in": None if pin is None else round(pin, 1),
                "tyres": ({"stop": tyre_stop.n, "n": tyre_stop.tyres} if tyre_stop else
                          ({"stop": last.n, "n": 0} if last is not None and last.tyres == 0 else None)),
                "in_pits": bool(c.in_pits),
                "pace": round(pace, 3) if pace else None,
                "catch": catch,
                "drivers": [{"name": d, "pace": round(p, 3) if p else None, "laps": k} for d, p, k in team][:4],
            })
        return rows


def idx_pos(same, c) -> int:
    return same.index(c) + 1
