"""Komentarz po wyprzedzeniu albo stracie pozycji w klasie – z opóźnieniem.

Inżynier nie chwali od razu: czeka, aż pozycja w klasie utrzyma się przez CONFIRM_S sekund bez zmian
(żeby nie chwalić kogoś, kto za chwilę ją odda). Zmiany przez postoje (nasze albo rywala) nie są
komentowane. Najwyżej jeden komentarz na MIN_GAP_S sekund, tylko w wyścigu, przy zielonej fladze.
"""

from __future__ import annotations

from typing import Optional

CONFIRM_S = 30.0
MIN_GAP_S = 45.0

PHRASES = {
    "pro": {
        "gain1": "Dobra robota, P{p}.", "gainN": "Plus {n}, jesteś P{p}.",
        "loss1": "Straciłeś pozycję, P{p}.", "lossN": "Minus {n}, jesteś P{p}.",
        "ahead": " {who} {gap} przed Tobą.", "behind": " {who} {gap} za Tobą.",
    },
    "kumpel": {
        "gain1": "Brawo, stary! P{p}.", "gainN": "Ale jazda, plus {n}! P{p}.",
        "loss1": "Szkoda, P{p}. Odbijemy to.", "lossN": "Spokojnie, minus {n}, P{p}. Odbijemy.",
        "ahead": " {who} {gap} przed Tobą.", "behind": " {who} {gap} z tyłu.",
    },
    "twardziel": {
        "gain1": "No, wreszcie. P{p}. Nie oddawaj.", "gainN": "Plus {n}, P{p}. Tak trzymać, nie zwalniaj.",
        "loss1": "Oddałeś pozycję. P{p}. Weź się w garść.", "lossN": "Minus {n}, P{p}. Pobudka, odrabiamy.",
        "ahead": " {who} {gap} przed Tobą, goń go.", "behind": " {who} {gap} z tyłu, pilnuj.",
    },
    "analityk": {
        "gain1": "Pozycja zyskana, P{p}.", "gainN": "Zysk {n} pozycji, P{p}.",
        "loss1": "Pozycja stracona, P{p}.", "lossN": "Strata {n} pozycji, P{p}.",
        "ahead": " {who} {gap} przed Tobą.", "behind": " {who} {gap} za Tobą.",
    },
}


def _gap_txt(g: float) -> str:
    return f"{abs(g):.1f}".replace(".", ",") + " s"


def _surname(name: str) -> str:
    parts = (name or "").split()
    return parts[-1] if parts else (name or "rywal")


class OvertakeWatch:
    def __init__(self, cfg: Optional[dict] = None, persona: str = "pro") -> None:
        self.enabled = bool((cfg or {}).get("overtakes", True))
        self.persona = persona if persona in PHRASES else "pro"
        self.reset()

    def reset(self) -> None:
        self.base_ahead: Optional[set] = None    # id aut w klasie przed nami przy ostatnim stanie „ustalonym”
        self.base_pos = 0
        self.change_t: Optional[float] = None
        self.pitted: dict = {}                   # auto (my = -1) -> kiedy ostatnio było w alei
        self.first_change: Optional[float] = None
        self.last_said = -1e9
        self._cur_ahead: Optional[set] = None

    def update(self, snap, rivals) -> Optional[str]:
        """Zwraca komentarz albo None. rivals: Rivals (do odstępu)."""
        if snap.session != "race":
            self.reset()
            return None
        me = snap.player_scoring()
        if me is None:
            return None
        same = sorted([c for c in snap.cars if c.car_class == me.car_class], key=lambda c: c.place)
        idx = next((i for i, c in enumerate(same) if c.is_player), None)
        if idx is None:
            return None
        ahead = {c.car_id for c in same[:idx]}
        for c in same:
            if c.in_pits or c.pit_state in (2, 3, 4):
                self.pitted[-1 if c.is_player else c.car_id] = snap.t
        if me.laps_done < 1 or snap.phase != "green":
            self._settle(ahead, idx + 1)       # start i neutralizacja: bez komentarzy
            return None
        if self.base_ahead is None:
            self._settle(ahead, idx + 1)
            return None
        if ahead != self._cur_ahead:
            self._cur_ahead = ahead
            self.change_t = snap.t
            if self.first_change is None:
                self.first_change = snap.t
            return None
        if self.change_t is None or snap.t - self.change_t < CONFIRM_S:
            return None
        # pozycja stabilna od CONFIRM_S sekund
        since = (self.first_change or snap.t) - 90       # postoje tuż przed zmianą i w jej trakcie
        pit = {cid for cid, t in self.pitted.items() if t >= since}
        passed = {cid for cid in self.base_ahead - ahead if cid not in pit}     # wyprzedzeni przez nas
        lost = {cid for cid in ahead - self.base_ahead if cid not in pit}       # ci, którzy nas wyprzedzili
        we_pitted = -1 in pit
        pos = idx + 1
        self._settle(ahead, pos)
        if we_pitted or not self.enabled or (not passed and not lost):
            return None
        net = len(passed) - len(lost)
        if net == 0 or snap.t - self.last_said < MIN_GAP_S:
            return None
        self.last_said = snap.t
        ph = PHRASES[self.persona]
        if net > 0:
            txt = (ph["gain1"] if net == 1 else ph["gainN"]).format(p=pos, n=net)
            target = next((c for c in same if c.car_id in passed), None)
            key = "behind"
        else:
            txt = (ph["loss1"] if net == -1 else ph["lossN"]).format(p=pos, n=-net)
            target = next((c for c in same if c.car_id in lost), None)
            key = "ahead"
        if target is not None and net in (1, -1):
            try:
                info = next((r for r in rivals.rivals(snap, 3, 3) if r.car.car_id == target.car_id), None)
                if info is not None and info.gap_s is not None and not info.laps_diff and abs(info.gap_s) < 30:
                    txt += ph[key].format(who=_surname(target.driver), gap=_gap_txt(info.gap_s))
            except Exception:
                pass
        return txt

    def _settle(self, ahead: set, pos: int) -> None:
        self.base_ahead, self.base_pos = set(ahead), pos
        self._cur_ahead = set(ahead)
        self.change_t = None
        self.first_change = None
