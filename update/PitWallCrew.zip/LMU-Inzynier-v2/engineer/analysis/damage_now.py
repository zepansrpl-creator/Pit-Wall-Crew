"""Bieżący stan uszkodzeń auta: z pamięci wspólnej (koła, opony, nadwozie) i z interfejsu gry (zawieszenie)."""

from __future__ import annotations

WHEEL_NOM = ["lewe przednie", "prawe przednie", "lewe tylne", "prawe tylne"]


def describe(snap, rest=None) -> list[str]:
    """Krótkie zdania o tym, co jest uszkodzone teraz. Pusta lista = brak uszkodzeń."""
    p = snap.player if snap is not None else None
    out: list[str] = []
    if p is None:
        return out
    det = list(getattr(p, "wheel_detached", []) or [])
    for i, d in enumerate(det[:4]):
        if d:
            out.append(f"odpadło koło {WHEEL_NOM[i]}")
    flat = list(getattr(p, "wheel_flat", []) or [])
    for i, f in enumerate(flat[:4]):
        if f and not (i < len(det) and det[i]):
            out.append(f"przebita opona, koło {WHEEL_NOM[i]}")
    susp = getattr(rest, "suspension", None) if rest is not None and getattr(rest, "ok", False) else None
    if susp:
        bad = [(i, v) for i, v in enumerate(susp[:4]) if v and v > 0.02 and not (i < len(det) and det[i])]
        for i, v in bad:
            out.append(f"uszkodzone zawieszenie, {WHEEL_NOM[i]}, {v * 100:.0f} procent")
    dents = sum(getattr(p, "dents", []) or [])
    if getattr(p, "parts_detached", False):
        out.append("odpadły części nadwozia")
    elif dents:
        out.append("uszkodzone nadwozie" + (", mocno" if dents >= 6 else ""))
    return out


def level(snap, rest=None) -> int:
    """Liczba do pit walla (0 = brak)."""
    p = snap.player if snap is not None else None
    if p is None:
        return 0
    n = sum(getattr(p, "dents", []) or []) + (4 if getattr(p, "parts_detached", False) else 0)
    n += 4 * sum(1 for d in (getattr(p, "wheel_detached", []) or []) if d)
    susp = getattr(rest, "suspension", None) if rest is not None else None
    if susp:
        n += sum(2 for v in susp if v and v > 0.02)
    return n
