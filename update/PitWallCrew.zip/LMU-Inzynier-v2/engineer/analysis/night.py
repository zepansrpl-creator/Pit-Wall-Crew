"""Zmiana temperatury toru (noc, poranek) a ciśnienie opon.

Wzorzec: ciepłe ciśnienia (w trakcie jazdy) z pierwszego stintu wyścigu, od 3. okrążenia na oponach.
Gdy w bieżącym stincie ciepłe ciśnienia odbiegają od wzorca (zwykle w nocy: zimniejszy tor = niższe
ciśnienia), inżynier podaje, o ile zmienić ciśnienie w menu boksu na następnym postoju
(1 klik = 1 kPa), osobno przód i tył. Grill i temperatury silnika podpowiada moduł silnika.
"""

from __future__ import annotations

from typing import Optional

MIN_DIFF = 2.0     # kPa – mniejsze różnice pomijamy


def _avg(rows: list[list[float]]) -> Optional[list[float]]:
    rows = [r for r in rows if r and len(r) == 4 and all(x > 0 for x in r)]
    if not rows:
        return None
    return [sum(r[i] for r in rows) / len(rows) for i in range(4)]


def _good(l) -> bool:
    return not l.pit and not l.fcy and l.stint_lap >= 3 and l.tyre_pressures and l.wetness < 0.1


class PressureAdvisor:
    def __init__(self) -> None:
        self.ref_p: Optional[list[float]] = None
        self.ref_tt: Optional[float] = None
        self.advice: Optional[tuple[int, int, float]] = None   # (przód kliki, tył kliki, zmiana temp. toru)
        self._told_stint: Optional[int] = None

    def reset(self) -> None:
        self.__init__()

    def update(self, laps: list, stint_start: int) -> None:
        if self.ref_p is None:
            # wzorzec: pierwszy stint z co najmniej 3 dobrymi okrążeniami
            first: list = []
            for l in laps:
                if l.pit and first:
                    break
                if _good(l):
                    first.append(l)
            if len(first) >= 3:
                self.ref_p = _avg([l.tyre_pressures for l in first[:5]])
                self.ref_tt = sum(l.track_temp for l in first[:5]) / len(first[:5])
            return
        cur = [l for l in laps[stint_start:] if _good(l)][-3:]
        if len(cur) < 3:
            self.advice = None
            return
        p = _avg([l.tyre_pressures for l in cur])
        if p is None:
            return
        tt = sum(l.track_temp for l in cur) / len(cur)
        front = (self.ref_p[0] + self.ref_p[1] - p[0] - p[1]) / 2
        rear = (self.ref_p[2] + self.ref_p[3] - p[2] - p[3]) / 2
        if max(abs(front), abs(rear)) < MIN_DIFF:
            self.advice = None
            return
        self.advice = (round(front), round(rear), tt - (self.ref_tt or tt))

    def phrase(self) -> str:
        """Krótko do planu postoju: 'ciśnienie przód +3, tył +2'."""
        if not self.advice:
            return ""
        f, r, _ = self.advice
        sg = lambda v: f"+{v}" if v > 0 else str(v)
        parts = []
        if f:
            parts.append(f"przód {sg(f)}")
        if r:
            parts.append(f"tył {sg(r)}")
        return ("ciśnienie " + ", ".join(parts)) if parts else ""

    def message(self, stint_id: int) -> Optional[str]:
        """Raz na stint: pełny komunikat."""
        ph = self.phrase()
        if not ph or self._told_stint == stint_id:
            return None
        self._told_stint = stint_id
        f, r, dtt = self.advice
        why = ""
        if abs(dtt) >= 2:
            why = f" Tor {'chłodniejszy' if dtt < 0 else 'cieplejszy'} o {abs(dtt):.0f} stopni niż w pierwszym stincie."
        return (f"Na następnym postoju {ph} kliki, żeby wrócić do ciśnień z pierwszego stintu.{why}")
