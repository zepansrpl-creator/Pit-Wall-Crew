"""Tempo i trend przewagi rywali."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional

from ..model import CarScoring, Snapshot


@dataclass
class CarHistory:
    car_id: int
    driver: str = ""
    vehicle: str = ""
    car_class: str = ""
    laps: list[tuple[int, float, bool]] = field(default_factory=list)  # (okrążenie, czas, czyste)
    gaps: list[tuple[int, float]] = field(default_factory=list)        # (okr. gracza, przewaga w s; + = rywal z tyłu)
    _laps_done: int = -1
    _pit_this_lap: bool = False

    def pace(self, n: int = 3) -> Optional[float]:
        clean = [t for _, t, ok in self.laps if ok]
        if not clean:
            return None
        best = min(clean)
        recent = [t for t in clean[-n:] if t < best * 1.04]
        return sum(recent) / len(recent) if recent else None

    def gap_trend(self, n: int = 4) -> Optional[float]:
        """Zmiana przewagi na okrążenie (s/okr.). Dodatnia = rywal się oddala od Ciebie (w dowolną stronę)."""
        pts = self.gaps[-n:]
        if len(pts) < 3:
            return None
        xs = [x for x, _ in pts]
        ys = [abs(y) for _, y in pts]
        mx, my = sum(xs) / len(xs), sum(ys) / len(ys)
        den = sum((x - mx) ** 2 for x in xs)
        if den == 0:
            return None
        return sum((x - mx) * (y - my) for x, y in zip(xs, ys)) / den


@dataclass
class RivalInfo:
    car: CarScoring
    hist: CarHistory
    gap_s: Optional[float]      # + = rywal z tyłu, - = przed Tobą (czas)
    laps_diff: int              # różnica okrążeń (gdy dubel)
    pace: Optional[float]
    pace_diff: Optional[float]  # s/okr., + = rywal wolniejszy od Ciebie
    trend: Optional[float]
    laps_to_catch: Optional[float]
    class_place: int

    def describe(self, fmt_time) -> str:
        c = self.car
        who = f"P{self.class_place} w klasie {c.driver} ({c.vehicle})"
        if self.laps_diff:
            pos = f"{abs(self.laps_diff)} okr. {'za Tobą' if self.laps_diff > 0 else 'przed Tobą'}"
        elif self.gap_s is not None:
            pos = f"{abs(self.gap_s):.1f} s {'za Tobą' if self.gap_s > 0 else 'przed Tobą'}"
        else:
            pos = "przewaga nieznana"
        parts = [who, pos]
        if self.pace:
            p = f"tempo {fmt_time(self.pace)}"
            if self.pace_diff is not None:
                p += f" ({abs(self.pace_diff):.2f} s/okr. {'wolniej' if self.pace_diff > 0 else 'szybciej'} niż Ty)"
            parts.append(p)
        if self.trend is not None and abs(self.trend) >= 0.05:
            parts.append(f"przewaga {'rośnie' if self.trend > 0 else 'maleje'} o {abs(self.trend):.2f} s/okr.")
        if self.laps_to_catch is not None and self.laps_to_catch < 40:
            if self.gap_s is not None and self.gap_s > 0:
                parts.append(f"dogoni Cię za ok. {self.laps_to_catch:.0f} okr.")
            else:
                parts.append(f"dogonisz go za ok. {self.laps_to_catch:.0f} okr.")
        if c.in_pits:
            parts.append("teraz w alei serwisowej")
        parts.append(f"postoje: {c.pit_stops}")
        return ", ".join(parts)


def robust_pace(times: list[float], n: int = 5) -> Optional[float]:
    """Typowe tempo: mediana ostatnich n czystych okrążeń, bez odstających (> 4% od najlepszego)."""
    if not times:
        return None
    best = min(times)
    recent = [t for t in times if t < best * 1.04][-n:]
    if not recent:
        return None
    recent = sorted(recent)
    m = len(recent) // 2
    return recent[m] if len(recent) % 2 else (recent[m - 1] + recent[m]) / 2


class RivalTracker:
    def __init__(self) -> None:
        self.cars: dict[int, CarHistory] = {}
        self.player_laps_done = -1
        # tempo każdego kierowcy w każdym aucie (zostaje po zmianie kierowcy): (auto, kierowca) -> czyste okrążenia
        self.driver_laps: dict[tuple[int, str], list[float]] = {}
        self.car_names: dict[int, str] = {}
        self.events: list[tuple[int, str, str]] = []   # zmiany kierowców: (auto, poprzedni, nowy)
        # prędkość maksymalna każdego auta: car_id -> [to okrążenie, poprzednie okrążenie, najlepsza w sesji, okrążenia]
        self.vmax: dict[int, list] = {}

    def reset(self) -> None:
        self.cars.clear()
        self.player_laps_done = -1
        self.driver_laps.clear()
        self.car_names.clear()
        self.events.clear()
        self.vmax.clear()

    # ------------------------------------------------------------ kierowcy
    def driver_pace(self, car_id: int, driver: str) -> Optional[float]:
        return robust_pace(self.driver_laps.get((car_id, driver), []))

    def team(self, car_id: int) -> list[tuple[str, Optional[float], int]]:
        """Kierowcy auta: (nazwisko, tempo, liczba czystych okrążeń), od najszybszego."""
        rows = [(d, robust_pace(t), len(t)) for (cid, d), t in self.driver_laps.items() if cid == car_id and d]
        return sorted(rows, key=lambda r: (r[1] is None, r[1] or 0))

    def _speed(self, c: CarScoring) -> None:
        v = self.vmax.get(c.car_id)
        if v is None:
            v = self.vmax[c.car_id] = [0.0, 0.0, 0.0, c.laps_done]
        if c.laps_done != v[3]:                 # nowe okrążenie: zapamiętaj maksimum poprzedniego
            if v[0] > 0:
                v[1] = v[0]
            v[0], v[3] = 0.0, c.laps_done
        if not c.in_pits and 0 < c.speed_kmh < 420:   # > 420 km/h = błąd odczytu
            v[0] = max(v[0], c.speed_kmh)
            v[2] = max(v[2], c.speed_kmh)

    def top_speed(self, car_id: int) -> tuple[float, float]:
        """(maks. na ostatnim pełnym okrążeniu albo bieżącym, najlepsza w sesji) w km/h; 0 = brak danych."""
        v = self.vmax.get(car_id)
        if not v:
            return 0.0, 0.0
        return (v[1] or v[0]), v[2]

    def update(self, snap: Snapshot) -> None:
        player = snap.player_scoring()
        for c in snap.cars:
            self._speed(c)
            h = self.cars.get(c.car_id)
            self.car_names[c.car_id] = c.vehicle
            if h is not None and h.driver != c.driver and h.driver and c.driver:
                self.events.append((c.car_id, h.driver, c.driver))
                del self.events[:-20]
            if h is None or h.driver != c.driver:
                h = CarHistory(car_id=c.car_id, driver=c.driver, vehicle=c.vehicle, car_class=c.car_class,
                               _laps_done=c.laps_done)
                self.cars[c.car_id] = h
            if c.in_pits or (0 < c.speed_kmh < 40 and snap.phase == "green"):
                h._pit_this_lap = True
                h.gaps.clear()  # postój albo wypadek psuje trend przewagi
            if c.laps_done > h._laps_done:
                if h._laps_done >= 0 and c.last_lap > 0:
                    clean = not h._pit_this_lap and snap.phase != "fcy" and c.laps_done > 1
                    h.laps.append((c.laps_done, c.last_lap, clean))
                    if clean:
                        self.driver_laps.setdefault((c.car_id, c.driver), []).append(c.last_lap)
                h._laps_done = c.laps_done
                h._pit_this_lap = c.in_pits

        # Twój postój psuje trend przewagi do wszystkich
        if player is not None and player.in_pits:
            for h in self.cars.values():
                h.gaps.clear()
        # przewagi zapisujemy raz na okrążenie gracza
        if player is not None and player.laps_done > self.player_laps_done:
            self.player_laps_done = player.laps_done
            for c in snap.cars:
                if c.is_player:
                    continue
                gap, laps = self._gap(snap, player, c)
                if gap is not None and laps == 0 and not c.in_pits:
                    self.cars[c.car_id].gaps.append((player.laps_done, gap))

    def _ref_lap(self, player: CarScoring) -> float:
        me = self.cars.get(player.car_id)
        pace = me.pace() if me else None
        if pace:
            return pace
        if player.best_lap > 0:
            return player.best_lap
        return 120.0

    def _gap(self, snap: Snapshot, player: CarScoring, c: CarScoring) -> tuple[Optional[float], int]:
        """Przewaga liczona z dystansu na torze (niezależna od symulatora).

        Zwraca (sekundy, różnica okrążeń). Sekundy > 0 = rywal za Tobą.
        Gdy różnica przekracza okrążenie, zwraca (None, liczba okrążeń; > 0 = rywal z tyłu).
        """
        L = snap.track_length
        if L <= 0:
            return None, 0
        d = (player.laps_done * L + player.lap_dist) - (c.laps_done * L + c.lap_dist)
        if abs(d) >= L:
            return None, int(d / L)
        return d / (L / self._ref_lap(player)), 0

    def rivals(self, snap: Snapshot, ahead: int = 2, behind: int = 2) -> list[RivalInfo]:
        player = snap.player_scoring()
        if player is None:
            return []
        same = sorted([c for c in snap.cars if c.car_class == player.car_class], key=lambda c: c.place)
        idx = next((i for i, c in enumerate(same) if c.is_player), None)
        if idx is None:
            return []
        me = self.cars.get(player.car_id)
        my_pace = me.pace() if me else None
        chosen = same[max(0, idx - ahead):idx] + same[idx + 1:idx + 1 + behind]
        out = []
        for c in chosen:
            h = self.cars.get(c.car_id) or CarHistory(car_id=c.car_id)
            gap, laps = self._gap(snap, player, c)
            pace = h.pace()
            pdiff = (pace - my_pace) if (pace and my_pace) else None
            trend = h.gap_trend()
            catch = None
            if gap is not None and pdiff is not None and abs(pdiff) > 0.05:
                # rywal z tyłu i szybszy, albo przed Tobą i wolniejszy
                if (gap > 0 and pdiff < 0) or (gap < 0 and pdiff > 0):
                    catch = abs(gap) / abs(pdiff)
                    if catch < 1:
                        catch = None  # walka koło w koło, prognoza bez sensu
            out.append(RivalInfo(
                car=c, hist=h, gap_s=gap, laps_diff=laps, pace=pace, pace_diff=pdiff, trend=trend,
                laps_to_catch=catch, class_place=same.index(c) + 1,
            ))
        return out

    def class_position(self, snap: Snapshot) -> tuple[int, int]:
        player = snap.player_scoring()
        if player is None:
            return 0, 0
        same = sorted([c for c in snap.cars if c.car_class == player.car_class], key=lambda c: c.place)
        idx = next((i for i, c in enumerate(same) if c.is_player), -1)
        return idx + 1, len(same)

    def faster_class_behind(self, snap: Snapshot, horizon_s: float = 12.0) -> list[tuple[CarScoring, float]]:
        """Auta szybszej klasy, które dojadą do Ciebie w ciągu horizon_s sekund (szacunek z pozycji na torze)."""
        player = snap.player_scoring()
        if player is None or snap.track_length <= 0:
            return []
        me = self.cars.get(player.car_id)
        my_pace = me.pace() if me else None
        out = []
        for c in snap.cars:
            if c.is_player or c.car_class == player.car_class or c.in_pits:
                continue
            h = self.cars.get(c.car_id)
            pace = h.pace() if h else None
            if not pace or not my_pace or pace >= my_pace:
                continue
            behind_m = (player.lap_dist - c.lap_dist) % snap.track_length
            closing = snap.track_length / pace - snap.track_length / my_pace  # m/s
            t_track = behind_m / (snap.track_length / pace)
            if closing > 0 and t_track < horizon_s * 3:
                eta = behind_m / closing
                if eta <= horizon_s:
                    out.append((c, eta))
        return sorted(out, key=lambda x: x[1])

    def class_best_laps(self, snap: Snapshot, top: int = 5) -> list[CarScoring]:
        player = snap.player_scoring()
        if player is None:
            return []
        same = [c for c in snap.cars if c.car_class == player.car_class and c.best_lap > 0]
        return sorted(same, key=lambda c: c.best_lap)[:top]
