"""Tempo i trend przewagi rywali."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional

from ..model import CarScoring, Snapshot


@dataclass
class CarHistory:
    car_id: int
    driver: str = ""
    vehicle: str = ""
    car_class: str = ""
    laps: list[tuple[int, float, bool]] = field(default_factory=list)  # (okrążenie, czas, czyste)
    gaps: list[tuple[int, float]] = field(default_factory=list)        # (okr. gracza, przewaga w s; + = rywal z tyłu)
    _laps_done: int = -1
    _pit_this_lap: bool = False

    def pace(self, n: int = 3) -> Optional[float]:
        clean = [t for _, t, ok in self.laps if ok]
        if not clean:
            return None
        best = min(clean)
        recent = [t for t in clean[-n:] if t < best * 1.04]
        return sum(recent) / len(recent) if recent else None

    def gap_trend(self, n: int = 4) -> Optional[float]:
        """Zmiana przewagi na okrążenie (s/okr.). Dodatnia = rywal się oddala od Ciebie (w dowolną stronę)."""
        pts = self.gaps[-n:]
        if len(pts) < 3:
            return None
        xs = [x for x, _ in pts]
        ys = [abs(y) for _, y in pts]
        mx, my = sum(xs) / len(xs), sum(ys) / len(ys)
        den = sum((x - mx) ** 2 for x in xs)
        if den == 0:
            return None
        return sum((x - mx) * (y - my) for x, y in zip(xs, ys)) / den


@dataclass
class RivalInfo:
    car: CarScoring
    hist: CarHistory
    gap_s: Optional[float]      # + = rywal z tyłu, - = przed Tobą (czas)
    laps_diff: int              # różnica okrążeń (gdy dubel)
    pace: Optional[float]
    pace_diff: Optional[float]  # s/okr., + = rywal wolniejszy od Ciebie
    trend: Optional[float]
    laps_to_catch: Optional[float]
    class_place: int

    def describe(self, fmt_time) -> str:
        c = self.car
        who = f"P{self.class_place} w klasie {c.driver} ({c.vehicle})"
        if self.laps_diff:
            pos = f"{abs(self.laps_diff)} okr. {'za Tobą' if self.laps_diff > 0 else 'przed Tobą'}"
        elif self.gap_s is not None:
            pos = f"{abs(self.gap_s):.1f} s {'za Tobą' if self.gap_s > 0 else 'przed Tobą'}"
        else:
            pos = "przewaga nieznana"
        parts = [who, pos]
        if self.pace:
            p = f"tempo {fmt_time(self.pace)}"
            if self.pace_diff is not None:
                p += f" ({abs(self.pace_diff):.2f} s/okr. {'wolniej' if self.pace_diff > 0 else 'szybciej'} niż Ty)"
            parts.append(p)
        if self.trend is not None and abs(self.trend) >= 0.05:
            parts.append(f"przewaga {'rośnie' if self.trend > 0 else 'maleje'} o {abs(self.trend):.2f} s/okr.")
        if self.laps_to_catch is not None and self.laps_to_catch < 40:
            if self.gap_s is not None and self.gap_s > 0:
                parts.append(f"dogoni Cię za ok. {self.laps_to_catch:.0f} okr.")
            else:
                parts.append(f"dogonisz go za ok. {self.laps_to_catch:.0f} okr.")
        if c.in_pits:
            parts.append("teraz w alei serwisowej")
        parts.append(f"postoje: {c.pit_stops}")
        return ", ".join(parts)


def robust_pace(times: list[float], n: int = 5) -> Optional[float]:
    """Typowe tempo: mediana ostatnich n czystych okrążeń, bez odstających (> 4% od najlepszego)."""
    if not times:
        return None
    best = min(times)
    recent = [t for t in times if t < best * 1.04][-n:]
    if not recent:
        return None
    recent = sorted(recent)
    m = len(recent) // 2
    return recent[m] if len(recent) % 2 else (recent[m - 1] + recent[m]) / 2


class RivalTracker:
    def __init__(self) -> None:
        self.cars: dict[int, CarHistory] = {}
        self.player_laps_done = -1
        # tempo każdego kierowcy w każdym aucie (zostaje po zmianie kierowcy): (auto, kierowca) -> czyste okrążenia
        self.driver_laps: dict[tuple[int, str], list[float]] = {}
        self.car_names: dict[int, str] = {}
        self.events: list[tuple[int, str, str]] = []   # zmiany kierowców: (auto, poprzedni, nowy)
        # prędkość maksymalna każdego auta: car_id -> [to okrążenie, poprzednie okrążenie, najlepsza w sesji, okrążenia]
        self.vmax: dict[int, list] = {}

    def reset(self) -> None:
        self.cars.clear()
        self.player_laps_done = -1
        self.driver_laps.clear()
        self.car_names.clear()
        self.events.clear()
        self.vmax.clear()

    # ------------------------------------------------------------ kierowcy
    def driver_pace(self, car_id: int, driver: str) -> Optional[float]:
        return robust_pace(self.driver_laps.get((car_id, driver), []))

    def team(self, car_id: int) -> list[tuple[str, Optional[float], int]]:
        """Kierowcy auta: (nazwisko, tempo, liczba czystych okrążeń), od najszybszego."""
        rows = [(d, robust_pace(t), len(t)) for (cid, d), t in self.driver_laps.items() if cid == car_id and d]
        return sorted(rows, key=lambda r: (r[1] is None, r[1] or 0))

    def _speed(self, c: CarScoring) -> None:
        v = self.vmax.get(c.car_id)
        if v is None:
            v = self.vmax[c.car_id] = [0.0, 0.0, 0.0, c.laps_done, False]
        if c.laps_done != v[3]:                 # nowe okrążenie: zapamiętaj maksimum poprzedniego
            if v[0] > 0 and not v[4]:           # okrążenie z boksem / wyjazdowe się nie liczy
                v[1] = v[0]
            v[0], v[3], v[4] = 0.0, c.laps_done, bool(c.in_pits)
        if c.in_pits:
            v[4] = True
        if not c.in_pits and 0 < c.speed_kmh < 420:   # > 420 km/h = błąd odczytu
            v[0] = max(v[0], c.speed_kmh)
            v[2] = max(v[2], c.speed_kmh)

    def top_speed(self, car_id: int) -> tuple[float, float]:
        """(maks. na ostatnim pełnym okrążeniu albo bieżącym, najlepsza w sesji) w km/h; 0 = brak danych."""
        v = self.vmax.get(car_id)
        if not v:
            return 0.0, 0.0
        return (v[1] or v[0]), v[2]

    def update(self, snap: Snapshot) -> None:
        player = snap.player_scoring()
        for c in snap.cars:
            self._speed(c)
            h = self.cars.get(c.car_id)
            self.car_names[c.car_id] = c.vehicle
            if h is not None and h.driver != c.driver and h.driver and c.driver:
                self.events.append((c.car_id, h.driver, c.driver))
                del self.events[:-20]
            if h is None or h.driver != c.driver:
                h = CarHistory(car_id=c.car_id, driver=c.driver, vehicle=c.vehicle, car_class=c.car_class,
                               _laps_done=c.laps_done)
                self.cars[c.car_id] = h
            if c.in_pits or (0 < c.speed_kmh < 40 and snap.phase == "green"):
                h._pit_this_lap = True
                h.gaps.clear()  # postój albo wypadek psuje trend przewagi
            if c.laps_done > h._laps_done:
                if h._laps_done >= 0 and c.last_lap > 0:
                    clean = not h._pit_this_lap and snap.phase != "fcy" and c.laps_done > 1
                    h.laps.append((c.laps_done, c.last_lap, clean))
                    if clean:
                        self.driver_laps.setdefault((c.car_id, c.driver), []).append(c.last_lap)
                h._laps_done = c.laps_done
                h._pit_this_lap = c.in_pits

        # Twój postój psuje trend przewagi do wszystkich
        if player is not None and player.in_pits:
            for h in self.cars.values():
                h.gaps.clear()
        # przewagi zapisujemy raz na okrążenie gracza
        if player is not None and player.laps_done > self.player_laps_done:
            self.player_laps_done = player.laps_done
            for c in snap.cars:
                if c.is_player:
                    continue
                gap, laps = self._gap(snap, player, c)
                if gap is not None and laps == 0 and not c.in_pits:
                    self.cars[c.car_id].gaps.append((player.laps_done, gap))

    def _ref_lap(self, player: CarScoring) -> float:
        me = self.cars.get(player.car_id)
        pace = me.pace() if me else None
        if pace:
            return pace
        if player.best_lap > 0:
            return player.best_lap
        return 120.0

    def _gap(self, snap: Snapshot, player: CarScoring, c: CarScoring) -> tuple[Optional[float], int]:
        """Przewaga liczona z dystansu na torze (niezależna od symulatora).

        Zwraca (sekundy, różnica okrążeń). Sekundy > 0 = rywal za Tobą.
        Gdy różnica przekracza okrążenie, zwraca (None, liczba okrążeń; > 0 = rywal z tyłu).
        """
        L = snap.track_length
        if L <= 0:
            return None, 0
        d = (player.laps_done * L + player.lap_dist) - (c.laps_done * L + c.lap_dist)
        if abs(d) >= L:
            return None, int(d / L)
        return d / (L / self._ref_lap(player)), 0

    def rivals(self, snap: Snapshot, ahead: int = 2, behind: int = 2) -> list[RivalInfo]:
        player = snap.player_scoring()
        if player is None:
            return []
        same = sorted([c for c in snap.cars if c.car_class == player.car_class], key=lambda c: c.place)
        idx = next((i for i, c in enumerate(same) if c.is_player), None)
        if idx is None:
            return []
        me = self.cars.get(player.car_id)
        my_pace = me.pace() if me else None
        chosen = same[max(0, idx - ahead):idx] + same[idx + 1:idx + 1 + behind]
        out = []
        for c in chosen:
            h = self.cars.get(c.car_id) or CarHistory(car_id=c.car_id)
            gap, laps = self._gap(snap, player, c)
            pace = h.pace()
            pdiff = (pace - my_pace) if (pace and my_pace) else None
            trend = h.gap_trend()
            catch = None
            if gap is not None and pdiff is not None and abs(pdiff) > 0.05:
                # rywal z tyłu i szybszy, albo przed Tobą i wolniejszy
                if (gap > 0 and pdiff < 0) or (gap < 0 and pdiff > 0):
                    catch = abs(gap) / abs(pdiff)
                    if catch < 1:
                        catch = None  # walka koło w koło, prognoza bez sensu
            out.append(RivalInfo(
                car=c, hist=h, gap_s=gap, laps_diff=laps, pace=pace, pace_diff=pdiff, trend=trend,
                laps_to_catch=catch, class_place=same.index(c) + 1,
            ))
        return out

    def class_position(self, snap: Snapshot) -> tuple[int, int]:
        player = snap.player_scoring()
        if player is None:
            return 0, 0
        same = sorted([c for c in snap.cars if c.car_class == player.car_class], key=lambda c: c.place)
        idx = next((i for i, c in enumerate(same) if c.is_player), -1)
        return idx + 1, len(same)

    def faster_class_behind(self, snap: Snapshot, horizon_s: float = 12.0) -> list[tuple[CarScoring, float]]:
        """Auta szybszej klasy, które dojadą do Ciebie w ciągu horizon_s sekund (szacunek z pozycji na torze)."""
        player = snap.player_scoring()
        if player is None or snap.track_length <= 0:
            return []
        me = self.cars.get(player.car_id)
        my_pace = me.pace() if me else None
        out = []
        for c in snap.cars:
            if c.is_player or c.car_class == player.car_class or c.in_pits:
                continue
            h = self.cars.get(c.car_id)
            pace = h.pace() if h else None
            if not pace or not my_pace or pace >= my_pace:
                continue
            behind_m = (player.lap_dist - c.lap_dist) % snap.track_length
            closing = snap.track_length / pace - snap.track_length / my_pace  # m/s
            t_track = behind_m / (snap.track_length / pace)
            if closing > 0 and t_track < horizon_s * 3:
                eta = behind_m / closing
                if eta <= horizon_s:
                    out.append((c, eta))
        return sorted(out, key=lambda x: x[1])

    def faster_class_eta(self, snap: Snapshot, cls: Optional[str] = None) -> list[tuple[CarScoring, float, float]]:
        """Wszystkie auta szybszej klasy za Tobą na torze: (auto, za ile sekund dojedzie, ile sekund za Tobą na torze).

        Bez limitu czasu – do pytania „za ile dubluje mnie pierwszy hypercar”. Tempo z czystych okrążeń,
        a gdy jeszcze go nie ma – z najlepszego okrążenia."""
        player = snap.player_scoring()
        if player is None or snap.track_length <= 0:
            return []
        L = snap.track_length
        me = self.cars.get(player.car_id)
        my_pace = (me.pace() if me else None) or (player.best_lap if player.best_lap > 0 else None)
        if not my_pace:
            return []
        out = []
        for c in snap.cars:
            if c.is_player or c.car_class == player.car_class or c.in_pits or c.finished:
                continue
            if cls and cls not in c.car_class.lower().replace(" ", ""):
                continue
            h = self.cars.get(c.car_id)
            pace = (h.pace() if h else None) or (c.best_lap if c.best_lap > 0 else None)
            if not pace or pace >= my_pace - 0.5:
                continue
            behind_m = (player.lap_dist - c.lap_dist) % L
            closing = L / pace - L / my_pace          # m/s
            out.append((c, behind_m / closing, behind_m / (L / pace)))
        return sorted(out, key=lambda x: x[1])

    def class_best_laps(self, snap: Snapshot, top: int = 5) -> list[CarScoring]:
        player = snap.player_scoring()
        if player is None:
            return []
        same = [c for c in snap.cars if c.car_class == player.car_class and c.best_lap > 0]
        return sorted(same, key=lambda c: c.best_lap)[:top]


class RivalCorners:
    """Przejazd rywali przez zakręty – z pozycji na torze (dystans i prędkość w danych wyników gry).

    Gra nie podaje telemetrii innych aut (gaz, hamulec), ale podaje ich dystans na okrążeniu i prędkość
    kilka razy na sekundę. Z tego: czas przejazdu każdego zakrętu (od początku hamowania do pełnego gazu
    na Twoim wzorcu) i najniższa prędkość w zakręcie. Ty liczony tak samo – porównanie jest uczciwe.
    Tylko auta Twojej klasy, ostatnie 5 czystych okrążeń każdego kierowcy."""

    KEEP = 5

    def __init__(self) -> None:
        self.cur: dict[int, list] = {}         # car_id -> [laps_done, kierowca, dist, t, v, czyste]
        self.laps: dict[tuple[int, str], list] = {}   # (car_id, kierowca) -> [(czas okrążenia, dist, t, v)]

    def reset(self) -> None:
        self.cur.clear()
        self.laps.clear()

    def update(self, snap) -> None:
        from array import array
        me = snap.player_scoring()
        if me is None or snap.track_length <= 0:
            return
        green = snap.phase == "green"
        for c in snap.cars:
            if c.car_class != me.car_class:
                continue
            st = self.cur.get(c.car_id)
            if st is None or st[0] != c.laps_done or st[1] != c.driver:
                if st is not None and st[1] == c.driver and c.laps_done == st[0] + 1 and st[5] and \
                        len(st[2]) > 50 and c.last_lap > 0 and st[2][0] < 300 and st[2][-1] > snap.track_length - 300:
                    rec = self.laps.setdefault((c.car_id, c.driver), [])
                    rec.append((c.last_lap, st[2], st[3], st[4]))
                    del rec[:-self.KEEP]
                st = self.cur[c.car_id] = [c.laps_done, c.driver, array("f"), array("d"), array("f"), True]
            if c.in_pits or not green or c.pit_state in (1, 2, 3, 4) or (0 < c.speed_kmh < 40):
                st[5] = False
            d = st[2]
            if not d or c.lap_dist > d[-1] + 4:
                d.append(c.lap_dist)
                st[3].append(snap.t)
                st[4].append(c.speed_kmh)

    @staticmethod
    def _t_at(lap, x: float) -> Optional[float]:
        import bisect
        d, t = lap[1], lap[2]
        i = bisect.bisect_left(d, x)
        if i <= 0 or i >= len(d):
            return None
        d0, d1 = d[i - 1], d[i]
        if d1 - d0 > 120:                     # dziura w danych
            return None
        return t[i - 1] + (t[i] - t[i - 1]) * (x - d0) / max(1e-6, d1 - d0)

    def corner_times(self, lap, corners) -> dict:
        out = {}
        for c in corners:
            a, b = self._t_at(lap, c.start), self._t_at(lap, c.end)
            if a is None or b is None or b <= a:
                continue
            vs = [v for x, v in zip(lap[1], lap[3]) if c.apex - 60 <= x <= c.apex + 60]
            out[c.name] = (b - a, min(vs) if vs else None)
        return out

    def best(self, car_id: int, driver: str):
        rec = self.laps.get((car_id, driver)) or []
        return min(rec, key=lambda r: r[0]) if rec else None

    def compare(self, me, other, corners) -> Optional[tuple]:
        """(moje okrążenie, jego okrążenie, [(zakręt, różnica czasu s (+ = on wolniejszy), różnica prędkości)])"""
        a, b = self.best(me.car_id, me.driver), self.best(other.car_id, other.driver)
        if a is None or b is None or not corners:
            return None
        ta, tb = self.corner_times(a, corners), self.corner_times(b, corners)
        rows = []
        for c in corners:
            if c.name in ta and c.name in tb:
                dv = (tb[c.name][1] - ta[c.name][1]) if ta[c.name][1] and tb[c.name][1] else None
                rows.append((c.name, tb[c.name][0] - ta[c.name][0], dv))
        return a[0], b[0], rows
