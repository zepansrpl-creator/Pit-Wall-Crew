"""Sugestie bez pytania: powtarzające się problemy z autem widoczne w telemetrii.

Wykrywamy na każdym odczycie (w zakrętach znanych z najlepszego okrążenia):
- blokowanie przednich / tylnych kół na hamowaniu (poślizg wzdłużny opony przy hamulcu),
- buksowanie tylnych kół na wyjściu (poślizg wzdłużny tyłu przy gazie).
Po okrążeniu dokładamy balans z analizy prowadzenia (podsterowność / nadsterowność w fazach zakrętu).

Komunikat pada tylko, gdy problem powtarza się na co najmniej 3 z 4 ostatnich okrążeń,
najwyżej raz na kilkanaście minut. Rada zależy od sesji:
- wyścig: to, co kierowca zmieni z kokpitu (balans hamulców, TC, ABS) albo technika jazdy,
- trening / kwalifikacje: także zmiany w garażu.
Po zmianie ustawienia w aucie sprawdzamy, czy pomogło.
"""

from __future__ import annotations

import collections
from dataclasses import dataclass
from typing import Optional

LOCK, LOCK_REAR, SPIN = "lock_front", "lock_rear", "spin"
ABS_HEAVY, TC_HEAVY = "abs", "tc"


@dataclass
class _Pending:
    kind: str
    lap_idx: int
    settings: tuple
    count_before: float
    changed_at: Optional[int] = None


def _corner_at(corners, d: float):
    for c in corners:
        if c.start <= c.end:
            if c.start <= d <= c.end:
                return c
        elif d >= c.start or d <= c.end:   # zakręt przez linię mety
            return c
    return None


# pełna lista zakrętów z ostatniego skróconego komunikatu – na dopytanie „w których?”
LAST_FULL: dict = {"text": "", "t": 0.0}


def _list(names: list[str], case: str = "loc") -> str:
    """Do 3 zakrętów wymienia wszystkie, więcej – tylko ile i dwa pierwsze („w 6 zakrętach, najbardziej T3 i T11”);
    pełną listę inżynier poda, gdy kierowca dopyta „w których?”."""
    import time
    names = list(dict.fromkeys(names))
    if len(names) == 1:
        return names[0]
    full = ", ".join(names[:-1]) + " i " + names[-1]
    if len(names) <= 3:
        return full
    LAST_FULL["text"], LAST_FULL["t"] = full, time.monotonic()
    n = len(names)
    return (f"{n} zakrętach, najbardziej {names[0]} i {names[1]}" if case == "loc"
            else f"{n} zakrętów, najbardziej {names[0]} i {names[1]}")


class SuggestMonitor:
    def __init__(self, cfg: Optional[dict] = None) -> None:
        cfg = cfg or {}
        self.enabled = bool(cfg.get("suggestions", True))
        self.lock_slip = float(cfg.get("lock_slip", 0.30))      # poślizg wzdłużny uznany za blokowanie
        self.spin_slip = float(cfg.get("spin_slip", 0.22))      # ... za buksowanie
        self.min_event_s = float(cfg.get("lock_min_s", 0.12))   # tyle musi trwać, żeby się liczyło
        self.gap_s = float(cfg.get("suggest_gap_min", 12)) * 60
        self.repeat_s = float(cfg.get("suggest_repeat_min", 30)) * 60
        self.abs_frac = float(cfg.get("abs_heavy_frac", 0.75))  # ABS przez taką część hamowania = dużo
        self.tc_heavy_s = float(cfg.get("tc_heavy_s", 1.2))     # TC tyle sekund na wyjściu z jednego zakrętu
        self._cur: dict[tuple[str, str], float] = collections.defaultdict(float)
        self._brk: dict[str, list[float]] = collections.defaultdict(lambda: [0.0, 0.0])  # zakręt -> [hamowanie, ABS]
        self.history: collections.deque[dict[tuple[str, str], float]] = collections.deque(maxlen=4)
        self._t: Optional[float] = None
        self._last_said: Optional[float] = None
        self._said: dict[str, float] = {}
        self._pending: Optional[_Pending] = None
        self.laps_seen = 0
        self.last_text = ""
        self.limits = None    # interfejs gry: setup z zakresami (at_min / at_max), żeby nie radzić niemożliwego

    # ------------------------------------------------------------ odczyty
    def sample(self, snap, corners) -> None:
        p = snap.player
        t = snap.t
        dt = 0.0 if self._t is None else max(0.0, min(0.5, t - self._t))
        self._t = t
        if p is None or p.in_pits or not corners or dt == 0 or p.speed_kmh < 40 or len(p.tyres) < 4:
            return
        slips = [ty.long_slip for ty in p.tyres]
        c = _corner_at(corners, p.lap_dist)
        if c is None:
            return
        if p.brake > 0.25:
            b = self._brk[c.name]
            b[0] += dt
            if p.abs_active:
                b[1] += dt
            if max(slips[0], slips[1]) > self.lock_slip:
                self._cur[(LOCK, c.name)] += dt
            elif max(slips[2], slips[3]) > self.lock_slip:
                self._cur[(LOCK_REAR, c.name)] += dt
        elif p.throttle > 0.3 and p.brake < 0.05:
            if max(slips[2], slips[3]) > self.spin_slip:
                self._cur[(SPIN, c.name)] += dt
            if p.tc_active:
                self._cur[(TC_HEAVY, c.name)] += dt

    def end_lap(self, pit: bool) -> None:
        lap = {k: v for k, v in self._cur.items() if v >= self.min_event_s and k[0] in (LOCK, LOCK_REAR, SPIN)}
        tc = {k: v for k, v in self._cur.items() if k[0] == TC_HEAVY}
        if tc:
            others = sorted(tc.values())
            typical = others[len(others) // 2]
            for k, v in tc.items():
                if v >= max(self.tc_heavy_s, 2.5 * typical):
                    lap[k] = v
        fr = {n: a / b for n, (b, a) in self._brk.items() if b >= 0.8}
        if fr:
            avg = sum(fr.values()) / len(fr)
            for n, f in fr.items():
                if f >= max(self.abs_frac, avg + 0.3):
                    lap[(ABS_HEAVY, n)] = f
        self._cur = collections.defaultdict(float)
        self._brk = collections.defaultdict(lambda: [0.0, 0.0])
        if pit:
            return
        self.history.append(lap)
        self.laps_seen += 1

    def reset_stint(self) -> None:
        self.history.clear()
        self._cur = collections.defaultdict(float)
        self._brk = collections.defaultdict(lambda: [0.0, 0.0])

    # ------------------------------------------------------------ analiza
    def _repeated(self, kind: str) -> list[str]:
        """Zakręty, w których problem był na co najmniej 3 z 4 ostatnich okrążeń."""
        if len(self.history) < 3:
            return []
        cnt: collections.Counter = collections.Counter()
        for lap in self.history:
            for (k, name) in lap:
                if k == kind:
                    cnt[name] += 1
        return [n for n, v in cnt.items() if v >= 3]

    def _rate(self, kind: str) -> float:
        if not self.history:
            return 0.0
        return sum(sum(1 for (k, _) in lap if k == kind) for lap in self.history) / len(self.history)

    def check(self, t: float, race: bool, settings: tuple, handling=None) -> Optional[str]:
        """Wołane po okrążeniu. Zwraca jedną sugestię albo nic."""
        if not self.enabled:
            return None
        verdict = self._check_effect(settings)
        if verdict:
            return verdict
        if self._last_said is not None and t - self._last_said < self.gap_s:
            return None
        for kind, text in self._candidates(race, handling):
            text = self._fit_setup(text)
            if not text:
                continue
            last = self._said.get(kind)
            if last is not None and t - last < self.repeat_s:
                continue
            self._said[kind] = t
            self._last_said = t
            self._pending = _Pending(kind, self.laps_seen, settings, self._rate(kind))
            self.last_text = text
            return text
        return None

    def _fit_setup(self, text: str) -> Optional[str]:
        """Usuwa albo zamienia rady, których nie da się zrobić w obecnym setupie (np. stabilizator już odłączony)."""
        L = self.limits
        if L is None or not getattr(L, "setup", None):
            return text
        swaps = [
            ("miększy tylny stabilizator", "VM_REAR_ANTISWAY", "miększe tylne sprężyny", "WM_SPRING-W_RL"),
            ("Miększy przedni stabilizator o klik", "VM_FRONT_ANTISWAY", "Miększe przednie sprężyny o klik", "WM_SPRING-W_FL"),
        ]
        for phrase, key, alt, alt_key in swaps:
            if phrase in text and L.at_min(key):
                text = text.replace(phrase, alt) if not L.at_min(alt_key) else text.replace(", albo w garażu " + phrase, "") \
                    .replace(", albo " + phrase, "").replace(phrase + ".", "")
        drops = [("Tylne skrzydło o klik niżej", "VM_REAR_WING", "min"), ("Tylne skrzydło o klik wyżej", "VM_REAR_WING", "max"),
                 ("mniejszy preload dyferencjału", "VM_DIFF_PRELOAD", "min"),
                 ("Mniejszy preload dyferencjału", "VM_DIFF_PRELOAD", "min")]
        for phrase, key, side in drops:
            if phrase in text and (L.at_min(key) if side == "min" else L.at_max(key)):
                text = text.replace(", albo w garażu " + phrase, "").replace(phrase + ".", "")
        for w, key in (("LP", "WM_PRESSURE-W_FL"), ("PP", "WM_PRESSURE-W_FR"), ("LT", "WM_PRESSURE-W_RL"), ("PT", "WM_PRESSURE-W_RR")):
            if f"Opona {w}:" in text and "Ciśnienie niżej" in text and L.at_min(key):
                return None
        text = text.strip()
        if not text.endswith("."):
            text += "."
        # zostało samo stwierdzenie bez rady -> nie mówimy
        return text if any(x in text for x in ("o klik", "o jeden", "pół procent", "Spokojniej", "Łagodniej", "lżej",
                                                "sprężyny", "Ciśnienie", "Hamuj", "camberu", "Kanały")) else None

    def _check_effect(self, settings: tuple) -> Optional[str]:
        """Po sugestii: jeśli kierowca zmienił ustawienie w aucie, po 3 okrążeniach mówimy, czy pomogło."""
        pd = self._pending
        if pd is None or pd.kind.startswith("h_"):
            return None
        if self.laps_seen - pd.lap_idx > 10:
            self._pending = None
            return None
        if settings == pd.settings:
            return None
        if pd.changed_at is None:            # kierowca właśnie zmienił ustawienie: liczymy okrążenia od zmiany
            pd.changed_at = self.laps_seen
            self.history.clear()
            return None
        if self.laps_seen - pd.changed_at < 3:
            return None
        self._pending = None
        now = self._rate(pd.kind)
        what = {LOCK: "blokowania przodu", LOCK_REAR: "blokowania tyłu", SPIN: "buksowania",
                ABS_HEAVY: "pracy ABS-u", TC_HEAVY: "pracy TC"}.get(pd.kind, "problemu")
        if now <= pd.count_before * 0.5:
            return f"Po zmianie lepiej, dużo mniej {what}."
        if now < pd.count_before:
            return f"Po zmianie trochę mniej {what}."
        return f"Po zmianie bez poprawy {what}. Możesz wrócić do poprzedniego ustawienia."

    def _candidates(self, race: bool, h) -> list[tuple[str, str]]:
        out: list[tuple[str, str]] = []
        lf = self._repeated(LOCK)
        if len(lf) >= 2:
            out.append((LOCK, f"Blokujesz przód w {_list(lf)}. Balans hamulców pół procent do tyłu."))
        elif lf:
            out.append((LOCK, f"Blokujesz przód na hamowaniu do {lf[0]}. Łagodniej dociskaj hamulec pod koniec."))
        lr = self._repeated(LOCK_REAR)
        if lr:
            out.append((LOCK_REAR, f"Tył blokuje się na hamowaniu w {_list(lr)}. Balans hamulców pół procent do przodu."))
        sp = self._repeated(SPIN)
        if len(sp) >= 2:
            txt = f"Tył buksuje na wyjściu z {_list(sp, "gen")}. TC główne o jeden wyżej"
            txt += "." if race else ", albo w garażu miększy tylny stabilizator."
            out.append((SPIN, txt))
        elif sp:
            out.append((SPIN, f"Tył buksuje na wyjściu z {sp[0]}. Spokojniej otwieraj gaz."))
        ab = self._repeated(ABS_HEAVY)
        if len(ab) >= 3:
            out.append((ABS_HEAVY, f"ABS pracuje prawie przez całe hamowanie w {_list(ab)}. "
                                   "Balans hamulców pół procent do tyłu albo lżej na pedale."))
        elif ab:
            out.append((ABS_HEAVY, f"W {_list(ab)} ABS pracuje prawie przez całe hamowanie. Hamuj trochę lżej."))
        tc = self._repeated(TC_HEAVY)
        if len(tc) >= 3:
            txt = f"TC dużo pracuje na wyjściach z {_list(tc, "gen")}. TC Cut o jeden niżej, mniej odetnie mocy"
            out.append((TC_HEAVY, txt + ("." if race else ", albo w garażu mniejszy preload dyferencjału.")))
        elif tc:
            out.append((TC_HEAVY, f"Na wyjściu z {_list(tc, "gen")} TC pracuje dużo. Spokojniej z gazem."))
        out += self._handling(race, h)
        return out

    def _handling(self, race: bool, h) -> list[tuple[str, str]]:
        """Balans z analizy prowadzenia (3 ostatnie czyste okrążenia). Progi ostrzejsze niż przy pytaniu."""
        if h is None or self.laps_seen < 4:
            return []
        under, over = 1.4, -1.4
        cs = h.corners

        def where(attr, pred, cls=None):
            return [c.name for c in cs if getattr(c, attr) is not None and pred(getattr(c, attr))
                    and (cls is None or c.speed_class in cls)]

        out = []
        e_over = where("entry", lambda b: b < over)
        if len(e_over) >= 2:
            out.append(("h_entry_over", f"Tył ucieka na wejściu w {_list(e_over)}. Balans hamulców pół procent do przodu."))
        e_under = where("entry", lambda b: b > under)
        if len(e_under) >= 2:
            out.append(("h_entry_under", f"Podsterowność na wejściu w {_list(e_under)}. Balans hamulców pół procent do tyłu."))
        x_over = where("exit", lambda b: b < over)
        if len(x_over) >= 2:
            txt = f"Nadsterowność na wyjściu z {_list(x_over)}. TC Slip o jeden wyżej"
            out.append(("h_exit_over", txt + ("." if race else ", albo miększy tylny stabilizator.")))
        if not race:
            slow = where("mid", lambda b: b > under, ("wolny", "średni"))
            if len(slow) >= 2:
                out.append(("h_mid_under_slow", f"Podsterowność w środku wolnych zakrętów: {_list(slow)}. "
                                                "Miększy przedni stabilizator o klik."))
            fast_u = where("mid", lambda b: b > under, ("szybki",))
            if len(fast_u) >= 2:
                out.append(("h_mid_under_fast", f"Podsterowność w szybkich zakrętach: {_list(fast_u)}. "
                                                "Tylne skrzydło o klik niżej."))
            fast_o = where("mid", lambda b: b < over, ("szybki",))
            if len(fast_o) >= 2:
                out.append(("h_mid_over_fast", f"Nadsterowność w szybkich zakrętach: {_list(fast_o)}. "
                                               "Tylne skrzydło o klik wyżej."))
            x_under = where("exit", lambda b: b > under)
            if len(x_under) >= 3:
                out.append(("h_exit_under", f"Podsterowność na wyjściach z {_list(x_under)}. "
                                            "Mniejszy preload dyferencjału."))
            tyres = getattr(h, "tyres", []) or []
            for tf in tyres:
                for note in tf.notes:
                    if "ciśnienie za wysokie" in note:
                        out.append((f"h_press_hi_{tf.wheel}", f"Opona {tf.wheel}: środek gorętszy od krawędzi. Ciśnienie niżej."))
                    elif "ciśnienie za niskie" in note:
                        out.append((f"h_press_lo_{tf.wheel}", f"Opona {tf.wheel}: środek chłodniejszy od krawędzi. Ciśnienie wyżej."))
            out += _camber_brakes(tyres)
        return out


BRAKE_HOT_C = 800.0     # najwyższa temperatura tarczy na okrążeniu – powyżej: otworzyć kanały
BRAKE_COLD_C = 350.0    # poniżej: można przymknąć (mniej oporu, szybciej rozgrzane)


def _camber_brakes(tyres) -> list[tuple[str, str]]:
    """Trening: camber z różnicy temperatur krawędzi opon, kanały hamulców z temperatur tarcz (osobno przód i tył)."""
    out: list[tuple[str, str]] = []
    if len(tyres) != 4:
        return out
    for axle, pair in (("przód", tyres[:2]), ("tył", tyres[2:])):
        diff = sum(t.inner - t.outer for t in pair) / 2
        if diff > 12:
            out.append((f"h_camber_less_{axle}", f"{axle.capitalize()}: wewnętrzne krawędzie opon gorętsze o {diff:.0f} stopni. "
                                                 f"Mniej negatywnego camberu o klik."))
        elif diff < -3:
            out.append((f"h_camber_more_{axle}", f"{axle.capitalize()}: zewnętrzne krawędzie gorętsze o {-diff:.0f} stopni. "
                                                 f"Więcej negatywnego camberu o klik."))
        bm = [t.brake_max for t in pair if t.brake_max and t.brake_max > 0]
        if bm:
            hot = max(bm)
            if hot > BRAKE_HOT_C:
                out.append((f"h_duct_open_{axle}", f"Hamulce {axle}: do {hot:.0f} stopni. Kanały hamulców bardziej otwarte o klik."))
            elif hot < BRAKE_COLD_C:
                out.append((f"h_duct_close_{axle}", f"Hamulce {axle}: tylko {hot:.0f} stopni. Kanały hamulców przymknij o klik."))
    return out
