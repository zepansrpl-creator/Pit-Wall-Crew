"""Rejestrator okrążeń: zapisuje przebieg każdego okrążenia co BIN metrów."""

from __future__ import annotations

import json
import math
import os
import re
from dataclasses import dataclass, field, asdict
from typing import Optional

from ..model import Snapshot

BIN = 5.0  # metry


@dataclass
class LapTrace:
    lap: int
    track: str
    car: str
    track_length: float
    lap_time: float = 0.0
    valid: bool = True
    pit: bool = False             # okrążenie z wjazdem/wyjazdem z alei
    fcy: bool = False             # okrążenie pod FCY / safety car
    incomplete: bool = False      # za mało danych (start w połowie okrążenia, przerwa w odczycie)
    fuel_start: float = 0.0
    fuel_end: float = 0.0
    ve_start: Optional[float] = None
    ve_end: Optional[float] = None
    wear_end: float = 0.0
    wear_tyres: list[float] = field(default_factory=list)   # zużycie FL, FR, RL, RR na końcu okrążenia (0..1)
    damage_end: int = 0                                      # suma uszkodzeń nadwozia (0..16)
    impact: bool = False                                     # uderzenie w trakcie okrążenia
    stint_lap: int = 0                                       # które okrążenie na tych oponach
    driver: str = ""
    wetness: float = 0.0          # średnia wilgotność toru na okrążeniu (0..1)
    rain: float = 0.0             # średnia intensywność deszczu (0..1)
    track_temp: float = 0.0
    compound: str = ""            # mieszanka opon (przód)
    off_tracks: int = 0           # ile razy kierowca wyjechał poza tor
    tl_steps: int = 0             # przyrost kroków za limity toru
    # dane per bin (indeks = dystans / BIN)
    t: list[float] = field(default_factory=list)        # czas od startu okrążenia (s)
    speed: list[float] = field(default_factory=list)    # km/h
    throttle: list[float] = field(default_factory=list)
    brake: list[float] = field(default_factory=list)
    steer: list[float] = field(default_factory=list)
    gear: list[int] = field(default_factory=list)
    tc: list[int] = field(default_factory=list)          # 1 gdy TC ciął moc
    abs: list[int] = field(default_factory=list)
    bal: list[float] = field(default_factory=list)       # poślizg przód - tył (stopnie); + podsterowność, - nadsterowność
    latg: list[float] = field(default_factory=list)      # przeciążenie boczne (g, wartość bezwzględna)
    rpmf: list[float] = field(default_factory=list)      # obroty / obroty maksymalne
    # średnie z okrążenia (tylko przy prędkości > 80 km/h)
    tyre_temps: list[list[float]] = field(default_factory=list)   # [FL, FR, RL, RR] x [wewn., środek, zewn.] °C
    tyre_pressures: list[float] = field(default_factory=list)     # kPa
    brake_max: list[float] = field(default_factory=list)          # °C
    tyre_optimal: float = 0.0

    @property
    def fuel_used(self) -> float:
        return self.fuel_start - self.fuel_end

    @property
    def ve_used(self) -> Optional[float]:
        if self.ve_start is None or self.ve_end is None:
            return None
        return self.ve_start - self.ve_end

    def plausible(self) -> bool:
        """Czy dane okrążenia są prawdziwe: czas rośnie wzdłuż toru i nigdzie nie wychodzi prędkość ponad 420 km/h
        (przerwa w odczycie, powrót do boksu albo teleport dają „dziurę” – takie okrążenie psuło porównania,
        ostrzeżenia o dublowaniu i moment „box, box”)."""
        t = self.t
        n = len(t)
        if n < 50 or self.lap_time <= 0 or self.track_length <= 0:
            return False
        if self.lap_time < self.track_length / (420 / 3.6):
            return False
        w = 40                                  # 200 m
        for i in range(1, n):
            if t[i] < t[i - 1] - 0.5 and i > 3:
                return False
        for i in range(4, n - w, 5):
            dt = t[i + w] - t[i]
            if dt <= 0 or (w * BIN) / dt * 3.6 > 420:
                return False
        return True

    @property
    def clean(self) -> bool:
        """Okrążenie nadaje się do porównań tempa i zużycia."""
        return self.valid and not self.pit and not self.fcy and self.lap_time > 0 and len(self.t) > 0

    def time_at(self, dist: float) -> float:
        i = min(len(self.t) - 1, max(0, int(dist / BIN)))
        v = self.t[i]
        # starsze zapisy miały w pierwszych binach czas z końca poprzedniego okrążenia
        if i < len(self.t) // 4 and self.lap_time > 0 and v > self.lap_time * 0.5:
            return self.lap_time * i / max(1, len(self.t))
        return v

    def save(self, path: str) -> None:
        os.makedirs(os.path.dirname(path), exist_ok=True)
        with open(path, "w", encoding="utf-8") as f:
            json.dump(asdict(self), f)

    @staticmethod
    def load(path: str) -> "LapTrace":
        with open(path, encoding="utf-8") as f:
            return LapTrace(**json.load(f))


def _fill(arr: list, n: int, default=0.0) -> list:
    """Uzupełnia puste biny ostatnią znaną wartością (czas: interpolacja liniowa)."""
    out = list(arr[:n]) + [None] * max(0, n - len(arr))
    last = default
    for i in range(n):
        if out[i] is None:
            out[i] = last
        else:
            last = out[i]
    return out


def _fill_time(arr: list, n: int, lap_time: float) -> list:
    pts = [(i, v) for i, v in enumerate(arr[:n]) if v is not None]
    if not pts:
        return [0.0] * n
    if pts[0][0] != 0:
        pts.insert(0, (0, 0.0))
    if pts[-1][0] != n - 1:
        pts.append((n - 1, lap_time if lap_time > pts[-1][1] else pts[-1][1]))
    out = [0.0] * n
    for (i0, v0), (i1, v1) in zip(pts, pts[1:]):
        for i in range(i0, i1 + 1):
            out[i] = v0 + (v1 - v0) * ((i - i0) / (i1 - i0) if i1 > i0 else 0)
    return out


class LapRecorder:
    """Buduje LapTrace dla bieżącego okrążenia i zwraca je po przejechaniu linii mety."""

    def __init__(self) -> None:
        self.current: Optional[LapTrace] = None
        self._raw: dict[str, list] = {}
        self._lap_start_t = 0.0
        self._laps_done: Optional[int] = None
        self._last_dist = 0.0
        self._last_player = None
        self._last_impact_t: Optional[float] = None
        self._env = [0.0, 0.0, 0.0, 0]
        self._was_off = False
        self._tl0 = 0

    def reset(self) -> None:
        self.current = None
        self._laps_done = None

    def _start(self, snap: Snapshot, laps_done: int, started_clean: bool) -> None:
        p = snap.player
        self._lap_start_t = snap.t
        n = int(math.ceil(snap.track_length / BIN)) if snap.track_length > 0 else 2000
        self._raw = {k: [None] * n for k in ("t", "speed", "throttle", "brake", "steer", "gear", "tc", "abs",
                                             "bal", "latg", "rpmf")}
        self._tsum = [[0.0, 0.0, 0.0] for _ in range(4)]
        self._psum = [0.0] * 4
        self._tcount = 0
        self._bmax = [0.0] * 4
        ps = snap.player_scoring()
        self._env = [0.0, 0.0, 0.0, 0]
        self._tl0 = p.track_limit_steps
        self.current = LapTrace(
            lap=laps_done + 1, track=snap.track, car=snap.car_name, track_length=snap.track_length,
            fuel_start=p.fuel_l, ve_start=p.virtual_energy, valid=started_clean, incomplete=not started_clean,
            pit=p.in_pits, driver=ps.driver if ps else "",
            damage_end=sum(p.dents) + (4 if p.parts_detached else 0), compound=p.compound_front,
        )

    def update(self, snap: Snapshot) -> Optional[LapTrace]:
        p = snap.player
        ps = snap.player_scoring()
        if p is None or ps is None or snap.track_length <= 0:
            return None
        finished: Optional[LapTrace] = None

        if self._laps_done is None:
            self._laps_done = ps.laps_done
            # okrążenie zaczęte w połowie nie nadaje się do porównań
            self._start(snap, ps.laps_done, started_clean=p.lap_dist < 50)
        elif ps.laps_done > self._laps_done:
            finished = self._finish(snap, ps.last_lap)
            self._laps_done = ps.laps_done
            self._start(snap, ps.laps_done, started_clean=True)
        elif ps.laps_done < self._laps_done:
            # restart sesji / powrót do garażu
            self._laps_done = ps.laps_done
            self._start(snap, ps.laps_done, started_clean=False)

        cur = self.current
        if cur is None:
            return finished
        if p.in_pits:
            cur.pit = True
        if p.lap_invalid:
            cur.valid = False
        if snap.phase == "fcy":
            cur.fcy = True
        self._env[0] += snap.wetness
        self._env[1] += snap.rain
        self._env[2] += snap.track_temp
        self._env[3] += 1
        if ps.off_track and not self._was_off and not p.in_pits and p.speed_kmh > 30:
            cur.off_tracks += 1
        self._was_off = ps.off_track
        cur.tl_steps = max(0, p.track_limit_steps - self._tl0)
        if p.compound_front:
            cur.compound = p.compound_front

        i = int(p.lap_dist / BIN)
        if 0 <= i < len(self._raw["t"]) and self._raw["t"][i] is None:
            # do binu trafia tylko pierwszy pomiar (pozycja wejścia w bin)
            # nie zapisuj "cofnięć" dystansu tuż po linii mety (ekstrapolacja)
            # ani pomiarów z początku nowego okrążenia, zanim gra policzy je w wynikach (dystans już
            # wyzerowany, licznik okrążeń jeszcze nie) – to psuło czas w pierwszym binie (np. 237 s przy 0 m)
            el = snap.t - self._lap_start_t
            if not (p.lap_dist > snap.track_length - 100 and el < 5) and not (p.lap_dist < 100 and el > 20):
                self._raw["t"][i] = snap.t - self._lap_start_t
                self._raw["speed"][i] = p.speed_kmh
                self._raw["throttle"][i] = p.throttle
                self._raw["brake"][i] = p.brake
                self._raw["steer"][i] = p.steering
                self._raw["gear"][i] = p.gear
                self._raw["tc"][i] = 1 if p.tc_active else 0
                self._raw["abs"][i] = 1 if p.abs_active else 0
                ty = p.tyres
                if len(ty) == 4 and p.speed_kmh > 60:
                    front = (ty[0].slip_deg + ty[1].slip_deg) / 2
                    rear = (ty[2].slip_deg + ty[3].slip_deg) / 2
                    self._raw["bal"][i] = front - rear
                else:
                    self._raw["bal"][i] = 0.0
                self._raw["latg"][i] = abs(p.lat_g)
                self._raw["rpmf"][i] = p.rpm / p.max_rpm if p.max_rpm > 0 else 0.0
        if len(p.tyres) == 4 and p.speed_kmh > 80 and not p.in_pits:
            for k, ty in enumerate(p.tyres):
                l, m, r = ty.temp_c
                inner, outer = (r, l) if k in (0, 2) else (l, r)  # lewe koła: lewa strona = zewnętrzna
                self._tsum[k][0] += inner
                self._tsum[k][1] += m
                self._tsum[k][2] += outer
                self._psum[k] += ty.pressure_kpa
                self._bmax[k] = max(self._bmax[k], ty.brake_c)
            self._tcount += 1
        self._last_player = p
        cur.fuel_end = p.fuel_l
        cur.ve_end = p.virtual_energy
        cur.wear_end = max(t.wear for t in p.tyres) if p.tyres else 0.0
        cur.wear_tyres = [round(t.wear, 4) for t in p.tyres]
        dmg = sum(p.dents) + (4 if p.parts_detached else 0)
        if dmg > cur.damage_end or (p.last_impact_t and p.last_impact_t != self._last_impact_t
                                    and p.last_impact_mag > 500):
            if self._last_impact_t is not None:
                cur.impact = True
        self._last_impact_t = p.last_impact_t
        cur.damage_end = dmg
        return finished

    def _finish(self, snap: Snapshot, last_lap: float) -> Optional[LapTrace]:
        cur = self.current
        if cur is None:
            return None
        measured = snap.t - self._lap_start_t
        if self._env[3]:
            cur.wetness = round(self._env[0] / self._env[3], 4)
            cur.rain = round(self._env[1] / self._env[3], 4)
            cur.track_temp = round(self._env[2] / self._env[3], 1)
        cur.lap_time = last_lap if last_lap > 0 and abs(last_lap - measured) < 2.0 else measured
        filled = sum(1 for v in self._raw["t"] if v is not None)
        n = len(self._raw["t"])
        if filled < n * 0.6:
            # rzadkie odczyty (np. 5 razy na sekundę) dają równe, małe luki – to jeszcze pełne okrążenie;
            # niepełne jest dopiero przy dłuższej przerwie w danych
            run = longest = 0
            for v in self._raw["t"]:
                run = run + 1 if v is None else 0
                longest = max(longest, run)
            if filled < n * 0.15 or longest * BIN > 60:
                cur.valid = False  # za mało danych (np. przerwa w odczycie)
                cur.incomplete = True
        cur.t = [round(v, 4) for v in _fill_time(self._raw["t"], n, cur.lap_time)]
        cur.speed = [round(v, 2) for v in _fill(self._raw["speed"], n)]
        cur.throttle = [round(v, 3) for v in _fill(self._raw["throttle"], n)]
        cur.brake = [round(v, 3) for v in _fill(self._raw["brake"], n)]
        cur.steer = [round(v, 3) for v in _fill(self._raw["steer"], n)]
        cur.gear = _fill(self._raw["gear"], n, 0)
        cur.tc = _fill(self._raw["tc"], n, 0)
        cur.abs = _fill(self._raw["abs"], n, 0)
        cur.bal = [round(v, 3) for v in _fill(self._raw["bal"], n)]
        cur.latg = [round(v, 3) for v in _fill(self._raw["latg"], n)]
        cur.rpmf = [round(v, 3) for v in _fill(self._raw["rpmf"], n)]
        if self._tcount:
            cur.tyre_temps = [[round(x / self._tcount, 1) for x in w] for w in self._tsum]
            cur.tyre_pressures = [round(x / self._tcount, 1) for x in self._psum]
            cur.brake_max = [round(x) for x in self._bmax]
        snap_p = self._last_player
        if snap_p is not None and snap_p.tyres:
            cur.tyre_optimal = snap_p.tyres[0].optimal_c
        return cur


def safe_name(s: str) -> str:
    return re.sub(r"[^A-Za-z0-9_.-]+", "_", s).strip("_") or "unknown"


class LapStore:
    """Najlepsze okrążenie per tor + auto zapisywane na dysku (referencja między sesjami)."""

    def __init__(self, root: str) -> None:
        self.root = root

    def _dir(self, track: str, car: str) -> str:
        return os.path.join(self.root, safe_name(track), safe_name(car))

    def load_best(self, track: str, car: str) -> Optional[LapTrace]:
        """Najlepsze okrążenie z poprzednich sesji. Uszkodzone (np. z „dziurą” po powrocie do boksu)
        odkładamy jako best_lap_uszkodzone.json i zaczynamy od nowa."""
        self.last_invalid = False
        path = os.path.join(self._dir(track, car), "best_lap.json")
        if os.path.exists(path):
            try:
                lap = LapTrace.load(path)
            except (OSError, ValueError, TypeError):
                return None
            if not lap.plausible():
                self.last_invalid = True
                try:
                    os.replace(path, path.replace("best_lap.json", "best_lap_uszkodzone.json"))
                except OSError:
                    pass
                return None
            return lap
        return None

    def save_best(self, lap: LapTrace) -> str:
        path = os.path.join(self._dir(lap.track, lap.car), "best_lap.json")
        lap.save(path)
        return path
