"""Pages d'aide en français : commandes, fonctions, mode d'emploi, à propos (original : commands.py, help_texts.py)."""

COMMANDS: list[tuple[str, list[tuple[str, str]]]] = [
    ("Piloter l'ingénieur", [
        ("« silence » / « tais-toi » / « ingénieur, silence »", "« OK. » et silence total (alertes comprises) ; il reparle après le prochain appui sur le bouton radio"),
        ("« <prénom de l'ingénieur>, silence » (ex. « Marc, silence »)", "pareil, si tu as donné un prénom à l'ingénieur (Réglages → Voix)"),
        ("« urgent seulement » / « seulement quand je demande »", "seulement les alertes urgentes et les réponses à tes questions"),
        ("« tu peux parler » / « continue »", "retour aux messages sur les changements"),
        ("« répète » / « redis »", "répète la dernière réponse"),
        ("« test radio » / « tu m'entends ? »", "vérification radio"),
        ("« lesquels ? » / « quels virages ? »", "la liste complète après une réponse courte (« dans 6 virages, surtout T3 et T11 »), jusqu'à 2 minutes après"),
        ("« que sais-tu faire » / « aide »", "courte liste des sujets"),
        ("appui sur le bouton radio", "interrompt ce que dit l'ingénieur"),
    ]),
    ("Activer et désactiver les conseils", [
        ("« pas de prises de tour » / « prises de tour activées »", "alertes sur les catégories plus rapides derrière toi"),
        ("« coach » / « pas de coach »", "conseils avant un virage quand une erreur se répète"),
        ("« comparaison » / « pas de comparaison »", "« T5 : tu freines 15 mètres plus tôt » – comparaison avec ton meilleur tour"),
        ("« comparaison d'équipe » / « pas de comparaison d'équipe »", "« T5 : Patrick freine 15 mètres plus tard. Essaie de freiner plus tard. » – avant un virage où un coéquipier est nettement plus rapide dans des conditions similaires"),
        ("« commentaires » / « pas de commentaires »", "un commentaire après un gain ou une perte de position"),
        ("« conseils » / « pas de conseils »", "conseils de réglages et de pilotage"),
    ]),
    ("Carburant, énergie, arrêt", [
        ("« combien de carburant ? » / « ça tiendra ? »", "carburant, nombre de tours, marge"),
        ("« combien d'énergie ? » / « énergie virtuelle ? »", "énergie virtuelle"),
        ("« quand je rentre ? » / « plan d'arrêt ? »", "tour d'arrêt (au moins 0,2 % d'énergie à l'entrée des stands), combien d'énergie, quels pneus"),
        ("« combien de temps dure l'arrêt ? »", "temps d'arrêt voie des stands comprise"),
        ("« quels pneus on change ? »", "quels pneus changer à l'arrêt (selon le plan de l'équipe ou l'usure) et pourquoi"),
        ("« combien économiser ? » / « comment économiser ? »", "objectif de consommation par tour pour gagner un arrêt ou atteindre le tour prévu"),
        ("« la consommation change ? »", "tendance de la consommation de carburant et d'énergie"),
        ("« combien de temps reste ? » / « combien de tours restent ? »", "temps et tours jusqu'à l'arrivée"),
    ]),
    ("Chronos et pilotage", [
        ("« mon temps ? » / « comment ça va ? »", "dernier et meilleur tour, régularité"),
        ("« où je perds ? » / « où puis-je gagner ? »", "virages où tu perds le plus"),
        ("« virage 5 »", "détails d'un virage précis"),
        ("« je perds du rythme ? » / « suis-je fatigué ? »", "fatigue et baisse de rythme"),
        ("« quelle position ? »", "position dans la catégorie et au général"),
    ]),
    ("Rivaux", [
        ("« qui est devant ? » / « qui je chasse ? »", "écart, rythme, tendance"),
        ("« qui est derrière ? » / « qui me chasse ? »", "écart, rythme, tendance"),
        ("« quand vais-je le rattraper ? » / « va-t-il me rattraper ? »", "dans combien de tours au rythme actuel"),
        ("« rythme du rival ? »", "rythme de la voiture devant ou derrière"),
        ("« qui conduit la voiture devant ? »", "pilotes de la voiture rivale et leur rythme"),
        ("« le rival a changé les pneus ? »", "estimation des pneus du rival au dernier arrêt"),
        ("« quand le rival va rentrer ? »", "arrêt prévu du rival"),
        ("« quand l'hypercar va me prendre un tour ? » / « quand la LMP2 me rattrape ? »", "première voiture d'une catégorie plus rapide : quand elle arrive et à quelle distance elle est ; les suivantes"),
        ("« vitesse de pointe des autres ? »", "vitesse de pointe des rivaux, la tienne et celle du plus rapide de la catégorie"),
    ]),
    ("Voiture", [
        ("« comment sont les pneus ? » / « pressions ? »", "usure, températures, pressions"),
        ("« freins ? »", "usure et températures des freins"),
        ("« compare-moi avec Patrick » / « où mon coéquipier est-il plus rapide ? »", "meilleur tour du coéquipier sur la même gomme, avec une usure, un carburant et une température de piste similaires : dans quels virages il est plus rapide, ce qu'il fait différemment (freinage, vitesse, gaz, rapport) et un conseil"),
        ("« dans quels virages Wieczorek est plus lent que moi ? »", "un rival de ta catégorie : meilleurs tours des deux, où il est plus lent et plus rapide, vitesse en virage"),
        ("« compare les températures des pneus et des freins avec le tour 4 après l'arrêt »", "dernier tour par rapport au tour choisi : freins avant/arrière, pneus avant/arrière, conseil sur le refroidissement des freins"),
        ("« dégâts ? » / « on répare ? »", "dégâts et perte de temps"),
        ("« la réparation dure 30 secondes »", "si la réparation vaut le coup avec ce temps"),
        ("« moteur ? » / « température d'eau ? » / « calandre »", "températures du moteur, conseil sur la calandre"),
        ("« sous-virage en entrée du dernier virage »", "conseil pour le virage et les réglages"),
        ("« j'ai mis la répartition de freinage à 54 » / « ça a aidé ? »", "note le changement de réglage et l'évalue après quelques tours"),
        ("« que changer dans le réglage ? »", "propositions (en course, seulement les réglages du cockpit)"),
        ("« quel TC ? » / « antipatinage ? » / « combien d'ABS ? »", "réglage actuel et conseil d'après les mesures (fonctionne aussi sans IA)"),
    ]),
    ("Météo", [
        ("« météo ? » / « il va pleuvoir ? »", "pluie, humidité, prévisions, température de piste"),
        ("« quand passer en pluie ? » / « quand les slicks ? »", "si et quand un changement de pneus vaut le coup"),
    ]),
    ("Équipe et mémoire", [
        ("« retiens … » / « note … »", "une note pour la mémoire d'équipe (l'IA en tient compte)"),
        ("« notification Adam : réveille-toi, tu roules bientôt »", "notification immédiate sur le téléphone d'un coéquipier (ntfy) ; « notification à tout le monde : … » – à toute l'équipe"),
        ("« dis au prochain pilote que … »", "une note que l'ingénieur lit au pilote suivant lors du briefing"),
        ("questions d'analyse : « compare… », « quelle différence… », « pourquoi… », « qui est le plus rapide… »", "réponse de l'IA avec toutes les données de course"),
        ("toute autre question", "réponse de l'IA (Groq) ; si la reconnaissance est incertaine – « Je n'ai pas compris, répète. »"),
    ]),
    ("Mur des stands (pour l'équipe)", [
        ("« Au pilote »", "un message que l'ingénieur lit au pilote"),
        ("« Demander à l'ingénieur »", "une question à l'ingénieur, la réponse s'entend sur la radio d'équipe"),
        ("« Demander (texte seul) »", "la réponse apparaît seulement sur le mur des stands, le pilote ne l'entend pas"),
        ("« En mémoire »", "une note pour la mémoire d'équipe"),
    ]),
    ("Problèmes et suggestions", [
        ("Appli → Aide → « Signaler un problème » ou mur des stands → Aide", "décris un problème ou une idée – ça va directement à l'auteur"),
    ]),
]

FEATURES: list[tuple[str, list[str]]] = [
    ("Pit Wall Crew en bref", [
        "Un ingénieur de course vocal pour Le Mans Ultimate et un mur des stands pour toute l'équipe. L'ingénieur ne parle que "
        "de ce qui change quelque chose et répond à tes questions à la voix. L'équipe voit tout en direct dans le navigateur et "
        "entend l'ingénieur dans sa propre appli. Fonctionne sur tous les circuits, avec toutes les voitures et catégories.",
    ]),
    ("Alertes urgentes (tout de suite, courtes)", [
        "• Prise de tour par une catégorie plus rapide : « Hypercar, 2 secondes », groupes (« trois Hypercars »).",
        "• Voiture arrêtée ou très lente devant toi, voiture hors piste.",
        "• Drapeaux (jaunes locaux compris), FCY, pénalités, limites de piste, drapeau vert.",
        "• « Box, box » environ 25 s avant l'entrée des stands dans le tour de rentrée. Après le drapeau à damier – plus d'appels au stand.",
    ]),
    ("Stratégie", [
        "• Carburant et énergie virtuelle : consommation mesurée comme dans le jeu ; tours restants, plan d'arrêt (énergie, pneus), temps d'arrêt.",
        "• Arrêt le plus tard possible : à l'entrée des stands et à l'arrivée il reste au moins 0,2 % d'énergie (0,3 l de carburant).",
        "• Plan d'arrêt 3 tours avant, rappel dans le tour de rentrée, position à la sortie des stands.",
        "• Économie : quand quelques pour cent de moins font gagner un arrêt – objectif par tour et contrôle à chaque tour.",
        "• FCY : faut-il rentrer maintenant. Dégâts : combien de secondes ils coûtent et faut-il réparer.",
        "• Pneus : usure et températures, quand un train neuf vaut le coup, pressions la nuit.",
        "• Météo : pluie, piste qui sèche, quand changer de pneus.",
    ]),
    ("Rivaux", [
        "• Écart et tendance avec les voitures devant et derrière dans ta catégorie, quand tu les rattrapes.",
        "• Vitesse de pointe des rivaux comparée à la tienne.",
        "• Rythme de chaque pilote de la voiture rivale, arrêt prévu et pneus.",
        "• Un commentaire après un gain ou une perte de position – seulement si la position tient 30 secondes.",
    ]),
    ("Coach et réglages", [
        "• Coach avant un virage quand une erreur se répète (blocages, patinage, ABS/TC, gaz).",
        "• Comparaison avec ton meilleur tour sur des pneus similaires : « T5 : tu freines 15 mètres plus tôt ».",
        "• Comparaison avec un coéquipier : les meilleurs tours de chaque pilote sont enregistrés automatiquement ; l'ingénieur te dit avant un virage ce que ton coéquipier fait différemment.",
        "• Comparaison des virages avec un rival de ta catégorie.",
        "• Conseils de réglages du cockpit (répartition de freinage, TC, ABS) en course, et en essais aussi au garage.",
        "• Décris le comportement à la voix (« sous-virage en entrée du dernier virage ») – l'ingénieur vérifie les données et conseille.",
        "• Fatigue du pilote : baisse de rythme, régularité moins bonne et erreurs.",
    ]),
    ("Équipe", [
        "• Mur des stands dans le navigateur (téléphone, PC) : état de la voiture, carte du circuit, rivaux, planning des relais, radio d'équipe.",
        "• Planning calculé en direct et notifications sur téléphone (ntfy) environ 30 minutes avant ton relais et en cas de pluie. Sans plan pour aujourd'hui, le planning se crée automatiquement pour le pilote en piste.",
        "• Messages du mur des stands au pilote (l'ingénieur les lit) et questions « texte seul ».",
        "• Briefing au changement de pilote : dégâts, sorties du pilote précédent, plan, notes.",
        "• Radio d'équipe : quand tu ne roules pas, l'appli joue les messages de l'ingénieur de la voiture de l'équipe.",
        "• IA dans le cloud (Groq, gratuite) : reconnaissance vocale et réponses sans serveur.",
        "• Mémoire d'équipe : des notes dont l'IA tient compte.",
        "• Lien spectateurs – vue en direct uniquement, sans radio ni plan.",
    ]),
    ("Voix", [
        "• Voix naturelle avec effet radio et un prénom pour l'ingénieur.",
        "• Bouton radio sur le volant ou une touche ; un appui interrompt l'ingénieur.",
        "• Listes longues raccourcies : « dans 6 virages, surtout T3 et T11 » – la liste complète avec « lesquels ? ».",
        "• « Silence » – « OK. » et silence total jusqu'au prochain appui ; « urgent seulement » – alertes et réponses seulement.",
    ]),
]

MANUAL: list[tuple[str, list[str]]] = [
    ("Premier lancement", [
        "• Dans LMU une fois : Settings → Gameplay → Enable Plugins = ON.",
        "• Équipe : saisis le code et le mot de passe de l'équipe (de tes coéquipiers) ou clique sur « Créer une nouvelle équipe… ». "
        "« Tester la connexion » et choisis ton prénom. Partagez le code et le mot de passe uniquement en privé.",
        "• Micro et bouton : choisis le micro, « Test 3 s », puis « Définir : appuie sur le bouton… » et appuie sur le bouton du volant.",
        "• Voix : choisis la voix, le débit, l'effet radio, la langue et le prénom ; « Écouter ».",
        "• Clique sur « Enregistrer et redémarrer ».",
    ]),
    ("Le jour de la course", [
        "• Chaque membre de l'équipe a l'appli lancée – même sans rouler. Le programme reconnaît qui conduit.",
        "• IA : collez une fois une clé Groq gratuite sur le mur des stands (Équipe → IA de l'équipe).",
        "• Course de 24 h : celui qui ne roule pas peut éteindre LMU, l'appli et le PC. Avant ton relais (notification sur le téléphone), lance LMU et Pit Wall Crew avant de monter dans la voiture.",
        "• Avant le départ, vérifiez : « Équipe » et « IA : Groq » en vert dans l'appli, « en direct » sur le mur des stands.",
    ]),
    ("Parler à l'ingénieur", [
        "Maintiens le bouton, parle, relâche. Tu peux aussi écrire une question sur la page « Ingénieur » de l'appli. "
        "Toutes les commandes sont sur la page « Commandes ». Si les règles ne connaissent pas la réponse, la question va à l'IA (Groq).",
    ]),
    ("Mur des stands (page web)", [
        "• En direct : course, arrêt, pneus, météo, pilote, carte du circuit, rivaux, planning des relais, radio d'équipe.",
        "• Planning & plan : départ, pneus pour la course, plan des relais (pilote dans la liste, tours, changement des pneus gauche / droite), coller un plan depuis un tableur.",
        "• Équipe : code, QR, pilotes et sujets ntfy (bouton Test), lien spectateurs.",
        "• Tours (avec téléchargement CSV) et mémoire d'équipe.",
    ]),
    ("Notifications sur le téléphone", [
        "• Installe l'appli gratuite ntfy (Google Play / App Store).",
        "• Mur des stands : onglet Équipe → 📱 à côté de ton prénom – le sujet et un QR code apparaissent.",
        "• Dans ntfy touche +, saisis le sujet et abonne-toi (ou scanne le QR code).",
        "• Clique sur Test sur le mur des stands – « Pit Wall Crew – test » arrive sur ton téléphone.",
    ]),
    ("Si quelque chose ne marche pas", [
        "• Mur des stands : « pas de données du jeu » – l'appli tourne-t-elle chez le pilote avec « Équipe » en vert ?",
        "• « Mauvais code ou mot de passe d'équipe » – corrige-le sur la page Équipe, « Tester la connexion », « Enregistrer ».",
        "• L'ingénieur ne t'entend pas – page Micro et bouton : « Test 3 s » ; Windows : Confidentialité → Microphone.",
        "• « IA : Groq – mauvaise clé » – colle à nouveau la clé sur le mur des stands.",
        "• Chaque message en double – le programme tourne deux fois. Ferme l'appli, termine « pythonw » dans le Gestionnaire des tâches, relance une fois.",
        "• Le jeu saccade – souvent pas assez de mémoire graphique : baisse les textures, les voitures visibles et les ombres, ferme les autres programmes.",
        "• Autre problème ou idée – Aide → « Signaler un problème ». Ça va directement à l'auteur.",
        "• Rapports de plantage : avec ton accord (demandé au premier lancement, modifiable sur la page « Signaler un problème »), le programme envoie à l'auteur l'erreur et le journal de la dernière session – sans voix, clés ni mots de passe.",
    ]),
    ("Mises à jour", [
        "L'appli cherche les mises à jour au démarrage (jamais en roulant), télécharge la nouvelle version, remplace les fichiers et redémarre. "
        "Les réglages et les données sont conservés.",
        "Les testeurs avec un code de l'auteur (Avancé → Code testeur) reçoivent les nouvelles versions avant tout le monde.",
    ]),
]

ABOUT = [
    ("Pit Wall Crew", [
        "Ingénieur de course vocal et mur des stands pour Le Mans Ultimate.",
        "Créé par Maciej Szczepaniak from FR Mods.",
    ]),
    ("Remerciements", [
        "À Rett et Barny pour leur aide aux tests.",
    ]),
]
