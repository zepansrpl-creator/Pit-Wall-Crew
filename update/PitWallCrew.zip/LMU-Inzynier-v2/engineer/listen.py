"""Rozmowa głosowa: push-to-talk (przycisk kierownicy lub klawisz) + rozpoznawanie mowy po polsku.

Trzymasz przycisk -> nagrywa mikrofon; puszczasz -> tekst trafia do inżyniera.
Rozpoznawanie mowy:
- "whisper": faster-whisper lokalnie na procesorze (prywatne, bez internetu; model pobiera się raz, ok. 500 MB dla "small")
- "google":  darmowe rozpoznawanie Google przez internet (szybkie, bez instalowania modelu)
"""

from __future__ import annotations

import os
import threading
import time
from typing import Callable, Optional

SAMPLE_RATE = 16000

VOCAB = ("Rozmowa kierowcy z inżynierem wyścigowym w Le Mans Ultimate. Paliwo, energia, VE, pitstop, zjazd, "
         "okrążenie, zakręt T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, ostatni zakręt, podsterowność, nadsterowność, "
         "stabilizator, balans hamulców, docisk, skrzydło, TC, ABS, opony, ciśnienie, camber, setup, "
         "zmieniłem, rywal, tempo, przewaga.")


# --------------------------------------------------------------------------- STT
class WhisperSTT:
    name = "whisper"

    def __init__(self, model: str = "small", threads: int = 4) -> None:
        from faster_whisper import WhisperModel
        self.model = WhisperModel(model, device="cpu", compute_type="int8", cpu_threads=threads)

    def transcribe(self, audio) -> str:
        import numpy as np
        pcm = audio.astype(np.float32) / 32768.0
        segments, _ = self.model.transcribe(pcm, language="pl", initial_prompt=VOCAB, beam_size=1,
                                            vad_filter=False, condition_on_previous_text=False)
        return " ".join(s.text.strip() for s in segments).strip()


class GoogleSTT:
    name = "google"

    def __init__(self) -> None:
        import speech_recognition as sr
        self.sr = sr
        self.rec = sr.Recognizer()

    def transcribe(self, audio) -> str:
        data = self.sr.AudioData(audio.tobytes(), SAMPLE_RATE, 2)
        try:
            return self.rec.recognize_google(data, language="pl-PL")
        except self.sr.UnknownValueError:
            return ""


def make_stt(kind: str, whisper_model: str = "small") -> Optional[object]:
    order = [kind] + [k for k in ("whisper", "google") if k != kind]
    for k in order:
        try:
            if k == "whisper":
                print(f"[mowa] Ładuję model rozpoznawania mowy Whisper '{whisper_model}' "
                      "(za pierwszym razem pobiera się z internetu)...")
                return WhisperSTT(whisper_model)
            if k == "google":
                return GoogleSTT()
        except Exception as e:
            print(f"[mowa] {k} niedostępny: {e}")
    return None


# --------------------------------------------------------------------------- mikrofon
# Windows pokazuje ten sam mikrofon kilka razy (MME, DirectSound, WASAPI, WDM-KS), a numery urządzeń
# zmieniają się po podłączeniu/odłączeniu sprzętu. Dlatego mikrofon zapisujemy po nazwie, a przy otwieraniu
# próbujemy kolejno: wybrany mikrofon (w różnych sterownikach), domyślny mikrofon Windows, pozostałe.
HOSTAPI_ORDER = ("MME", "Windows DirectSound", "Windows WASAPI", "Windows WDM-KS")
NOT_MICS = ("stereo mix", "miks stereo", "what u hear", "loopback", "wave out", "mapowanie dźwięku",
            "sound mapper", "podstawowy sterownik", "primary sound")
PRIVACY_HINT = ("Windows: Ustawienia -> Prywatność i zabezpieczenia -> Mikrofon -> włącz 'Dostęp do mikrofonu' "
                "i 'Zezwalaj aplikacjom klasycznym na dostęp do mikrofonu'")


def _same_name(a: str, b: str) -> bool:
    """MME obcina nazwy do 31 znaków, więc porównujemy początki."""
    a, b = a.lower().strip(), b.lower().strip()
    n = min(len(a), len(b), 31)
    return n >= 6 and a[:n] == b[:n]


def _input_devices(sd) -> list[dict]:
    try:
        apis = [h["name"] for h in sd.query_hostapis()]
    except Exception:
        apis = []
    out = []
    for i, d in enumerate(sd.query_devices()):
        if d["max_input_channels"] <= 0:
            continue
        api = apis[d["hostapi"]] if d.get("hostapi", -1) in range(len(apis)) else ""
        out.append({"index": i, "name": d["name"], "api": api, "channels": d["max_input_channels"],
                    "rate": int(d.get("default_samplerate") or SAMPLE_RATE)})
    return out


def _api_rank(api: str) -> int:
    return HOSTAPI_ORDER.index(api) if api in HOSTAPI_ORDER else len(HOSTAPI_ORDER)


def _is_mic(name: str) -> bool:
    return not any(x in name.lower() for x in NOT_MICS)


def list_mics(sd=None) -> list[dict]:
    """Prawdziwe mikrofony, każdy raz (z najpewniejszym sterownikiem), do pokazania kierowcy."""
    if sd is None:
        import sounddevice as sd
    devs = sorted(_input_devices(sd), key=lambda d: _api_rank(d["api"]))
    out: list[dict] = []
    for d in devs:
        if _is_mic(d["name"]) and not any(_same_name(d["name"], o["name"]) for o in out):
            out.append(dict(d, name=_full_name(d["name"], devs)))
    return out


def _full_name(name: str, devs: list[dict]) -> str:
    """Najdłuższa wersja nazwy (MME ją obcina)."""
    return max((d["name"] for d in devs if _same_name(name, d["name"])), key=len, default=name)


def _default_input(sd) -> int | None:
    try:
        dev = sd.default.device
        idx = dev[0] if isinstance(dev, (list, tuple)) or hasattr(dev, "__getitem__") else dev
        idx = int(idx)
        return idx if idx >= 0 else None
    except Exception:
        return None


def _candidates(sd, wanted: str | int | None) -> tuple[list[dict], str | None, str]:
    """Kolejność urządzeń do wypróbowania, nazwa i opis mikrofonu z ustawień."""
    devs = _input_devices(sd)
    by_api = sorted(devs, key=lambda d: _api_rank(d["api"]))
    order: list[dict] = []
    want_desc = ""

    def add(d: dict) -> None:
        if all(o["index"] != d["index"] for o in order):
            order.append(d)

    want_name = None
    if isinstance(wanted, int) or (isinstance(wanted, str) and wanted.strip().isdigit()):
        idx = int(wanted)
        want_desc = f"numer {idx}"
        hit = next((d for d in devs if d["index"] == idx), None)
        if hit is not None:
            want_name = hit["name"]
            want_desc = f"{hit['name']} (numer {idx})"
            add(hit)
    elif wanted:
        want_name = str(wanted).strip()
        want_desc = want_name
    if want_name:
        for d in by_api:
            if _same_name(want_name, d["name"]) or want_name.lower() in d["name"].lower():
                add(d)
    di = _default_input(sd)
    default = next((d for d in devs if d["index"] == di), None)
    if default is not None:
        for d in by_api:
            if d["index"] == di or _same_name(default["name"], d["name"]):
                add(d)
    for d in by_api:
        if _is_mic(d["name"]):
            add(d)
    return order, want_name, want_desc


def _resample(x, sr_in: int, sr_out: int = SAMPLE_RATE):
    """Zmiana częstotliwości próbkowania przez FFT (z filtrem antyaliasingowym)."""
    import numpy as np
    if sr_in == sr_out or len(x) == 0:
        return x
    n_out = max(1, int(round(len(x) * sr_out / sr_in)))
    X = np.fft.rfft(x)
    keep = n_out // 2 + 1
    if len(X) < keep:
        X = np.concatenate([X, np.zeros(keep - len(X), dtype=X.dtype)])
    return np.fft.irfft(X[:keep], n_out) * (n_out / len(x))


class Microphone:
    def __init__(self, device: str | int | None = None, quiet: bool = False) -> None:
        import numpy as np
        import sounddevice as sd
        self.np = np
        self._frames: list = []
        self._pre: list = []          # ostatnie ~0.5 s przed wciśnięciem przycisku (początek słowa)
        self._pre_n = 0
        self.rate = 48000             # nadpisane po otwarciu; callback może ruszyć wcześniej
        self._recording = False
        self._lock = threading.Lock()
        self.stream = None
        order, want_name, want = _candidates(sd, device)
        errors = []
        for d in order:
            try:
                self.stream, self.rate, self.channels = self._open(sd, d)
            except Exception as e:
                errors.append(f"{d['name']} [{d['api']}]: {e}")
                continue
            self.name, self.api, self.index = _full_name(d["name"], order), d["api"], d["index"]
            break
        if self.stream is None:
            mics = list_mics(sd)
            lst = "; ".join(m["name"] for m in mics) or "brak"
            raise RuntimeError(f"nie udało się otworzyć żadnego mikrofonu (widoczne: {lst}). "
                               f"Sprawdź, czy mikrofon jest podłączony. {PRIVACY_HINT}. "
                               "Potem wybierz mikrofon plikiem test_mikrofonu.bat.")
        self.fallback = bool(want) and not (want_name and (_same_name(self.name, want_name) or
                                                           want_name.lower() in self.name.lower()))
        if not quiet:
            if self.fallback:
                print(f"[mowa] Mikrofon z ustawień ({want}) jest niedostępny.")
                print(f"[mowa] Używam: {self.name}. Inny mikrofon wybierzesz plikiem test_mikrofonu.bat.")
            else:
                print(f"[mowa] Mikrofon: {self.name}")

    def _open(self, sd, d: dict):
        rates = list(dict.fromkeys([SAMPLE_RATE, d["rate"], 48000, 44100]))
        chans = list(dict.fromkeys([1, min(2, d["channels"])]))
        last = None
        for ch in chans:
            for sr in rates:
                try:
                    st = sd.InputStream(samplerate=sr, channels=ch, dtype="int16", device=d["index"],
                                        callback=self._cb, blocksize=max(256, sr // 20))
                    st.start()
                    return st, sr, ch
                except Exception as e:
                    last = e
        raise last if last else RuntimeError("brak obsługiwanego formatu")

    def _cb(self, indata, frames, t, status) -> None:
        with self._lock:
            if self._recording:
                self._frames.append(indata.copy())
            else:
                self._pre.append(indata.copy())
                self._pre_n += frames
                while self._pre and self._pre_n - len(self._pre[0]) >= int(self.rate * 0.5):
                    self._pre_n -= len(self._pre.pop(0))

    def start(self) -> None:
        with self._lock:
            self._frames = list(self._pre)   # kierowca często zaczyna mówić razem z wciśnięciem
            self._pre, self._pre_n = [], 0
            self._recording = True

    def stop(self):
        np = self.np
        time.sleep(0.35)  # końcówka wypowiedzi (przycisk puszczany często razem z ostatnią sylabą)
        self._recording = False
        with self._lock:
            frames, self._frames = self._frames, []
        if not frames:
            return np.zeros(0, dtype=np.int16)
        a = np.concatenate(frames).astype(np.float64)
        a = a.mean(axis=1) if a.ndim > 1 else a
        if self.rate != SAMPLE_RATE:
            a = _resample(a, self.rate, SAMPLE_RATE)
        a = a - a.mean()
        peak = float(np.abs(a).max()) if len(a) else 0.0
        self.last_raw_peak = int(peak)          # poziom z mikrofonu przed podgłośnieniem (do dziennika)
        self.last_gain = 1.0
        if 0 < peak < 26000:   # cichy mikrofon (np. słuchawki bezprzewodowe): podgłaśniamy, najwyżej 20 razy
            self.last_gain = min(20.0, 26000.0 / peak)
            a = a * self.last_gain
        return np.clip(np.round(a), -32768, 32767).astype(np.int16)

    def close(self) -> None:
        try:
            self.stream.stop()
            self.stream.close()
        except Exception:
            pass


# --------------------------------------------------------------------------- przyciski
def _sdl_safe_hints() -> None:
    """SDL tylko przez DirectInput/XInput: bez HIDAPI, RawInput i Windows.Gaming.Input, które potrafią
    przejmować kierownicę z force feedbackiem."""
    os.environ["SDL_JOYSTICK_ALLOW_BACKGROUND_EVENTS"] = "1"
    os.environ["SDL_JOYSTICK_HIDAPI"] = "0"
    os.environ["SDL_JOYSTICK_RAWINPUT"] = "0"
    os.environ["SDL_JOYSTICK_WGI"] = "0"


class PTTSource:
    """Sprawdza, czy przycisk mówienia jest wciśnięty (kierownica albo klawiatura)."""

    def __init__(self, key: str = "", joystick_name: str = "", joystick_button: int = -1) -> None:
        self.key = key
        self.joystick_name = joystick_name
        self.joystick_button = joystick_button
        self._joy = None
        self._pg = None
        self._kb = None
        self._wj: list[int] = []      # numery kontrolerów w winmm (Windows)
        self._wj_next = 0.0

    def init(self) -> None:
        """Wywoływać w wątku, który potem odpytuje przyciski (wymóg SDL)."""
        if self.joystick_button >= 0 and self._winmm_init():
            pass
        elif self.joystick_button >= 0:
            _sdl_safe_hints()
            import pygame
            pygame.init()
            pygame.joystick.init()
            self._pg = pygame
            for i in range(pygame.joystick.get_count()):
                j = pygame.joystick.Joystick(i)
                j.init()
                if not self.joystick_name or self.joystick_name.lower() in j.get_name().lower():
                    self._joy = j
                    print(f"[mowa] Przycisk mówienia: {j.get_name()}, przycisk {self.joystick_button}")
                    break
            if self._joy is None:
                print("[mowa] Nie znaleziono kierownicy/kontrolera z konfiguracji (ustaw przycisk plikiem ustawienia.bat).")
        if self.key:
            try:
                import keyboard
                self._kb = keyboard
                print(f"[mowa] Klawisz mówienia: {self.key}")
            except Exception as e:
                print(f"[mowa] Klawiatura niedostępna: {e}")

    def _winmm_init(self) -> bool:
        """Windows: przyciski przez winmm (tylko odczyt, bez otwierania kierownicy) – nie koliduje z FFB gry."""
        try:
            from engineer import winjoy
            if not winjoy.available() or self.joystick_button >= winjoy.MAX_BUTTONS:
                return False
            devs = winjoy.devices()
            want = (self.joystick_name or "").lower()
            match = [d for d in devs if want and (want in d[1].lower() or d[1].lower() in want)]
            chosen = match or devs
            self._wj = [d[0] for d in chosen]
            self._winjoy = winjoy
            names = ", ".join(d[1] for d in chosen) or "brak – sprawdzę ponownie po podłączeniu"
            print(f"[mowa] Przycisk mówienia: {names}, przycisk {self.joystick_button}")
            return True
        except Exception as e:
            print(f"[mowa] winmm niedostępny ({e}), używam SDL")
            return False

    def pressed(self) -> bool:
        if getattr(self, "_winjoy", None) is not None:
            bit = 1 << self.joystick_button
            for dev in list(self._wj):
                b = self._winjoy.buttons(dev)
                if b is not None and b & bit:
                    return True
            if not self._wj and time.monotonic() > self._wj_next:   # kierownica podłączona później
                self._wj_next = time.monotonic() + 5
                self._wj = [d[0] for d in self._winjoy.devices()]
        if self._joy is not None:
            self._pg.event.pump()
            if self.joystick_button < self._joy.get_numbuttons() and self._joy.get_button(self.joystick_button):
                return True
        if self._kb is not None:
            try:
                return self._kb.is_pressed(self.key)
            except Exception:
                return False
        return False


class Listener:
    """Pętla push-to-talk w osobnym wątku. on_text(text) dostaje rozpoznaną wypowiedź."""

    def __init__(self, stt, mic: Microphone, ptt: PTTSource, on_text: Callable[[str], None],
                 on_press: Optional[Callable[[], None]] = None) -> None:
        self.stt, self.mic, self.ptt = stt, mic, ptt
        self.on_text, self.on_press = on_text, on_press
        threading.Thread(target=self._run, daemon=True).start()

    def _run(self) -> None:
        self.ptt.init()
        held = False
        t0 = 0.0
        while True:
            now = self.ptt.pressed()
            if now and not held:
                held, t0 = True, time.monotonic()
                if self.on_press:
                    self.on_press()
                self.mic.start()
                print("\n[mowa] słucham...")
            elif not now and held:
                held = False
                audio = self.mic.stop()
                if time.monotonic() - t0 < 0.35 or len(audio) < SAMPLE_RATE * 0.3:
                    continue
                if not audio.any():
                    print(f"[mowa] Mikrofon nagrał zupełną ciszę. Windows może blokować mikrofon. {PRIVACY_HINT}.")
                    continue
                threading.Thread(target=self._transcribe, args=(audio,), daemon=True).start()
            time.sleep(0.01)

    def _transcribe(self, audio) -> None:
        t = time.monotonic()
        try:
            text = self.stt.transcribe(audio)
        except Exception as e:
            print(f"[mowa] błąd rozpoznawania: {e}")
            return
        if not text:
            print("[mowa] nic nie zrozumiałem")
            return
        print(f"[TY] {text}   ({time.monotonic() - t:.1f} s)")
        self.on_text(text)


class PTTRecorder:
    """Push-to-talk bez rozpoznawania mowy na tym komputerze: nagranie trafia do on_audio(audio int16, 16 kHz)."""

    def __init__(self, mic: Microphone, ptt: PTTSource, on_audio: Callable, on_press: Optional[Callable] = None) -> None:
        self.mic, self.ptt, self.on_audio, self.on_press = mic, ptt, on_audio, on_press
        threading.Thread(target=self._run, daemon=True).start()

    def _run(self) -> None:
        self.ptt.init()
        held, t0 = False, 0.0
        while True:
            now = self.ptt.pressed()
            if now and not held:
                held, t0 = True, time.monotonic()
                if self.on_press:
                    self.on_press()
                self.mic.start()
                print("\n[mowa] słucham...")
            elif not now and held:
                held = False
                audio = self.mic.stop()
                if time.monotonic() - t0 < 0.35 or len(audio) < SAMPLE_RATE * 0.3:
                    continue
                if not audio.any():
                    print(f"[mowa] Mikrofon nagrał zupełną ciszę. Windows może blokować mikrofon. {PRIVACY_HINT}.")
                    continue
                threading.Thread(target=self.on_audio, args=(audio,), daemon=True).start()
            time.sleep(0.01)


def prep_stt(audio, rate: int = SAMPLE_RATE):
    """Przygotowanie nagrania do rozpoznania: filtr dudnienia (< ok. 80 Hz) i przycięcie długiej ciszy
    na początku i końcu (Whisper przy ciszy dopowiada słowa, np. „Wiesz,”). Zostawia 0,25 s przed mową
    i 0,35 s po niej."""
    import numpy as np
    a = np.asarray(audio, dtype=np.float64)
    if len(a) < rate // 5:
        return audio
    # filtr górnoprzepustowy 1. rzędu ~80 Hz
    k = 1.0 / (1.0 + 2 * np.pi * 80.0 / rate)
    y = np.empty_like(a)
    prev_x = prev_y = 0.0
    for i, x in enumerate(a):
        prev_y = k * (prev_y + x - prev_x)
        prev_x = x
        y[i] = prev_y
    n = rate // 100                                 # ramki 10 ms
    fr = y[: len(y) // n * n].reshape(-1, n)
    rms = np.sqrt((fr ** 2).mean(axis=1))
    loud = np.where(rms > max(rms.max() * 0.05, 50.0))[0]
    if len(loud):
        s = max(0, (loud[0] - 25) * n)
        e = min(len(y), (loud[-1] + 1 + 35) * n)
        y = y[s:e]
    return np.clip(np.round(y), -32768, 32767).astype(np.int16)


def to_wav_bytes(audio, rate: int = SAMPLE_RATE) -> bytes:
    import io
    import wave
    buf = io.BytesIO()
    with wave.open(buf, "wb") as w:
        w.setnchannels(1)
        w.setsampwidth(2)
        w.setframerate(rate)
        w.writeframes(audio.astype("<i2").tobytes())
    return buf.getvalue()


def from_wav_bytes(data: bytes):
    import io
    import wave
    import numpy as np
    with wave.open(io.BytesIO(data), "rb") as w:
        rate = w.getframerate()
        a = np.frombuffer(w.readframes(w.getnframes()), dtype="<i2")
    return a, rate


# --------------------------------------------------------------------------- narzędzia
def list_devices() -> None:
    try:
        print("MIKROFONY:")
        for m in list_mics():
            print(f"  {m['name']}")
    except Exception as e:
        print(f"Brak dostępu do mikrofonów: {e}")
    try:
        _sdl_safe_hints()
        import pygame
        pygame.init()
        pygame.joystick.init()
        print("KIEROWNICE / KONTROLERY:")
        for i in range(pygame.joystick.get_count()):
            j = pygame.joystick.Joystick(i)
            j.init()
            print(f"  {i}: {j.get_name()} (przycisków: {j.get_numbuttons()})")
    except Exception as e:
        print(f"Brak dostępu do kontrolerów: {e}")


def find_button(seconds: float = 30.0) -> None:
    """Wypisuje, który przycisk na kierownicy jest wciskany."""
    _sdl_safe_hints()
    import pygame
    pygame.init()
    pygame.joystick.init()
    joys = []
    for i in range(pygame.joystick.get_count()):
        j = pygame.joystick.Joystick(i)
        j.init()
        joys.append(j)
    if not joys:
        print("Nie widzę żadnej kierownicy ani kontrolera.")
        return
    print(f"Wciśnij przycisk, którego chcesz używać do mówienia (masz {seconds:.0f} s)...")
    prev = {}
    end = time.monotonic() + seconds
    while time.monotonic() < end:
        pygame.event.pump()
        for j in joys:
            for b in range(j.get_numbuttons()):
                v = j.get_button(b)
                if v and not prev.get((j.get_instance_id(), b)):
                    print(f'  {j.get_name()}: przycisk {b}   -> w config.toml: joystick_name = "{j.get_name()}", '
                          f"joystick_button = {b}")
                prev[(j.get_instance_id(), b)] = v
        time.sleep(0.01)
