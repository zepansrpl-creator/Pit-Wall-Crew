"""Dziennik przycięć i dziwnego force feedbacku.

Zapisuje do recordings/przyciecia_*.txt zdarzenia, które mogą tłumaczyć przycięcia gry i szarpanie
albo luzowanie się kierownicy, razem z tym, co działo się wtedy na komputerze:

- PC: wątek, który co 10 ms „budzi się” – gdy obudzi się z dużym opóźnieniem, cały komputer na chwilę
  stanął (zajęty procesor, sterownik, dysk, antywirus…),
- GRA: dane z gry przestały się zmieniać albo czas gry płynie wolniej niż zegar (gra się zacięła),
- FFB: nagły skok siły na kierownicy albo jej zanik w trakcie jazdy (z fizyki gry, nie z kierownicy),
- ZNACZNIK: kierowca nacisnął klawisz (domyślnie F9), gdy poczuł przycięcie – zapisujemy, co było
  w ostatnich sekundach.

Do każdego zdarzenia dopisujemy: obciążenie procesora, wolną pamięć, czy inżynier mówił,
czy trwało zapytanie do gry (interfejs na porcie 6397) i ile trwały ostatnie zapytania.
"""

from __future__ import annotations

import collections
import os
import sys
import threading
import time
from datetime import datetime
from typing import Optional


class _Cpu:
    """Obciążenie procesora całego komputera (Windows, bez dodatkowych bibliotek)."""

    def __init__(self) -> None:
        self.prev = None
        self.value: Optional[float] = None

    def sample(self) -> Optional[float]:
        if sys.platform != "win32":
            return None
        import ctypes
        from ctypes import wintypes
        idle, kern, user = wintypes.FILETIME(), wintypes.FILETIME(), wintypes.FILETIME()
        if not ctypes.windll.kernel32.GetSystemTimes(ctypes.byref(idle), ctypes.byref(kern), ctypes.byref(user)):
            return None
        f = lambda x: (x.dwHighDateTime << 32) | x.dwLowDateTime
        cur = (f(idle), f(kern), f(user))
        if self.prev is not None:
            di, dk, du = (c - p for c, p in zip(cur, self.prev))
            tot = dk + du
            if tot > 0:
                self.value = max(0.0, min(100.0, (tot - di) * 100.0 / tot))
        self.prev = cur
        return self.value


def _free_mem_mb() -> Optional[int]:
    if sys.platform != "win32":
        return None
    import ctypes

    class MS(ctypes.Structure):
        _fields_ = [("dwLength", ctypes.c_ulong), ("dwMemoryLoad", ctypes.c_ulong),
                    ("ullTotalPhys", ctypes.c_ulonglong), ("ullAvailPhys", ctypes.c_ulonglong),
                    ("ullTotalPageFile", ctypes.c_ulonglong), ("ullAvailPageFile", ctypes.c_ulonglong),
                    ("ullTotalVirtual", ctypes.c_ulonglong), ("ullAvailVirtual", ctypes.c_ulonglong),
                    ("ullAvailExtendedVirtual", ctypes.c_ulonglong)]
    m = MS()
    m.dwLength = ctypes.sizeof(MS)
    if not ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(m)):
        return None
    return int(m.ullAvailPhys / 1024 / 1024)


class StutterLog:
    def __init__(self, speaker=None, mark_key: str = "f9", folder: str = "recordings") -> None:
        self.speaker = speaker
        self.mark_key = mark_key
        self.path = os.path.join(folder, datetime.now().strftime("przyciecia_%Y%m%d_%H%M%S.txt"))
        self._f = None
        self._lock = threading.Lock()
        self.cpu = _Cpu()
        self.cpu_hist: collections.deque = collections.deque(maxlen=120)   # (czas, %) co 0,5 s
        self.events: collections.deque = collections.deque(maxlen=200)     # (czas, rodzaj)
        self.counts: collections.Counter = collections.Counter()
        # stan gry
        self._last_t: Optional[float] = None
        self._last_change_wall = time.monotonic()
        self._frozen_logged = False
        self._win: collections.deque = collections.deque(maxlen=200)       # (wall, czas gry)
        self._slow_cool = 0.0
        self._tq: collections.deque = collections.deque(maxlen=150)        # (wall, moment, prędkość)
        self._ffb_cool = 0.0
        self._lost_since: Optional[float] = None
        self.driving = False
        self._last_summary = time.monotonic()
        self._mark_cool = 0.0
        self.top_procs: list[tuple[str, float]] = []   # najbardziej obciążające procesy (psutil, co 2 s)
        self._procs: dict = {}
        self.near = ""                                   # auta tuż obok (do sprawdzenia „przycina, gdy dojeżdża hypercar”)

    # ----------------------------------------------------------------- start
    def start(self) -> None:
        threading.Thread(target=self._pc_loop, daemon=True).start()
        threading.Thread(target=self._cpu_loop, daemon=True).start()
        if self.mark_key:
            try:
                import keyboard
                keyboard.add_hotkey(self.mark_key, self.mark)
                print(f"[diagnostyka] Przycięcie albo dziwny FFB? Naciśnij {self.mark_key.upper()} – zapiszę, co się działo.")
            except Exception as e:
                print(f"[diagnostyka] klawisz znacznika niedostępny: {e}")

    def _cpu_loop(self) -> None:
        k = 0
        while True:
            v = self.cpu.sample()
            if v is not None:
                self.cpu_hist.append((time.monotonic(), v))
            k += 1
            if k % 4 == 0 and self.driving:
                self._sample_procs()
            time.sleep(0.5)

    def _sample_procs(self) -> None:
        """Które programy zajmują procesor (co 2 s, tylko w trakcie jazdy). Bez psutil – pomijamy."""
        try:
            import psutil
        except ImportError:
            return
        try:
            n = psutil.cpu_count() or 1
            seen, rows = set(), []
            for pr in psutil.process_iter(["name"]):
                seen.add(pr.pid)
                if pr.pid not in self._procs:
                    self._procs[pr.pid] = pr
                    pr.cpu_percent(None)            # pierwszy pomiar – wynik dopiero za 2 s
                    continue
                try:
                    c = self._procs[pr.pid].cpu_percent(None) / n
                except Exception:
                    continue
                if c >= 3:
                    rows.append(((pr.info.get("name") or "?").replace(".exe", ""), c))
            for pid in list(self._procs):
                if pid not in seen:
                    del self._procs[pid]
            rows.sort(key=lambda r: -r[1])
            self.top_procs = rows[:4]
        except Exception:
            pass

    def _pc_loop(self) -> None:
        """Wątek budzi się co 10 ms. Opóźnienie > 100 ms = komputer stanął."""
        last = time.perf_counter()
        while True:
            time.sleep(0.01)
            now = time.perf_counter()
            lag = now - last - 0.01
            last = now
            if lag > 0.1 and self.driving:
                self.event("PC", f"komputer stanął na {lag * 1000:.0f} ms (program nie dostał procesora)")

    # ----------------------------------------------------------------- dane z gry
    def tick(self, snap, driving: bool) -> None:
        self.driving = driving
        now = time.monotonic()
        p = snap.player if snap is not None else None
        if snap is None or p is None or not driving:
            self._last_t = None
            return
        moving = p.speed_kmh > 30 and not p.in_pits and snap.phase not in ("paused",)
        try:       # auta w promieniu 150 m na torze (sprawdzenie, czy przycina przy dojeżdżających autach)
            me = snap.player_scoring()
            L = snap.track_length
            near = []
            if me is not None and L > 0:
                for c in snap.cars:
                    if c.is_player or c.in_pits:
                        continue
                    d = (c.lap_dist - me.lap_dist + L / 2) % L - L / 2      # + przed nami, - za nami
                    if abs(d) < 150:
                        near.append(f"{c.car_class} {abs(d):.0f} m {'przed' if d > 0 else 'za'}")
            self.near = ("obok aut: " + ", ".join(near[:4])) if near else ""
        except Exception:
            self.near = ""
        # 1) dane przestały się zmieniać
        if self._last_t is None or snap.t != self._last_t:
            gap = now - self._last_change_wall
            if self._frozen_logged and self._last_t is not None:
                self.event("GRA", f"dane z gry znowu płyną po {gap:.2f} s przerwy")
            self._frozen_logged = False
            self._last_change_wall = now
            self._last_t = snap.t
        elif moving and not self._frozen_logged and now - self._last_change_wall > 0.25:
            self._frozen_logged = True
            self.event("GRA", "dane z gry stoją ponad 0,25 s w trakcie jazdy (gra się zacięła albo wczytuje)")
        # 2) czas gry płynie wolniej niż zegar (gra nie nadąża)
        self._win.append((now, snap.t))
        while self._win and now - self._win[0][0] > 2.0:
            self._win.popleft()
        if moving and len(self._win) > 20 and now > self._slow_cool:
            w0, g0 = self._win[0]
            dw, dg = now - w0, snap.t - g0
            if dw > 1.5 and dg < dw * 0.8:
                self._slow_cool = now + 5
                self.event("GRA", f"czas gry płynie wolniej: {dg:.2f} s gry w {dw:.2f} s zegara")
        # 3) FFB z fizyki gry
        tq = float(getattr(p, "ffb_torque", 0.0) or 0.0)
        self._tq.append((now, tq, p.speed_kmh))
        if moving and len(self._tq) > 30:
            vals = [abs(x[1]) for x in self._tq]
            typical = sorted(vals)[len(vals) // 2]
            prev = self._tq[-2][1]
            jump = abs(tq - prev)
            if now > self._ffb_cool and typical > 0.5 and jump > max(4.0, typical * 2.5):
                self._ffb_cool = now + 2
                self.event("FFB", f"skok siły na kierownicy {prev:.1f} → {tq:.1f} Nm (typowo {typical:.1f})")
            if p.speed_kmh > 80 and typical > 1.0 and abs(tq) < 0.05:
                if self._lost_since is None:
                    self._lost_since = now
                elif now - self._lost_since > 0.3 and now > self._ffb_cool:
                    self._ffb_cool = now + 3
                    self.event("FFB", f"siła na kierownicy spadła do zera przy {p.speed_kmh:.0f} km/h "
                                      f"(typowo {typical:.1f} Nm)")
            else:
                self._lost_since = None
        if now - self._last_summary > 300:
            self._last_summary = now
            self._summary()

    # ----------------------------------------------------------------- zapis
    def mark(self) -> None:
        now = time.monotonic()
        if now < self._mark_cool:
            return
        self._mark_cool = now + 2
        recent = [k for t, k in self.events if now - t < 15]
        c = collections.Counter(recent)
        what = ", ".join(f"{k} ×{n}" for k, n in c.items()) or "nic nie wykryłem w ostatnich 15 s"
        self.event("ZNACZNIK", f"kierowca zgłosił przycięcie / FFB. Ostatnie 15 s: {what}")
        print("[diagnostyka] Zapisane, dzięki.")

    def _context(self) -> str:
        now = time.monotonic()
        cpu = [v for t, v in self.cpu_hist if now - t < 5]
        parts = []
        if cpu:
            parts.append(f"procesor {cpu[-1]:.0f}% (max 5 s: {max(cpu):.0f}%)")
        mem = _free_mem_mb()
        if mem is not None:
            parts.append(f"wolna pamięć {mem} MB")
        if self.top_procs:
            parts.append("najbardziej obciążają: " + ", ".join(f"{n} {c:.0f}%" for n, c in self.top_procs))
        if self.near:
            parts.append(self.near)
        if self.speaker is not None and getattr(self.speaker, "_current", None):
            parts.append("inżynier właśnie mówił")
        try:
            from engineer.sources.lmu_rest import BUSY, RECENT
            if BUSY.get("path"):
                parts.append(f"trwało zapytanie do gry {BUSY['path']} ({now - BUSY['t0']:.2f} s)")
            rec = [(p, d) for t1, p, d in RECENT if now - t1 < 5]
            if rec:
                parts.append("zapytania do gry w ostatnich 5 s: " + ", ".join(f"{p.split('/')[-1]} {d:.2f} s" for p, d in rec))
        except Exception:
            pass
        return "; ".join(parts)

    def event(self, kind: str, text: str) -> None:
        now = time.monotonic()
        if kind != "PODSUMOWANIE":
            self.events.append((now, kind))
            self.counts[kind] += 1
        line = f"{datetime.now():%H:%M:%S.%f}"[:-3] + f" [{kind}] {text} | {self._context()}"
        with self._lock:
            try:
                if self._f is None:
                    os.makedirs(os.path.dirname(self.path) or ".", exist_ok=True)
                    self._f = open(self.path, "a", encoding="utf-8")
                    self._f.write("Dziennik przycięć. PC = cały komputer stanął, GRA = gra się zacięła, "
                                  "FFB = dziwna siła na kierownicy z fizyki gry, ZNACZNIK = zgłoszenie kierowcy.\n")
                self._f.write(line + "\n")
                self._f.flush()
            except Exception:
                pass

    def _summary(self) -> None:
        cpu = [v for _, v in self.cpu_hist]
        if not self.counts and not cpu:
            return
        c = ", ".join(f"{k} {n}" for k, n in self.counts.items()) or "brak zdarzeń"
        avg = f", procesor śr. {sum(cpu) / len(cpu):.0f}% max {max(cpu):.0f}% (ostatnia minuta)" if cpu else ""
        self.event("PODSUMOWANIE", f"od startu: {c}{avg}")
