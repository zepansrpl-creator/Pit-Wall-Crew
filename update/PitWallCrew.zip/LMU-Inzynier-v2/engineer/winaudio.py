"""Nazwa i ikona w mikserze głośności Windows: „Pit Wall Crew” zamiast „Python”.

Ustawia nazwę domyślnej sesji audio tego procesu (IAudioSessionControl::SetDisplayName / SetIconPath)
na domyślnym urządzeniu wyjściowym. Używa comtypes (jest już z pyttsx3). Każdy błąd jest cichy.
"""

from __future__ import annotations

import os
import sys

NAME = "Pit Wall Crew"
ICON = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "assets", "inzynier.ico")


def set_mixer_name(name: str = NAME, icon: str = ICON) -> bool:
    if sys.platform != "win32":
        return False
    try:
        from ctypes import HRESULT, POINTER, c_uint32, c_wchar_p

        import comtypes
        from comtypes import COMMETHOD, GUID, IUnknown

        class IAudioSessionControl(IUnknown):
            _iid_ = GUID("{F4B1A599-7266-4319-A8CA-E70ACB11E8CD}")
            _methods_ = [
                COMMETHOD([], HRESULT, "GetState", (["out"], POINTER(c_uint32), "pRetVal")),
                COMMETHOD([], HRESULT, "GetDisplayName", (["out"], POINTER(c_wchar_p), "pRetVal")),
                COMMETHOD([], HRESULT, "SetDisplayName", (["in"], c_wchar_p, "Value"),
                          (["in"], POINTER(GUID), "EventContext")),
                COMMETHOD([], HRESULT, "GetIconPath", (["out"], POINTER(c_wchar_p), "pRetVal")),
                COMMETHOD([], HRESULT, "SetIconPath", (["in"], c_wchar_p, "Value"),
                          (["in"], POINTER(GUID), "EventContext")),
            ]

        class IAudioSessionManager(IUnknown):
            _iid_ = GUID("{BFA971F1-4D5E-40BB-935E-967039BFBEE4}")
            _methods_ = [
                COMMETHOD([], HRESULT, "GetAudioSessionControl", (["in"], POINTER(GUID), "AudioSessionGuid"),
                          (["in"], c_uint32, "StreamFlags"),
                          (["out"], POINTER(POINTER(IAudioSessionControl)), "SessionControl")),
            ]

        class IMMDevice(IUnknown):
            _iid_ = GUID("{D666063F-1587-4E43-81F1-B948E807363F}")
            _methods_ = [
                COMMETHOD([], HRESULT, "Activate", (["in"], POINTER(GUID), "iid"), (["in"], c_uint32, "dwClsCtx"),
                          (["in"], POINTER(c_uint32), "pActivationParams"),
                          (["out"], POINTER(POINTER(IUnknown)), "ppInterface")),
            ]

        class IMMDeviceEnumerator(IUnknown):
            _iid_ = GUID("{A95664D2-9614-4F35-A746-DE8DB63617E6}")
            _methods_ = [
                COMMETHOD([], HRESULT, "EnumAudioEndpoints", (["in"], c_uint32, "dataFlow"),
                          (["in"], c_uint32, "dwStateMask"), (["out"], POINTER(POINTER(IUnknown)), "ppDevices")),
                COMMETHOD([], HRESULT, "GetDefaultAudioEndpoint", (["in"], c_uint32, "dataFlow"),
                          (["in"], c_uint32, "role"), (["out"], POINTER(POINTER(IMMDevice)), "ppDevice")),
            ]

        try:
            comtypes.CoInitialize()
        except OSError:
            pass
        enum = comtypes.CoCreateInstance(GUID("{BCDE0395-E52F-467C-8E3D-C4579291692E}"), IMMDeviceEnumerator,
                                         comtypes.CLSCTX_ALL)
        ok = False
        for role in (0, 1):            # eConsole, eMultimedia (zwykle to samo urządzenie)
            dev = enum.GetDefaultAudioEndpoint(0, role)          # eRender
            unk = dev.Activate(IAudioSessionManager._iid_, comtypes.CLSCTX_ALL, None)
            mgr = unk.QueryInterface(IAudioSessionManager)
            ctl = mgr.GetAudioSessionControl(GUID(), 0)          # domyślna sesja tego procesu
            ctl.SetDisplayName(name, None)
            if icon and os.path.exists(icon):
                ctl.SetIconPath(icon + ",0", None)
            ok = True
        return ok
    except Exception:
        return False
