"""Ikona Inżyniera LMU w oknie konsoli (Windows; w Windows Terminal może zostać ikona terminala)."""

from __future__ import annotations

import os
import sys

ICON = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "assets", "inzynier.ico")


def set_console_icon() -> None:
    if sys.platform != "win32" or not os.path.exists(ICON):
        return
    try:
        import ctypes
        u32, k32 = ctypes.windll.user32, ctypes.windll.kernel32
        k32.GetConsoleWindow.restype = ctypes.c_void_p
        hwnd = k32.GetConsoleWindow()
        if not hwnd:
            return
        u32.LoadImageW.restype = ctypes.c_void_p
        u32.LoadImageW.argtypes = [ctypes.c_void_p, ctypes.c_wchar_p, ctypes.c_uint, ctypes.c_int, ctypes.c_int, ctypes.c_uint]
        u32.SendMessageW.argtypes = [ctypes.c_void_p, ctypes.c_uint, ctypes.c_void_p, ctypes.c_void_p]
        LR_LOADFROMFILE, IMAGE_ICON, WM_SETICON = 0x10, 1, 0x80
        big = u32.LoadImageW(None, ICON, IMAGE_ICON, 32, 32, LR_LOADFROMFILE)
        small = u32.LoadImageW(None, ICON, IMAGE_ICON, 16, 16, LR_LOADFROMFILE)
        if big:
            u32.SendMessageW(ctypes.c_void_p(hwnd), WM_SETICON, ctypes.c_void_p(1), ctypes.c_void_p(big))
        if small:
            u32.SendMessageW(ctypes.c_void_p(hwnd), WM_SETICON, ctypes.c_void_p(0), ctypes.c_void_p(small))
    except Exception:
        pass
