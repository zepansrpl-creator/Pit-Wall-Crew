"""Mózg obliczeniowy: łączy rejestrator, analizy i komunikaty po okrążeniu."""

from __future__ import annotations

import json
import os
from dataclasses import dataclass
from typing import Optional

from .analysis.corners import CornerDef, CornerDelta, compare, detect_corners, theoretical_best
from .analysis.fuel import fuel_report


def DBG_LOG(**kw) -> None:
    try:
        from .debuglog import DBG
        DBG.log("energy", **kw)
    except Exception:
        pass
from .analysis.handling import analyze as analyze_handling, label as balance_label
from . import setup_rules
from .analysis.hazards import HazardMonitor
from .analysis.strategy import Strategist
from .analysis.laps import LapRecorder, LapStore, LapTrace, safe_name
from .analysis.rivals import RivalTracker
from .analysis.suggest import SuggestMonitor
from .analysis.fatigue import FatigueMonitor
from .analysis.weather import WeatherAdvisor
from .analysis.engine import EngineMonitor
from .fmt import fmt_clock, fmt_time, laps_word, spoken_delta, spoken_lap
from .model import SESSION_NAMES, Snapshot


@dataclass
class Message:
    text: str
    priority: int  # wyższy = ważniejszy
    urgent: bool = False  # pilne ostrzeżenie: przerywa inne komunikaty, mówione także w trybie "cisza"
    team: bool = False    # ważne dla całego zespołu (idzie też do radia zespołu i na ścianę boksów)
    natural: bool = True  # można dodać wtrącenie („Słuchaj,”); False = szybki, ważny komunikat


class Engineer:
    def __init__(self, data_dir: str = "data", reference_file: Optional[str] = None,
                 fuel_margin_laps: float = 0.5, fuel_warn_laps: float = 3.0,
                 alerts_cfg: Optional[dict] = None, strategy_cfg: Optional[dict] = None,
                 engine_cfg: Optional[dict] = None) -> None:
        self.hazards = HazardMonitor(alerts_cfg)
        self.strategist = Strategist(strategy_cfg, data_dir)
        self._dmg_seen = 0
        self._phase: Optional[str] = None
        self.store = LapStore(data_dir)
        self.data_dir = data_dir
        self.reference_file = reference_file
        self.fuel_margin_laps = fuel_margin_laps
        self.fuel_warn_laps = fuel_warn_laps
        self.recorder = LapRecorder()
        self.rivals = RivalTracker()
        from .analysis.rivals import RivalCorners
        self.rival_corners = RivalCorners()
        self.teamlaps = None        # TeamLaps (ustawia kierowca.py, gdy jest zespół)
        self.mate_deltas = None     # (meta kolegi, [CornerDelta], ścisłe) z ostatniego okrążenia
        self.laps: list[LapTrace] = []
        self.ref: Optional[LapTrace] = None
        self.ref_source = ""
        self.corners: list[CornerDef] = []
        self.last_deltas: list[CornerDelta] = []
        self.session_key: Optional[tuple] = None
        self.snap: Optional[Snapshot] = None
        self._last_rival_msg: dict[int, float] = {}
        self._fuel_announced_lap = -10
        self.quiet = False                              # True = komunikaty tylko na pytanie
        self.remember_cb = None                         # zapis do pamięci zespołu (ściana boksów), gdy jest
        self._noted: set = set()
        self.notes: list[tuple[int, str]] = []          # (okrążenie, uwaga kierowcy o prowadzeniu)
        self.setup_changes: list[tuple[int, str]] = []  # (liczba okrążeń w sesji w chwili zmiany, opis)
        self.fatigue = FatigueMonitor(alerts_cfg)
        from .analysis.saving import SaveCoach
        self.saver = SaveCoach()
        from .analysis.night import PressureAdvisor
        self.pressures = PressureAdvisor()
        from .analysis.warmup import TyreWarmup
        self.warmup = TyreWarmup()
        self.suggest = SuggestMonitor(alerts_cfg)
        from .analysis.coach import CornerCoach
        self.coach = CornerCoach(alerts_cfg)
        from .analysis.compare_best import BestCompare
        self.compare_best = BestCompare(alerts_cfg)
        from .analysis.overtakes import OvertakeWatch
        self.overtakes = OvertakeWatch(alerts_cfg)
        self.rest = None                  # wewnętrzny interfejs LMU (prognoza, hamulce, grill), gdy dostępny
        from .analysis.rival_pits import RivalPits
        self.rival_pits = RivalPits()
        self._ratio_told = -1
        self._rain_told: set = set()
        self._brakes_told = -1
        self.weather = WeatherAdvisor(strategy_cfg)
        self.engine = EngineMonitor(engine_cfg)
        self.targets: dict = {}          # plan zespołu z arkusza: ve_per_lap, fuel_per_lap, wear, stint_laps, lap_time
        self._stint_start_idx = 0
        self.save_to_plan = None
        self._tyre_warned: set[int] = set()
        self._stop_told: Optional[tuple[int, float]] = None
        self._last_rival_any = -99
        self._inlap: Optional[int] = None
        self._box_called = False
        self._inlap_calls = 0             # ile razy wołaliśmy na zjazd od ostatniego postoju
        self._inlap_pits = -1
        self.pit_call_s = float((strategy_cfg or {}).get("pit_call_s", 25))          # przed linią mety
        self.pit_call_entry_s = float((strategy_cfg or {}).get("pit_call_entry_s", 12))  # przed wjazdem do alei
        self._last_rival_any = -99

    # ------------------------------------------------------------------ sesja
    def _new_session(self, snap: Snapshot) -> list[Message]:
        from .analysis import fuel as _fuelmod
        _fuelmod.GAME_VE_PER_LAP["v"] = None
        self.coach.reset()
        self.compare_best.reset()
        self.overtakes.reset()
        self.recorder.reset()
        self.rivals.reset()
        self.rival_corners.reset()
        self.mate_deltas = None
        if self.teamlaps is not None:
            self.teamlaps.match = None
            self.teamlaps._idx_t = None
        self.laps.clear()
        self.saver.reset()
        self.pressures.reset()
        self.warmup.reset()
        self.last_deltas = []
        self._last_rival_msg.clear()
        self._fuel_announced_lap = -10
        self.notes.clear()
        self.setup_changes.clear()
        self.hazards.reset()
        self.strategist.new_session(snap)
        self.fatigue.reset_driver(snap.t)
        self._stint_start_idx = 0
        self._tyre_warned.clear()
        self._stop_told = None
        self._dmg_seen = sum(snap.player.dents) if snap.player else 0
        self._phase = snap.phase
        self.ref, self.ref_source = None, ""
        if self.reference_file and os.path.exists(self.reference_file):
            try:
                lap = LapTrace.load(self.reference_file)
                if lap.track == snap.track:
                    self.ref, self.ref_source = lap, f"okrążenie referencyjne {lap.driver or 'z pliku'}"
            except (OSError, ValueError, TypeError):
                pass
        if self.ref is None:
            best = self.store.load_best(snap.track, snap.car_name)
            if best is not None:
                self.ref, self.ref_source = best, "Twoje najlepsze okrążenie z poprzednich sesji"
            elif getattr(self.store, "last_invalid", False):
                # zakręty wyznaczone z uszkodzonego okrążenia też odkładamy – wyznaczy je pierwsze dobre okrążenie
                cp = self._corners_path(snap)
                try:
                    if os.path.exists(cp):
                        os.replace(cp, cp.replace("corners.json", "corners_uszkodzone.json"))
                except OSError:
                    pass
        self.corners = self._load_corners(snap) or (detect_corners(self.ref) if self.ref else [])
        if self.ref is not None and self.corners:
            self._save_corners(snap)
        name = SESSION_NAMES.get(snap.session, snap.session)
        return [Message("Radio sprawdzone.", 1)]

    def _corners_path(self, snap: Snapshot) -> str:
        return os.path.join(self.data_dir, safe_name(snap.track), "corners.json")

    def _load_corners(self, snap: Snapshot) -> list[CornerDef]:
        path = self._corners_path(snap)
        if os.path.exists(path):
            try:
                with open(path, encoding="utf-8") as f:
                    return [CornerDef(**c) for c in json.load(f)]
            except (OSError, ValueError, TypeError):
                return []
        return []

    def _save_corners(self, snap: Snapshot) -> None:
        path = self._corners_path(snap)
        if os.path.exists(path):
            return
        os.makedirs(os.path.dirname(path), exist_ok=True)
        with open(path, "w", encoding="utf-8") as f:
            json.dump([c.__dict__ for c in self.corners], f, indent=1)

    # ------------------------------------------------------------------ pętla
    def update(self, snap: Snapshot) -> list[Message]:
        msgs: list[Message] = []
        key = (snap.track, snap.session, snap.car_name)
        if key != self.session_key and snap.player is not None:
            self.session_key = key
            msgs += self._new_session(snap)
        self.snap = snap
        self.rivals.update(snap)
        try:
            self.rival_corners.update(snap)
        except Exception as e:
            print(f"[rywale-zakręty] {e}")
        msgs += self._driver_changes(snap)
        for a in self.hazards.update(snap, self.ref, self.corners):
            msgs.append(Message(a.text, 10 if a.urgent else 4, urgent=a.urgent, natural=False))
        p0 = snap.player
        if p0 is not None and not p0.in_pits:
            # co mówi plan zespołu o najbliższym postoju (do sprawdzenia, gdy postój się skończy); tylko w wyścigu
            # z planem (inna długość wyścigu = brak planu, np. 2,4 h przy planie na 24 h)
            self._plan_stop = (self.targets.get("stint"), self.targets.get("stop_s"), self.targets.get("tyres")) \
                if (self.targets and self.targets.get("stop_s") and snap.session == "race") else None
        last0 = self.strategist.learner.last
        learned = self.strategist.update(snap, self.ref)
        if learned:
            msgs.append(Message(learned, 0))  # tylko w oknie, bez mówienia
        last = self.strategist.learner.last
        if last is not None and last is not last0 and getattr(self, "_plan_stop", None):
            from .analysis.strategy import check_stop
            chk = check_stop(last, self._plan_stop[1], self._plan_stop[2], self._plan_stop[0])
            if chk:
                self.pit_checks = (getattr(self, "pit_checks", []) + [chk])[-10:]
                msgs.append(Message(chk, 0))   # na ścianę boksów, bez mówienia
        msgs += self._live_strategy(snap)
        wx = self.weather.sample(snap.t, snap.rain, snap.dark_cloud, snap.wetness)
        if wx:
            msgs.append(Message(wx, 7, team=True))
        p = snap.player
        if p is not None:
            hot = self.engine.sample(p.water_c, p.oil_c, p.overheating, p.in_pits, snap.t)
            if hot:
                msgs.append(Message(hot, 9, urgent=True, team=True))
        try:
            self.suggest.sample(snap, self.corners)
            self.rival_pits.update(snap, self.rest)
        except Exception:
            pass
        lap = self.recorder.update(snap)
        if lap is not None:
            msgs += self._on_lap(lap, snap)
        msgs += self._box_call(snap)
        wu = self.warmup.update(snap)
        if wu:
            msgs.append(Message(wu, 6))
        if not self.quiet:
            tip = self.coach.update(snap, self.corners, self.ref)
            if tip:   # krótko i od razu, tuż przed zakrętem (inaczej nie ma sensu)
                msgs.append(Message(tip, 8, urgent=True, natural=False))
            else:     # porównanie z najlepszym okrążeniem (liczby), gdy trener nic nie mówi
                cmp_tip = self.compare_best.update(snap, self.corners, self.coach._said_this_lap,
                                                   lambda n: self.coach._active(n) is not None)
                if cmp_tip:
                    self.coach._said_this_lap = True       # jedna podpowiedź przed zakrętem na okrążenie
                    msgs.append(Message(cmp_tip, 7, urgent=True, natural=False))
            ot = self.overtakes.update(snap, self.rivals)
            if ot:
                msgs.append(Message(ot, 3, natural=False))
        if snap.session == "race" and self._race_over(snap):
            # po fladze w szachownicę: żadnych planów postoju, „box, box” ani oszczędzania
            msgs = [m for m in msgs if not any(w in m.text for w in (
                "Zjazd", "zjazd", "Box", "postój", "Postój", "Okrążenie zjazdowe", "przelicznik", "oszczęd", "Energia"))]
        return msgs

    def plan(self):
        if self.snap is None:
            return None
        self.strategist.plan_tyres = self.targets.get("tyres") if self.targets else None
        return self.strategist.plan(self.snap, self.laps, self.rivals, self.fuel_margin_laps, self._rival_will_pit)

    def _rival_will_pit(self, c, within_laps: float) -> bool:
        """Czy rywal zjedzie najpóźniej razem z nami (wtedy nie wyprzedzi nas na postoju)."""
        try:
            fr = fuel_report(self.snap, self.laps, self.fuel_margin_laps)
            typical = (1.0 / fr.ve_per_lap) if fr and fr.ve_per_lap else None
            n = self.rival_pits.pit_in(c, self.rest, typical)
            return n is not None and n <= within_laps
        except Exception:
            return False

    def _live_strategy(self, snap: Snapshot) -> list[Message]:
        msgs: list[Message] = []
        p = snap.player
        if p is None:
            return msgs
        # nowe uderzenie
        dmg = sum(p.dents) + (4 if p.parts_detached else 0)
        if dmg > self._dmg_seen:
            heavy = dmg - self._dmg_seen >= 3 or p.parts_detached
            # jedno uderzenie gra zapisuje w kilku krokach – jeden komunikat na 15 s
            if snap.t - getattr(self, "_dmg_told_t", -1e9) > 15:
                self._dmg_told_t = snap.t
                msgs.append(Message("Uderzenie, " + ("spore uszkodzenia, " if heavy else "") + "mierzę stratę.", 6))
        self._dmg_seen = dmg
        # FCY: czy zjechać teraz
        if snap.phase == "fcy" and self._phase != "fcy" and snap.session == "race":
            plan = self.plan()
            ps = snap.player_scoring()
            stint_laps = len([l for l in self.laps if not l.pit][-30:])
            if plan and plan.stop_needed and plan.laps_to_stop is not None and ps is not None:
                save = self.strategist.params.lane_loss_s * (1 - self.strategist.params.fcy_factor)
                if plan.laps_to_stop <= 15 and stint_laps >= 3:
                    txt = f"FCY, postój tańszy o {save:.0f} s. "
                    txt += ("Zjedź, gdy otworzą aleję." if snap.yellow_state in (1, 2) else "Aleja otwarta, zjeżdżaj.")
                    msgs.append(Message(txt, 8, team=True))
        self._phase = snap.phase
        return msgs

    # ------------------------------------------------------------ okrążenie
    # Bez pytania inżynier NIE podaje czasu okrążenia ani stanu paliwa/opon (kierowca widzi je sam).
    # Mówi tylko o zmianach i o tym, co z nich wynika na przyszłość.
    def _on_lap(self, lap: LapTrace, snap: Snapshot) -> list[Message]:
        self.laps.append(lap)
        self.weather.add_lap(lap)
        self.engine.end_lap(lap.pit)
        msgs: list[Message] = []
        if lap.pit:
            self.engine.reset_stint()
            self._stint_start_idx = len(self.laps)
            self.fatigue.new_stint()
            self._tyre_warned.clear()
            self._stop_told = None
        tired = self.fatigue.add_lap(lap, snap.t)
        if tired:
            msgs.append(Message(tired, 5, team=True))
        msgs += self._suggestion(lap, snap)
        msgs += self._rest_checks(snap)

        if lap.clean:
            # porównanie zakrętów liczymy zawsze (na pytanie), ale bez komunikatu
            self.last_deltas = []
            if self.ref is not None and self.corners and lap is not self.ref:
                self.last_deltas = compare(lap, self.ref, self.corners)
            new_ref = (self.ref is None or lap.lap_time < self.ref.lap_time) and lap.plausible()
            if new_ref and not self.ref_source.startswith("okrążenie referencyjne"):
                self.ref, self.ref_source = lap, "Twoje najlepsze okrążenie"
                self.store.save_best(lap)
                if not self.corners:
                    self.corners = detect_corners(lap)
                    if self.corners:
                        self._save_corners(snap)

        try:   # trener na zakręty: błędy z tego okrążenia (telemetria + uczciwe porównanie z wzorcem)
            faults = self.suggest.history[-1] if (self.suggest.history and not lap.pit) else {}
            fair, similar = self._fair_deltas(lap)
            if not similar:   # inne opony niż na wzorcu: prędkość w zakręcie nie jest winą kierowcy
                for d in fair:
                    d.min_speed_diff = 0.0
            better = self.coach.end_lap(faults, fair, lap.pit)
            mate = None
            tm = self.teamlaps.match if self.teamlaps is not None else None
            if tm is not None and lap.clean and self.corners and self.saver.state is None:
                from .analysis.teamlaps import mate_deltas
                md = mate_deltas(lap, tm[1], self.corners)
                self.mate_deltas = (tm[0], md, tm[2]) if md else None
                mate = self.mate_deltas
            self.compare_best.end_lap(fair, lap.pit, speed_ok=similar, mate=mate)
            if better and not self.quiet:
                msgs.append(Message(better, 3, natural=False))
        except Exception as e:
            print(f"[trener] {e}")

        plan_said = False
        if snap.session == "race":
            fr0 = fuel_report(snap, self.laps, self.fuel_margin_laps)
            used = None
            if not lap.pit and not lap.fcy:
                used = lap.ve_used if (fr0 is not None and fr0.ve is not None and fr0.ve_per_lap) else lap.fuel_used
            pp = self.strategist.params
            for t in self.saver.on_lap(fr0, fr0.laps_to_finish if fr0 else None, pp.lane_loss_s + pp.base_s, used):
                msgs.append(Message(t, 6, team=True))
            self.pressures.update(self.laps, self._stint_start_idx)
            ps0 = snap.player_scoring()
            pm = self.pressures.message(ps0.pit_stops if ps0 else 0)
            if pm:
                msgs.append(Message(pm, 4, team=True))
            plan = self.plan()
            ps = snap.player_scoring()
            stint_id = ps.pit_stops if ps else 0
            if plan and plan.stop_needed and plan.laps_to_stop is not None and plan.laps_to_stop <= 3 \
                    and self.strategist._announced_stint != stint_id:
                self.strategist._announced_stint = stint_id
                self._announced_inlap = (stint_id, ps.laps_done + (plan.laps_to_stop or 0) + 1) if ps else None
                speech = plan.short()
                g = self.engine.pit_phrase(short=True)
                if g:
                    speech = speech.rstrip(".") + ". " + g[0].upper() + g[1:] + "."
                msgs.append(Message(speech, 6, team=True))
                plan_said = True
            # zjazd zapowiedziany, a zużycie się zmieniło: powiedz, że okrążenie zjazdowe się przesuwa
            ai = getattr(self, "_announced_inlap", None)
            if not plan_said and ai and ps is not None and ai[0] == stint_id and not lap.pit:
                plan2, n2 = self._laps_to_stop(snap)
                if plan2 is not None and n2 is not None and n2 >= 1:
                    new_inlap = ps.laps_done + n2 + 1
                    if new_inlap != ai[1]:
                        self._announced_inlap = (stint_id, new_inlap)
                        said = n2 + 1 if plan2.frac < 0.5 else n2
                        w = "okrążenie" if said == 1 else ("okrążenia" if said % 10 in (2, 3, 4) and said % 100 not in (12, 13, 14) else "okrążeń")
                        diff = new_inlap - ai[1]
                        when = ("o okrążenie" if abs(diff) == 1 else f"o {abs(diff)} okrążenia") + \
                            (" później" if diff > 0 else " wcześniej")
                        msgs.append(Message(f"Zjazd {when}: za {said} {w}.", 6, team=True))
                        plan_said = True
            d = plan.damage if plan else None
            if d and d.loss_per_lap is not None and self.strategist._damage_announced != d.lap:
                self.strategist._damage_announced = d.lap
                if d.loss_per_lap < 0.15:
                    msgs.append(Message("Uszkodzenie nie kosztuje czasu, bez naprawy.", 4, team=True))
                else:
                    txt = f"Uszkodzenie kosztuje {d.loss_per_lap:.1f} s na okrążenie"
                    if plan.repair_worth is not None:
                        txt += ", naprawa się opłaca" if plan.repair_worth else ", naprawa się nie opłaca"
                    else:
                        txt += ". Podaj czas naprawy"
                    msgs.append(Message(txt + ".", 5, team=True))

        inlap = self._inlap_start(snap)
        if inlap:
            msgs += inlap
            plan_said = True
        if not plan_said:
            msgs += self._consumption_trend(snap)
        msgs += self._tyre_trend()
        msgs += self._rival_changes(snap, lap)
        p = snap.player
        if p is not None:
            fr = fuel_report(snap, self.laps, self.fuel_margin_laps)
            adv = self.weather.advise(snap.rain, snap.wetness, p.compound_front,
                                      fr.stint_laps_left if fr else None, snap.track_temp,
                                      self.targets.get("lap_time"))
            w = self.weather.proactive(adv, snap.t)
            if w:
                msgs.append(Message(w, 6, team=True))
            e = self.engine.proactive(snap.t)
            if e:
                msgs.append(Message(e, 6, team=True))
        return msgs

    def _driver_changes(self, snap: Snapshot) -> list[Message]:
        """Zmiana kierowcy u rywala blisko w klasie: czy nowy kierowca jest szybszy, czy wolniejszy."""
        ev, self.rivals.events = self.rivals.events, []
        me = snap.player_scoring()
        if not ev or me is None or snap.session != "race":
            return []
        same = sorted([c for c in snap.cars if c.car_class == me.car_class], key=lambda c: c.place)
        idx = next((i for i, c in enumerate(same) if c.is_player), None)
        if idx is None:
            return []
        out = []
        for car_id, old, new in ev:
            k = next((i for i, c in enumerate(same) if c.car_id == car_id), None)
            if k is None or k == idx or abs(k - idx) > 3:
                continue
            po, pn = self.rivals.driver_pace(car_id, old), self.rivals.driver_pace(car_id, new)
            if po is None or pn is None or abs(pn - po) < 0.3:
                continue
            where = "przed Tobą" if k < idx else "za Tobą"
            n = k - idx
            pos = f"{abs(n)}. auto {where}" if abs(n) > 1 else f"auto {where}"
            last = lambda name: name.split()[-1]
            out.append(Message(f"Zmiana kierowcy, {pos}: teraz {last(new)}, o {abs(pn - po):.1f} s na okrążenie "
                               f"{'wolniejszy' if pn > po else 'szybszy'} niż {last(old)}.", 3, team=True))
        return out

    def _fair_ref(self, lap: LapTrace) -> tuple[Optional[LapTrace], bool]:
        """Wzorzec do porównania w zakrętach, uczciwy dla zużytych opon i warunków.

        1) najszybsze czyste okrążenie z podobnym zużyciem opon (średnio ±10 pkt %), tą samą mieszanką,
           podobną ilością paliwa (±30 l), wilgotnością (±5 pkt %) i temperaturą toru (±4°C) → (wzorzec, True);
        2) inaczej najszybsze czyste okrążenie z tego stintu (te same opony, ale były świeższe) → (wzorzec, False):
           wtedy tylko uwagi o technice (punkt hamowania, gaz), bez prędkości w zakręcie;
        3) brak – gdy warunki są inne niż na wszystkich wzorcach (deszcz, noc) albo kierowca oszczędza.
        """
        if self.saver.state is not None or not lap.t:
            return None, False

        def wear(l):
            return sum(l.wear_tyres) / len(l.wear_tyres) if l.wear_tyres else None

        def same_cond(l):
            return abs(l.wetness - lap.wetness) <= 0.05 and abs(l.rain - lap.rain) <= 0.05 and \
                (not l.track_temp or not lap.track_temp or abs(l.track_temp - lap.track_temp) <= 4)
        pool = [l for l in self.laps if l is not lap and l.clean and not l.pit and l.t and len(l.t) == len(lap.t)
                and same_cond(l) and (not l.compound or not lap.compound or l.compound == lap.compound)]
        w0 = wear(lap)
        similar = [l for l in pool if w0 is not None and wear(l) is not None and abs(wear(l) - w0) <= 0.10
                   and abs((l.fuel_start or 0) - (lap.fuel_start or 0)) <= 30]
        if similar:
            return min(similar, key=lambda l: l.lap_time), True
        stint = [l for l in self._stint_laps() if l in pool]
        if stint:
            return min(stint, key=lambda l: l.lap_time), False
        return None, False

    def _fair_deltas(self, lap: LapTrace) -> tuple[list, bool]:
        if not lap.clean or lap.pit or not self.corners:
            return [], False
        ref, similar = self._fair_ref(lap)
        if ref is None or ref.lap_time >= lap.lap_time:
            return [], similar
        out = compare(lap, ref, self.corners)
        for d in out:   # przyczyny techniczne (niezależne od opon): punkt hamowania, gaz
            d.reasons_technique = (d.brake_point_diff is not None and d.brake_point_diff <= -10) or \
                (d.throttle_point_diff is not None and d.throttle_point_diff >= 15) or d.coast_diff >= 15
        return out, similar

    def _stint_laps(self) -> list[LapTrace]:
        return self.laps[self._stint_start_idx:]

    def _consumption_trend(self, snap: Snapshot) -> list[Message]:
        """Zużycie paliwa/energii zmienia moment zjazdu: mówimy o zmianie i o skutku (nie o stanie baku)."""
        fr = fuel_report(snap, self.laps, self.fuel_margin_laps)
        ps = snap.player_scoring()
        if fr is None or fr.stint_laps_left is None or ps is None:
            return []
        if fr.stint_laps_left < 0.6:
            if ps.in_pits or (snap.player is not None and snap.player.in_pits):
                return []                  # już zjeżdża
            what = "energii" if fr.limiting == "VE" else "paliwa"
            return [Message(f"Koniec {what}, zjeżdżaj do boksu w tym okrążeniu.", 9)]
        if len([l for l in self._stint_laps() if l.clean]) < 3:
            return []
        if fr.limiting == "VE" and fr.ve_per_lap:
            use, target, unit, what = fr.ve_per_lap * 100, self.targets.get("ve_per_lap"), "%", "energii"
        else:
            use, target, unit, what = fr.per_lap_l, self.targets.get("fuel_per_lap"), " l", "paliwa"
        if use is None:
            return []
        done = len(self._stint_laps())
        fuel_left = int(fr.stint_laps_left)
        planned = self.targets.get("stint_laps")
        plan_left = max(0, int(planned) - done) if planned else None
        # zjazd wyznacza paliwo/energia tylko wtedy, gdy nie starczy do planowanego zjazdu
        limited = plan_left is None or fuel_left < plan_left
        stop_lap = ps.laps_done + (fuel_left if limited else plan_left)
        msgs: list[Message] = []
        if self._stop_told is None:
            self._stop_told = (stop_lap, use)
            if planned and limited and plan_left - fuel_left >= 1:
                n = plan_left - fuel_left
                txt = self._saving_text(fr, use, unit, what, plan_left, n)
                msgs.append(Message(txt, 5, team=True))
            return msgs
        told_lap, told_use = self._stop_told
        if stop_lap == told_lap or not limited:
            return msgs
        if abs(use - told_use) / max(told_use, 1e-6) < 0.05:
            return msgs  # drobne wahania zaokrągleń, zużycie praktycznie bez zmian
        diff = stop_lap - told_lap
        self._stop_told = (stop_lap, use)
        change = "wzrosło" if use > told_use else "spadło"
        n = abs(diff)
        if diff < 0:
            # najpierw: ile oszczędzać, żeby utrzymać dotychczasowy zjazd; dopiero potem skutek
            laps_to_old = max(1, told_lap - ps.laps_done)
            txt = self._saving_text(fr, use, unit, what, laps_to_old, n)
        else:
            txt = f"Zużycie {what} spadło, zjazd {n} {laps_word(n)} później."
        msgs.append(Message(txt, 5, team=True))
        return msgs

    def _saving_text(self, fr, use: float, unit: str, what: str, laps_target: int, laps_early: int) -> str:
        """Ile oszczędzać na okrążenie, żeby dojechać do zjazdu za laps_target okrążeń (i co, jeśli nie)."""
        if unit == "%":
            left = (fr.ve or 0.0) * 100 - 0.5            # mały zapas energii na wjazd do alei
        else:
            left = fr.fuel_l - 0.5
        laps_target = max(1, int(laps_target))
        need = left / laps_target
        save = use - need
        if save <= 0:
            return f"Zużycie {what} w normie, strategia bez zmian."
        if save / use * 100 > 8:
            return f"Za duże zużycie {what}, zjazd {laps_early} {laps_word(laps_early)} wcześniej."
        return f"Musisz oszczędzić {save:.1f}{unit} {what} na okrążenie, żeby utrzymać strategię."

    def _tyre_trend(self) -> list[Message]:
        """Opony zużywają się szybciej niż w planie (albo niż na początku stintu) – jeden komunikat na stint."""
        stint = [l for l in self._stint_laps() if l.clean and len(l.wear_tyres) == 4]
        if len(stint) < 4 or self._tyre_warned:
            return []
        names = ["lewy przód", "prawy przód", "lewy tył", "prawy tył"]
        recent = stint[-3:]
        plan = self.targets.get("wear")  # % na okrążenie dla LP, PP, LT, PT
        worse = []
        for k in range(4):
            rate = (recent[-1].wear_tyres[k] - stint[-4].wear_tyres[k]) / 3 * 100
            if plan and len(plan) == 4 and plan[k]:
                ref, src = plan[k], "w planie"
            else:
                if len(stint) < 7:
                    return []
                ref = (stint[2].wear_tyres[k] - stint[0].wear_tyres[k]) / 2 * 100
                src = "na początku stintu"
            if ref > 0 and rate >= ref * 1.2 and rate - ref >= 0.2:
                worse.append((rate / ref, k, rate, ref, src))
        if not worse:
            return []
        self._tyre_warned.update(k for _, k, *_ in worse)
        _, k, rate, ref, src = max(worse)
        txt = f"{names[k][0].upper() + names[k][1:]} zużywa się szybciej niż {src}"
        left = self._laps_left_estimate()
        if left is not None:
            worn = recent[-1].wear_tyres[k] * 100
            txt += f", na postoju zostanie {max(0, 100 - worn - rate * left):.0f}%"
        txt += "."
        return [Message(txt, 4, team=True)]

    def _laps_left_estimate(self) -> Optional[float]:
        if self.snap is None:
            return None
        fr = fuel_report(self.snap, self.laps, self.fuel_margin_laps)
        return fr.stint_laps_left if fr else None

    def _rival_changes(self, snap: Snapshot, lap: LapTrace) -> list[Message]:
        """Rywal w klasie blisko (do 10 s) wyraźnie odrabia albo ucieka – najwyżej co 5 okrążeń."""
        if snap.session != "race" or lap.pit:
            return []
        if lap.lap - self._last_rival_any < 5:
            return []
        for r in self.rivals.rivals(snap, ahead=1, behind=1):
            if r.trend is None or r.gap_s is None or abs(r.gap_s) > 10 or abs(r.trend) > 3 or r.car.in_pits:
                continue
            behind = r.gap_s > 0
            contact = r.laps_to_catch is not None and r.trend < 0 and r.laps_to_catch < 10
            if behind and not contact:
                continue  # rywal z tyłu, który traci, nie wymaga komunikatu
            if not behind and not (contact or r.trend >= 0.5):
                continue
            if lap.lap - self._last_rival_msg.get(r.car.car_id, -99) < 8:
                continue
            self._last_rival_msg[r.car.car_id] = lap.lap
            self._last_rival_any = lap.lap
            name = r.car.driver.split()[-1] if r.car.driver else "Rywal"
            if behind:
                txt = f"{name} za Tobą, {r.gap_s:.1f} s, odrabia {abs(r.trend):.1f} na okrążenie"
            elif r.trend < 0:
                txt = f"{name} przed Tobą, {abs(r.gap_s):.1f} s, odrabiasz {abs(r.trend):.1f} na okrążenie"
            else:
                txt = f"{name} przed Tobą, {abs(r.gap_s):.1f} s, ucieka {r.trend:.1f} na okrążenie"
            if contact:
                n = max(1, round(r.laps_to_catch))
                txt += f", kontakt za {n} {laps_word(n)}"
            return [Message(txt + ".", 3)]
        return []

    # ------------------------------------------------------- okrążenie zjazdowe
    def _laps_to_stop(self, snap: Snapshot):
        """Okrążenia do zjazdu: z paliwa/energii albo z planu zespołu (planowana długość stintu), co wcześniej."""
        plan = self.plan()
        if plan is None or not plan.stop_needed or plan.laps_to_stop is None:
            return plan, None
        n = plan.laps_to_stop
        self.save_to_plan = None
        planned = self.targets.get("stint_laps")
        if planned:
            done = len(self._stint_laps())
            n_plan = max(0, int(planned) - done - 1)
            if n_plan > n:
                # energii (paliwa) brakuje do planu tylko trochę: zostaw zjazd z planu i podaj cel oszczędzania
                per = self._per_lap_for(snap, n_plan)
                if per is not None:
                    n, self.save_to_plan = n_plan, per
                    plan.laps_to_stop = n_plan
                    plan.outline = (plan.outline + " " if plan.outline else "") + \
                        f"Wg planu: zużycie najwyżej {str(per[0]).replace('.', ',')}{per[1]} na okrążenie."
            n = min(n, n_plan)
        return plan, n

    def _per_lap_for(self, snap: Snapshot, n: int):
        """Zużycie na okrążenie, przy którym dojedzie się do zjazdu za n okrążeń (z minimalnym zapasem),
        gdy wymaga to oszczędzania najwyżej 3%. (wartość, jednostka) albo None."""
        fr = fuel_report(snap, self.laps, self.fuel_margin_laps)
        ps = snap.player_scoring()
        if fr is None or ps is None or snap.track_length <= 0:
            return None
        frac = min(max(ps.lap_dist / snap.track_length, 0.0), 1.0)
        dist = (1.0 - frac) + n
        if fr.limiting == "VE" and fr.ve_per_lap and fr.ve is not None:
            per, use, unit = (fr.ve - 0.002) / dist, fr.ve_per_lap, "%"
            per, use = per * 100, use * 100
        elif fr.per_lap_l and fr.fuel_l:
            per, use, unit = (fr.fuel_l - 0.3) / dist, fr.per_lap_l, " l"
        else:
            return None
        if per >= use or (use - per) / use > 0.03:
            return None
        return (round(per, 2), unit)

    def _rest_checks(self, snap: Snapshot) -> list[Message]:
        """Prognoza deszczu i zużycie hamulców z wewnętrznego interfejsu gry (raz na zdarzenie)."""
        r = self.rest
        if r is None or not r.ok:
            return []
        out: list[Message] = []
        try:
            self.engine.grille_now = r.grille
            self.suggest.limits = r
            self.strategist.new_tyres = r.new_tyres
            if r.tyres_parallel is not None:
                self.strategist.params.tyres_parallel = r.tyres_parallel
            out += self._energy_check(snap, r)
            # przelicznik paliwa: paliwo nie może skończyć się przed energią
            p = snap.player
            fr = fuel_report(snap, self.laps, self.fuel_margin_laps)
            ps0 = snap.player_scoring()
            stint0 = ps0.pit_stops if ps0 else 0
            if fr and p and fr.laps_on_ve and fr.laps_in_tank and r.fuel_ratio and self._ratio_told != stint0 \
                    and len([l for l in self._stint_laps() if l.clean]) >= 2 and fr.laps_in_tank < fr.laps_on_ve + 0.05:
                # naprawdę: paliwa starczy na mniej (albo tyle samo) okrążeń co energii
                need = r.fuel_ratio * (fr.laps_on_ve + 0.2) / fr.laps_in_tank
                self._ratio_told = stint0
                out.append(Message(
                    f"Paliwa starczy na {fr.laps_in_tank:.1f} okrążenia, energii na {fr.laps_on_ve:.1f}, paliwo skończy "
                    f"się pierwsze. Na postoju przelicznik paliwa na {need:.2f}.".replace(".", ",", 0), 7, team=True))
            risk = r.rain_risk(None)
            if risk:
                key = (r.session, risk[0], risk[1] // 10)
                if key not in self._rain_told:
                    self._rain_told.add(key)
                    from .sources.lmu_rest import when_pl
                    out.append(Message(f"Prognoza: {when_pl(risk[0], r.session)} szansa deszczu {risk[1]} procent.",
                                       6, team=True))
            ps = snap.player_scoring()
            stint = ps.pit_stops if ps else 0
            if r.brakes and min(r.brakes) < 0.3 and self._brakes_told != stint:
                self._brakes_told = stint
                out.append(Message(f"Hamulce: zostało {min(r.brakes) * 100:.0f} procent. Na postoju wymień.", 6, team=True))
        except Exception as e:
            print(f"[interfejs gry] {e}")
        return out

    def note(self, text: str) -> None:
        """Notatka do pamięci zespołu (AI czyta ją przy pytaniach). Bez duplikatów w jednej sesji."""
        if not text or self.remember_cb is None or text in self._noted:
            return
        self._noted.add(text)
        self.notes_log = (getattr(self, "notes_log", []) + [text])[-10:]
        s = self.snap
        try:
            self.remember_cb(text, s.track if s else "", s.car_name if s else "")
        except Exception as e:
            print(f"[pamięć] {e}")

    def _suggestion(self, lap: LapTrace, snap: Snapshot) -> list[Message]:
        """Sugestia ustawień / jazdy, gdy problem powtarza się na kolejnych okrążeniach (komenda: sugestie / bez sugestii)."""
        try:
            self.suggest.end_lap(lap.pit)
            p = snap.player
            if p is None or not self.suggest.enabled:
                return []
            settings = (round(p.rear_brake_bias, 3), p.tc, p.abs)
            h = None
            if self.corners and len(self.laps) >= 4:
                from .analysis.handling import analyze
                h = analyze(self.laps, self.corners)
            txt = self.suggest.check(snap.t, snap.session == "race", settings, h)
        except Exception as e:
            print(f"[sugestie] błąd: {e}")
            return []
        if txt and txt.startswith("Po zmianie"):
            sess = "wyścig" if snap.session == "race" else "trening"
            self.note(f"{sess}, tor {snap.track_temp:.0f}°C: {txt}")
        return [Message(txt, 4, team=True)] if txt else []

    def _energy_check(self, snap: Snapshot, r) -> list[Message]:
        """Zużycie energii i paliwa liczymy tak jak gra (jej zapis okrążeń). Do dziennika: porównanie z własnym
        pomiarem (gdyby kiedyś gra podawała coś dziwnego)."""
        from .analysis import fuel as fuelmod
        from .analysis.rival_pits import fuel_per_lap as game_fuel, ve_per_lap as game_ve
        ps, p = snap.player_scoring(), snap.player
        if ps is None or p is None:
            return []
        laps = r.usage.get(ps.driver, []) if isinstance(r.usage, dict) else []
        g, gf = game_ve(laps), game_fuel(laps)
        fuelmod.GAME_VE_PER_LAP["v"], fuelmod.GAME_VE_PER_LAP["fuel"] = g, gf
        key = (ps.pit_stops, len(self.laps))
        if key != getattr(self, "_ve_chk_key", None):
            self._ve_chk_key = key
            ours = [l.ve_used for l in self.laps if l.clean and l.ve_used and l.ve_used > 0][-3:]
            DBG_LOG(ve_check=True, game_ve=None if g is None else round(g * 100, 2), game_fuel=gf,
                    own_ve=round(sum(ours) / len(ours) * 100, 2) if ours else None)
        return []

    def _race_over(self, snap: Snapshot) -> bool:
        """Flaga w szachownicę albo już po mecie – żadnych planów postoju ani „box, box”."""
        ps = snap.player_scoring()
        return snap.phase == "over" or (ps is not None and ps.finished)

    def _inlap_start(self, snap: Snapshot) -> list[Message]:
        """Na początku okrążenia zjazdowego: przypomnienie z planem postoju."""
        if snap.session != "race" or self._race_over(snap):
            return []
        plan, n = self._laps_to_stop(snap)
        ps = snap.player_scoring()
        if plan is None or n is None or ps is None:
            return []
        if ps.in_pits or (snap.player is not None and snap.player.in_pits):
            return []                              # linia mety w alei (np. Le Mans): już zjeżdża, nie powtarzamy
        if ps.pit_stops != self._inlap_pits:      # był postój: liczymy od nowa
            self._inlap_pits, self._inlap_calls = ps.pit_stops, 0
        if n > 0:
            self._inlap_calls = 0
            return []
        if self._inlap_calls >= 2:                # kierowca/zespół zdecydował inaczej, nie męczymy co okrążenie
            return []
        self._inlap_calls += 1
        self._inlap = ps.laps_done + 1
        self._box_called = False
        what = self._pit_what(plan)
        txt = "Okrążenie zjazdowe" if self._inlap_calls == 1 else "Nie było zjazdu. Okrążenie zjazdowe"
        if what:
            txt += ". " + what
        return [Message(txt.rstrip(".") + ".", 8, team=True)]

    def _pit_what(self, plan) -> str:
        """Co zrobić na postoju, krótko: 'Energia 70%, przednie opony, grill otwórz o stopień.'"""
        what = []
        if plan.ve_target_pct is not None:
            what.append("energia do pełna" if plan.ve_target_pct >= 99 else f"energia {plan.ve_target_pct:.0f}%")
        elif plan.fuel_add_l > 0.5:
            what.append(f"paliwo {plan.fuel_add_l:.0f} l")
        if plan.tyres:
            opt = plan.tyres.option
            what.append("bez opon" if opt == "bez zmiany opon" else
                        ("cztery opony" if opt == "wszystkie cztery" else f"{opt} opony"))
        g = self.engine.pit_phrase(short=True)
        if g:
            what.append(g)
        pr = self.pressures.phrase()
        if pr:
            what.append(pr)
        if not what:
            return ""
        t = ", ".join(what)
        return t[0].upper() + t[1:] + "."

    def _box_call(self, snap: Snapshot) -> list[Message]:
        """Pod koniec okrążenia zjazdowego: 'box, box' na tyle wcześnie, żeby trafić we wjazd do alei."""
        ps, p = snap.player_scoring(), snap.player
        if self._inlap is None or ps is None or p is None or self._box_called:
            return []
        if self._race_over(snap):
            self._inlap = None
            return []
        if ps.laps_done + 1 != self._inlap or p.in_pits:
            if ps.laps_done + 1 > self._inlap or p.in_pits:
                self._inlap = None
            return []
        # wjazd do alei: z gry (interfejs) albo zmierzony na poprzednim postoju; bez tego linia mety
        entry = None
        r = self.rest
        L = snap.track_length
        meas = getattr(self.strategist.params, "pit_entry_m", None)
        rest_pe = getattr(r, "pit_entry", None) if r is not None else None
        # wartość z gry tylko gdy wiarygodna: pod koniec okrążenia i zgodna z wjazdem zmierzonym na postoju
        # (w wyścigu 2,4 h gra podała ok. 7 km na Le Mans – „box, box” w połowie okrążenia)
        if rest_pe and L and L * 0.75 < rest_pe < L and (not meas or abs(rest_pe - meas) < 1500):
            entry = rest_pe
        elif meas:
            entry = meas
        # wjazd do alei leży pod koniec okrążenia; dziwna wartość z gry = linia mety
        target = entry if entry and L * 0.5 < entry < L else L
        if p.lap_dist < L * 0.3:
            return []          # tuż za linią mety nigdy „box, box” (nawet przy błędnym okrążeniu wzorcowym)
        lead = self.pit_call_entry_s if target < L else self.pit_call_s
        if p.lap_dist > target:
            return []
        to_go = (target - p.lap_dist) / max(10.0, p.speed_kmh / 3.6)
        if self.ref is not None and self.ref.lap_time > 0:
            t_ref = self.ref.time_at(target - 1) - self.ref.time_at(p.lap_dist)
            if t_ref > 0 and (target - p.lap_dist) / t_ref * 3.6 < 400:     # wzorzec bez „dziur”
                to_go = t_ref
        if to_go > lead:
            return []
        self._box_called = True
        out = [Message("Box, box.", 10, urgent=True, team=True)]
        plan, _ = self._laps_to_stop(snap)
        what = self._pit_what(plan) if plan else ""
        if what:   # zaraz po "box, box" jeszcze raz, co na postoju (u kierowcy)
            out.append(Message(what, 9))
        return out

    # ------------------------------------------------- wypowiedzi kierowcy
    def driver_said(self, text: str) -> None:
        """Zapamiętuje uwagi o prowadzeniu i zmiany setupu z wypowiedzi kierowcy."""
        lap = (self.snap.player_scoring().laps_done if self.snap and self.snap.player_scoring() else 0)
        if setup_rules.is_setup_change(text):
            self.setup_changes.append((len(self.laps), text))
        elif setup_rules.is_feedback(text):
            self.notes.append((lap, text))

    def _setup_section(self, question: str = "") -> list[str]:
        out = []
        rep = analyze_handling(self.laps, self.corners)
        p = self.snap.player if self.snap else None
        if p:
            arb = ""
            if p.front_arb >= 0:
                arb = f", stabilizator przód {p.front_arb}, tył {p.rear_arb}"
            mm = f", mapa silnika {p.motor_map}" if p.motor_map >= 0 else ""
            out.append(f"USTAWIENIA REGULOWANE W AUCIE: TC {p.tc}, ABS {p.abs}, balans hamulców "
                       f"{(1 - p.rear_brake_bias) * 100:.1f}% przód{arb}{mm}")
        race_now = bool(self.snap is not None and self.snap.session == "race")
        if race_now:
            out.append("SESJA: WYŚCIG – proponuj tylko balans hamulców, TC, ABS, mapę silnika albo technikę; "
                       "żadnych stabilizatorów ani zmian w garażu.")
        if rep is None:
            out.append("PROWADZENIE: za mało danych (potrzebne czyste okrążenie i wykryte zakręty)")
        else:
            out.append("PROWADZENIE (pomiar z kątów poślizgu opon):\n" + rep.describe())
            c = setup_rules.corner_from_text(question, rep)
            if c is not None:
                out.append(f"KIEROWCA PYTA O ZAKRĘT: {c.describe()}")
                out.append(f"PORADA DLA ZAKRĘTU: {setup_rules.corner_tip(c, race_now)}")
            tips = setup_rules.suggestions(rep, race_now)
            if tips:
                out.append("PODPOWIEDZI WYNIKAJĄCE Z DANYCH: " + " ".join(tips[:5]))
        if self.notes:
            out.append("WCZEŚNIEJSZE UWAGI KIEROWCY: " + " | ".join(f"okr. {l}: {t}" for l, t in self.notes[-5:]))
        if self.setup_changes:
            idx, desc = self.setup_changes[-1]
            before = [l for l in self.laps[:idx] if l.clean][-3:]
            after = [l for l in self.laps[idx:] if l.clean]
            line = f"OSTATNIA ZMIANA SETUPU: \"{desc}\"; czystych okrążeń po zmianie: {len(after)}"
            if before and after:
                b = sum(l.lap_time for l in before) / len(before)
                a = sum(l.lap_time for l in after[-3:]) / len(after[-3:])
                line += f"; średni czas przed {fmt_time(b)}, po {fmt_time(a)} ({a - b:+.2f} s)"
                rb, ra = analyze_handling(before, self.corners), analyze_handling(after, self.corners)
                if rb and ra:
                    diffs = []
                    for cb, ca in zip(rb.corners, ra.corners):
                        for ph, nm in (("entry", "wejście"), ("mid", "środek"), ("exit", "wyjście")):
                            vb, va = getattr(cb, ph), getattr(ca, ph)
                            if vb is not None and va is not None and abs(va - vb) >= 0.3:
                                diffs.append(f"{cb.name} {nm} {vb:+.1f}° -> {va:+.1f}° ({balance_label(va)})")
                    if diffs:
                        line += "; zmiany balansu: " + ", ".join(diffs[:6])
                    else:
                        line += "; balans w zakrętach bez wyraźnej zmiany"
            if len(after) < 3:
                line += " (do pewnej oceny potrzeba 3 czystych okrążeń po zmianie)"
            out.append(line)
        return out

    # ------------------------------------------------------- podsumowanie
    def _speed_energy_section(self, s: Snapshot) -> list[str]:
        """Prędkości maksymalne, energia i odstępy aut w klasie (4 przed, 4 za) oraz najszybsze auta innych klas –
        żeby AI mogło odpowiadać na porównania („różnica vmax aut przede mną”)."""
        me = s.player_scoring()
        if me is None:
            return []
        rv = self.rivals
        same = sorted([c for c in s.cars if c.car_class == me.car_class], key=lambda c: c.place)
        i = next((k for k, c in enumerate(same) if c.is_player), None)
        if i is None:
            return []
        rest = getattr(self, "rest", None)
        rows = []
        for k, c in enumerate(same[max(0, i - 4):i + 5], start=max(0, i - 4)):
            v, best = rv.top_speed(c.car_id)
            gap, laps = rv._gap(s, me, c) if not c.is_player else (0.0, 0)
            where = "TY" if c.is_player else (f"{k - i:+d} poz., odstęp {gap:+.1f} s" if gap is not None
                                              else f"{k - i:+d} poz., {laps:+d} okr.")
            ve = None
            if c.is_player and s.player is not None and s.player.virtual_energy is not None:
                ve = s.player.virtual_energy
            elif rest is not None:
                try:
                    ve = self.rival_pits._ve_now(rest, c)
                except Exception:
                    ve = None
            parts = [f"P{k + 1} {c.driver} [{c.vehicle}] ({where})"]
            if v:
                parts.append(f"vmax {v:.0f} km/h (najlepsza {best:.0f})")
            if ve is not None:
                parts.append(f"energia {ve * 100:.0f}%")
            if c.last_lap > 0:
                parts.append(f"ostatnie {fmt_time(c.last_lap)}")
            if c.in_pits:
                parts.append("w boksie")
            rows.append(", ".join(parts))
        out = ["AUTA W KLASIE (odstęp + = za Tobą, - = przed Tobą; vmax = prędkość maksymalna na ostatnim okrążeniu): "
               + " | ".join(rows)]
        others = {}
        for c in s.cars:
            if c.car_class == me.car_class:
                continue
            v = rv.top_speed(c.car_id)[0]
            if v and v > others.get(c.car_class, (0, None))[0]:
                others[c.car_class] = (v, c.driver)
        if others:
            out.append("NAJWYŻSZA VMAX W INNYCH KLASACH: " + ", ".join(f"{k} {v:.0f} km/h ({d})" for k, (v, d) in others.items()))
        try:
            eta = rv.faster_class_eta(s)[:3]
            if eta:
                out.append("SZYBSZA KLASA ZA TOBĄ (szacunek, kiedy dojedzie): " + ", ".join(
                    f"{c.car_class} {c.driver} za {t:.0f} s (teraz {b:.0f} s za Tobą na torze)" for c, t, b in eta))
        except Exception:
            pass
        return out

    def _more_sections(self, s: Snapshot) -> list[str]:
        """Dodatkowe dane dla AI, żeby odpowiadało też na pytania, których program nie przewidział:
        cała stawka, szczegóły okrążeń, postoje rywali, kary, flagi, uszkodzenia, prognoza."""
        out: list[str] = []
        me = s.player_scoring()
        try:   # kolega z zespołu w podobnych warunkach: gdzie szybszy i co robi inaczej
            if self.mate_deltas:
                from .analysis.teamlaps import first_name, mate_reasons
                m, mds, strict = self.mate_deltas
                nm = first_name(m.get("driver") or "")
                rows = [f"{d.corner.name} +{d.time_loss:.2f} s ({'; '.join(mate_reasons(d, nm, strict)) or '-'})"
                        for d in sorted(mds, key=lambda d: -d.time_loss) if d.time_loss >= 0.1][:6]
                if rows:
                    out.append(f"KOLEGA Z ZESPOŁU ({m.get('driver')}, okrążenie {m.get('lap_time')} s, "
                               f"{'podobne' if strict else 'trochę inne'} warunki) – gdzie jest szybszy od Twojego "
                               "ostatniego okrążenia: " + ", ".join(rows))
            if me is not None and self.corners:
                rc = []
                for c in s.cars:
                    if c.is_player or c.car_class != me.car_class:
                        continue
                    res = self.rival_corners.compare(me, c, self.corners)
                    if res and res[2]:
                        diffs = ", ".join(f"{n} {d:+.2f}" for n, d, _ in res[2] if abs(d) >= 0.05)
                        rc.append(f"{c.driver} (najl. {res[1]:.2f} s): {diffs or 'równo'}")
                if rc:
                    out.append("ZAKRĘTY RYWALI W KLASIE (różnica czasu przejazdu zakrętu względem Twojego najlepszego "
                               "okrążenia, + = rywal wolniejszy): " + " | ".join(rc[:12]))
        except Exception as e:
            print(f"[AI-dane] {e}")
        cars = sorted(s.cars, key=lambda c: c.place)
        if cars:
            def gap(c):
                if c.place == 1:
                    return "lider"
                if c.laps_behind_leader:
                    return f"+{c.laps_behind_leader} okr."
                return f"+{c.time_behind_leader:.1f} s" if c.time_behind_leader else ""
            rows = []
            for c in cars[:60]:
                r = f"P{c.place} {c.car_class} {c.driver}{' (TY)' if c.is_player else ''} [{c.vehicle}] {gap(c)}"
                if c.best_lap > 0:
                    r += f" najl {fmt_time(c.best_lap)}"
                if c.pit_stops:
                    r += f" post {c.pit_stops}"
                if c.in_pits:
                    r += " BOKS"
                if c.penalties:
                    r += f" kary {c.penalties}"
                rows.append(r)
            out.append("STAWKA (wszystkie auta, odstęp do lidera): " + "; ".join(rows))
        st_rows = []
        for cid, car in list(getattr(self.rival_pits, "cars", {}).items()):
            stops = getattr(car, "stops", None) or []
            if not stops:
                continue
            name = next((c.driver for c in s.cars if c.car_id == cid), "?")
            st_rows.append(name + ": " + ", ".join(
                f"okr {x.lap} stał {x.stationary:.0f} s" + (f", ~{x.tyres} opony" if x.tyres else "") for x in stops[-3:]))
        if st_rows:
            out.append("POSTOJE RYWALI (ostatnie): " + " | ".join(st_rows[:20]))
        if self.laps:
            rows = []
            self._last_drv_tmp = None
            for l in self.laps[-10:]:
                r = f"{l.lap}: {fmt_time(l.lap_time)}"
                if l.fuel_used > 0:
                    r += f", paliwo {l.fuel_used:.2f} l"
                if l.ve_used:
                    r += f", energia {l.ve_used * 100:.1f}%"
                if l.wear_tyres:
                    r += ", zużycie opon " + "/".join(f"{w * 100:.0f}" for w in l.wear_tyres) + "%"
                flags = [x for x, on in (("boks", l.pit), ("FCY", l.fcy), ("nieważne", not l.valid),
                                         (f"poza torem x{l.off_tracks}", l.off_tracks), ("uderzenie", l.impact)) if on]
                if flags:
                    r += " (" + ", ".join(flags) + ")"
                if l.driver and l.driver != getattr(self, "_last_drv_tmp", None):
                    r += f" [{l.driver}]"
                self._last_drv_tmp = l.driver
                rows.append(r)
            out.append("OKRĄŻENIA SZCZEGÓŁOWO (ostatnie 10; zużycie opon LP/PP/LT/PT): " + "; ".join(rows))
        if me is not None:
            pen = [f"kary {me.penalties}"] if me.penalties else []
            if s.tl_steps_per_penalty:
                pen.append(f"limity toru: kara co {s.tl_steps_per_penalty} kroków")
            ys = [str(i + 1) for i, y in enumerate(s.sector_yellow) if y]
            if ys:
                pen.append("żółta flaga w sektorze " + ", ".join(ys))
            pen.append(f"faza wyścigu {s.phase}")
            out.append("FLAGI I KARY: " + ", ".join(pen))
        try:
            from .analysis.damage_now import describe as dmg_describe
            d = dmg_describe(s, getattr(self, "rest", None))
            out.append("USZKODZENIA TERAZ: " + ("; ".join(d) if d else "brak"))
        except Exception:
            pass
        r = getattr(self, "rest", None)
        if r is not None and getattr(r, "ok", False):
            try:
                if r.brakes:
                    out.append("HAMULCE (zostało): " + "/".join(f"{b * 100:.0f}%" for b in r.brakes))
                fc = r.forecast_text()
                if fc:
                    out.append("PROGNOZA POGODY (z gry): " + fc)
            except Exception:
                pass
        return out

    def summary(self, setup: bool = False, question: str = "") -> str:
        """Tekstowy stan wyścigu dla modelu AI. Wszystkie liczby policzone tutaj."""
        s = self.snap
        if s is None:
            return "Brak danych z gry."
        out = []
        sess = SESSION_NAMES.get(s.session, s.session)
        rem = f"pozostało {fmt_clock(s.time_remaining)}" if s.time_remaining is not None else (
            f"limit {s.max_laps} okr." if s.max_laps else "")
        out.append(f"SESJA: {sess}, tor {s.track} ({s.track_length:.0f} m), auto {s.car_name}, {rem}, "
                   f"faza {s.phase}, powietrze {s.air_temp:.0f}°C, tor {s.track_temp:.0f}°C, "
                   f"deszcz {s.rain * 100:.0f}%, wilgotność toru {s.wetness * 100:.0f}%")

        ps = s.player_scoring()
        if ps:
            cp, cn = self.rivals.class_position(s)
            clean = [l for l in self.laps if l.clean]
            recent = clean[-3:]
            avg = sum(l.lap_time for l in recent) / len(recent) if recent else None
            line = (f"KIEROWCA: P{cp}/{cn} w klasie {ps.car_class} (P{ps.place} ogólnie), ukończone okr. {ps.laps_done}, "
                    f"ostatnie {fmt_time(ps.last_lap)}, najlepsze {fmt_time(ps.best_lap)}")
            if avg:
                line += f", średnia z {len(recent)} czystych okr. {fmt_time(avg)}"
            if clean:
                consistency = max(l.lap_time for l in recent) - min(l.lap_time for l in recent)
                line += f", rozrzut ostatnich czasów {consistency:.2f} s"
            out.append(line)
            tb = theoretical_best(self.laps, self.corners)
            if tb:
                out.append(f"OKRĄŻENIE TEORETYCZNE (suma najlepszych odcinków): {fmt_time(tb)}")

        fr = fuel_report(s, self.laps, self.fuel_margin_laps)
        if fr:
            out.append("PALIWO/ENERGIA: " + fr.describe())

        p = s.player
        if p:
            names = ["LP", "PP", "LT", "PT"]
            tyres = []
            for n, t in zip(names, p.tyres):
                tyres.append(f"{n} {t.temp_c[0]:.0f}/{t.temp_c[1]:.0f}/{t.temp_c[2]:.0f}°C "
                             f"{t.pressure_kpa:.0f} kPa zużycie {t.wear * 100:.0f}% hamulec {t.brake_c:.0f}°C")
            opt = p.tyres[0].optimal_c if p.tyres else 0
            out.append(f"OPONY ({p.compound_front}/{p.compound_rear}, optimum ok. {opt:.0f}°C, "
                       f"temperatury bieżnika lewa/środek/prawa strona): " + "; ".join(tyres))
            out.append(f"USTAWIENIA W AUCIE: TC {p.tc}, ABS {p.abs}, balans hamulców {(1 - p.rear_brake_bias) * 100:.1f}% przód")

        if self.last_deltas:
            ranked = [d for d in sorted(self.last_deltas, key=lambda d: -d.time_loss) if abs(d.time_loss) >= 0.03]
            if not ranked:
                ranked = sorted(self.last_deltas, key=lambda d: -d.time_loss)[:1]
            out.append(f"ZAKRĘTY (ostatnie okrążenie vs {self.ref_source}): " + "; ".join(d.describe() for d in ranked))
        elif self.ref is None:
            out.append("ZAKRĘTY: brak okrążenia referencyjnego (potrzebne jedno czyste okrążenie)")

        if s.session == "race":
            rv = self.rivals.rivals(s)
            if rv:
                out.append("RYWALE W KLASIE: " + " | ".join(r.describe(fmt_time) for r in rv))
            fast = self.rivals.faster_class_behind(s)
            if fast:
                out.append("SZYBSZA KLASA Z TYŁU: " + ", ".join(
                    f"{c.driver} ({c.car_class}) dojedzie za ok. {eta:.0f} s" for c, eta in fast))
        else:
            best = self.rivals.class_best_laps(s)
            if best:
                out.append("NAJLEPSZE CZASY W KLASIE: " + ", ".join(
                    f"{c.driver} {fmt_time(c.best_lap)}" for c in best))

        try:
            out += self._speed_energy_section(s)
        except Exception:
            pass
        try:
            out += self._more_sections(s)
        except Exception:
            pass
        try:
            ps0 = s.player_scoring()
            out.append(f"STINT: okrążeń w tym stincie {len(self._stint_laps())}, postojów {ps0.pit_stops if ps0 else 0}, "
                       f"ukończone okrążenia w wyścigu {ps0.laps_done if ps0 else 0}")
        except Exception:
            pass
        if self.laps:
            hist = [f"{l.lap}: {fmt_time(l.lap_time)}{'' if l.clean else ' (nieczyste)'}" for l in self.laps[-6:]]
            out.append("OSTATNIE OKRĄŻENIA: " + ", ".join(hist))
        if s.session == "race":
            plan = self.plan()
            if plan:
                out.append("STRATEGIA (policzona przez program): " + plan.describe().replace("\n", " | "))
        if self.fatigue.last is not None:
            out.append("ZMĘCZENIE KIEROWCY: " + self.fatigue.last.describe())
        if self.weather.last is not None:
            out.append("POGODA I TOR: " + self.weather.describe())
        if self.engine.water > 0:
            out.append("SILNIK: " + self.engine.report().text)
        if self.targets:
            out.append("PLAN ZESPOŁU (arkusz): " + ", ".join(f"{k} {v}" for k, v in self.targets.items()))
        if setup and self.snap is not None:
            out += self._setup_section(question)
        return "\n".join(out)
