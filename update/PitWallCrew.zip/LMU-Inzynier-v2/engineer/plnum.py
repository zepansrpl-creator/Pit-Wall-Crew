"""Liczby po polsku do odczytu głosem: odmiana liczebników i rzeczowników.

Syntezator mowy źle odmienia cyfry („za 2 sekundy” czyta „za dwa sekundy”), dlatego zanim tekst trafi
do syntezy, wszystkie liczby zamieniamy tu na słowa w poprawnym rodzaju i przypadku.

Główne funkcje:
- qty(2, "sekunda")            -> "dwie sekundy"
- qty(5, "sekunda", "gen")     -> "pięciu sekund"
- qty(1.5, "litr")             -> "półtora litra"
- ordinal(3, "n", "loc")       -> "trzecim"
- speak("za 2 sekundy, P3, T5") -> "za dwie sekundy, P trzy, te pięć"
"""

from __future__ import annotations

import re

CASES = ("nom", "gen", "dat", "acc", "inst", "loc")

# ------------------------------------------------------------------ rzeczowniki (sg 6 przypadków, pl 6 przypadków)
_N: dict[str, tuple[str, tuple[str, ...], tuple[str, ...]]] = {
    "sekunda": ("f", ("sekunda", "sekundy", "sekundzie", "sekundę", "sekundą", "sekundzie"),
                ("sekundy", "sekund", "sekundom", "sekundy", "sekundami", "sekundach")),
    "minuta": ("f", ("minuta", "minuty", "minucie", "minutę", "minutą", "minucie"),
               ("minuty", "minut", "minutom", "minuty", "minutami", "minutach")),
    "godzina": ("f", ("godzina", "godziny", "godzinie", "godzinę", "godziną", "godzinie"),
                ("godziny", "godzin", "godzinom", "godziny", "godzinami", "godzinach")),
    "opona": ("f", ("opona", "opony", "oponie", "oponę", "oponą", "oponie"),
              ("opony", "opon", "oponom", "opony", "oponami", "oponach")),
    "litr": ("m", ("litr", "litra", "litrowi", "litr", "litrem", "litrze"),
             ("litry", "litrów", "litrom", "litry", "litrami", "litrach")),
    "metr": ("m", ("metr", "metra", "metrowi", "metr", "metrem", "metrze"),
             ("metry", "metrów", "metrom", "metry", "metrami", "metrach")),
    "kilometr": ("m", ("kilometr", "kilometra", "kilometrowi", "kilometr", "kilometrem", "kilometrze"),
                 ("kilometry", "kilometrów", "kilometrom", "kilometry", "kilometrami", "kilometrach")),
    "procent": ("m", ("procent", "procentu", "procentowi", "procent", "procentem", "procencie"),
                ("procent", "procent", "procentom", "procent", "procentami", "procentach")),
    "stopień": ("m", ("stopień", "stopnia", "stopniowi", "stopień", "stopniem", "stopniu"),
                ("stopnie", "stopni", "stopniom", "stopnie", "stopniami", "stopniach")),
    "punkt": ("m", ("punkt", "punktu", "punktowi", "punkt", "punktem", "punkcie"),
              ("punkty", "punktów", "punktom", "punkty", "punktami", "punktach")),
    "postój": ("m", ("postój", "postoju", "postojowi", "postój", "postojem", "postoju"),
               ("postoje", "postojów", "postojom", "postoje", "postojami", "postojach")),
    "klik": ("m", ("klik", "kliku", "klikowi", "klik", "klikiem", "kliku"),
             ("kliki", "klików", "klikom", "kliki", "klikami", "klikach")),
    "zakręt": ("m", ("zakręt", "zakrętu", "zakrętowi", "zakręt", "zakrętem", "zakręcie"),
               ("zakręty", "zakrętów", "zakrętom", "zakręty", "zakrętami", "zakrętach")),
    "stint": ("m", ("stint", "stintu", "stintowi", "stint", "stintem", "stincie"),
              ("stinty", "stintów", "stintom", "stinty", "stintami", "stintach")),
    "okrążenie": ("n", ("okrążenie", "okrążenia", "okrążeniu", "okrążenie", "okrążeniem", "okrążeniu"),
                  ("okrążenia", "okrążeń", "okrążeniom", "okrążenia", "okrążeniami", "okrążeniach")),
    "miejsce": ("n", ("miejsce", "miejsca", "miejscu", "miejsce", "miejscem", "miejscu"),
                ("miejsca", "miejsc", "miejscom", "miejsca", "miejscami", "miejscach")),
    "auto": ("n", ("auto", "auta", "autu", "auto", "autem", "aucie"),
             ("auta", "aut", "autom", "auta", "autami", "autach")),
}

# forma rzeczownika -> [(lemat, przypadek, liczba)]
_FORMS: dict[str, list[tuple[str, str, str]]] = {}
for _lem, (_g, _sg, _pl) in _N.items():
    for _c, _f in zip(CASES, _sg):
        _FORMS.setdefault(_f, []).append((_lem, _c, "sg"))
    for _c, _f in zip(CASES, _pl):
        _FORMS.setdefault(_f, []).append((_lem, _c, "pl"))

# skróty jednostek w tekście
_UNITS = {"s": "sekunda", "sek": "sekunda", "l": "litr", "min": "minuta", "km": "kilometr", "m": "metr",
          "°C": "stopień", "°": "stopień", "%": "procent", "h": "godzina"}

# ------------------------------------------------------------------ liczebniki główne
_ONES = {
    # nom, gen, dat, inst, loc   (acc = nom, z wyjątkami dla 1 i 2 w rodzaju żeńskim)
    0: ("zero", "zero", "zero", "zero", "zero"),
    3: ("trzy", "trzech", "trzem", "trzema", "trzech"),
    4: ("cztery", "czterech", "czterem", "czterema", "czterech"),
    5: ("pięć", "pięciu", "pięciu", "pięcioma", "pięciu"),
    6: ("sześć", "sześciu", "sześciu", "sześcioma", "sześciu"),
    7: ("siedem", "siedmiu", "siedmiu", "siedmioma", "siedmiu"),
    8: ("osiem", "ośmiu", "ośmiu", "ośmioma", "ośmiu"),
    9: ("dziewięć", "dziewięciu", "dziewięciu", "dziewięcioma", "dziewięciu"),
    10: ("dziesięć", "dziesięciu", "dziesięciu", "dziesięcioma", "dziesięciu"),
    11: ("jedenaście", "jedenastu", "jedenastu", "jedenastoma", "jedenastu"),
    12: ("dwanaście", "dwunastu", "dwunastu", "dwunastoma", "dwunastu"),
    13: ("trzynaście", "trzynastu", "trzynastu", "trzynastoma", "trzynastu"),
    14: ("czternaście", "czternastu", "czternastu", "czternastoma", "czternastu"),
    15: ("piętnaście", "piętnastu", "piętnastu", "piętnastoma", "piętnastu"),
    16: ("szesnaście", "szesnastu", "szesnastu", "szesnastoma", "szesnastu"),
    17: ("siedemnaście", "siedemnastu", "siedemnastu", "siedemnastoma", "siedemnastu"),
    18: ("osiemnaście", "osiemnastu", "osiemnastu", "osiemnastoma", "osiemnastu"),
    19: ("dziewiętnaście", "dziewiętnastu", "dziewiętnastu", "dziewiętnastoma", "dziewiętnastu"),
}
_TENS = {
    20: ("dwadzieścia", "dwudziestu", "dwudziestu", "dwudziestoma", "dwudziestu"),
    30: ("trzydzieści", "trzydziestu", "trzydziestu", "trzydziestoma", "trzydziestu"),
    40: ("czterdzieści", "czterdziestu", "czterdziestu", "czterdziestoma", "czterdziestu"),
    50: ("pięćdziesiąt", "pięćdziesięciu", "pięćdziesięciu", "pięćdziesięcioma", "pięćdziesięciu"),
    60: ("sześćdziesiąt", "sześćdziesięciu", "sześćdziesięciu", "sześćdziesięcioma", "sześćdziesięciu"),
    70: ("siedemdziesiąt", "siedemdziesięciu", "siedemdziesięciu", "siedemdziesięcioma", "siedemdziesięciu"),
    80: ("osiemdziesiąt", "osiemdziesięciu", "osiemdziesięciu", "osiemdziesięcioma", "osiemdziesięciu"),
    90: ("dziewięćdziesiąt", "dziewięćdziesięciu", "dziewięćdziesięciu", "dziewięćdziesięcioma",
         "dziewięćdziesięciu"),
}
_HUND = {
    100: ("sto", "stu", "stu", "stoma", "stu"),
    200: ("dwieście", "dwustu", "dwustu", "dwustoma", "dwustu"),
    300: ("trzysta", "trzystu", "trzystu", "trzystoma", "trzystu"),
    400: ("czterysta", "czterystu", "czterystu", "czterystoma", "czterystu"),
    500: ("pięćset", "pięciuset", "pięciuset", "pięciuset", "pięciuset"),
    600: ("sześćset", "sześciuset", "sześciuset", "sześciuset", "sześciuset"),
    700: ("siedemset", "siedmiuset", "siedmiuset", "siedmiuset", "siedmiuset"),
    800: ("osiemset", "ośmiuset", "ośmiuset", "ośmiuset", "ośmiuset"),
    900: ("dziewięćset", "dziewięciuset", "dziewięciuset", "dziewięciuset", "dziewięciuset"),
}
_CI = {"nom": 0, "gen": 1, "dat": 2, "acc": 0, "inst": 3, "loc": 4}

_ONE = {
    "m": {"nom": "jeden", "gen": "jednego", "dat": "jednemu", "acc": "jeden", "inst": "jednym", "loc": "jednym"},
    "f": {"nom": "jedna", "gen": "jednej", "dat": "jednej", "acc": "jedną", "inst": "jedną", "loc": "jednej"},
    "n": {"nom": "jedno", "gen": "jednego", "dat": "jednemu", "acc": "jedno", "inst": "jednym", "loc": "jednym"},
}


def _two(g: str, case: str) -> str:
    if case in ("nom", "acc"):
        return "dwie" if g == "f" else "dwa"
    if case == "inst":
        return "dwiema" if g == "f" else "dwoma"
    return {"gen": "dwóch", "dat": "dwóm", "loc": "dwóch"}[case]


def _below_1000(n: int, g: str, case: str, final: bool = True) -> list[str]:
    out: list[str] = []
    h, rest = divmod(n, 100)
    if h:
        out.append(_HUND[h * 100][_CI[case]])
    if rest == 0:
        return out
    if rest < 20:
        t, u = 0, rest
    else:
        t, u = divmod(rest, 10)
        out.append(_TENS[t * 10][_CI[case]])
    if u == 0 and t:
        return out
    if u == 1:
        # samodzielne 1 odmienia się; w złożonych („dwadzieścia jeden”) zostaje „jeden”
        out.append(_ONE[g][case] if (not out) else "jeden")
    elif u == 2:
        out.append(_two(g, case))
    else:
        out.append(_ONES[u][_CI[case]])
    return out


def cardinal(n: int, gender: str = "m", case: str = "nom") -> str:
    """Liczebnik główny słownie (0..999 999)."""
    n = int(n)
    if n < 0:
        return "minus " + cardinal(-n, gender, case)
    if n == 0:
        return "zero"
    th, rest = divmod(n, 1000)
    parts: list[str] = []
    if th:
        if th == 1:
            parts.append({"nom": "tysiąc", "acc": "tysiąc", "gen": "tysiąca", "dat": "tysiącowi",
                          "inst": "tysiącem", "loc": "tysiącu"}[case])
        else:
            parts += _below_1000(th, "m", case)
            word = _plural_form(th, ("tysiąc", "tysiąca", "tysiącowi", "tysiąc", "tysiącem", "tysiącu"),
                                ("tysiące", "tysięcy", "tysiącom", "tysiące", "tysiącami", "tysiącach"), case)
            parts.append(word)
    if rest:
        parts += _below_1000(rest, gender, case)
    return " ".join(parts)


def _plural_form(n: int, sg: tuple[str, ...], pl: tuple[str, ...], case: str) -> str:
    """Forma rzeczownika po liczebniku całkowitym n."""
    ci = CASES.index(case)
    if n == 1:
        return sg[ci]
    if case in ("nom", "acc"):
        if n % 10 in (2, 3, 4) and n % 100 not in (12, 13, 14):
            return pl[0]
        return pl[1]  # pięć sekund, dwadzieścia jeden sekund
    return pl[ci]


def plural(n: int, one: str, few: str, many: str) -> str:
    """Forma rzeczownika spoza słownika: plural(2, 'błąd', 'błędy', 'błędów') -> 'błędy'."""
    n = abs(int(n))
    if n == 1:
        return one
    if n % 10 in (2, 3, 4) and n % 100 not in (12, 13, 14):
        return few
    return many


def noun(lemma: str, n: int, case: str = "nom") -> str:
    g, sg, pl = _N[lemma]
    return _plural_form(int(n), sg, pl, case)


# ------------------------------------------------------------------ ułamki
_TENTH_NOM = {1: "jedna dziesiąta", 2: "dwie dziesiąte", 3: "trzy dziesiąte", 4: "cztery dziesiąte"}


def _fraction(digits: str, case: str) -> str:
    """'3' -> 'trzy dziesiąte', '25' -> 'dwadzieścia pięć setnych'."""
    k = int(digits)
    unit_nom = {1: ("dziesiąta", "dziesiąte", "dziesiątych"), 2: ("setna", "setne", "setnych"),
                3: ("tysięczna", "tysięczne", "tysięcznych")}[len(digits)]
    if case in ("nom", "acc"):
        word = cardinal(k, "f", "nom") if k != 1 else ("jedna" if case == "nom" else "jedną")
        if k == 1:
            form = unit_nom[0] if case == "nom" else unit_nom[0][:-1] + "ą"
        elif k % 10 in (2, 3, 4) and k % 100 not in (12, 13, 14):
            form = unit_nom[1]
        else:
            form = unit_nom[2]
        return f"{word} {form}"
    # pozostałe przypadki: dopełniacz wystarcza w praktyce („około dwóch dziesiątych”)
    word = cardinal(k, "f", "gen")
    form = unit_nom[0][:-1] + "ej" if k == 1 else unit_nom[2]
    return f"{word} {form}"


def number(x: float, gender: str = "m", case: str = "nom", decimals: int = 1) -> str:
    """Liczba (także z ułamkiem) słownie, bez rzeczownika."""
    neg = x < 0
    x = abs(x)
    s = f"{x:.{decimals}f}" if decimals > 0 else str(int(round(x)))
    if "." in s:
        ip, fp = s.split(".")
        fp = fp.rstrip("0")
    else:
        ip, fp = s, ""
    i = int(ip)
    pre = "minus " if neg else ""
    if not fp:
        return pre + cardinal(i, gender, case)
    if fp == "5" and i == 0:
        return pre + "pół"
    if fp == "5" and i == 1:
        return pre + ("półtorej" if gender == "f" else "półtora")
    if fp == "5":
        return pre + f"{cardinal(i, gender, case)} i pół"
    if i == 0:
        return pre + _fraction(fp, case)
    return pre + f"{cardinal(i, gender, case)} i {_fraction(fp, case)}"


def _frac_noun(lemma: str) -> str:
    return "procent" if lemma == "procent" else _N[lemma][1][1]


def qty(x: float, lemma: str, case: str = "nom", decimals: int = 1) -> str:
    """Liczba z rzeczownikiem w poprawnej formie: qty(2, 'sekunda') -> 'dwie sekundy'."""
    g, sg, pl = _N[lemma]
    xr = round(abs(x), decimals) if decimals > 0 else round(abs(x))
    if decimals > 0 and abs(xr - round(xr)) > 1e-9:
        # liczba z ułamkiem: rzeczownik w dopełniaczu liczby pojedynczej („dwie i pół sekundy”)
        return f"{number(x, g, case, decimals)} {_frac_noun(lemma)}"
    n = int(round(xr))
    pre = "minus " if x < 0 and n else ""
    return f"{pre}{cardinal(n, g, case)} {_plural_form(n, sg, pl, case)}"


# ------------------------------------------------------------------ liczebniki porządkowe
_ORD_STEM = {
    1: "pierwsz", 2: "drug", 3: "trzec", 4: "czwart", 5: "piąt", 6: "szóst", 7: "siódm", 8: "ósm",
    9: "dziewiąt", 10: "dziesiąt", 11: "jedenast", 12: "dwunast", 13: "trzynast", 14: "czternast",
    15: "piętnast", 16: "szesnast", 17: "siedemnast", 18: "osiemnast", 19: "dziewiętnast",
    20: "dwudziest", 30: "trzydziest", 40: "czterdziest", 50: "pięćdziesiąt", 60: "sześćdziesiąt",
    70: "siedemdziesiąt", 80: "osiemdziesiąt", 90: "dziewięćdziesiąt", 100: "setn",
}
_ORD_END = {
    "m": {"nom": "y", "gen": "ego", "dat": "emu", "acc": "y", "inst": "ym", "loc": "ym"},
    "f": {"nom": "a", "gen": "ej", "dat": "ej", "acc": "ą", "inst": "ą", "loc": "ej"},
    "n": {"nom": "e", "gen": "ego", "dat": "emu", "acc": "e", "inst": "ym", "loc": "ym"},
}


def _ord_word(stem: str, g: str, case: str) -> str:
    e = _ORD_END[g][case]
    if stem in ("drug",):  # drugi, druga, drugie, drugiego
        if e.startswith("y"):
            e = "i" + e[1:]
        elif e.startswith("e"):
            e = "i" + e
        return stem + e
    if stem == "trzec":  # trzeci, trzecia, trzecie, trzeciego, trzecią
        if e.startswith("y"):
            return stem + "i" + e[1:]
        return stem + "i" + e
    return stem + e


def ordinal(n: int, gender: str = "m", case: str = "nom") -> str:
    """Liczebnik porządkowy: ordinal(3, 'n', 'loc') -> 'trzecim'."""
    n = int(n)
    if n <= 0:
        return cardinal(n, gender, case)
    words = []
    h, rest = divmod(n, 100)
    if h == 1 and rest == 0:
        return _ord_word("setn", gender, case)
    if h:
        words.append(_HUND[h * 100][0])  # „sto pierwszy” – setki w mianowniku
    if rest:
        if rest < 20 or rest % 10 == 0:
            words.append(_ord_word(_ORD_STEM[rest], gender, case))
        else:
            t, u = divmod(rest, 10)
            words.append(_ord_word(_ORD_STEM[t * 10], gender, case))
            words.append(_ord_word(_ORD_STEM[u], gender, case))
    return " ".join(words)


# ------------------------------------------------------------------ czasy
def lap_time(s: float) -> str:
    """104.5 -> 'minuta czterdzieści cztery i pięć dziesiątych' (styl radiowy: 'jeden czterdzieści cztery')."""
    if not s or s <= 0:
        return "brak czasu"
    s = round(s, 1)
    m, sec = divmod(s, 60)
    whole = int(sec)
    tenth = int(round((sec - whole) * 10)) % 10
    secs = cardinal(whole, "f") if whole else "zero"
    if whole < 10 and m:
        secs = "zero " + secs
    tail = f" i {_fraction(str(tenth), 'nom')}" if tenth else ""
    if tenth == 5:
        tail = " i pół"
    if m:
        return f"{cardinal(int(m), 'm')} {secs}{tail}"
    return f"{secs}{tail} {noun('sekunda', 2 if whole else 5)}"


def duration(s: float, case: str = "nom") -> str:
    """Czas trwania: 95 -> 'minuta trzydzieści pięć sekund'; 3700 -> 'godzina i jedna minuta'."""
    s = int(round(s))
    h, rem = divmod(s, 3600)
    m, sec = divmod(rem, 60)
    parts = []
    if h:
        parts.append("godzina" if (h == 1 and case == "nom") else qty(h, "godzina", case, 0))
    if m:
        parts.append(qty(m, "minuta", case, 0) if not (m == 1 and case == "nom" and not h) else "minuta")
    if sec and not h:
        parts.append(qty(sec, "sekunda", case, 0))
    if not parts:
        return qty(0, "sekunda", case, 0)
    return " i ".join(parts) if len(parts) == 2 and h else " ".join(parts)


def clock(hh: int, mm: int, case: str = "nom") -> str:
    """Godzina zegarowa: (14, 5) -> 'czternasta zero pięć'; case='loc' -> 'czternastej zero pięć'."""
    h = ordinal(hh, "f", case) if hh else "zero"
    if mm == 0:
        return h
    return f"{h} {('zero ' + cardinal(mm, 'f')) if mm < 10 else cardinal(mm, 'f')}"


# ------------------------------------------------------------------ odczyt dowolnego tekstu
_GEN_PREPS = {"brakuje", "brak", "zabraknie", "około", "do", "od", "z", "ze", "bez", "dla", "u", "zamiast", "sprzed", "podczas", "koło", "spod",
              "powyżej", "poniżej", "wokół", "obok", "wśród", "spośród", "według", "zza", "ciągu"}
_LOC_PREPS = {"po", "przy", "w", "we", "na", "o"}
_NUM = r"\d+(?:[.,]\d+)?"


def _num_val(s: str) -> tuple[int, str]:
    s = s.replace(",", ".")
    if "." in s:
        a, b = s.split(".")
        return int(a), b
    return int(s), ""


def _read_number_noun(num: str, word: str, prev: str) -> str | None:
    cands = _FORMS.get(word.lower())
    if not cands:
        return None
    lemma = cands[0][0]
    g = _N[lemma][0]
    i, frac = _num_val(num)
    frac = frac.rstrip("0")
    if frac:
        case = "gen" if prev in _GEN_PREPS else "nom"
        return f"{number(float(f'{i}.{frac}'), g, case, len(frac))} {_frac_noun(lemma)}"
    forms = {(c, nb) for lem, c, nb in cands if lem == lemma}
    # dobór przypadku liczebnika na podstawie formy rzeczownika i przyimka
    if i == 1:
        order = CASES
        if prev in _LOC_PREPS:
            order = ("loc", "acc", "nom", "gen", "inst", "dat")
        elif prev in _GEN_PREPS:
            order = ("gen", "nom", "acc", "loc", "inst", "dat")
        elif prev in ("za", "przez"):
            order = ("acc", "nom", "inst", "gen", "loc", "dat")
        case = next((c for c in order if (c, "sg") in forms), "nom")
        return f"{cardinal(1, g, case)} {_N[lemma][1][CASES.index(case)]}"
    few = i % 10 in (2, 3, 4) and i % 100 not in (12, 13, 14)
    pl_cases = {c for c, nb in forms if nb == "pl"}
    oblique = pl_cases and pl_cases <= {"loc", "inst", "dat"}
    if oblique:
        # forma rzeczownika sama mówi, jaki to przypadek („w ostatnich 5 okrążeniach”)
        case = "loc" if "loc" in pl_cases else ("inst" if "inst" in pl_cases else "dat")
    elif prev in _GEN_PREPS:
        case = "gen"
    elif ("inst", "pl") in forms:
        case = "inst"
    elif ("loc", "pl") in forms and prev in _LOC_PREPS:
        case = "loc"
    elif ("dat", "pl") in forms:
        case = "dat"
    # „524 stopni”, „4 okrążeń” bez przyimka to błąd w tekście (częsty u AI) – czytamy poprawnie w mianowniku:
    # „pięćset dwadzieścia cztery stopnie”, a nie „pięciuset dwudziestu czterech stopni”
    else:
        case = "acc" if prev in ("za", "o", "na", "przez", "w") else "nom"
    return f"{cardinal(i, g, case)} {_plural_form(i, _N[lemma][1], _N[lemma][2], case)}"


def genitive_name(name: str) -> str:
    """Imię w dopełniaczu do „wiadomość od …”: Patryk→Patryka, Maciej→Macieja, Ania→Ani, zespół→zespołu."""
    n = (name or "").strip()
    if not n:
        return "zespołu"
    if n.lower() in ("zespół", "zespol"):
        return "zespołu"
    parts = n.split()
    first = parts[0]
    low = first.lower()
    if low.endswith(("ia", "ja")):
        first = first[:-2] + "i"          # Ania→Ani, Maja→Mai
    elif low.endswith(("ka", "ga")):
        first = first[:-1] + "i"
    elif low.endswith("a"):
        first = first[:-1] + "y"
    elif low.endswith("ek") and len(low) > 3:
        first = first[:-2] + "ka"        # Marek→Marka, Jacek→Jacka
    elif low[-1:].isalpha() and low[-1] not in "aeiouyąęó":
        first = first + "a"
    return " ".join([first] + parts[1:])


SPLIT_SPELLING = "split"     # zapis dla syntezatora, wybrany odsłuchem (tools/test_split.py)


def speak(text: str) -> str:
    """Zamienia wszystkie liczby w tekście na poprawnie odmienione słowa."""
    t = text.replace("\u2011", "-").replace("\u2010", "-").replace("\u00a0", " ").replace("\u202f", " ")
    # zakres „7,6-7,8” / „11–12” -> „7,6 do 7,8”
    t = re.sub(rf"({_NUM})\s?[-–—]\s?({_NUM})", r"\1 do \2", t)
    # skróty, które syntezator czyta źle
    for a, b in ((r"\bok\.\s", "około "), (r"\bokr\.", "okrążenia"), (r"\bnp\.", "na przykład"),
                 (r"\bmin\.(?=\s+\d)", "minimum"), (r"\bmaks\.", "maksymalnie"), (r"\bmax\.", "maksymalnie"),
                 (r"\bpit[- ]?stop", "postój"), (r"\bpit\b", "zjazd"), (r"\s*\(([^()]{1,40})\)", r", \1,"),
                 (r"\bPT\b", "prawa tylna"), (r"\bLT\b", "lewa tylna"), (r"\bLP\b", "lewa przednia"),
                 (r"\bPP\b", "prawa przednia"), (r"\bVE\b", "energia"), (r"\bFCY\b", "ef si łaj"),
                 (r"\bgaz\.", "gaz!"),          # „gaz.” głos czyta jak skrót „gazowa”
                 # rozkład hamowania przód/tył: kierowca chce słyszeć „podział hamulców”
                 (r"\b([BbSs])(?:alans|plit|ias)(u|em|ie)?(?=\s+hamulc)",
                  lambda m: ("P" if m.group(1).isupper() else "p") + "odział" + {"u": "u", "em": "em", "ie": "e"}.get(m.group(2) or "", "")),
                 (r"\b([Bb])rake bias\b", lambda m: ("P" if m.group(1) == "B" else "p") + "odział hamulców"),
                 (r"\b([Ss])plit", lambda m: m.group(1) + SPLIT_SPELLING[1:])):  # głos czytał „splyt”
        t = re.sub(a, b, t)
    t = re.sub(r",\s*([.,;:])", r"\1", t)
    # wymowa nazw: syntezator czyta „hypercar” po angielsku-dziwnie – po polsku „hajperkar”
    t = re.sub(r"\b([Hh])ypercar(\w*)", lambda m: ("H" if m.group(1) == "H" else "h") + "ajperkar" + m.group(2), t)
    t = re.sub(r"\b([Hh])iperkar(\w*)", lambda m: ("H" if m.group(1) == "H" else "h") + "ajperkar" + m.group(2), t)
    # jednostki skrócone -> pełne słowa w odpowiedniej formie
    def unit_sub(m: re.Match) -> str:
        num, u = m.group(1), m.group(2)
        lemma = _UNITS[u]
        i, frac = _num_val(num)
        if frac.rstrip("0"):
            return f"{num} {_frac_noun(lemma)}"
        return f"{num} {noun(lemma, i)}"
    t = re.sub(rf"({_NUM})\s?km/h", lambda m: f"{m.group(1)} {noun('kilometr', _num_val(m.group(1))[0]) if not _num_val(m.group(1))[1].rstrip('0') else 'kilometra'} na godzinę", t)
    t = re.sub(rf"({_NUM})\s?(°C|°|%)", unit_sub, t)
    t = re.sub(rf"({_NUM})\s?(s|sek|l|min|km|h|m)\b(?!\w)", unit_sub, t)
    # liczebnik porządkowy: „1. w klasie”, „5. miejsce”
    t = re.sub(r"\b(\d{1,3})\.(?=\s+[a-ząćęłńóśźż])", lambda m: ordinal(int(m.group(1))), t)
    # nazwy klas i aut: GT3 -> GT trzy, LMP2 -> LMP dwa
    t = re.sub(r"\b([A-Z]{2,})(\d)\b", lambda m: f"{m.group(1)} {cardinal(int(m.group(2)))}", t)
    # czasy okrążeń 1:44.512 / 1:44,5
    t = re.sub(r"\b(\d):(\d{2})[.,](\d+)\b", lambda m: lap_time(int(m.group(1)) * 60 + float(f"{m.group(2)}.{m.group(3)}")), t)
    # godziny 14:05
    def clock_sub(m: re.Match) -> str:
        prev = (m.group(1) or "").strip().lower()
        case = "loc" if prev == "o" else ("gen" if prev in ("do", "od", "około", "koło") else "nom")
        return (m.group(1) or "") + clock(int(m.group(2)), int(m.group(3)), case)
    t = re.sub(r"(\b\w+\s)?\b([01]?\d|2[0-3]):([0-5]\d)\b", clock_sub, t)
    # oznaczenia zakrętów i pozycji
    t = re.sub(r"\bT(\d{1,2})\b", lambda m: "te " + cardinal(int(m.group(1))), t)
    t = re.sub(r"\bP(\d{1,2})\b", lambda m: "P " + cardinal(int(m.group(1))), t)
    t = re.sub(r"\+(\d)", r"plus \1", t)
    t = re.sub(r"(?<![\w])-(\d)", r"minus \1", t)

    # liczba + rzeczownik
    def _prev(m: re.Match) -> str:
        """Słowo tuż przed liczbą (z tekstu przed dopasowaniem – nie „zjada” go poprzednie dopasowanie)."""
        w = re.findall(r"(\w+)\s*$", m.string[:m.start()])
        return w[0].lower() if w else ""

    def num_noun(m: re.Match) -> str:
        out = _read_number_noun(m.group(1), m.group(2), _prev(m))
        return m.group(0) if out is None else out
    t = re.sub(rf"(?<![\w.,])({_NUM})\s(\w+)", num_noun, t)

    # pozostałe liczby: mianownik (po przyimku – dopełniacz)
    def lone(m: re.Match) -> str:
        case = "gen" if _prev(m) in _GEN_PREPS else "nom"
        i, frac = _num_val(m.group(1))
        frac = frac.rstrip("0")
        if frac:
            return number(float(f"{i}.{frac}"), "m", case, len(frac))
        return cardinal(i, "m", case)
    t = re.sub(rf"(?<![\w.,])({_NUM})", lone, t)
    return re.sub(r"\s{2,}", " ", t)
