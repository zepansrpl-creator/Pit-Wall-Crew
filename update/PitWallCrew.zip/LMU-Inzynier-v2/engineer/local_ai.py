"""Lokalny model AI przez Ollamę (darmowy, działa na Twoim komputerze, bez internetu).

Domyślny model: polski Bielik 4.5B (SpeakLeash/bielik-4.5b-v3.0-instruct:Q8_0, ok. 5 GB).
Lżejsza alternatywa: gemma4:e2b-it-qat (ok. 4,3 GB).
"""

from __future__ import annotations

import json
import threading
import urllib.error
import urllib.request
from typing import Optional

from .ai import SETUP_PROMPT, SYSTEM_PROMPT

DEFAULT_MODEL = "SpeakLeash/bielik-4.5b-v3.0-instruct:Q8_0"


class OllamaEngineer:
    def __init__(self, model: str = DEFAULT_MODEL, url: str = "http://localhost:11434",
                 max_tokens: int = 220, keep_alive: str = "60m", history_turns: int = 4,
                 use_gpu: bool = True) -> None:
        self.model = model
        self.url = url.rstrip("/")
        self.max_tokens = max_tokens
        self.keep_alive = keep_alive
        self.history_turns = history_turns
        self.use_gpu = use_gpu
        self.history: list[dict] = []
        self.status = "nie sprawdzono"

    # ------------------------------------------------------------------ http
    def _post(self, path: str, payload: dict, timeout: float = 120.0) -> dict:
        req = urllib.request.Request(self.url + path, data=json.dumps(payload).encode("utf-8"),
                                     headers={"Content-Type": "application/json"})
        with urllib.request.urlopen(req, timeout=timeout) as r:
            return json.loads(r.read().decode("utf-8"))

    def _get(self, path: str, timeout: float = 3.0) -> dict:
        with urllib.request.urlopen(self.url + path, timeout=timeout) as r:
            return json.loads(r.read().decode("utf-8"))

    def available(self) -> bool:
        """Czy Ollama działa i ma pobrany model."""
        try:
            tags = self._get("/api/tags")
        except Exception:
            self.status = "Ollama nie działa (uruchom ją albo zainstaluj instalatorem)"
            return False
        names = {m.get("name", "") for m in tags.get("models", [])}
        want = self.model if ":" in self.model else self.model + ":latest"
        if want not in names and self.model not in names:
            self.status = f"brak modelu {self.model} (pobierz: ollama pull {self.model})"
            return False
        self.status = "gotowy"
        return True

    def ensure_running(self, wait_s: float = 15.0) -> bool:
        """Jeśli Ollama jest zainstalowana, ale nie działa — uruchom ją w tle."""
        import os
        import shutil
        import subprocess
        import sys
        import time
        try:
            self._get("/api/tags", timeout=1.5)
            return True
        except Exception:
            pass
        exe = shutil.which("ollama") or os.path.join(os.environ.get("LOCALAPPDATA", ""), "Programs", "Ollama", "ollama.exe")
        if not exe or not os.path.exists(exe):
            return False
        flags = 0x08000000 if sys.platform == "win32" else 0  # bez okna konsoli
        try:
            subprocess.Popen([exe, "serve"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, creationflags=flags)
        except OSError:
            return False
        end = time.monotonic() + wait_s
        while time.monotonic() < end:
            try:
                self._get("/api/tags", timeout=1.0)
                return True
            except Exception:
                time.sleep(0.5)
        return False

    def warm_up(self) -> None:
        """Ładuje model do pamięci w tle, żeby pierwsza odpowiedź była szybka."""
        def run():
            try:
                self._chat([{"role": "user", "content": "Powiedz: gotowe."}], 5)
            except Exception:
                pass
        threading.Thread(target=run, daemon=True).start()

    def _chat(self, messages: list[dict], max_tokens: int) -> str:
        options = {"num_predict": max_tokens, "temperature": 0.3, "num_ctx": 8192}
        if not self.use_gpu:
            options["num_gpu"] = 0
        resp = self._post("/api/chat", {"model": self.model, "messages": messages, "stream": False,
                                         "keep_alive": self.keep_alive, "options": options})
        return resp.get("message", {}).get("content", "").strip()

    # ------------------------------------------------------------------ pytania
    def ask(self, question: str, state: str, setup: bool = False) -> Optional[str]:
        system = SYSTEM_PROMPT + (SETUP_PROMPT if setup else "")
        user = f"STAN (aktualne dane z gry):\n{state}\n\nKIEROWCA MÓWI: {question}"
        messages = [{"role": "system", "content": system}] + self.history[-self.history_turns * 2:] + \
                   [{"role": "user", "content": user}]
        try:
            answer = self._chat(messages, self.max_tokens + (120 if setup else 0))
        except (urllib.error.URLError, TimeoutError, OSError, ValueError) as e:
            self.status = f"błąd: {e}"
            return None
        answer = _clean(answer)
        if not answer:
            return None
        self.history += [{"role": "user", "content": question}, {"role": "assistant", "content": answer}]
        return answer


def _clean(text: str) -> str:
    """Małe modele lubią markdown i listy — zamieniamy na zwykłe zdania do odczytu głosem."""
    import re
    text = re.sub(r"[*_#`>]+", "", text)
    text = re.sub(r"^\s*[-•\d]+[.)]?\s+", "", text, flags=re.MULTILINE)
    text = re.sub(r"\s*\n+\s*", " ", text).strip()
    # najwyżej 4 zdania
    parts = re.split(r"(?<=[.!?])\s+", text)
    return " ".join(parts[:4])
