"""Styl mówienia inżyniera: wtrącenia na początku wypowiedzi i tryb solo.

- Wtrącenia („Słuchaj,”, „Dobra,”) tylko w zwykłych komunikatach i odpowiedziach, nigdy w ostrzeżeniach.
  Mniej więcej co trzecia–czwarta wypowiedź, bez powtarzania tego samego dwa razy z rzędu.
- „Hmm,” rzadko, tylko przed dłuższą odpowiedzią na pytanie (brzmi jak namysł; „yyy” w syntezie brzmi sztucznie).
- Tryb solo (jeden gracz, bez zespołu): ostrzejszy, kumpelski ton i zamiana zdań zespołowych
  („zgłoś zmianę”) na mobilizujące („Pobudka, nie śpij…”).
"""

from __future__ import annotations

import random
import re
from typing import Optional

FILLERS = ["Słuchaj,", "Dobra,", "Okej,", "Słuchaj,", "Dobra, słuchaj,"]
FILLERS_SOLO = ["Słuchaj,", "Dobra,", "Ej,", "Okej,", "No dobra,"]
# osobowość inżyniera (ustawienia → Głos → Styl): wtrącenia i jak często
PERSONAS = {
    "pro": ("Spokojny profesjonalista", FILLERS, 1.0),
    "kumpel": ("Kumpel – luźno i ciepło", ["Stary,", "Słuchaj,", "Ej,", "Dobra,", "No to tak,"], 1.4),
    "twardziel": ("Twardziel – ostro i wymagająco", ["Słuchaj,", "Uwaga,", "Dobra,", "No,"], 0.8),
    "analityk": ("Analityk – same konkrety", [], 0.0),
}
THINK = ["Hmm,", "Hmm, dobra,"]
URGENT_WORDS = re.compile(r"(auto z (lewej|prawej)|na środku|Uważaj|[Ff]laga|Żółta|Stoi|Wolne auto|poza torem|"
                          r"Hypercar|LMP|sekund[ya]?\.$|[Kk]apeć|przebit|[Kk]ara|Full course|Box)")

# zdania zespołowe → wersja solo (dopasowanie fragmentu)
SOLO_SWAPS = [
    (re.compile(r"Tempo spada i jest więcej błędów\. Jeśli jesteś zmęczony, zgłoś zmianę\."),
     "Pobudka, nie śpij! Tempo Ci spadło i sypią się błędy. Ogarnij się, skup na hamowaniach."),
    (re.compile(r"Jeśli jesteś zmęczony, zgłoś zmianę\."), "Pobudka, nie śpij, ogarnij się."),
    (re.compile(r"[^.]*zgłoś zmianę[^.]*\."), "Pobudka, nie śpij, tempo Ci spadło. Ogarnij się."),
    (re.compile(r"Tempo spada\."), "Tempo Ci leci w dół, przyciśnij."),
]


class Style:
    def __init__(self, fillers: bool = True, rate: float = 0.3, solo: bool = False, seed: Optional[int] = None,
                 persona: str = "pro") -> None:
        self.persona = persona if persona in PERSONAS else "pro"
        _, self._pool, mult = PERSONAS[self.persona]
        self.fillers = fillers and bool(self._pool)
        self.rate = rate * mult
        self.solo = solo or self.persona == "twardziel"     # twardziel: mobilizujące zdania jak w trybie solo
        self._rnd = random.Random(seed)
        self._last: Optional[str] = None

    def team_to_solo(self, text: str) -> str:
        if not self.solo:
            return text
        for rx, rep in SOLO_SWAPS:
            if rx.search(text):
                return rx.sub(rep, text, count=1)
        return text

    def _lower_first(self, text: str) -> str:
        # „Zjazd za 3” → „zjazd za 3”, ale „LMP 2”, „TC”, nazwiska z wielkiej litery zostają
        if len(text) >= 2 and text[0].isupper() and text[1].islower():
            first = text.split(" ", 1)[0].strip(",.")
            if first.lower() in ("hypercar", "ferrari", "porsche"):
                return text
            return text[0].lower() + text[1:]
        return text

    def apply(self, text: str, kind: str = "inżynier") -> str:
        """kind: 'inżynier' (zwykły komunikat), 'odpowiedź', 'odprawa', 'ostrzeżenie'…"""
        text = self.team_to_solo(text)
        if not self.fillers or kind not in ("inżynier", "odpowiedź") or len(text) < 25:
            return text
        if text.startswith(("Wiadomość od", "Odprawa", "Box", "Okrążenie zjazdowe", "Ok", "Dobra", "Wracam",
                            "Przekażę", "Zapisałem", "Wysłane", "Nie znam", "Powiedz:")):
            return text
        if URGENT_WORDS.search(text):      # przeszkody, flagi, dublowanie: zawsze krótko i od razu
            return text
        r = self._rnd.random()
        if kind == "odpowiedź" and len(text) > 60 and r < 0.12:
            pre = self._rnd.choice(THINK)
        elif r < self.rate:
            base = FILLERS_SOLO if (self.solo and self.persona == "pro") else self._pool
            pool = [f for f in base if f != self._last] or base
            pre = self._rnd.choice(pool)
        else:
            return text
        self._last = pre
        return f"{pre} {self._lower_first(text)}"
