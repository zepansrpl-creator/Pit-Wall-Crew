"""Hilfeseiten auf Deutsch: Befehle, Funktionen, Anleitung, Über (Original: commands.py, help_texts.py)."""

COMMANDS: list[tuple[str, list[tuple[str, str]]]] = [
    ("Den Ingenieur steuern", [
        ("„ruhig“ / „Ruhe“ / „Ingenieur, ruhig“ / „nicht reden“", "„OK.“ und völlige Stille (auch keine Warnungen); spricht wieder nach dem nächsten Druck auf die Funktaste"),
        ("„<Name des Ingenieurs>, ruhig“ (z. B. „Markus, ruhig“)", "dasselbe, wenn du dem Ingenieur einen Namen gegeben hast (Einstellungen → Stimme)"),
        ("„nur Dringendes“ / „nur wenn ich frage“", "nur dringende Warnungen und Antworten auf deine Fragen"),
        ("„du kannst reden“ / „rede weiter“", "wieder Meldungen über Änderungen"),
        ("„wiederhol“ / „nochmal“", "wiederholt die letzte Antwort"),
        ("„Funkcheck“ / „hörst du mich?“", "Funkprüfung"),
        ("„welche Kurven?“ / „in welchen?“", "die vollständige Liste nach einer kurzen Antwort („in 6 Kurven, vor allem T3 und T11“), bis zu 2 Minuten danach"),
        ("„was kannst du“ / „Hilfe“", "kurze Themenliste"),
        ("Druck auf die Funktaste", "unterbricht, was der Ingenieur gerade sagt"),
    ]),
    ("Hinweise ein- und ausschalten", [
        ("„keine Überrundung“ / „Überrundung an“", "Warnungen vor schnelleren Klassen hinter dir"),
        ("„Coach“ / „kein Coach“", "Hinweise vor einer Kurve, wenn sich ein Fehler wiederholt"),
        ("„Vergleich“ / „kein Vergleich“", "„T5: du bremst 15 Meter früher“ – Vergleich mit deiner besten Runde"),
        ("„Teamvergleich“ / „kein Teamvergleich“", "„T5: Patrick bremst 15 Meter später. Versuch später zu bremsen.“ – vor einer Kurve, in der ein Teamkollege unter ähnlichen Bedingungen deutlich schneller ist"),
        ("„Kommentare“ / „keine Kommentare“", "ein Kommentar nach Positionsgewinn oder -verlust"),
        ("„Tipps“ / „keine Tipps“", "Setup- und Fahrtechnik-Tipps"),
    ]),
    ("Kraftstoff, Energie, Boxenstopp", [
        ("„wie viel Sprit?“ / „reicht es?“", "Kraftstoff, wie viele Runden, Reserve"),
        ("„wie viel Energie?“ / „virtuelle Energie?“", "virtuelle Energie"),
        ("„wann in die Box?“ / „Boxenplan?“", "Boxenrunde (mindestens 0,2 % Energie bei der Boxeneinfahrt), wie viel Energie, welche Reifen"),
        ("„wie lange dauert der Stopp?“", "Stoppzeit inklusive Boxengasse"),
        ("„welche Reifen wechseln wir?“ / „Reifenwechsel?“", "welche Reifen beim Stopp gewechselt werden (aus dem Teamplan oder nach Verschleiß) und warum"),
        ("„wie viel sparen?“ / „wie spare ich?“", "Verbrauchsziel pro Runde, um einen Stopp zu sparen oder die geplante Boxenrunde zu erreichen"),
        ("„Verbrauchstrend?“", "Trend beim Kraftstoff- und Energieverbrauch"),
        ("„wie lange noch?“ / „wie viele Runden noch?“", "Zeit und Runden bis ins Ziel"),
    ]),
    ("Rundenzeiten und Fahren", [
        ("„meine Zeit?“ / „wie läuft's?“", "letzte und beste Runde, Konstanz"),
        ("„wo verliere ich?“ / „wo kann ich gewinnen?“", "Kurven mit dem größten Verlust"),
        ("„Kurve 5“", "Details zu einer bestimmten Kurve"),
        ("„verliere ich Tempo?“ / „bin ich müde?“", "Müdigkeit und Tempoabfall"),
        ("„welche Position?“", "Position in der Klasse und gesamt"),
    ]),
    ("Gegner", [
        ("„wer ist vor mir?“ / „wen jage ich?“", "Abstand, Tempo, Trend"),
        ("„wer ist hinter mir?“ / „wer jagt mich?“", "Abstand, Tempo, Trend"),
        ("„wann hole ich ihn ein?“ / „holt er mich ein?“", "in wie vielen Runden beim aktuellen Tempo"),
        ("„Tempo des Gegners?“", "Tempo des Autos vor oder hinter dir"),
        ("„wer fährt vor mir?“", "Fahrer im Gegnerauto und ihr Tempo"),
        ("„hat der Gegner Reifen gewechselt?“", "Schätzung der Reifen des Gegners beim letzten Stopp"),
        ("„wann fährt der Gegner an die Box?“", "voraussichtlicher Stopp des Gegners"),
        ("„wann überrundet mich das erste Hypercar?“ / „wann holt mich LMP2 ein?“", "erstes Auto einer schnelleren Klasse: wann es da ist und wie weit es hinter dir ist; die nächsten"),
        ("„Höchstgeschwindigkeit der anderen?“ / „Vmax der Hypercars?“", "Höchstgeschwindigkeit der Gegner, deine und die des Schnellsten der Klasse"),
    ]),
    ("Auto", [
        ("„wie sind die Reifen?“ / „Reifendruck?“", "Verschleiß, Temperaturen, Drücke"),
        ("„Bremsen?“", "Verschleiß und Temperaturen der Bremsen"),
        ("„vergleich mich mit Patrick“ / „wo ist mein Teamkollege schneller?“", "schnellste Runde des Teamkollegen auf derselben Mischung, mit ähnlichem Reifenverschleiß, Kraftstoff und Streckentemperatur: in welchen Kurven er schneller ist, was er anders macht (Bremsen, Kurvengeschwindigkeit, Gas, Gang) und ein Tipp"),
        ("„in welchen Kurven ist Wieczorek langsamer als ich?“", "ein Gegner aus deiner Klasse: beste Runden beider, wo er langsamer und schneller ist, Kurvengeschwindigkeit"),
        ("„vergleiche Reifen- und Bremstemperaturen mit Runde 4 nach dem Stopp“", "letzte Runde gegen die gewählte: Bremsen vorne/hinten, Reifen vorne/hinten, Tipp zur Bremskühlung"),
        ("„Schaden?“ / „reparieren?“", "Schaden und Zeitverlust"),
        ("„Reparatur dauert 30 Sekunden“", "ob sich die Reparatur bei dieser Zeit lohnt"),
        ("„Motor?“ / „Wassertemperatur?“ / „Kühlergrill“", "Motortemperaturen, Tipp zum Kühlergrill"),
        ("„Untersteuern am Eingang der letzten Kurve“", "Tipp zur Kurve und zum Setup"),
        ("„ich habe die Bremsbalance auf 54 geändert“ / „hat es geholfen?“", "speichert die Setup-Änderung und bewertet sie nach ein paar Runden"),
        ("„was soll ich am Setup ändern?“", "Vorschläge (im Rennen nur Einstellungen im Cockpit)"),
        ("„welches TC?“ / „Traktionskontrolle?“ / „wie viel ABS?“", "aktuelle Einstellung und Tipp aus den Messungen (geht auch ohne KI)"),
    ]),
    ("Wetter", [
        ("„Wetter?“ / „regnet es?“", "Regen, Nässe, Prognose, Streckentemperatur"),
        ("„wann Regenreifen?“ / „wann Slicks?“", "ob und wann sich ein Reifenwechsel lohnt"),
    ]),
    ("Team und Gedächtnis", [
        ("„merk dir …“ / „Notiz …“", "eine Notiz fürs Teamgedächtnis (die KI berücksichtigt sie)"),
        ("„Benachrichtigung Adam: aufwachen, du fährst gleich“", "sofortige Handy-Benachrichtigung an einen Teamkollegen (ntfy); „Benachrichtigung an alle: …“ – ans ganze Team"),
        ("„sag dem nächsten Fahrer, dass …“", "eine Notiz, die der Ingenieur dem nächsten Fahrer bei der Übergabe vorliest"),
        ("Analysefragen: „vergleiche…“, „was ist der Unterschied…“, „warum…“, „wer ist am schnellsten…“", "beantwortet die KI mit allen Renndaten"),
        ("jede andere Frage", "beantwortet die KI (Groq); bei unsicherer Spracherkennung – „Hab ich nicht verstanden, bitte wiederholen.“"),
    ]),
    ("Boxenmauer (für das Team)", [
        ("„An den Fahrer“", "eine Nachricht, die der Ingenieur dem Fahrer vorliest"),
        ("„Ingenieur fragen“", "eine Frage an den Ingenieur, die Antwort ist im Teamfunk zu hören"),
        ("„Fragen (nur Text)“", "die Antwort erscheint nur auf der Boxenmauer, der Fahrer hört sie nicht"),
        ("„Ins Gedächtnis“", "eine Notiz fürs Teamgedächtnis"),
    ]),
    ("Probleme und Vorschläge", [
        ("App → Hilfe → „Problem melden“ oder Boxenmauer → Hilfe", "beschreibe ein Problem oder eine Idee – geht direkt an den Autor"),
    ]),
]

FEATURES: list[tuple[str, list[str]]] = [
    ("Pit Wall Crew in Kürze", [
        "Ein Sprach-Renningenieur für Le Mans Ultimate und eine Boxenmauer fürs ganze Team. Der Ingenieur spricht nur über "
        "das, was etwas ändert, und beantwortet deine Fragen per Stimme. Das Team sieht alles live im Browser und hört den "
        "Ingenieur in der eigenen App. Funktioniert auf jeder Strecke, mit jedem Auto und jeder Klasse.",
    ]),
    ("Dringende Warnungen (sofort, kurz)", [
        "• Überrundung durch eine schnellere Klasse: „Hypercar, 2 Sekunden“, Gruppen („drei Hypercars“).",
        "• Stehendes oder sehr langsames Auto vor dir, Auto neben der Strecke.",
        "• Flaggen (auch lokale Gelbe), FCY, Strafen, Track Limits, grüne Flagge.",
        "• Im Qualifying (in LMU privat) keine Warnungen vor anderen Autos – Flaggen und Strafen bleiben.",
        "• „Box, Box“ etwa 25 s vor der Boxeneinfahrt in der Inlap. Nach der Zielflagge – keine Boxenrufe mehr.",
    ]),
    ("Strategie", [
        "• Kraftstoff und virtuelle Energie: Verbrauch wie im Spiel gemessen; Restrunden, Boxenplan (Energie, Reifen), Stoppzeit.",
        "• So spät wie möglich an die Box: bei der Einfahrt und im Ziel bleiben mindestens 0,2 % Energie (0,3 l Kraftstoff).",
        "• Boxenplan 3 Runden vorher, Erinnerung in der Inlap, wo du nach dem Stopp herauskommst.",
        "• Sparen: wenn ein paar Prozent weniger Verbrauch einen Stopp sparen – Ziel pro Runde und Kontrolle nach jeder Runde.",
        "• Schäden: wie viele Sekunden sie kosten und ob reparieren.",
        "• Reifen: Verschleiß und Temperaturen, wann ein neuer Satz lohnt, Drücke in der Nacht.",
        "• Wetter: Regen, abtrocknende Strecke, wann die Reifen wechseln.",
    ]),
    ("Gegner", [
        "• Abstand und Trend zu den Autos vor und hinter dir in der Klasse, wann du sie einholst.",
        "• Höchstgeschwindigkeit der Gegner im Vergleich zu deiner.",
        "• Tempo jedes Fahrers im Gegnerauto, voraussichtlicher Stopp und Reifen.",
        "• Ein Kommentar nach Positionsgewinn oder -verlust – erst wenn die Position 30 Sekunden hält.",
    ]),
    ("Coach und Setup", [
        "• Coach vor einer Kurve, wenn sich ein Fehler wiederholt (Blockieren, Durchdrehen, ABS/TC, Gas).",
        "• Vergleich mit deiner besten Runde auf ähnlichen Reifen: „T5: du bremst 15 Meter früher“.",
        "• Vergleich mit Teamkollegen: die schnellsten Runden jedes Fahrers werden automatisch gespeichert; der Ingenieur sagt vor einer Kurve, was der Kollege anders macht.",
        "• Kurvenvergleich mit einem Gegner aus deiner Klasse.",
        "• Setup-Tipps aus dem Cockpit (Bremsbalance, TC, ABS) im Rennen, im Training auch Garagenänderungen: Stabilisatoren, Federn, Flügel, Bodenfreiheit, Sturz, Spur, Dämpfer (Aufsetzen, Randsteine), Bremskühlung, Reifendruck.",
        "• Fahrgefühl per Stimme beschreiben („Untersteuern am Eingang der letzten Kurve“) – der Ingenieur prüft die Daten und rät.",
        "• Müdigkeit des Fahrers: Tempoabfall, schlechtere Konstanz und Fehler.",
    ]),
    ("Team", [
        "• Boxenmauer im Browser (Handy, PC): Autostatus, Streckenkarte, Gegner, Stintplan, Teamfunk.",
        "• Live berechneter Zeitplan und Handy-Benachrichtigungen (ntfy) etwa 30 Minuten vor deinem Stint und bei Regen. Ohne Plan für heute wird der Zeitplan automatisch für den aktuellen Fahrer erstellt.",
        "• Nachrichten von der Boxenmauer an den Fahrer (der Ingenieur liest sie vor) und Fragen „nur Text“.",
        "• Übergabe beim Fahrerwechsel: Schäden, Ausrutscher des Vorgängers, Plan, Notizen.",
        "• Teamfunk: wenn du nicht fährst, spielt die App die Meldungen des Ingenieurs aus dem Teamauto ab.",
        "• Cloud-KI (Groq, kostenlos): Spracherkennung und KI-Antworten ohne Server.",
        "• Teamgedächtnis: Notizen, die die KI berücksichtigt.",
        "• Zuschauer-Link – nur Live-Ansicht, ohne Funk und Plan.",
    ]),
    ("Stimme", [
        "• Natürliche Stimme mit Funkeffekt und eigenem Namen für den Ingenieur.",
        "• Funktaste am Lenkrad oder eine Taste; ein Druck unterbricht den Ingenieur.",
        "• Lange Listen verkürzt: „in 6 Kurven, vor allem T3 und T11“ – die ganze Liste mit „welche Kurven?“.",
        "• „Ruhig“ – „OK.“ und völlige Stille bis zum nächsten Druck; „nur Dringendes“ – nur Warnungen und Antworten.",
    ]),
]

MANUAL: list[tuple[str, list[str]]] = [
    ("Erster Start", [
        "• In LMU einmalig: Settings → Gameplay → Enable Plugins = ON.",
        "• Team: Teamcode und Passwort eingeben (von deinen Teamkollegen) oder „Neues Team erstellen…“ klicken. „Verbindung testen“ "
        "und deinen Namen wählen. Code und Passwort nur privat weitergeben.",
        "• Mikrofon und Taste: Mikrofon wählen, „Test 3 s“, dann „Festlegen: Taste drücken…“ und die Taste am Lenkrad drücken.",
        "• Stimme: Stimme, Tempo, Funkeffekt, Sprache und Name wählen; „Anhören“.",
        "• „Speichern und neu starten“ klicken.",
    ]),
    ("Am Renntag", [
        "• Jeder im Team hat die App laufen – auch wer nicht fährt. Das Programm erkennt, wer fährt.",
        "• KI: einmal einen kostenlosen Groq-Schlüssel auf der Boxenmauer einfügen (Team → Team-KI).",
        "• 24-h-Rennen: wer nicht fährt, kann LMU, App und PC ausschalten. Vor deinem Stint (Handy-Benachrichtigung) LMU und Pit Wall Crew starten, bevor du einsteigst.",
        "• Vor dem Start prüfen: grünes „Team“ und „KI: Groq“ in der App, „live“ auf der Boxenmauer.",
    ]),
    ("Mit dem Ingenieur sprechen", [
        "Taste halten, sprechen, loslassen. Du kannst eine Frage auch auf der Seite „Renningenieur“ eintippen. "
        "Alle Befehle stehen auf der Seite „Befehle“. Kennen die Regeln die Antwort nicht, geht die Frage an die KI (Groq).",
    ]),
    ("Boxenmauer (Webseite)", [
        "• Live: Rennen, Boxenstopp, Reifen, Wetter, Fahrer, Streckenkarte, Gegner, Stintplan, Teamfunk.",
        "• Zeitplan & Plan: Rennstart, Reifen fürs Rennen, Stintplan (Fahrer aus der Liste, Runden, Reifenwechsel links / rechts), Plan aus einer Tabelle einfügen.",
        "• Team: Code, QR, Fahrer und ntfy-Themen (Test-Taste), Zuschauer-Link.",
        "• Runden (mit CSV-Download) und Teamgedächtnis.",
    ]),
    ("Handy-Benachrichtigungen", [
        "• Installiere die kostenlose App ntfy (Google Play / App Store).",
        "• Boxenmauer: Tab Team → 📱 neben deinem Namen – Thema und QR-Code erscheinen.",
        "• In ntfy auf + tippen, Thema eingeben und abonnieren (oder QR-Code scannen).",
        "• Auf der Boxenmauer Test klicken – „Pit Wall Crew – test“ kommt aufs Handy.",
    ]),
    ("Wenn etwas nicht funktioniert", [
        "• Boxenmauer: „keine Daten aus dem Spiel“ – läuft beim Fahrer die App mit grünem „Team“?",
        "• „Falscher Teamcode oder Passwort“ – auf der Seite Team korrigieren, „Verbindung testen“, „Speichern“.",
        "• Der Ingenieur hört dich nicht – Seite Mikrofon und Taste: „Test 3 s“; Windows: Datenschutz → Mikrofon.",
        "• „KI: Groq – falscher Schlüssel“ – den Schlüssel erneut auf der Boxenmauer einfügen.",
        "• Jede Meldung doppelt – das Programm läuft zweimal. App schließen, „pythonw“ im Task-Manager beenden, einmal starten.",
        "• Das Spiel ruckelt – meist zu wenig Grafikspeicher: Texturen, sichtbare Autos und Schatten reduzieren, andere Programme schließen.",
        "• Anderes Problem oder eine Idee – Hilfe → „Problem melden“. Geht direkt an den Autor.",
        "• Absturzberichte: mit deiner Zustimmung (Frage beim ersten Start, änderbar auf der Seite „Problem melden“) sendet das Programm dem Autor den Fehler und das Protokoll der letzten Sitzung – ohne Sprachaufnahmen, Schlüssel und Passwörter.",
    ]),
    ("Updates", [
        "Die App sucht beim Start nach Updates (nie während der Fahrt), lädt die neue Version, ersetzt die Dateien und startet neu. "
        "Einstellungen und Daten bleiben erhalten.",
        "Tester mit einem Code vom Autor (Erweitert → Testercode) bekommen neue Versionen vor allen anderen.",
    ]),
]

ABOUT = [
    ("Pit Wall Crew", [
        "Sprach-Renningenieur und Boxenmauer für Le Mans Ultimate.",
        "Erstellt von Maciej Szczepaniak from FR Mods.",
        "© 2026 Maciej Szczepaniak (FR Mods). Alle Rechte vorbehalten. Kopieren, Weitergeben oder Verändern des Programms ohne Zustimmung des Autors ist verboten – siehe LICENCJA.txt.",
    ]),
    ("Danke", [
        "An Rett und Barny für die Hilfe beim Testen.",
    ]),
]
