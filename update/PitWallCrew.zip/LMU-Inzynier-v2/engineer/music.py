"""Muzyka w tle komunikatów inżyniera (dla zabawy).

"indyjska": generowana w całości w programie (numpy): bordunowa tanpura, sitar (szarpana struna
Karplus-Strong) w skali indyjskiej i tabla w rytmie keherwa. Bez cudzych nagrań, więc można się tym dzielić.
Można też podać własny plik .wav (np. muzyka = "C:/muzyka/moja.wav").
"""

from __future__ import annotations

import os

import numpy as np

SR = 24000
BPM = 96


def _env(n: int, attack: float, decay: float, sr: int = SR) -> np.ndarray:
    t = np.arange(n) / sr
    a = np.minimum(1.0, t / max(attack, 1e-4))
    return a * np.exp(-t / decay)


def _tanpura(n: int, rng: np.random.Generator) -> np.ndarray:
    """Bordun: struny Pa, Sa', Sa', Sa szarpane po kolei, z bogatymi alikwotami (brzęczenie jawari)."""
    out = np.zeros(n)
    sa = 146.83  # D3
    strings = [sa * 0.75, sa, sa, sa * 0.5]  # Pa (niżej), Sa, Sa, Sa (oktawa niżej)
    period = int(SR * 60 / BPM * 1.0)
    pos, k = 0, 0
    while pos < n:
        f = strings[k % 4]
        m = min(n - pos, int(SR * 4.5))
        t = np.arange(m) / SR
        tone = np.zeros(m)
        for h in range(1, 14):
            # jawari: wyższe alikwoty "oddychają" w czasie
            amp = (1.0 / h ** 0.9) * (0.6 + 0.4 * np.sin(2 * np.pi * (0.7 + 0.13 * h) * t + h))
            tone += amp * np.sin(2 * np.pi * f * h * t * (1 + 0.0007 * rng.standard_normal()))
        out[pos:pos + m] += tone * _env(m, 0.02, 1.8)
        pos += period
        k += 1
    return out / (np.max(np.abs(out)) or 1.0)


def _pluck(freq: float, dur: float, rng: np.random.Generator, bend: float = 0.0) -> np.ndarray:
    """Struna szarpana (Karplus-Strong) z lekkim podciągnięciem dźwięku (meend) i brzęczeniem jak w sitarze."""
    n = int(SR * dur)
    out = np.zeros(n)
    f = freq
    p = max(2, int(SR / f))
    buf = rng.uniform(-1, 1, p)
    idx = 0
    for i in range(n):
        if bend and i % 64 == 0:
            f2 = freq * (1 + bend * min(1.0, i / (0.25 * SR)))
            p2 = max(2, int(SR / f2))
            if p2 != len(buf):
                buf = np.resize(buf, p2)
                idx %= p2
        v = buf[idx]
        nxt = buf[(idx + 1) % len(buf)]
        buf[idx] = 0.996 * 0.5 * (v + nxt)
        out[i] = v
        idx = (idx + 1) % len(buf)
    # brzęczenie sitara: lekkie przesterowanie i podbicie wysokich
    out = np.tanh(out * 2.2)
    out[1:] += 0.35 * np.diff(out)
    return out * _env(n, 0.002, dur * 0.6)


def _tabla(kind: str, rng: np.random.Generator) -> np.ndarray:
    n = int(SR * 0.45)
    t = np.arange(n) / SR
    if kind in ("dha", "ge", "dhi"):  # bayan: niski, opadający dźwięk
        f = 95 * (1 + 0.6 * np.exp(-t / 0.05))
        bass = np.sin(2 * np.pi * np.cumsum(f) / SR) * np.exp(-t / 0.18)
    else:
        bass = np.zeros(n)
    if kind in ("dha", "na", "dhi", "ti"):  # dayan: dźwięczny, wysoki
        f0 = 340 if kind != "ti" else 420
        ring = sum(np.sin(2 * np.pi * f0 * r * t) / (i + 1) for i, r in enumerate((1, 2.0, 2.98, 4.1)))
        ring = ring * np.exp(-t / (0.12 if kind != "ti" else 0.05))
    else:
        ring = np.zeros(n)
    click = rng.standard_normal(n) * np.exp(-t / 0.006) * 0.4
    if kind == "ka":
        click *= 2.5
    return 0.9 * bass + 0.6 * ring + click


def indian_loop(seconds: float = 20.0, seed: int = 7) -> np.ndarray:
    rng = np.random.default_rng(seed)
    n = int(SR * seconds)
    beat = 60 / BPM / 2  # ósemki
    out = 0.55 * _tanpura(n, rng)

    # tabla: keherwa (8 uderzeń)
    pattern = ["dha", "ge", "na", "ti", "na", "ka", "dhi", "na"]
    hits = {k: _tabla(k, rng) for k in set(pattern)}
    tabla = np.zeros(n)
    i = 0
    while True:
        pos = int(i * beat * SR)
        if pos >= n:
            break
        h = hits[pattern[i % 8]] * (1.0 if i % 8 == 0 else 0.75)
        m = min(len(h), n - pos)
        tabla[pos:pos + m] += h[:m]
        i += 1
    out += 0.5 * tabla / (np.max(np.abs(tabla)) or 1.0)

    # sitar: krótkie frazy w skali raga Bhairav (Sa re Ga ma Pa dha Ni) od D4
    sa = 293.66
    scale = [1, 16 / 15, 5 / 4, 4 / 3, 3 / 2, 8 / 5, 15 / 8, 2]
    sitar = np.zeros(n)
    t = 0.5
    deg = 0
    while t < seconds - 1.0:
        phrase = rng.integers(3, 7)
        for _ in range(phrase):
            deg = int(np.clip(deg + rng.choice([-2, -1, -1, 1, 1, 2]), 0, len(scale) - 1))
            dur = beat * rng.choice([1, 1, 2, 2, 3])
            note = _pluck(sa * scale[deg], min(1.6, dur * 2.5), rng, bend=0.03 if rng.random() < 0.3 else 0.0)
            pos = int(t * SR)
            if pos >= n:
                break
            m = min(len(note), n - pos)
            sitar[pos:pos + m] += note[:m]
            t += dur
        t += beat * rng.choice([2, 4])  # pauza między frazami
    out += 0.45 * sitar / (np.max(np.abs(sitar)) or 1.0)

    # płynne zapętlenie: krótkie przenikanie końca z początkiem
    xf = int(0.5 * SR)
    fade = np.linspace(0, 1, xf)
    out[:xf] = out[:xf] * fade + out[-xf:] * (1 - fade)
    out = out[:-xf]
    return out / (np.max(np.abs(out)) or 1.0) * 0.9


def _resample(x: np.ndarray, sr_in: int, sr_out: int) -> np.ndarray:
    if sr_in == sr_out or len(x) == 0:
        return x
    n_out = max(1, int(round(len(x) * sr_out / sr_in)))
    return np.interp(np.arange(n_out) * sr_in / sr_out, np.arange(len(x)), x)


def load(name: str, sr: int, cache_dir: str = "cache") -> np.ndarray | None:
    """Zwraca pętlę muzyki (mono float) w podanej częstotliwości albo None."""
    if not name or name.lower() in ("brak", "none", "false", "off"):
        return None
    from .radio import read_wav, write_wav
    if name.lower() in ("indyjska", "indian", "hinduska"):
        path = os.path.join(cache_dir, "muzyka_indyjska.wav")
        if not os.path.exists(path):
            os.makedirs(cache_dir, exist_ok=True)
            write_wav(path + ".part.wav", indian_loop(), SR)
            os.replace(path + ".part.wav", path)
    else:
        path = name
        if not os.path.exists(path):
            print(f"[muzyka] Nie ma pliku {path}")
            return None
    x, sr_in = read_wav(path)
    return _resample(x, sr_in, sr)


def mix(speech: np.ndarray, sr: int, loop: np.ndarray, volume: float = 0.18, key: int = 0) -> np.ndarray:
    """Muzyka pod mową: wejście 0,4 s przed głosem, wyciszenie po nim; głos zawsze na wierzchu."""
    pre, post = int(0.4 * sr), int(0.7 * sr)
    speech = speech / (np.max(np.abs(speech)) or 1.0)
    n = pre + len(speech) + post
    start = (key * 7919) % max(1, len(loop))
    idx = (start + np.arange(n)) % len(loop)
    bed = loop[idx] * volume
    env = np.ones(n)
    env[:pre] = np.linspace(0, 1, pre)
    env[-post:] = np.linspace(1, 0, post)
    # lekkie przyciszenie muzyki, gdy inżynier mówi
    duck = np.ones(n)
    duck[pre:pre + len(speech)] = 0.7
    out = bed * env * duck
    out[pre:pre + len(speech)] += speech
    return out / (np.max(np.abs(out)) or 1.0) * 0.95
