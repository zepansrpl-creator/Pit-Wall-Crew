"""Wspólny model danych, niezależny od symulatora.

Każde źródło (LMU na żywo, powtórka z pliku, demo) zwraca obiekty Snapshot.
Reszta programu pracuje wyłącznie na tych klasach.
"""

from __future__ import annotations

from dataclasses import dataclass, field, asdict
from typing import Optional


SESSION_NAMES = {
    "test": "test",
    "practice": "trening",
    "qualify": "kwalifikacje",
    "warmup": "rozgrzewka",
    "race": "wyścig",
}


@dataclass
class TyreState:
    temp_c: tuple[float, float, float] = (0.0, 0.0, 0.0)  # lewa / środek / prawa strona bieżnika
    carcass_c: float = 0.0
    pressure_kpa: float = 0.0
    wear: float = 0.0  # 0 = nowa, 1 = całkowicie zużyta
    brake_c: float = 0.0
    optimal_c: float = 0.0
    slip_deg: float = 0.0     # kąt poślizgu opony (stopnie, wartość bezwzględna)
    grip_fract: float = 0.0   # jaka część śladu opony się ślizga (0..1)
    long_slip: float = 0.0    # poślizg wzdłużny (blokowanie / buksowanie): |prędkość śladu| / prędkość koła po ziemi
    ride_h: float = -1.0      # prześwit przy tym kole (m), -1 = brak danych
    load_n: float = -1.0      # nacisk opony na asfalt (N), -1 = brak danych
    surface: int = 0          # 0 sucho, 1 mokro, 2 trawa, 3 ziemia, 4 żwir, 5 tarka


@dataclass
class PlayerTelemetry:
    lap: int = 0
    lap_dist: float = 0.0          # metry od linii mety
    speed_kmh: float = 0.0
    throttle: float = 0.0          # 0..1
    brake: float = 0.0             # 0..1
    steering: float = 0.0          # -1..1
    ffb_torque: float = 0.0        # moment na kolumnie kierownicy (siła FFB z fizyki gry, Nm)
    gear: int = 0
    rpm: float = 0.0
    max_rpm: float = 0.0
    fuel_l: float = 0.0
    fuel_capacity_l: float = 0.0
    virtual_energy: Optional[float] = None  # 0..1, tylko auta z VE
    lat_g: float = 0.0
    lon_g: float = 0.0
    yaw_rate: float = 0.0          # rad/s
    tc_active: bool = False
    abs_active: bool = False
    lap_invalid: bool = False
    in_pits: bool = False
    tyres: list[TyreState] = field(default_factory=lambda: [TyreState() for _ in range(4)])  # FL, FR, RL, RR
    compound_front: str = ""
    compound_rear: str = ""
    rear_brake_bias: float = 0.0
    tc: int = 0
    abs: int = 0
    front_arb: int = -1       # stabilizator przód (ustawienie w aucie), -1 = brak danych
    rear_arb: int = -1
    motor_map: int = -1
    front_ride_height: float = 0.0  # m
    rear_ride_height: float = 0.0   # m
    dents: list[int] = field(default_factory=lambda: [0] * 8)  # uszkodzenia nadwozia w 8 miejscach (0/1/2)
    parts_detached: bool = False
    wheel_flat: list[bool] = field(default_factory=lambda: [False] * 4)
    wheel_detached: list[bool] = field(default_factory=lambda: [False] * 4)
    last_impact_t: float = 0.0
    last_impact_mag: float = 0.0
    track_limit_steps: int = 0
    water_c: float = 0.0        # temperatura wody w silniku
    oil_c: float = 0.0          # temperatura oleju
    overheating: bool = False   # gra pokazuje ikonę przegrzania


@dataclass
class CarScoring:
    car_id: int
    driver: str
    vehicle: str
    car_class: str
    place: int
    laps_done: int
    lap_dist: float
    last_lap: float              # s, <=0 gdy brak
    best_lap: float              # s, <=0 gdy brak
    last_s1: float = 0.0         # czas sektora 1 (s)
    last_s2: float = 0.0         # czas sektorów 1+2 (s)
    best_s1: float = 0.0
    best_s2: float = 0.0
    in_pits: bool = False
    pit_stops: int = 0
    time_behind_leader: float = 0.0
    laps_behind_leader: int = 0
    is_player: bool = False
    fuel_fraction: Optional[float] = None
    finished: bool = False
    speed_kmh: float = 0.0
    off_track: bool = False      # poza asfaltem (|pozycja boczna| > krawędź toru)
    path_lateral: float = 0.0    # m od środka toru: dodatnie = prawa strona (sprawdzone na telemetrii Le Mans)
    blue_flag: bool = False      # gra pokazuje temu autu niebieską flagę
    penalties: int = 0
    pit_state: int = 0           # 0 brak, 1 zgłoszony, 2 wjazd, 3 postój, 4 wyjazd
    control: int = 0             # kto prowadzi: 0 ten komputer, 1 AI, 2 inny komputer (zmiennik), -1 nikt
    x: float = 0.0               # położenie w świecie (m), poziomo – do mapy toru
    z: float = 0.0


@dataclass
class Snapshot:
    t: float                     # czas sesji (s)
    session: str                 # test / practice / qualify / warmup / race
    track: str
    track_length: float
    car_name: str
    time_remaining: Optional[float]  # s, None = sesja na okrążenia
    max_laps: Optional[int]
    phase: str                   # green / fcy / stopped / over / before
    air_temp: float
    track_temp: float
    rain: float                  # 0..1
    wetness: float               # 0..1 średnia wilgotność toru
    player: Optional[PlayerTelemetry]
    cars: list[CarScoring]
    sector_yellow: list[bool] = field(default_factory=lambda: [False, False, False])
    yellow_state: int = 0        # FCY: 2 aleja zamknięta, 4 aleja otwarta, 5 ostatnie okrążenie
    tl_steps_per_penalty: int = 0
    tl_steps_per_point: int = 0
    dark_cloud: float = 0.0      # zachmurzenie / ciemność chmur 0..1 (zapowiedź deszczu)

    def player_scoring(self) -> Optional[CarScoring]:
        for c in self.cars:
            if c.is_player:
                return c
        return None

    def to_dict(self) -> dict:
        return asdict(self)

    @staticmethod
    def from_dict(d: dict) -> "Snapshot":
        p = d.get("player")
        player = None
        if p:
            tyres = [TyreState(**{**t, "temp_c": tuple(t["temp_c"])}) for t in p.pop("tyres", [])]
            player = PlayerTelemetry(**p, tyres=tyres or [TyreState() for _ in range(4)])
        cars = [CarScoring(**c) for c in d.get("cars", [])]
        rest = {k: v for k, v in d.items() if k not in ("player", "cars")}
        return Snapshot(**rest, player=player, cars=cars)
