"""Wczytanie config.toml odporne na powtórzone klucze (zostaje pierwsze wystąpienie, plik jest poprawiany)."""

from __future__ import annotations

import re
import tomllib


def dedupe(text: str) -> str:
    out, sec, seen = [], "", set()
    for line in text.splitlines(keepends=True):
        s = line.strip()
        if s.startswith("[") and not s.startswith("[["):
            sec = s
        m = re.match(r"\s*([A-Za-z0-9_\-]+)\s*=", line)
        if m:
            k = (sec, m.group(1))
            if k in seen:
                continue
            seen.add(k)
        out.append(line)
    return "".join(out)


def loads_fixing(text: str, path: str | None = None) -> dict:
    try:
        return tomllib.loads(text)
    except tomllib.TOMLDecodeError:
        fixed = dedupe(text)
        data = tomllib.loads(fixed)          # gdy dalej błąd – zgłoś go wyżej
        if path:
            try:
                with open(path, "w", encoding="utf-8") as f:
                    f.write(fixed)
            except OSError:
                pass
        return data
