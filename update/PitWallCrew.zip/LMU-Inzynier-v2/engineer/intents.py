"""Inżynier bez AI: rozpoznaje typowe pytania kierowcy i odpowiada z danych.

Działa bez internetu, bez kluczy i bez opłat. Odpowiedzi są pisane do odczytu głosem.
Gdy pytanie nie pasuje do żadnego tematu, answer() zwraca None (wtedy może odpowiedzieć model AI, jeśli włączony).
"""

from __future__ import annotations

import math
import re
import unicodedata
from typing import Optional

from .analysis.fuel import fuel_report
from .analysis.handling import OVER, UNDER, CornerHandling, analyze as analyze_handling, label
from .fmt import fmt_clock, laps_word, spoken_delta, spoken_lap
from . import setup_rules

# ----------------------------------------------------------------------------- tekst

NUM_WORDS = {
    "jeden": 1, "jedna": 1, "dwa": 2, "dwie": 2, "trzy": 3, "cztery": 4, "piec": 5, "szesc": 6, "siedem": 7,
    "osiem": 8, "dziewiec": 9, "dziesiec": 10, "jedenascie": 11, "dwanascie": 12, "trzynascie": 13,
    "czternascie": 14, "pietnascie": 15, "szesnascie": 16, "siedemnascie": 17, "osiemnascie": 18,
    "dziewietnascie": 19, "dwadziescia": 20,
}
# "trójka", "w trójce", "piątką" itd.
COLLOQUIAL = {"jedyn[kc]": 1, "dwoj[kc]": 2, "troj[kc]": 3, "czwor[kc]": 4, "piat[kc]": 5, "szost[kc]": 6,
              "siodem[kc]": 7, "osem[kc]": 8, "dziewiat[kc]": 9, "dziesiat[kc]": 10, "jedenast[kc]": 11,
              "dwunast[kc]": 12}
ORDINALS = {"pierwsz": 1, "drug": 2, "trzec": 3, "czwart": 4, "piat": 5, "szost": 6, "siodm": 7, "osm": 8,
            "dziewiat": 9, "dziesiat": 10, "jedenast": 11, "dwunast": 12, "trzynast": 13, "czternast": 14,
            "pietnast": 15}


# „powiedz następnemu, że …”, „przekaż zmiennikowi …”, „notatka dla następnego kierowcy: …”
NEXT_DRIVER_RE = re.compile(
    r"(?i)(?:\b(?:powiedz|przeka[żz](?:cie)?)\s+(?:nast[ęe]pnemu|kolejnemu|zmiennikowi)(?:\s+kierowcy)?"
    r"|(?:\b(?:zanotuj|zapisz|notatka)\s+)?\bdla\s+(?:(?:nast[ęe]pnego|kolejnego)\s+kierowcy|zmiennika))\b"
    r"[\s,:\-]*(?:(?:że|ze)\b)?[\s,:]*(?P<note>.*)$", re.S)


def fold(text: str) -> str:
    """Małe litery, bez polskich znaków i interpunkcji: 'Ile mam paliwa?' -> 'ile mam paliwa'."""
    t = text.lower().replace("ł", "l")
    t = "".join(c for c in unicodedata.normalize("NFD", t) if unicodedata.category(c) != "Mn")
    t = re.sub(r"[^a-z0-9%,. ]+", " ", t)
    t = re.sub(r"\b(" + "|".join(NUM_WORDS) + r")\b", lambda m: str(NUM_WORDS[m.group(1)]), t)
    t = re.sub(r"\b(te|tee|ti)\s+(\d{1,2})\b", r"t\2", t)       # "te pięć" -> t5
    t = re.sub(r"\bt\s+(\d{1,2})\b", r"t\1", t)
    t = t.replace("pod sterow", "podsterow").replace("nad sterow", "nadsterow")
    return re.sub(r"\s+", " ", t).strip()


def has(t: str, *words: str) -> bool:
    return any(w in t for w in words)


def corner_number(t: str, n_corners: int) -> Optional[int]:
    """Numer zakrętu (1..n) z wypowiedzi albo None."""
    m = re.search(r"\bt(\d{1,2})\b", t) or re.search(r"\bzakre\w*\s+(?:nr\.?\s*|numer\s*)?(\d{1,2})\b", t)
    if m:
        k = int(m.group(1))
        return k if 1 <= k <= n_corners else None
    if "przedostatni" in t and n_corners > 1:
        return n_corners - 1
    if "ostatni" in t and n_corners:
        return n_corners
    for stem, k in COLLOQUIAL.items():
        if re.search(r"\b" + stem, t) and k <= n_corners:
            return k
    if "zakre" in t or "nawrot" in t or "szykan" in t:
        for stem, k in ORDINALS.items():
            if re.search(r"\b" + stem, t) and k <= n_corners:
                return k
    return None


def phase_from(t: str) -> Optional[str]:
    if has(t, "wejsci", "hamowan", "hamuj", "dohamow", "wjezdz", "wchodz", "turn in", "skrecani"):
        return "entry"
    if has(t, "wyjsci", "gaz", "wyjezdz", "przyspiesz", "wychodz"):
        return "exit"
    if has(t, "srodk", "apeks", "apex", "szczyt"):
        return "mid"
    return None


def claimed_balance(t: str) -> Optional[str]:
    if has(t, "podsterow", "nie skreca", "nie chce skrecic", "wypycha", "ucieka przod", "przod ucieka",
           "przod sie slizga", "jedzie prosto", "nie wchodzi w zakret", "slizga sie przod"):
        return "under"
    if has(t, "nadsterow", "ucieka tyl", "tyl ucieka", "zarzuca", "obraca", "tyl sie slizga", "kreci sie",
           "nerwow", "slizga sie tyl", "tyl wyjezdza", "tyl wychodzi"):
        return "over"
    return None


PHASE_PL = {"entry": "na wejściu", "mid": "w środku zakrętu", "exit": "na wyjściu"}

TECHNIQUE = {
    ("under", "entry"): "zacznij wcześniej i płynniej odpuszczać hamulec, skręcaj stopniowo",
    ("under", "mid"): "wejdź odrobinę wolniej, żeby przód złapał przyczepność, i nie dokładaj skrętu",
    ("under", "exit"): "otwieraj gaz płynniej i prostuj kierownicę, zanim dasz pełny gaz",
    ("over", "entry"): "mniej skrętu przy mocnym hamowaniu i skończ redukcje biegów wcześniej",
    ("over", "mid"): "nie zdejmuj gwałtownie gazu w środku zakrętu, trzymaj go równo",
    ("over", "exit"): "dawaj gaz później i stopniowo, przy mniejszym kącie skrętu",
}


def litres(x: float) -> str:
    n = int(round(x))
    return f"{n} {n_word(n, 'litr', 'litry', 'litrów')}"


def sentences(parts: list[str]) -> str:
    out = []
    for p in parts:
        p = p.strip()
        if p:
            out.append(p[0].upper() + p[1:])
    return ". ".join(out) + "." if out else ""


def n_word(n: float, one: str, few: str, many: str) -> str:
    n = int(round(n))
    if n == 1:
        return one
    if n % 10 in (2, 3, 4) and n % 100 not in (12, 13, 14):
        return few
    return many


# ----------------------------------------------------------------------------- odpowiedzi

class RuleEngineer:
    """Odpowiada na pytania bez AI. eng = engineer.core.Engineer."""

    def __init__(self, eng) -> None:
        self.eng = eng
        self.last_answer = ""
        self._tracing = False
        self._final = False
        self.trace: list[str] = []     # które funkcje odpowiedziały na ostatnie pytanie (dziennik diagnostyczny)

    def __getattribute__(self, name):
        if name[:1] != "_" and name not in ("eng", "trace", "last_answer") and object.__getattribute__(self, "_tracing"):
            tr = object.__getattribute__(self, "trace")
            if len(tr) < 8:
                tr.append(name)
        return object.__getattribute__(self, name)

    # -- pomocnicze ----------------------------------------------------------
    def _snap(self):
        return self.eng.snap

    def _fuel(self):
        s = self._snap()
        return fuel_report(s, self.eng.laps, self.eng.fuel_margin_laps) if s else None

    def _handling(self):
        return analyze_handling(self.eng.laps, self.eng.corners)

    # -- tematy --------------------------------------------------------------
    def fuel(self, t: str) -> str:
        fr = self._fuel()
        if fr is None:
            return "Nie mam jeszcze danych z auta."
        if fr.per_lap_l is None:
            return f"Masz {litres(fr.fuel_l)} paliwa. Zużycie policzę po pierwszym czystym okrążeniu."
        lt = fr.laps_in_tank
        txt = f"{litres(fr.fuel_l).capitalize()}, na {lt:.0f} {laps_word(round(lt))}."
        if fr.limiting == "VE" and fr.laps_on_ve is not None:
            txt += f" Energia skończy się wcześniej, za {fr.laps_on_ve:.0f} {laps_word(round(fr.laps_on_ve))}."
        if fr.fuel_to_add is not None:
            txt += f" Do mety brakuje {litres(fr.fuel_to_add)}." if fr.fuel_to_add > 0 else " Do mety starczy."
        return txt

    def energy(self, t: str) -> str:
        fr = self._fuel()
        if fr is None or fr.ve is None:
            return "To auto nie ma wirtualnej energii albo nie mam jeszcze danych."
        if not fr.ve_per_lap:
            return f"Energii jest {fr.ve * 100:.0f} procent. Zużycie policzę po pierwszym czystym okrążeniu."
        txt = (f"Energii {fr.ve * 100:.0f} procent, zużywasz {fr.ve_per_lap * 100:.1f} procent na okrążenie, "
               f"starczy na {fr.laps_on_ve:.1f} okrążenia.")
        if fr.ve_needed_to_finish is not None:
            miss = fr.ve_needed_to_finish - fr.ve
            txt += f" Do mety brakuje {miss * 100:.0f} procent." if miss > 0 else " Energii starczy do mety."
        return txt

    def pit(self, t: str) -> str:
        fr = self._fuel()
        if fr is None or fr.stint_laps_left is None:
            return "Potrzebuję jednego czystego okrążenia, żeby policzyć zużycie i okno zjazdu."
        left = fr.stint_laps_left
        last_lap_in = max(0, math.floor(left - 0.3))
        what = "energii" if fr.limiting == "VE" else "paliwa"
        if fr.laps_to_finish is not None and left >= fr.laps_to_finish + 0.3:
            return f"Nie musisz zjeżdżać, {what} starczy do mety."
        if last_lap_in == 0:
            txt = f"Zjeżdżaj na tym okrążeniu, {what} prawie nie ma."
        else:
            txt = (f"Zjazd najpóźniej za {last_lap_in} {n_word(last_lap_in, 'okrążenie', 'okrążenia', 'okrążeń')}, "
                   f"wtedy skończy się {'energia' if fr.limiting == 'VE' else 'paliwo'}.")
        if fr.laps_to_finish is not None:
            after = max(0.0, fr.laps_to_finish - left)
            parts = []
            if fr.per_lap_l:
                need = after * fr.per_lap_l + 0.3
                cap = fr.capacity_l or need
                if need > cap:
                    parts.append(f"paliwa potrzeba {litres(need)}, więcej niż bak, więc będą dwa postoje")
                else:
                    parts.append(f"zatankuj około {litres(need)}")
            if fr.ve_per_lap:
                ve_need = after * fr.ve_per_lap + 0.002
                parts.append("energii do pełna" if ve_need >= 0.98 else f"energii około {ve_need * 100:.0f} procent")
            if parts:
                txt += " Na postoju " + " i ".join(parts) + ", żeby dojechać do mety."
        return txt

    def finish(self, t: str) -> str:
        s = self._snap()
        if s is None:
            return "Nie mam danych o sesji."
        fr = self._fuel()
        parts = []
        if s.time_remaining is not None:
            from .plnum import plural, duration
            # czas trwania słowami ("godzina i dwadzieścia siedem minut"), nie zegarem ("pierwsza dwadzieścia siedem")
            rem = s.time_remaining if s.time_remaining < 3600 else round(s.time_remaining / 60) * 60
            parts.append(f"Do końca sesji {duration(rem)}")
        if fr and fr.laps_to_finish is not None:
            n = fr.laps_to_finish
            parts.append(f"to około {math.ceil(n)} {n_word(math.ceil(n), 'okrążenie', 'okrążenia', 'okrążeń')}")
        elif s.max_laps:
            ps = s.player_scoring()
            if ps:
                n = s.max_laps - ps.laps_done
                parts.append(f"zostało {n} {n_word(n, 'okrążenie', 'okrążenia', 'okrążeń')}")
        return (", ".join(parts) + ".") if parts else "Nie wiem, ile zostało do końca."

    def laptimes(self, t: str) -> str:
        clean = [l for l in self.eng.laps if l.clean]
        if not clean:
            return "Nie mam jeszcze czystego okrążenia."
        last = self.eng.laps[-1]
        best = min(l.lap_time for l in clean)
        txt = f"Ostatnie {spoken_lap(last.lap_time)}"
        if last.clean and len(clean) > 1:
            d = last.lap_time - best
            txt += ", najlepsze okrążenie." if d <= 0.001 else f", {spoken_delta(d)} do najlepszego."
        else:
            txt += "."
        txt += f" Najlepsze {spoken_lap(best)}."
        recent = clean[-3:]
        if len(recent) >= 3:
            spread = max(l.lap_time for l in recent) - min(l.lap_time for l in recent)
            txt += f" Rozrzut ostatnich trzech {spread:.1f} sekundy."
        from .analysis.corners import theoretical_best
        tb = theoretical_best(self.eng.laps, self.eng.corners)
        if tb and 0.15 <= best - tb < 8:
            txt += f" W najlepszych odcinkach masz {best - tb:.1f} sekundy do znalezienia."
        return txt

    def where_lose(self, t: str) -> str:
        deltas = self.eng.last_deltas
        k = corner_number(t, len(self.eng.corners))
        if not deltas:
            return "Potrzebuję jeszcze jednego czystego okrążenia do porównania z najlepszym."
        if k is not None:
            d = next((x for x in deltas if x.corner.name == f"T{k}"), None)
            if d is None:
                return f"Nie mam porównania dla T{k}."
            if d.time_loss < 0.05:
                return f"W T{k} jesteś na poziomie najlepszego okrążenia."
            why = (": " + " i ".join(d.reasons)) if d.reasons else ""
            return f"W T{k} tracisz {spoken_delta(d.time_loss).replace('plus ', '')}{why}."
        ranked = [d for d in sorted(deltas, key=lambda x: -x.time_loss) if d.time_loss >= 0.05]
        ranked = [d for d in ranked if d.time_loss >= 0.08]
        if not ranked:
            return "Ostatnie okrążenie było równe z najlepszym we wszystkich zakrętach."
        out = []
        for d in ranked[:2]:
            why = (", " + d.reasons[0]) if d.reasons else ""
            out.append(f"{d.corner.name} {spoken_delta(d.time_loss).replace('plus ', '')}{why}")
        if len(ranked) > 2:
            import time as _t
            from .analysis.suggest import LAST_FULL
            LAST_FULL["text"] = ", ".join(f"{d.corner.name} {d.time_loss:.2f} s".replace(".", ",") for d in ranked)
            LAST_FULL["t"] = _t.monotonic()
            return f"Tracisz w {len(ranked)} zakrętach, najwięcej: " + "; ".join(out) + "."
        return "Najwięcej tracisz: " + "; ".join(out) + "."

    def corner_info(self, t: str, k: int) -> str:
        rep = self._handling()
        parts = []
        d = next((x for x in self.eng.last_deltas if x.corner.name == f"T{k}"), None)
        if d is not None:
            if d.time_loss >= 0.05:
                parts.append(f"W T{k} tracisz {spoken_delta(d.time_loss).replace('plus ', '')}"
                             + (": " + " i ".join(d.reasons) if d.reasons else ""))
            else:
                parts.append(f"W T{k} czas jak na najlepszym okrążeniu")
        if rep:
            c = next((x for x in rep.corners if x.position == k), None)
            if c is not None:
                probs = [(ph, getattr(c, ph)) for ph in ("entry", "mid", "exit")
                         if getattr(c, ph) is not None and (getattr(c, ph) >= UNDER or getattr(c, ph) <= OVER)]
                if probs:
                    parts.append("auto ma " + ", ".join(f"{label(v)} {PHASE_PL[ph]}" for ph, v in probs))
                else:
                    parts.append("balans auta jest tam neutralny")
        return sentences(parts) if parts else f"Nie mam jeszcze danych dla T{k}."

    def _rival(self, ahead: bool) -> str:
        s = self._snap()
        if s is None or s.session != "race":
            best = self.eng.rivals.class_best_laps(s) if s else []
            if best:
                ps = s.player_scoring()
                me = ps.best_lap if ps else 0
                top = best[0]
                txt = f"Najszybszy w klasie {top.driver.split()[-1]}, {spoken_lap(top.best_lap)}."
                if me > 0:
                    txt += f" Ty tracisz do niego {me - top.best_lap:.1f} sekundy." if me > top.best_lap else " To Ty."
                return txt
            return "Nie mam danych o rywalach."
        rv = self.eng.rivals.rivals(s, ahead=1 if ahead else 0, behind=0 if ahead else 1)
        rv = [r for r in rv if (r.gap_s is not None and (r.gap_s < 0) == ahead) or r.laps_diff]
        if not rv:
            return "Przed Tobą nikogo w klasie, prowadzisz." if ahead else "Za Tobą nikogo w klasie."
        r = rv[0]
        name = r.car.driver.split()[-1] if r.car.driver else "rywal"
        if r.laps_diff:
            return f"{name}, {abs(r.laps_diff)} {n_word(abs(r.laps_diff), 'okrążenie', 'okrążenia', 'okrążeń')} {'przed' if ahead else 'za'} Tobą."
        if abs(r.gap_s) < 0.4:
            txt = f"{name}, tuż {'przed' if ahead else 'za'} Tobą"
        else:
            txt = f"{name}, {abs(r.gap_s):.1f} sekundy {'przed' if ahead else 'za'} Tobą"
        if r.pace_diff is not None and abs(r.pace_diff) >= 0.05:
            faster = r.pace_diff < 0
            txt += f", jedzie {abs(r.pace_diff):.1f} na okrążenie {'szybciej' if faster else 'wolniej'}"
        if r.trend is not None and abs(r.trend) >= 0.1:
            txt += f", przewaga {'rośnie' if r.trend > 0 else 'maleje'}"
        if r.laps_to_catch is not None and r.laps_to_catch < 20:
            n = round(r.laps_to_catch)
            txt += (f", dogonisz go za około {n} {n_word(n, 'okrążenie', 'okrążenia', 'okrążeń')}" if ahead
                    else f", dogoni Cię za około {n} {n_word(n, 'okrążenie', 'okrążenia', 'okrążeń')}")
        if r.car.in_pits:
            txt += ", teraz jest w boksie"
        return txt + "."

    def position(self, t: str) -> str:
        s = self._snap()
        ps = s.player_scoring() if s else None
        if not ps:
            return "Nie mam danych o pozycji."
        cp, cn = self.eng.rivals.class_position(s)
        return f"Jesteś {cp}. w klasie {ps.car_class} na {cn}, {ps.place}. w klasyfikacji ogólnej."

    def tyres(self, t: str) -> str:
        s = self._snap()
        if s is None or s.player is None:
            return "Nie mam danych o oponach."
        ty = s.player.tyres
        avg = [sum(x.temp_c) / 3 for x in ty]
        opt = ty[0].optimal_c
        front, rear = (avg[0] + avg[1]) / 2, (avg[2] + avg[3]) / 2
        txt = f"Opony: przód {front:.0f}, tył {rear:.0f} stopni"
        if opt > 0:
            txt += f", optimum około {opt:.0f}"
        names = ["lewej przedniej", "prawej przedniej", "lewej tylnej", "prawej tylnej"]
        k = max(range(4), key=lambda i: ty[i].wear)
        txt += f". Najmniej zostało na {names[k]}: {(1 - ty[k].wear) * 100:.0f} procent."
        if has(t, "cisnien") and ty[0].pressure_kpa > 0:
            txt += (f" Ciśnienia: przód {(ty[0].pressure_kpa + ty[1].pressure_kpa) / 2:.0f}, "
                    f"tył {(ty[2].pressure_kpa + ty[3].pressure_kpa) / 2:.0f} kilopaskali.")
        rep = self._handling()
        notes = [f"{tf.wheel}: {n}" for tf in (rep.tyres if rep else []) for n in tf.notes][:2]
        if notes:
            txt += " " + ". ".join(notes).replace("LP", "Lewa przednia").replace("PP", "Prawa przednia") \
                .replace("LT", "Lewa tylna").replace("PT", "Prawa tylna") + "."
        return txt

    def compare_temps(self, t: str) -> str:
        """„Porównaj temperatury opon i hamulców z tego okrążenia i 4. okrążenia po pitstopie.”"""
        laps = [l for l in self.eng.laps if l.tyre_temps and l.brake_max and not l.incomplete]
        if len(laps) < 2:
            return "Mam za mało okrążeń z temperaturami, żeby porównać."
        now = next((l for l in reversed(laps) if not l.pit), laps[-1])
        m = re.search(r"(\d{1,2})\D{0,25}(?:po|od)\s+(?:pit|postoj|zjezdzie|zjazd|boks)", t)
        L = self.eng.laps
        outs = [i for i, l in enumerate(L) if l.pit and not (i + 1 < len(L) and L[i + 1].pit)]
        if not m and has(t, "poprzedni", "wczesniejsz", "ostatni stint") and outs:
            idx_now = len(L) - 1 - L[::-1].index(now)
            last = max((o for o in outs if o <= idx_now), default=None)
            if last is not None:
                m = re.match(r"(\d+)", str(idx_now - last + 1) + " po postoju")
        if m:
            n = int(m.group(1))
            pits = [i for i, l in enumerate(self.eng.laps) if l.pit]
            ref = None
            for p in reversed(pits):                    # ostatni postój, po którym było już n okrążeń
                if p + 1 < len(self.eng.laps) and self.eng.laps[p + 1].pit:
                    continue                            # środek postoju (wjazd + wyjazd) – liczymy od okrążenia wyjazdowego
                k = p + n - 1
                if k < len(self.eng.laps) and self.eng.laps[k] is not now and self.eng.laps[k].tyre_temps:
                    ref = self.eng.laps[k]
                    break
            if ref is None:
                return f"Nie mam jeszcze {n}. okrążenia po postoju z temperaturami."
            label = f"{n}. okrążeniem po postoju" + (" w poprzednim stincie" if has(t, "poprzedni", "wczesniejsz") else "")
        else:
            nums = [int(x) for x in re.findall(r"\b(\d{1,3})\b", t)]
            ref = next((l for l in laps if nums and l.lap == nums[0]), None) or laps[0]
            label = f"okrążeniem {ref.lap}"

        def tyre(l, i):
            return sum(l.tyre_temps[i]) / len(l.tyre_temps[i])
        fr = lambda l: max(l.brake_max[0], l.brake_max[1])
        rr = lambda l: max(l.brake_max[2], l.brake_max[3])
        tf = lambda l: (tyre(l, 0) + tyre(l, 1)) / 2
        tr = lambda l: (tyre(l, 2) + tyre(l, 3)) / 2
        d = lambda a, b: f"{a:.0f} wobec {b:.0f}" + (f" ({a - b:+.0f})" if abs(a - b) >= 1 else "")
        txt = (f"Ostatnie okrążenie w porównaniu z {label}. Hamulce maks.: przód {d(fr(now), fr(ref))}, tył {d(rr(now), rr(ref))} stopni. "
               f"Opony średnio: przód {d(tf(now), tf(ref))}, tył {d(tr(now), tr(ref))} stopni")
        opt = now.tyre_optimal or ref.tyre_optimal
        txt += f", optimum około {opt:.0f}." if opt else "."
        # rada o chłodzeniu hamulców (orientacyjne okno dla stalowych hamulców GT3)
        f_now = fr(now)
        if f_now < 400:
            txt += " Przednie hamulce są chłodne, przymknięcie chłodzenia powinno je podgrzać."
        elif f_now > 750:
            txt += " Przednie hamulce są gorące, nie przymykaj chłodzenia."
        else:
            txt += " Hamulce są w normalnym zakresie; przymykaj chłodzenie najwyżej o jeden krok i sprawdź po kilku okrążeniach."
        return txt

    def brakes(self, t: str) -> str:
        s = self._snap()
        if s is None or s.player is None:
            return "Nie mam danych o hamulcach."
        b = [x.brake_c for x in s.player.tyres]
        bias = (1 - s.player.rear_brake_bias) * 100
        txt = (f"Hamulce: przód {max(b[0], b[1]):.0f}, tył {max(b[2], b[3]):.0f} stopni. "
               f"Balans {str(round(bias, 1)).replace('.', ',')} procent na przód.")
        r = getattr(self.eng, "rest", None)
        if r is not None and r.ok and r.brakes:
            left = min(r.brakes) * 100
            txt += " Zużycie klocków jeszcze niewielkie." if left >= 97 else f" Zostało najmniej {left:.0f} procent klocków."
        return txt

    def weather(self, t: str) -> str:
        s = self._snap()
        if s is None:
            return "Nie mam danych o pogodzie."
        if has(t, "temperatur", "ile stopni") and not has(t, "pogod", "deszcz", "pada", "prognoz", "opon", "hamulc"):
            txt = f"Tor {s.track_temp:.0f}, powietrze {s.air_temp:.0f} stopni."
            adv = self.eng.weather.last
            if adv is not None and adv.track_temp_trend_h is not None and abs(adv.track_temp_trend_h) >= 2:
                txt += (" Tor się nagrzewa" if adv.track_temp_trend_h > 0 else " Tor stygnie") + \
                    f", około {abs(adv.track_temp_trend_h):.0f} stopni na godzinę."
            return txt
        txt = f"Powietrze {s.air_temp:.0f}, tor {s.track_temp:.0f} stopni."
        if s.rain > 0.05:
            txt += f" Pada, intensywność {s.rain * 100:.0f} procent."
        else:
            txt += " Nie pada."
        if s.wetness > 0.02:
            txt += f" Wilgotność toru {s.wetness * 100:.0f} procent."
        adv = self.eng.weather.last
        if adv is not None:
            if abs(adv.trend_per_lap) >= 0.005:
                txt += (" Rośnie" if adv.trend_per_lap > 0 else " Spada") + \
                    f" o {abs(adv.trend_per_lap) * 100:.1f} punktu na okrążenie."
            if adv.text:
                txt += " " + adv.text
            if adv.track_temp_trend_h is not None and abs(adv.track_temp_trend_h) >= 2:
                txt += f" Temperatura toru zmienia się o {adv.track_temp_trend_h:+.0f} stopni na godzinę."
        eta = getattr(self.eng.weather, "dry_eta", None)
        if eta is not None:
            txt += f" Tor przesycha, slicki będą szybsze za około {eta:.0f} minut." if eta >= 1 else \
                " Tor już na tyle suchy, że slicki są szybsze."
        r = getattr(self.eng, "rest", None)
        fc = r.forecast_text() if r is not None and r.ok else ""
        if has(t, "prognoz") and fc:
            return fc
        if fc:
            txt += " " + fc
        return txt

    def engine(self, t: str) -> str:
        e = self.eng.engine
        if e.water <= 0:
            return "Nie mam danych o temperaturach silnika."
        return e.report().text[0].upper() + e.report().text[1:] + "."

    def fatigue(self, t: str) -> str:
        rep = self.eng.fatigue.last
        if rep is None or rep.level == "za mało danych":
            mins = rep.minutes if rep else 0
            return f"Jedziesz {mins:.0f} minut. Za mało czystych okrążeń w tym stincie, żeby ocenić tempo."
        if rep.level == "ok":
            txt = f"Tempo trzymasz, zmęczenia nie widać. Jedziesz {rep.minutes:.0f} minut."
        else:
            txt = f"Widzę pierwsze oznaki zmęczenia: {', '.join(rep.reasons) or 'gorsza powtarzalność'}."
        if rep.pace_drop is not None:
            txt += f" Różnica tempa do początku stintu {rep.pace_drop:+.1f} s."
        return txt

    def trends(self, t: str) -> str:
        """Jak zmieniło się zużycie w ostatnich okrążeniach i co z tego wynika."""
        stint = [l for l in self.eng._stint_laps() if l.clean]
        if len(stint) < 4:
            return "Za mało czystych okrążeń w tym stincie, żeby ocenić zmiany zużycia."
        early, recent = stint[:-3], stint[-3:]
        parts = []
        ve_r = [l.ve_used for l in recent if l.ve_used]
        ve_e = [l.ve_used for l in early if l.ve_used]
        if ve_r and ve_e:
            r, e = sum(ve_r) / len(ve_r) * 100, sum(ve_e) / len(ve_e) * 100
            parts.append(f"Energia: ostatnie 3 okrążenia {r:.1f}% na okrążenie, wcześniej w stincie {e:.1f}%.")
        fr_ = [l.fuel_used for l in recent if l.fuel_used > 0]
        fe = [l.fuel_used for l in early if l.fuel_used > 0]
        if fr_ and fe:
            parts.append(f"Paliwo: {sum(fr_) / len(fr_):.2f} l, wcześniej {sum(fe) / len(fe):.2f} l na okrążenie.")
        if len(recent[-1].wear_tyres) == 4 and len(stint[0].wear_tyres) == 4:
            names = ["lewy przód", "prawy przód", "lewy tył", "prawy tył"]
            n = len(stint) - 1
            rates = [(recent[-1].wear_tyres[k] - stint[0].wear_tyres[k]) / n * 100 for k in range(4)]
            k = max(range(4), key=lambda i: rates[i])
            parts.append(f"Opony: najszybciej zużywa się {names[k]}, {rates[k]:.1f}% na okrążenie.")
        fr = self._fuel()
        if fr and fr.stint_laps_left is not None:
            n = int(fr.stint_laps_left)
            parts.append(f"Przy tym zużyciu zostało około {n} {laps_word(n)} do zjazdu.")
        return " ".join(parts) if parts else "Nie widzę zmian zużycia."

    def top_speed(self, t: str) -> str:
        """Prędkość maksymalna: auto przed / za Tobą, klasa (hypercar, LMP2, GT3) albo zestawienie."""
        s = self._snap()
        player = s.player_scoring() if s else None
        if s is None or player is None:
            return "Nie mam danych o prędkościach."
        rv = self.eng.rivals
        from .plnum import plural
        kmh = lambda v: f"{v:.0f} {plural(int(round(v)), 'kilometr', 'kilometry', 'kilometrów')} na godzinę"
        mine, mine_best = rv.top_speed(player.car_id)
        name = lambda c: (c.driver.split()[-1] if c.driver else c.vehicle) or "rywal"
        cls_word = next((c for w, c in (("hiperkar", "hyper"), ("hypercar", "hyper"), ("lmp2", "lmp2"), ("lmp 2", "lmp2"),
                                        ("lmp3", "lmp3"), ("gt3", "gt3"), ("gt 3", "gt3"), ("gte", "gte"), ("gt4", "gt4"))
                         if w in t), None)
        if cls_word:
            cars = [c for c in s.cars if cls_word in c.car_class.lower().replace(" ", "")]
            if not cars:
                return f"Nie ma na torze aut tej klasy."
            rows = sorted(((rv.top_speed(c.car_id)[0], c) for c in cars), key=lambda r: -r[0])
            rows = [r for r in rows if r[0] > 0]
            if not rows:
                return "Jeszcze nie zmierzyłem ich prędkości, potrzebuję jednego okrążenia."
            avg = sum(r[0] for r in rows) / len(rows)
            txt = (f"Najszybszy w klasie {rows[0][1].car_class}: {name(rows[0][1])}, {kmh(rows[0][0])}. "
                   f"Średnio {avg:.0f}.")
            if mine:
                txt += f" Ty {mine:.0f}."
            return txt
        same = sorted([c for c in s.cars if c.car_class == player.car_class], key=lambda c: c.place)
        i = next((k for k, c in enumerate(same) if c.is_player), None)
        ahead = same[i - 1] if i else None
        behind = same[i + 1] if i is not None and i + 1 < len(same) else None

        def one(c, where):
            v, best = rv.top_speed(c.car_id)
            if not v:
                return f"{name(c)} {where}: jeszcze nie zmierzyłem."
            txt = f"{name(c)} {where}: {kmh(v)}"
            if mine:
                d = v - mine
                txt += ", tyle co Ty" if abs(d) < 2 else (f", o {abs(d):.0f} szybciej od Ciebie" if d > 0
                                                        else f", o {abs(d):.0f} wolniej od Ciebie")
            return txt + "."
        if has(t, "przede mna", "przed mna", "z przodu", "auto przed", "gonie"):
            return one(ahead, "przed Tobą") if ahead else "Przed Tobą nikogo w klasie."
        if has(t, "za mna", "z tylu", "goni mnie", "auto za"):
            return one(behind, "za Tobą") if behind else "Za Tobą nikogo w klasie."
        if has(t, "moja", "mam ", "ja ", "moje", "jaka mam") and not has(t, "rywal", "inn"):
            return f"Twoja maksymalna na ostatnim okrążeniu {kmh(mine)}, najlepsza {mine_best:.0f}." if mine \
                else "Jeszcze nie zmierzyłem, potrzebuję jednego okrążenia."
        rows = sorted(((rv.top_speed(c.car_id)[0], c) for c in same if not c.is_player), key=lambda r: -r[0])
        rows = [r for r in rows if r[0] > 0]
        parts = []
        if mine:
            parts.append(f"Twoja maksymalna {kmh(mine)}.")
        if ahead:
            parts.append(one(ahead, "przed Tobą"))
        if behind:
            parts.append(one(behind, "za Tobą"))
        if rows:
            parts.append(f"Najszybszy w klasie na prostej {name(rows[0][1])}, {rows[0][0]:.0f}.")
        return " ".join(parts) or "Jeszcze nie zmierzyłem prędkości, potrzebuję jednego okrążenia."

    def traffic(self, t: str) -> str:
        """„Za ile pierwszy hypercar będzie dublował?” – najbliższe auto szybszej klasy i za ile dojedzie."""
        s = self._snap()
        if s is None:
            return "Nie mam danych o innych klasach."
        cls = next((c for w, c in (("hiperkar", "hyper"), ("hypercar", "hyper"), ("lmp2", "lmp2"), ("lmp 2", "lmp2"),
                                   ("lmp3", "lmp3")) if w in t), None)
        rows = self.eng.rivals.faster_class_eta(s, cls)
        if not rows:
            return ("Żaden " + ("hypercar" if cls == "hyper" else "z szybszej klasy") +
                    " nie jest teraz za Tobą albo nie znam jeszcze ich tempa.")

        from .plnum import plural
        secs = lambda x: f"{int(round(x))} {plural(int(round(x)), 'sekundę', 'sekundy', 'sekund')}"

        def when(sec: float) -> str:
            if sec < 60:
                return "za około " + secs(sec)
            m = int(round(sec / 60))
            return f"za około {m} {plural(m, 'minutę', 'minuty', 'minut')}"
        c, eta, behind = rows[0]
        who = c.driver.split()[-1] if c.driver else c.vehicle
        txt = f"Pierwszy {c.car_class}, {who}, dojedzie do Ciebie {when(eta)}. Jest {secs(behind).replace('sekundę', 'sekundę')} za Tobą na torze."
        if len(rows) > 1:
            c2, eta2, _ = rows[1]
            txt += f" Następny {c2.car_class} {when(eta2)}."
        return txt

    def setup_feedback(self, t: str, direction: str) -> str:
        self.eng.note(f"kierowca czuje: {getattr(self, '_raw', t).strip()}")
        rep = self._handling()
        k = corner_number(t, len(self.eng.corners))
        phase = phase_from(t)
        kind = "podsterowność" if direction == "under" else "nadsterowność"
        if rep is None:
            fix = setup_rules.fix_for(phase or "mid", "średni", UNDER if direction == "under" else OVER, self._race())
            return (f"Przyjąłem, {kind}. Nie mam jeszcze pomiarów z czystych okrążeń. "
                    f"Na początek {TECHNIQUE[(direction, phase or 'mid')]}. Jeśli to nie pomoże: {fix}.")
        sign = 1 if direction == "under" else -1
        corners = [c for c in rep.corners if c.position == k] if k else rep.corners

        def strength(c: CornerHandling, ph: str) -> float:
            v = getattr(c, ph)
            return sign * v if v is not None else -9

        # faza: podana przez kierowcę albo ta, gdzie pomiar najmocniej pokazuje zgłoszony problem
        best = None
        for c in corners:
            for ph in ([phase] if phase else ["entry", "mid", "exit"]):
                s = strength(c, ph)
                if best is None or s > best[0]:
                    best = (s, c, ph)
        if best is None:
            return "Nie rozpoznałem zakrętu. Powiedz numer, na przykład T5, albo ostatni zakręt."
        s, c, ph = best
        v = getattr(c, ph)
        where = f"w {c.name}" if k else f"najmocniej w {c.name}"
        fix = setup_rules.fix_for(ph, c.speed_class, UNDER if direction == "under" else OVER, self._race())
        technique = TECHNIQUE[(direction, ph)]
        if v is None:
            return f"Nie mam pomiaru {where} {PHASE_PL[ph]}. Na początek {technique}. Jeśli się powtarza: {fix}."
        threshold = UNDER if direction == "under" else -OVER
        if s >= threshold:
            others = [x for x in rep.corners if x is not c and x.speed_class == c.speed_class
                      and strength(x, ph) >= threshold]
            txt = f"Zgadza się, pomiar {where} {PHASE_PL[ph]} też pokazuje {kind}."
            if not others and k:
                txt += (f" W innych {c.speed_class}ch zakrętach tego nie ma, więc najpierw technika: {technique}. "
                        f"Jeśli to nie pomoże, w setupie: {fix}.")
            else:
                txt += f" Proponuję: {fix}. Po trzech okrążeniach powiedz, czy jest lepiej."
            return txt
        opposite = sign * v <= -threshold
        if opposite:
            other = "nadsterowność" if direction == "under" else "podsterowność"
            return (f"Ciekawe, pomiar {where} {PHASE_PL[ph]} pokazuje raczej {other}. "
                    f"Możliwe, że tył ucieka i przez to auto pcha przodem, albo odwrotnie. "
                    f"Zrób jeszcze dwa okrążenia i powiedz dokładniej, kiedy to czujesz: na hamowaniu, w środku czy na gazie.")
        return (f"Pomiar {where} {PHASE_PL[ph]} nie pokazuje wyraźnej {('podsterowności' if direction == 'under' else 'nadsterowności')}, "
                f"balans jest bliski neutralnego. Najpierw technika: {technique}. Jeśli to się powtarza, spróbuj: {fix}.")

    def setup_general(self, t: str) -> str:
        tips = setup_rules.suggestions(self._handling(), self._race())
        if not tips:
            return "Na razie pomiary nie pokazują wyraźnego problemu. Powiedz, co czujesz i w którym zakręcie."
        return " ".join(tips[:2])

    def setup_change(self, t: str, raw: str) -> str:
        self.eng.note(f"zmiana setupu: {raw.strip()}")
        return "Przyjąłem zmianę. Zrób trzy czyste okrążenia i zapytaj, czy pomogło."

    def setup_result(self, t: str) -> str:
        if not self.eng.setup_changes:
            return "Nie mam zapisanej zmiany setupu. Powiedz, co zmieniłeś, zaczynając od słowa zmieniłem."
        idx, desc = self.eng.setup_changes[-1]
        before = [l for l in self.eng.laps[:idx] if l.clean][-3:]
        after = [l for l in self.eng.laps[idx:] if l.clean]
        if len(after) < 3:
            n = len(after)
            return f"Po zmianie mam {n} {n_word(n, 'czyste okrążenie', 'czyste okrążenia', 'czystych okrążeń')}, potrzebuję trzech."
        txt = ""
        if before:
            b = sum(l.lap_time for l in before) / len(before)
            a = sum(l.lap_time for l in after[-3:]) / 3
            d = a - b
            if abs(d) < 0.1:
                txt = "Średni czas praktycznie bez zmian."
            else:
                txt = f"Średni czas {'lepszy' if d < 0 else 'gorszy'} o {abs(d):.1f} sekundy."
        rb, ra = analyze_handling(before, self.eng.corners), analyze_handling(after, self.eng.corners)
        changes = []
        if rb and ra:
            for cb, ca in zip(rb.corners, ra.corners):
                for ph in ("entry", "mid", "exit"):
                    vb, va = getattr(cb, ph), getattr(ca, ph)
                    if vb is not None and va is not None and abs(va - vb) >= 0.3 and (abs(vb) >= 0.5 or abs(va) >= 0.5):
                        better = abs(va) < abs(vb)
                        changes.append((abs(va - vb), f"{cb.name} {PHASE_PL[ph]} {'lepiej' if better else 'gorzej'}, "
                                                      f"teraz {label(va)}"))
        if changes:
            changes.sort(key=lambda x: -x[0])
            txt += " Balans: " + "; ".join(c for _, c in changes[:3]) + "."
        else:
            txt += " Balans w zakrętach bez wyraźnej zmiany."
        self.eng.note(f"efekt zmiany „{desc}”: {txt.strip()}")
        return txt.strip()

    def strategy(self, t: str) -> str:
        plan = self.eng.plan()
        if plan is None:
            return "Potrzebuję jednego czystego okrążenia, żeby policzyć zużycie i plan postoju."
        sv = self.eng.saver.text()
        sv = (" " + sv) if sv else ""
        if plan.outline and has(t, "ile postoj", "do mety", "strategi", "calego wyscigu", "caly wyscig", "do konca"):
            return plan.outline + " " + (plan.short() or "") + sv
        return plan.speech() + sv

    def saving(self, t: str) -> str:
        sv = self.eng.saver.text()
        if sv:
            return sv + " Zdejmuj gaz chwilę przed hamowaniem na końcu długich prostych."
        return "Nie ma potrzeby oszczędzać, jedź normalnie. Powiem, gdy oszczędzanie da o jeden postój mniej."

    def _race(self) -> bool:
        s = self._snap()
        return bool(s is not None and s.session == "race")

    def rival_info(self, t: str, ahead: bool, focus: str) -> str:
        """Rywal przed / za Tobą w klasie: tempo, kiedy dogoni, kierowcy zespołu, opony na ostatnim postoju."""
        s = self._snap()
        if s is None:
            return "Nie mam danych o rywalach."
        import team.state as ts
        rows = ts.build(self.eng, s).get("rivals_table") or []
        me = next((i for i, r in enumerate(rows) if r["me"]), None)
        if me is None:
            return "Nie mam danych o rywalach."
        k = me - 1 if ahead else me + 1
        if not 0 <= k < len(rows):
            return "Przed Tobą nikogo w klasie, prowadzisz." if ahead else "Za Tobą nikogo w klasie."
        r, mine = rows[k], rows[me]
        name = r["name"].split()[-1] if r["name"] else "rywal"
        where = "przed Tobą" if ahead else "za Tobą"
        last = lambda n: n.split()[-1]
        if focus == "tyres":
            ty = r.get("tyres")
            if not r.get("stops"):
                return f"{name} {where} jeszcze nie zjeżdżał."
            if not ty:
                return f"{name} {where}: nie wiem na pewno, ile opon zmienił, postojów {r['stops']}."
            if ty["n"] == 0:
                return f"{name} {where}: na ostatnim postoju bez zmiany opon."
            return f"{name} {where}: około {ty['n']} opony na postoju numer {ty['stop']}."
        if focus == "team":
            ds = [d for d in r.get("drivers", []) if d["pace"]]
            if not ds:
                return f"W aucie {where} jedzie {name}, za mało okrążeń, żeby porównać kierowców."
            txt = f"W aucie {where} teraz jedzie {name}."
            if len(ds) == 1:
                return txt + f" Znam tylko jego tempo: {spoken_lap(ds[0]['pace'])}."
            best, worst = ds[0], ds[-1]
            txt += (f" Najszybszy {last(best['name'])}, {spoken_lap(best['pace'])}, najwolniejszy {last(worst['name'])}, "
                    f"o {worst['pace'] - best['pace']:.1f} sekundy wolniej.")
            return txt
        txt = f"{name} {where}"
        if r.get("gap") is not None:
            txt += f", {abs(r['gap']):.1f} sekundy"
        if r.get("pace"):
            txt += f", tempo {spoken_lap(r['pace'])}"
            if mine.get("pace"):
                d = r["pace"] - mine["pace"]
                if abs(d) >= 0.1:
                    txt += f", {abs(d):.1f} na okrążenie {'wolniej' if d > 0 else 'szybciej'} od Ciebie"
                else:
                    txt += ", tempo jak Twoje"
        else:
            txt += ", jego tempa jeszcze nie znam"
        if r.get("catch"):
            n = round(r["catch"])
            txt += (f". Dogonisz go za około {n} {laps_word(n)}" if ahead else f". Dogoni Cię za około {n} {laps_word(n)}")
        elif focus == "catch":
            txt += (". Przy obecnym tempie go nie dogonisz" if ahead else ". Przy obecnym tempie Cię nie dogoni")
        return txt + "."

    def rival_pits(self, t: str) -> str:
        s = self._snap()
        if s is None:
            return "Nie mam danych o rywalach."
        import team.state as ts   # ta sama tabela co na ścianie boksów
        rows = ts.build(self.eng, s).get("rivals_table") or []
        me = next((i for i, r in enumerate(rows) if r["me"]), None)
        if me is None:
            return "Nie mam danych o rywalach."
        want = []
        if not has(t, "za mna", "z tylu") and me > 0:
            want.append(("przed Tobą", rows[me - 1]))
        if not has(t, "przede mna", "przed mna", "z przodu") and me + 1 < len(rows):
            want.append(("za Tobą", rows[me + 1]))
        parts = []
        for where, r in want:
            name = r["name"].split()[-1]
            if r["in_pits"]:
                parts.append(f"{name} {where} jest teraz w boksie")
            elif r["pit_in"] is None:
                parts.append(f"{name} {where}: nie wiem, kiedy zjedzie")
            else:
                n = round(r["pit_in"])
                parts.append(f"{name} {where} zjedzie za około {n} {laps_word(n)}" if n >= 1 else f"{name} {where} zjeżdża teraz")
        mine = rows[me].get("pit_in")
        if mine is not None:
            parts.append(f"Ty za {round(mine)} {laps_word(round(mine))}")
        return ". ".join(parts) + "." if parts else "Nie mam danych o rywalach."

    def pit_times(self, t: str) -> str:
        pp = self.eng.strategist.params
        src = ("Zmierzyłem to na Twoich postojach na tym torze" if pp.learned else
               "Na razie to wartości startowe, zmierzę je przy Twoim pierwszym postoju")
        fr = self._fuel()
        r = getattr(self.eng, "rest", None)
        pe = (r.pit_estimate or {}) if r is not None and r.ok else {}
        game = f" Gra dla obecnych ustawień menu boksu szacuje postój na {float(pe['total']):.0f} sekund." if pe.get("total") else ""
        txt = game + (f" Przejazd aleją kosztuje około {pp.lane_loss_s:.0f} sekund, tankowanie {pp.refuel_l_per_s:.1f} litra na sekundę, "
               f"zmiana kompletu opon około {pp.tyre_s * 4:.0f} sekund")
        if fr and fr.ve is not None:
            txt += f", energia {pp.ve_pct_per_s:.1f} procent na sekundę"
        return (txt + f". {src}.").strip()

    def tyre_change(self, t: str) -> str:
        plan = self.eng.plan()
        if plan is None:
            return "Potrzebuję jeszcze okrążeń, żeby policzyć zużycie opon."
        tyres = plan.tyres
        if tyres is None:
            if not plan.stop_needed:
                return "Nie planujemy postoju, opony muszą dojechać do mety."
            return "Na tych oponach przejechałeś za mało okrążeń, żeby policzyć zużycie. Zapytaj za dwa okrążenia."
        head = "Opony zostają" if tyres.option == "bez zmiany opon" else \
            ("Zmień wszystkie cztery opony" if tyres.option == "wszystkie cztery" else f"Zmień {tyres.option} opony")
        return f"{head}: {tyres.reason}."

    def damage(self, t: str) -> str:
        from .analysis.damage_now import describe
        now = describe(self.eng.snap, getattr(self.eng, "rest", None))
        head = ""
        if now:
            head = "; ".join(now)
            head = head[0].upper() + head[1:] + ". "
        plan = self.eng.plan()
        d = plan.damage if plan else None
        if d is None:
            if now:
                return head + "Stratę zmierzę po dwóch czystych okrążeniach."
            return "Nie widzę uszkodzeń."
        if d.loss_per_lap is None:
            return head + (f"Uderzenie było na okrążeniu {d.lap}. Potrzebuję dwóch czystych okrążeń, "
                           f"żeby zmierzyć stratę, mam {d.laps_measured}.")
        txt = head + f"Uszkodzenie kosztuje około {d.loss_per_lap:.1f} sekundy na okrążenie"
        fr = self._fuel()
        if fr and fr.laps_to_finish is not None:
            txt += f", do mety około {d.loss_per_lap * fr.laps_to_finish:.0f} sekund"
        if plan.repair_s:
            txt += f". Naprawa trwa {plan.repair_s:.0f} sekund"
            if plan.repair_worth is not None:
                txt += ", opłaca się naprawiać" if plan.repair_worth else ", nie opłaca się naprawiać"
                if d.loss_per_lap > 0:
                    be = plan.repair_s / d.loss_per_lap
                    txt += f". Zwraca się po około {be:.0f} okrążeniach"
        else:
            txt += ". Powiedz, ile trwa naprawa w menu boksu, a policzę, czy się opłaca"
        return txt + "."

    def repair_time(self, t: str, secs: float) -> str:
        self.eng.strategist.repair_s = secs
        plan = self.eng.plan()
        d = plan.damage if plan else None
        if d is None or d.loss_per_lap is None:
            return f"Zapisałem, naprawa {secs:.0f} sekund. Ocenię, czy się opłaca, gdy zmierzę stratę."
        return self.damage(t)

    def tc_advice(self, t: str) -> str:
        """„Jakie mam mieć TC?” / „ile ABS?” – obecne ustawienie i rada z pomiaru (bez AI)."""
        p = self.eng.snap.player if self.eng.snap else None
        sug = getattr(self.eng, "suggest", None)
        rep = (lambda k: sug._repeated(k) if sug is not None else [])
        if re.search(r"\babs\b", t) and not re.search(r"\b(tc|traction|trakcj\w*)\b", t):
            cur = f"Masz ABS {p.abs}. " if p is not None and p.abs > 0 else ""
            locks = rep("lock_front") + rep("lock_rear")
            if rep("abs"):
                return cur + f"ABS dużo pracuje w {', '.join(rep('abs'))}. Spróbuj o jeden niżej albo hamuj trochę lżej."
            if locks:
                return cur + f"Blokujesz koła w {', '.join(dict.fromkeys(locks))}. ABS o jeden wyżej."
            return cur + "Hamowania wyglądają dobrze, zostaw ABS. Zmieniaj o jeden klik i oceniaj po trzech okrążeniach."
        cur = f"Masz TC {p.tc}. " if p is not None and p.tc > 0 else ""
        heavy, spin = rep("tc"), rep("spin")
        if heavy:
            return cur + (f"TC dużo pracuje na wyjściach z {', '.join(heavy)}. TC Cut o jeden niżej, mniej odetnie "
                          "mocy. Jeśli tył zacznie uciekać, wróć.")
        if spin:
            return cur + f"Koła buksują na wyjściach z {', '.join(spin)}. TC główne o jeden wyżej albo spokojniej z gazem."
        if cur:
            return cur + ("Na wyjściach nie widzę problemu, zostaw. Typowo 7-7-7, szybciej 6-6-6, w deszczu "
                          "9-9-9. Zmieniaj o jeden klik i powiedz „zmieniłem TC”, to ocenię.")
        return ("Typowy start to TC 7-7-7, szybciej 6-6-6, w deszczu 9-9-9. Po kilku okrążeniach powiem, "
                "czy TC za dużo pracuje.")

    # -- porównanie z innym kierowcą ---------------------------------------
    def _my_lap(self):
        return next((l for l in reversed(self.eng.laps) if l.clean and l.t and l.plausible()), None)

    def _who_target(self, t: str, raw: str):
        """('mate', nazwisko) dla kolegi z zespołu, ('rival', auto) dla rywala, ('mate', '') = najlepszy kolega."""
        from .analysis.teamlaps import name_match
        tl = getattr(self.eng, "teamlaps", None)
        if tl is not None:
            for n in tl.teammates():
                if name_match(raw, n):
                    return "mate", n
        s = self._snap()
        me = s.player_scoring() if s else None
        if me is not None:
            for c in s.cars:
                if c.is_player or not c.driver or c.car_class != me.car_class:
                    continue
                if name_match(raw, c.driver):
                    return "rival", c
        if has(t, "kolega", "kolegi", "kolega", "kolegą", "kolega z zespolu", "z zespolem", "zespolu", "partner",
               "zmiennik", "koledz"):
            return "mate", ""
        return None

    def compare_driver(self, t: str, raw: str) -> Optional[str]:
        if has(t, "bez porown", "wlacz porown", "wylacz porown", "nie porownuj") or \
                t.strip(" .!") in ("porownanie z zespolem", "porownanie z kolega", "porownania z zespolem"):
            return None
        tgt = self._who_target(t, raw)
        if tgt is None:
            return None
        kind, who = tgt
        lap = self._my_lap()
        self._final = True        # odpowiedź z danych – bez przekazywania do AI
        if kind == "mate":
            return self._compare_mate(lap, who)
        return self._compare_rival(t, who)

    def _compare_mate(self, lap, who: str) -> str:
        from .analysis.teamlaps import describe, first_name
        tl = getattr(self.eng, "teamlaps", None)
        if tl is None or tl.call is None:
            return "Porównanie z kolegą działa tylko z ustawionym zespołem."
        if lap is None:
            return "Potrzebuję Twojego czystego okrążenia do porównania."
        if not self.eng.corners:
            return "Nie mam jeszcze mapy zakrętów. Przejedź czyste okrążenie."
        tl.refresh(lap, force=True)
        f = tl.find(lap, who)
        nm = first_name(who) if who else "kolegów"
        if f is None:
            names = [first_name(n) for n in tl.teammates()]
            if not names:
                return "Nie mam jeszcze okrążeń kolegów z tego toru. Wysyłają się same po czystych okrążeniach."
            return (f"Nie mam okrążenia {nm if who else 'kolegi'} w podobnych warunkach: ta sama mieszanka, "
                    "podobne zużycie opon, paliwo i temperatura toru.")
        m, ref, strict = f
        text, full = describe(lap, m, ref, strict, self.eng.corners, spoken_lap)
        if full:
            import time as _t
            from .analysis.suggest import LAST_FULL
            LAST_FULL["text"], LAST_FULL["t"] = full, _t.monotonic()
        return text

    def _compare_rival(self, t: str, car) -> str:
        s = self._snap()
        me = s.player_scoring() if s else None
        rc = getattr(self.eng, "rival_corners", None)
        name = car.driver.split()[-1]
        if rc is None or me is None or not self.eng.corners:
            return "Nie mam jeszcze mapy zakrętów. Przejedź czyste okrążenie."
        res = rc.compare(me, car, self.eng.corners)
        if res is None:
            return (f"Nie mam jeszcze pełnego czystego okrążenia {'Twojego' if rc.best(me.car_id, me.driver) is None else name}"
                    " w moich danych.")
        my_t, his_t, rows = res
        slower = sorted([r for r in rows if r[1] >= 0.05], key=lambda r: -r[1])     # on wolniejszy
        faster = sorted([r for r in rows if r[1] <= -0.05], key=lambda r: r[1])      # on szybszy

        def lst(rs, word):
            if not rs:
                return ""
            tot = sum(abs(r[1]) for r in rs)
            top = []
            for r in rs[:2]:
                x = f"{r[0]} {spoken_delta(abs(r[1])).replace('plus ', '')}"
                if r[2] is not None and abs(r[2]) >= 3:
                    x += f", w środku {round(abs(r[2]))} km/h {'mniej' if r[2] < 0 else 'więcej'}"
                top.append(x)
            if len(rs) > 2:
                return (f"{word} w {len(rs)} zakrętach, razem {spoken_delta(tot).replace('plus ', '')}, "
                        f"najbardziej " + " i ".join(top))
            return f"{word} w " + " i ".join(top)
        head = f"Najlepsze okrążenia: Ty {spoken_lap(my_t)}, {name} {spoken_lap(his_t)}. "
        a, b = lst(slower, "Wolniejszy"), lst(faster, "Szybszy")
        parts = [a, b] if not has(t, "szybsz", "zyskuj", "lepsz") else [b, a]
        body = ". ".join(p for p in parts if p)
        import time as _t
        from .analysis.suggest import LAST_FULL
        LAST_FULL["text"] = (("wolniejszy: " + ", ".join(f"{r[0]} {r[1]:.2f} s" for r in slower)) if slower else "") + \
            (("; szybszy: " + ", ".join(f"{r[0]} {abs(r[1]):.2f} s" for r in faster)) if faster else "")
        LAST_FULL["text"] = LAST_FULL["text"].replace(".", ",").strip("; ")
        LAST_FULL["t"] = _t.monotonic()
        return head + (body + "." if body else "W zakrętach jedziecie równo.")

    def help(self, t: str) -> str:
        return ("Możesz pytać o paliwo, energię, kiedy zjazd, ile do końca, czasy okrążeń, gdzie tracisz, "
                "konkretny zakręt, rywala przed i za Tobą, pozycję, opony, hamulce, pogodę i deszczowe, "
                "jak zmieniło się zużycie, czy tempo spada, temperaturę silnika i grill. "
                "Możesz też powiedzieć, co czujesz w aucie, na przykład podsterowność na wejściu w ostatni zakręt, "
                "albo że coś zmieniłeś w setupie. Zapytaj o plan postoju, opony do zmiany i uszkodzenia. "
                "Powiedz bez dublowania, jeśli ostrzeżenia o dublowaniu przeszkadzają. "
                "Powiedz sugestie albo bez sugestii, żeby włączyć lub wyłączyć podpowiedzi ustawień.")

    # -- rozpoznawanie -------------------------------------------------------
    def answer(self, raw: str) -> Optional[str]:
        self._raw = raw
        t = fold(raw)
        self.trace = []
        self._final = False
        self._tracing = True
        try:
            a = self._route(t, raw)
        finally:
            self._tracing = False
        if a:
            self.last_answer = a
        return a

    def _route(self, t: str, raw: str) -> Optional[str]:
        if re.search(r"porown|szybsz|wolniejsz|zakret|inaczej|zyskuj|traci|jak jedzie|jak jechac|lepsz|gorsz|"
                     r"jak on|co robi|uczyc|nauczyc|podpatrz", t):
            a = self.compare_driver(t, raw)
            if a:
                return a
        if has(t, "porown", "porownaj", "roznic") and has(t, "temp", "opon", "hamulc") and \
                re.search(r"okrazen|pitstop|postoj|zjazd|teraz|tego|stint", t):
            return self.compare_temps(t)
        nxt = NEXT_DRIVER_RE.search(raw)
        if nxt:
            note = nxt.group("note").strip(" ,:.")
            if not note:
                return "Powiedz: powiedz następnemu i treść notatki."
            note = note[0].upper() + note[1:]
            notes = getattr(self.eng, "handover_notes", [])
            if note not in notes:
                self.eng.handover_notes = notes + [note]
            return "Przekażę następnemu kierowcy na odprawie."
        if re.search(r"\b(tc|traction|trakcj\w*|kontrol\w* trakcj\w*|abs)\b", t) and \
                re.search(r"\b(jak\w*|ile|co|czy|ustaw\w*|mam|dac|zmienic|podnies\w*|obniz\w*)\b", t) and \
                not has(t, "zmienilem", "zmienilam", "ustawilem", "dalem", "przestawilem"):
            return self.tc_advice(t)
        if has(t, "w ktorych", "ktore zakrety", "jakie zakrety", "w jakich zakretach", "wymien", "ktore to", "jakie to") \
                and len(t.split()) <= 6:
            import time as _t
            from .analysis.suggest import LAST_FULL
            if LAST_FULL["text"] and _t.monotonic() - LAST_FULL["t"] < 120:
                return LAST_FULL["text"] + "."
        if has(t, "powtorz", "jeszcze raz", "co mowiles", "nie uslyszalem"):
            return self.last_answer or "Nic jeszcze nie mówiłem."
        if has(t, "tylko pilne", "tylko gdy pytam", "tylko kiedy pytam", "mow tylko", "tylko na pytania",
               "przestan mowic", "cisza", "nie gadaj", "badz cicho", "wycisz"):
            self.eng.quiet = True
            return "Ok, tylko pilne i odpowiedzi."
        if has(t, "mozesz mowic", "wlacz komunikaty", "mow dalej", "gadaj"):
            self.eng.quiet = False
            return "Wracam do komunikatów o zmianach."
        if has(t, "co umiesz", "pomoc", "o co moge", "jak dziala"):
            return self.help(t)
        m = re.match(r"^\s*(zapamietaj|zapisz|notatka|zanotuj)\b[\s,:]*(.*)$", t)
        if m:
            words = raw.split(None, 1)
            note = words[1].strip(" ,:") if len(words) > 1 else ""
            if not note:
                return "Powiedz: zapamiętaj i treść notatki."
            self.eng.note(note)
            return "Zapisałem w pamięci zespołu."
        if has(t, "radio test", "radiotest", "radio-test", "test radia", "sprawdzenie radia", "slyszysz mnie", "czy mnie slychac", "radio check"):
            return "Słyszę Cię dobrze."
        if has(t, "zjedzie", "zjezdza", "zjazd rywal", "kiedy rywal", "kiedy zjada", "postoj rywal"):
            return self.rival_pits(t)
        if has(t, "dogonie", "go dogon", "dojde go", "dojade go", "kiedy dojde"):
            return self.rival_info(t, ahead=True, focus="catch")
        if has(t, "dogoni mnie", "mnie dogoni", "dogoni") and not has(t, "hypercar", "hiperkar", "lmp", "szybsza klasa"):
            return self.rival_info(t, ahead=False, focus="catch")
        if has(t, "opon") and has(t, "rywal", "przede mna", "przed mna", "za mna", "z tylu", "zmienil", "zmienili",
                                    "on ", "auto przed", "auto za"):
            return self.rival_info(t, ahead=not has(t, "za mna", "z tylu", "auto za"), focus="tyres")
        if has(t, "kierowc", "najszybsz", "najwolniejsz", "kto jedzie", "kto teraz jedzie") and \
                has(t, "zespol", "aucie", "przed", "za mna", "z tylu", "rywal", "najszybsz", "najwolniejsz", "kto jedzie"):
            return self.rival_info(t, ahead=not has(t, "za mna", "z tylu", "auto za"), focus="team")
        if has(t, "tempo rywal", "jakie tempo ma", "jak szybko jedzie", "tempo auta", "tempo tego"):
            return self.rival_info(t, ahead=not has(t, "za mna", "z tylu", "auto za"), focus="pace")
        if has(t, "bez sugest", "nie dawaj sugest", "wylacz sugest", "koniec sugest", "stop sugest"):
            self.eng.suggest.enabled = False
            return "Dobra, bez sugestii. Zapytaj, jeśli chcesz radę."
        if has(t, "sugest") and (len(t.split()) <= 3 or has(t, "wlacz", "daj", "mow")):
            self.eng.suggest.enabled = True
            return ("Dobra, sugestie włączone. Powiem, gdy coś będzie się powtarzać."
                    + ("" if self.eng.snap is None or self.eng.snap.session == "race"
                       else " W treningu podpowiem też zmiany w garażu."))
        if has(t, "bez trenera", "wylacz trenera", "trener wylacz", "bez podpowiedzi w zakretach"):
            self.eng.coach.enabled = False
            return "Dobra, bez podpowiedzi przed zakrętami."
        if has(t, "wlacz trenera", "trener wlacz", "podpowiedzi w zakretach") or t.strip() == "trener":
            self.eng.coach.enabled = True
            return "Trener włączony. Podpowiem przed zakrętem, gdy błąd się powtarza."
        if has(t, "porownan", "porownuj") and has(t, "zespol", "kolega", "kolegami", "kolegi"):
            on = not has(t, "bez", "wylacz", "nie porownuj")
            self.eng.compare_best.mate_enabled = on
            return ("Porównanie z zespołem włączone. Powiem przed zakrętem, gdzie kolega jest wyraźnie szybszy."
                    if on else "Dobra, bez podpowiedzi z okrążeń kolegów.")
        if has(t, "bez porownan", "wylacz porownan", "porownanie wylacz", "nie porownuj"):
            self.eng.compare_best.enabled = False
            return "Dobra, bez porównań z najlepszym okrążeniem."
        if has(t, "wlacz porownan", "porownanie wlacz", "porownuj z najlepsz") or t.strip() in ("porownanie", "porownania"):
            self.eng.compare_best.enabled = True
            return "Porównanie włączone. Powiem przed zakrętem, gdzie tracisz do najlepszego okrążenia."
        if has(t, "bez komentarzy", "wylacz komentarze", "nie komentuj", "bez komentowania"):
            self.eng.overtakes.enabled = False
            return "Dobra, nie komentuję wyprzedzeń."
        if has(t, "wlacz komentarze", "komentuj wyprzedz", "komentarze wlacz") or t.strip() == "komentarze":
            self.eng.overtakes.enabled = True
            return "Dobra, skomentuję wyprzedzenia, gdy pozycja się utrzyma."
        if has(t, "bez dublowania", "nie mow o dublowaniu", "wylacz dublowanie"):
            self.eng.hazards.lapping_on = False
            return "Dobra, nie mówię o dublowaniu. Ostrzeżenia o wypadkach zostają."
        if has(t, "mow o dublowaniu", "wlacz dublowanie", "dublowanie wlacz"):
            self.eng.hazards.lapping_on = True
            return "Wracam do ostrzeżeń o dublowaniu."

        # czas naprawy podany przez kierowcę: "naprawa trwa 45 sekund", "45 sekund naprawy"
        m = re.search(r"napraw\w*\s+(?:trwa\s+|zajmie\s+|to\s+|bedzie\s+)?(?:okolo\s+)?(\d{1,3})", t) or \
            re.search(r"(\d{1,3})\s*(?:sekund\w*|s)\s+napraw", t)
        if m:
            return self.repair_time(t, float(m.group(1)))
        if has(t, "uszkodz", "napraw", "rozbit", "ile trace na uszk"):
            return self.damage(t)
        if has(t, "ile trwa postoj", "ile kosztuje postoj", "przejazd przez boks", "przejazd aleja", "czas tankowania",
               "jak szybko tankuje", "ile trwa tankowanie", "ile trwa zmiana opon", "czasy postoju"):
            return self.pit_times(t)
        if has(t, "oszczedz", "lift", "jak oszczedzac", "ile oszczedzac"):
            return self.saving(t)
        if has(t, "strategi", "plan", "co na postoju", "co robimy na postoju", "co w boksie", "robimy w boks",
               "na pitstop", "na pit stop", "w pitstop", "na zjezdzie", "robimy na", "robimy w",
               "co zrobic na", "co robic na", "co robic w"):
            return self.strategy(t)
        if has(t, "ile opon", "ktore opony", "zmienic opony", "zmieniac opony", "zmiana opon", "zmieniamy opony",
               "zmienic gumy", "jakie opony zmienic"):
            return self.tyre_change(t)

        # setup
        if setup_rules.is_setup_change(raw) or has(t, "zmienilem", "ustawilem", "przestawilem", "dalem o"):
            return self.setup_change(t, raw)
        if has(t, "pomoglo", "pomaga", "lepiej po zmianie", "jak po zmianie", "czy jest lepiej", "zmiana pomogla"):
            return self.setup_result(t)
        bal = claimed_balance(t)
        if bal:
            return self.setup_feedback(t, bal)
        if has(t, "setup", "ustawien", "co zmienic", "co poprawic w aucie", "stabilizator", "skrzydl"):
            return self.setup_general(t)

        if has(t, "silnik", "temperatura wody", "woda", "olej", "grill", "chlodnic", "przegrz"):
            return self.engine(t)
        if has(t, "zmeczen", "zmeczony", "slabne", "opadam", "trzymam tempo", "czy zwalniam"):
            return self.fatigue(t)
        if has(t, "pogod", "deszcz", "pada", "mokr", "deszczow", "slick", "prognoz"):
            return self.weather(t)
        if has(t, "jak sie zmienia", "jak sie zmienilo", "zmiana zuzycia", "trend", "jak zuzycie", "zuzycie w ostatnich"):
            return self.trends(t)

        # strategia
        if has(t, "energi", " ve", "wirtualn") or t.startswith("ve"):
            return self.energy(t)
        if has(t, "zjazd", "zjechac", "pitstop", "pit stop", "box", "tankowa", "dolac", "postoj"):
            return self.strategy(t) if self.eng.plan() else self.pit(t)
        if has(t, "paliw", "benzyn", "bak", "tank", "starczy", "spalani", "zuzyci paliw", "plyn"):
            return self.fuel(t)
        if has(t, "do konca", "do mety", "ile zostalo", "ile okrazen", "ile czasu"):
            return self.finish(t)
        if has(t, "predkosc maks", "maksymaln", "vmax", "v max", "top speed", "na prostej", "najwyzsza predkosc",
               "ile ma na prost", "predkosci maks", "max predkosc", "maks predkosc") and \
                not re.search(r"\bt\d{1,2}\b|zakre|minimaln", t):
            return self.top_speed(t)

        # rywale i pozycja
        if has(t, "szybsza klasa", "hypercar", "hiperkar", "lmp", "dubluj", "dojezdza", "z tylu szybsz"):
            return self.traffic(t)
        if has(t, "przede mna", "przed mna", "z przodu", "auto przed", "gonie", "kogo gonie"):
            return self._rival(ahead=True)
        if has(t, "za mna", "z tylu", "goni mnie", "kto mnie goni", "auto za"):
            return self._rival(ahead=False)
        if has(t, "rywal", "przeciwnik", "konkurenc", "tempo rywal", "lider"):
            return self._rival(ahead=True)
        if has(t, "pozycj", "miejsc", "ktory jestem", "ktore jestem"):
            return self.position(t)

        # jazda
        k = corner_number(t, len(self.eng.corners))
        if k is not None and has(t, "okrazeni", "okrazen") and not has(t, "zakret", "zakrec", "nawrot", "szykan", "wiraz"):
            k = None   # "ostatnie okrążenie" to okrążenie, nie ostatni zakręt
        if has(t, "trace", "tracisz", "gdzie moge zyskac", "co poprawic", "gdzie zyskac", "jak jechac", "gdzie wolno"):
            return self.where_lose(t)
        if k is not None:
            return self.corner_info(t, k)
        if has(t, "czas", "okrazeni", "najlepsze", "tempo", "jak jade", "jak mi idzie", "delta"):
            return self.laptimes(t)

        # auto i warunki
        if has(t, "opon", "cisnieni", "gum", "temperatur opon", "camber"):
            return self.tyres(t)
        if has(t, "hamulc", "tarcz", "balans hamul") or re.search(r"\b\w{0,2}[ao]?mul[ck]\w*|\bhamolc|\bhomulc", t):
            # „homulców”, „amulce” – częste błędy rozpoznawania słowa „hamulców”
            return self.brakes(t)
        if has(t, "pogod", "deszcz", "pada", "mokr", "temperatur", "tor jest", "slick", "przejsciow"):
            return self.weather(t)
        return None
