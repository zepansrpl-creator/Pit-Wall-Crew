"""Teksty stron „Co potrafi” i „Instrukcja” w aplikacji. Format: lista (nagłówek, [akapity]).
Akapit zaczynający się od „• ” jest punktem listy."""

FEATURES: list[tuple[str, list[str]]] = [
    ("Pit Wall Crew w skrócie", [
        "Głosowy inżynier wyścigowy do Le Mans Ultimate i ściana boksów dla całego zespołu. Inżynier mówi tylko o tym, "
        "co coś zmienia, a na pytania odpowiada głosem. Zespół widzi wszystko na żywo w przeglądarce i słyszy inżyniera we własnej aplikacji.",
    ]),
    ("Pilne ostrzeżenia (od razu, krótko)", [
        "• Dublowanie przez szybszą klasę: „Hypercar, 2 sekundy”, grupy aut, z której strony.",
        "• Auto stojące albo bardzo wolne przed Tobą, auto poza torem.",
        "• Flagi (także żółte w sektorach), FCY, kary, limity toru, zielona flaga.",
        "• „Box, box” ok. 25 s przed metą okrążenia zjazdowego.",
    ]),
    ("Strategia", [
        "• Paliwo i energia wirtualna: na ile okrążeń starczy, plan postoju (ile zatankować, które opony), czas postoju.",
        "• Plan postoju 3 okrążenia wcześniej, przypomnienie na okrążeniu zjazdowym, gdzie wyjedziesz po postoju.",
        "• Oszczędzanie: gdy kilka procent mniej zużycia daje postój mniej – cel na okrążenie i kontrola po każdym okrążeniu.",
        "• FCY: czy opłaca się zjechać teraz. Uszkodzenia: ile sekund kosztują i czy naprawiać.",
        "• Opony: zużycie i temperatury, kiedy opłaca się nowy komplet, „opony w temperaturze” po zmianie, ciśnienia w nocy.",
        "• Pogoda: deszcz, przesychanie toru („slicki szybsze za ok. X minut”), kiedy zmienić opony.",
    ]),
    ("Rywale", [
        "• Odstęp i trend do aut przed i za Tobą w klasie, kiedy dogonisz albo kto Cię dogoni.",
        "• Prędkość maksymalna rywali na prostej (auto przed, za Tobą, najszybszy w klasie, inne klasy) w porównaniu z Twoją.",
        "• Tempo każdego kierowcy w aucie rywala, przewidywany postój rywala i jego opony.",
        "• Komentarz po wyprzedzeniu albo stracie pozycji – dopiero gdy pozycja utrzyma się 30 sekund.",
    ]),
    ("Trener i ustawienia", [
        "• Trener przed zakrętem, gdy błąd powtarza się na kolejnych okrążeniach (blokowanie, buksowanie, ABS/TC, gaz).",
        "• Porównanie z najlepszym okrążeniem na podobnych oponach: „T5: hamujesz 15 metrów wcześniej”.",
        "• Sugestie ustawień z kokpitu (balans, TC, ABS) w wyścigu, a w treningu także garażu (camber, kanały hamulców).",
        "• Opis odczuć głosem („podsterowność na wejściu w ostatni zakręt”) – inżynier sprawdza pomiar i radzi.",
        "• Zmęczenie kierowcy: spadek tempa, gorsza równość i błędy.",
    ]),
    ("Zespół", [
        "• Ściana boksów w przeglądarce (telefon, komputer): stan auta, mapa toru z autami, rywale, grafik stintów, radio zespołu.",
        "• Grafik liczony na żywo i powiadomienia na telefon (ntfy) ok. 30 minut przed Twoją zmianą i o deszczu.",
        "• Głosem: „powiadomienie na telefon Amadeusz: wstawaj, zaraz wsiadasz” – kolega od razu dostaje powiadomienie na telefon.",
        "• Wiadomości ze ściany do kierowcy (inżynier je czyta) i pytania „tylko tekst”.",
        "• Odprawa przy zmianie kierowcy: uszkodzenia, wyjazdy poza tor i uderzenia poprzednika, plan, notatki „powiedz następnemu …”; podsumowanie stintu.",
        "• Radio zespołu: gdy nie jedziesz, aplikacja odtwarza komunikaty inżyniera z auta zespołu (pilne słyszy tylko kierowca); na ścianie boksów „🔊 Słuchaj inżyniera”.",
        "• AI w chmurze (Groq, darmowe): rozpoznawanie mowy (Whisper) i odpowiedzi AI bez serwera i bez obciążania komputera gracza.",
        "• Opcjonalnie: serwer AI zespołu (Whisper i Bielik na własnym komputerze) i bot Discord.",
        "• Pamięć zespołu: notatki, które AI bierze pod uwagę („ABS 9 za mocny w deszczu”).",
        "• Link dla obserwatorów – tylko podgląd na żywo, bez radia i planu.",
    ]),
    ("Głos", [
        "• Polski głos z efektem radia, imię i styl inżyniera (profesjonalista, kumpel, twardziel, analityk).",
        "• Przycisk mówienia na kierownicy albo klawisz; naciśnięcie przerywa mowę inżyniera.",
        "• „Cisza” albo „Inżynier, cicho” – „Ok.” i całkowita cisza (także ostrzeżenia) do następnego naciśnięcia przycisku; „tylko pilne” – same ostrzeżenia i odpowiedzi. Tryb solo – ostrzejszy ton, bez zespołu.",
    ]),
]

MANUAL: list[tuple[str, list[str]]] = [
    ("Pierwsze uruchomienie", [
        "• W LMU raz: Ustawienia → Rozgrywka → Enable Plugins = ON.",
        "• Zespół: wpisz kod i hasło zespołu (od kolegów) albo kliknij „Utwórz nowy zespół…”. Kliknij „Sprawdź połączenie” "
        "i wybierz swoje imię. Kod i hasło podawajcie sobie tylko prywatnie.",
        "• Mikrofon i przycisk: wybierz mikrofon, „Test 3 s”, potem „Ustaw: naciśnij przycisk…” i naciśnij przycisk na kierownicy.",
        "• Głos: wybierz głos, tempo, efekt radia, imię i styl; „Odsłuchaj”.",
        "• Kliknij „Zapisz i uruchom ponownie”.",
    ]),
    ("W dniu wyścigu", [
        "• Każdy z zespołu ma włączoną aplikację Pit Wall Crew – także gdy nie jedzie. Program sam rozpoznaje, kto prowadzi auto.",
        "• AI: raz wklejcie darmowy klucz Groq na ścianie boksów (Zespół → AI zespołu). Serwer AI nie jest potrzebny.",
        "• Kto nie jedzie, ma włączoną aplikację – słyszy komunikaty inżyniera (radio zespołu). Na Discordzie rozmawiacie między sobą.",
        "• Ściana boksów: przycisk „Ściana boksów ↗” w aplikacji albo link/QR z zakładki Zespół na stronie.",
        "• Przed startem sprawdźcie: w aplikacji zielone „Zespół” i „AI: Groq”, na ścianie „na żywo”.",
    ]),
    ("Rozmowa z inżynierem", [
        "Trzymaj przycisk, mów, puść. Pytanie możesz też wpisać w aplikacji na stronie „Inżynier”. "
        "Pełna lista komend jest na stronie „Komendy”. Gdy reguły nie znają odpowiedzi, pytanie trafia do AI (Groq).",
    ]),
    ("Ściana boksów (strona)", [
        "• Na żywo: wyścig, postój, opony, pogoda, kierowca, mapa toru, rywale, grafik stintów, radio zespołu.",
        "• Grafik i plan: start wyścigu, plan stintów (kto, ile okrążeń, co na postoju); wklejanie planu z arkusza.",
        "• Zespół: kod, QR, kierowcy i tematy ntfy (przycisk Test), link dla obserwatorów.",
        "• Okrążenia (z pobieraniem CSV) i Pamięć zespołu.",
        "• Radio: „Do kierowcy” – inżynier przeczyta; „Zapytaj inżyniera” – odpowiedź głosem; „Zapytaj (tylko tekst)”; „Do pamięci”.",
    ]),
    ("Powiadomienia na telefon", [
        "• Zainstaluj darmową aplikację ntfy (Sklep Play / App Store).",
        "• Na ścianie boksów: zakładka Zespół → przy swoim imieniu kliknij 📱 – pokaże się Twój temat i kod QR.",
        "• W ntfy dotknij +, wpisz ten temat i Subskrybuj (albo zeskanuj kod QR).",
        "• Na ścianie kliknij Test przy swoim imieniu – na telefonie przyjdzie „Pit Wall Crew – test”.",
        "Powiadomienie przychodzi ok. 30 minut przed Twoją zmianą, a gdy zmiana przesunie się o 10 minut lub więcej – drugie.",
    ]),
    ("Grafik stintów (jedna osoba, przed wyścigiem)", [
        "• Ściana boksów → Zespół: dodaj kierowców i zapisz.",
        "• Grafik i plan → 1. Wyścig: start, długość, czas okrążenia → Zapisz.",
        "• 2. Szybki plan: okrążeń w stincie, kierowcy po kolei, podwójne stinty, opony → Rozpisz plan → popraw → Zapisz plan.",
        "• W wyścigu grafik przelicza się sam z prawdziwego tempa.",
    ]),
    ("Gdy coś nie działa", [
        "• Ściana boksów: „brak danych z gry” – czy u kierowcy działa aplikacja i jest zielone „Zespół”?",
        "• „Zły kod albo hasło zespołu” – popraw w zakładce Zespół, „Sprawdź połączenie”, „Zapisz”.",
        "• Inżynier nie słyszy – zakładka Mikrofon i przycisk: „Test 3 s”; w Windows: Prywatność → Mikrofon.",
        "• Nie słyszysz inżyniera, gdy nie jedziesz – Zespół: „Słuchaj inżyniera, gdy nie jadę”; aplikacja musi być włączona.",
        "• „AI: Groq – zły klucz” – wklej klucz ponownie na ścianie boksów (Zespół → AI zespołu).",
        "• Nie ma powiadomień – start wyścigu i kierowcy w planie, temat w ntfy, przycisk Test; włączona aplikacja u kogokolwiek z zespołu.",
        "• Bez internetu inżynier działa dalej sam i połączy się ponownie automatycznie.",
    ]),
    ("Aktualizacja", [
        "Aplikacja sama sprawdza aktualizacje przy starcie (zanim uruchomi inżyniera – nigdy w trakcie jazdy), "
        "pobiera nową wersję, podmienia pliki i uruchamia się ponownie. Ustawienia, dane i nagrania zostają. "
        "Wyłączysz to w Zaawansowanych; tam też „Sprawdź aktualizacje teraz”. Serwer AI aktualizuje się przy starcie.",
        "Ręcznie: rozpakuj nową paczkę do tego samego folderu (zastąp pliki). Numer wersji widać pod nazwą aplikacji, "
        "zmiany opisuje plik ZMIANY.md.",
    ]),
]
