"""Efekt radia zespołowego: brzmienie jak inżynier w słuchawkach kierowcy.

- pasmo przenoszenia jak w krótkofalówce (ok. 300–3400 Hz)
- podbicie środka (wyrazistość) i lekkie przesterowanie
- cichy szum w tle
- krótki szum otwarcia nadajnika na początku i "ogon" szumu z kliknięciem na końcu
Wszystko w numpy, bez dodatkowych programów.
"""

from __future__ import annotations

import numpy as np


def _band(n: int, sr: int, lo: float, hi: float, order: int = 4) -> np.ndarray:
    f = np.fft.rfftfreq(n, 1.0 / sr)
    f[0] = 1e-3
    return 1.0 / (1.0 + (lo / f) ** order) / (1.0 + (f / hi) ** order)


def _filter(x: np.ndarray, sr: int, lo: float, hi: float, presence_db: float = 0.0) -> np.ndarray:
    n = len(x)
    X = np.fft.rfft(x)
    H = _band(n, sr, lo, hi)
    if presence_db:
        f = np.fft.rfftfreq(n, 1.0 / sr)
        H = H * (1.0 + (10 ** (presence_db / 20) - 1.0) * np.exp(-((f - 1900.0) / 700.0) ** 2))
    return np.fft.irfft(X * H, n)


def _noise(n: int, sr: int, level: float, rng: np.random.Generator) -> np.ndarray:
    if n <= 0:
        return np.zeros(0)
    return _filter(rng.standard_normal(n), sr, 400, 3000) * level


def apply(x: np.ndarray, sr: int, strength: float = 1.0, seed: int = 1,
          open_: bool = True, close: bool = True) -> np.ndarray:
    """x: mono float -1..1. Zwraca przetworzony sygnał float -1..1 (dłuższy o szum otwarcia/zamknięcia).
    open_/close=False: bez otwarcia/zamknięcia nadajnika (środkowe zdania jednej wypowiedzi)."""
    if len(x) == 0:
        return x
    s = max(0.0, min(2.0, strength))
    rng = np.random.default_rng(seed)
    peak = np.max(np.abs(x)) or 1.0
    x = x / peak

    # 1. pasmo krótkofalówki (im mocniejszy efekt, tym węższe) + wyrazistość
    lo, hi = 300 + 120 * s, 3600 - 400 * s
    y = _filter(x, sr, lo, hi, presence_db=3.0 + 2.0 * s)

    # 2. kompresja i przesterowanie (radio "dociąga" głos do równego poziomu)
    y = y / (np.max(np.abs(y)) or 1.0)
    drive = 1.5 + 2.5 * s
    y = np.tanh(y * drive) / np.tanh(drive)
    # przesterowanie dodaje ostre harmoniczne — przycinamy je ponownie do pasma radia
    y = _filter(y, sr, lo * 0.8, hi + 400)
    y = y / (np.max(np.abs(y)) or 1.0)

    # 3. szum w tle podczas mówienia
    y = y + _noise(len(y), sr, 0.010 * s, rng)

    # 4. otwarcie nadajnika: krótki szum + kliknięcie; zamknięcie: ogon szumu i klik
    open_n, tail_n = int(0.07 * sr), int(0.16 * sr)
    burst_open = _noise(open_n, sr, 0.10 * s, rng) * np.linspace(1.0, 0.25, open_n)
    tail = _noise(tail_n, sr, 0.13 * s, rng) * np.concatenate([np.linspace(0.3, 1.0, tail_n // 3),
                                                                 np.linspace(1.0, 0.0, tail_n - tail_n // 3)])
    click = np.zeros(int(0.004 * sr))
    if len(click):
        click[0] = 0.5 * s
        click[1:3] = -0.3 * s
    gap = _noise(int(0.08 * sr), sr, 0.010 * s, rng)   # krótka pauza między zdaniami: tylko cichy szum tła
    head = [click, burst_open] if open_ else []
    end = [tail, click] if close else [gap]
    out = np.concatenate(head + [y] + end)

    # 5. poziom końcowy
    return out / (np.max(np.abs(out)) or 1.0) * 0.9


def write_wav(path: str, y: np.ndarray, sr: int) -> None:
    import wave
    pcm = (np.clip(y, -1, 1) * 32767).astype(np.int16)
    with wave.open(path, "wb") as w:
        w.setnchannels(1)
        w.setsampwidth(2)
        w.setframerate(sr)
        w.writeframes(pcm.tobytes())


def read_wav(path: str) -> tuple[np.ndarray, int]:
    import wave
    with wave.open(path, "rb") as w:
        sr, ch, sw = w.getframerate(), w.getnchannels(), w.getsampwidth()
        raw = w.readframes(w.getnframes())
    dtype = {1: np.uint8, 2: np.int16, 4: np.int32}[sw]
    a = np.frombuffer(raw, dtype=dtype).astype(np.float64)
    if sw == 1:
        a = (a - 128) / 128.0
    else:
        a /= float(2 ** (8 * sw - 1))
    if ch > 1:
        a = a.reshape(-1, ch).mean(axis=1)
    return a, sr
