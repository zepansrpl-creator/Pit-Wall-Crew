"""Głos inżyniera: kolejka komunikatów odtwarzana w osobnym wątku.

Silniki (pierwszy działający wygrywa, kolejność z konfiguracji):
- "edge":  edge-tts (polskie głosy neuronowe Microsoft, wymaga internetu) + pygame do odtwarzania
- "sapi":  pyttsx3 (głos systemu Windows, offline; polski tylko gdy zainstalowany pakiet mowy PL)
- "print": tylko tekst w konsoli
"""

from __future__ import annotations

import collections
import hashlib
import os
import tempfile
import threading
import time

from .plnum import speak as pl_speak


class Speaker:
    def __init__(self, engines: list[str], edge_voice: str = "pl-PL-MarekNeural", rate: str = "+10%",
                 volume: float = 1.0, cache_dir: str = os.path.join("cache", "voice"), pitch: str = "+0Hz",
                 radio: bool = True, radio_strength: float = 1.0, music: str = "",
                 music_volume: float = 0.18) -> None:
        self.pitch = pitch
        self.music = (music or "").strip()
        if self.music.lower() in ("brak", "none", "false", "off"):
            self.music = ""
        self.music_volume = music_volume
        self._music_loop = None
        self._music_root = cache_dir
        self.radio = radio
        self.radio_strength = radio_strength
        # (tekst, pilne, grupa): zwykły komunikat dzielimy na zdania tej samej grupy
        # 4. pole: (otwarcie nadajnika, zamknięcie) – szum krótkofalówki tylko na początku i końcu wypowiedzi
        self.items: collections.deque[tuple[str, bool, int, tuple]] = collections.deque()
        self.cv = threading.Condition()
        self._gid = 0
        self._current: tuple[str, bool, int] | None = None   # co właśnie mówimy
        self._pre: dict[str, tuple[threading.Event, list]] = {}  # tekst -> (gotowe, [plik])
        self.edge_voice = edge_voice
        self.rate = rate
        self.volume = volume
        mtag = ("_m" + hashlib.md5(f"{self.music}{music_volume:g}".encode()).hexdigest()[:6]) if self.music else ""
        tag = (edge_voice + rate + pitch + (f"_radio{radio_strength:g}" if radio else "") + mtag) \
            .replace("%", "p").replace("+", "_").replace("-", "m")
        self.cache_dir = os.path.join(cache_dir, tag)
        self.engine = "print"
        self._sapi = None
        self._playing_urgent = False
        for e in engines:
            if e == "edge" and self._init_edge():
                self.engine = "edge"
                break
            if e == "sapi" and self._init_sapi():
                self.engine = "sapi"
                break
            if e == "print":
                break
        self._thread = threading.Thread(target=self._run, daemon=True)
        self._thread.start()

    # ------------------------------------------------------------ silniki
    def _init_edge(self) -> bool:
        try:
            import edge_tts  # noqa: F401
            return self._init_mixer()
        except Exception:
            return False

    def _init_mixer(self) -> bool:
        try:
            import pygame
            if not pygame.mixer.get_init():
                pygame.mixer.init(frequency=24000, size=-16, channels=1)
            return True
        except Exception:
            return False

    def _init_sapi(self) -> bool:
        try:
            import pyttsx3  # noqa: F401
            if (self.radio or self.music) and not self._init_mixer():
                self.radio, self.music = False, ""
            return True  # właściwa inicjalizacja w wątku głosu (wymóg COM w Windows)
        except Exception:
            return False

    def _sapi_engine(self):
        if self._sapi is None:
            import pyttsx3
            self._sapi = pyttsx3.init()
            for v in self._sapi.getProperty("voices"):
                if "pl" in (v.id + v.name).lower() or "polish" in v.name.lower():
                    self._sapi.setProperty("voice", v.id)
                    break
        return self._sapi

    def _cache_path(self, text: str, ext: str) -> str:
        return os.path.join(self.cache_dir, hashlib.md5(text.encode("utf-8")).hexdigest() + ext)

    def _synth(self, text: str, path: str) -> None:
        """Synteza mowy do pliku: mp3 (edge) albo wav (głos Windows)."""
        tmp = f"{path}.{os.getpid()}.{threading.get_ident()}.part"   # osobny plik na proces i wątek
        if self.engine == "edge":
            import asyncio
            import edge_tts
            asyncio.run(edge_tts.Communicate(text, self.edge_voice, rate=self.rate, pitch=self.pitch).save(tmp))
        else:
            eng = self._sapi_engine()
            tmp = f"{path}.{os.getpid()}.part.wav"
            eng.save_to_file(text, tmp)
            eng.runAndWait()
        try:
            os.replace(tmp, path)
        except OSError:
            # plik właśnie odtwarza inny wątek / proces – gotowy już jest, wystarczy go użyć
            if not os.path.exists(path):
                raise
            try:
                os.remove(tmp)
            except OSError:
                pass

    @property
    def fx(self) -> bool:
        """Czy dźwięk trzeba przetworzyć (radio i/lub muzyka w tle)."""
        return bool(self.radio or self.music)

    def _loop(self, sr: int):
        if self._music_loop is None:
            from . import music
            self._music_loop = music.load(self.music, sr, os.path.dirname(self._music_root) or "cache")
            if self._music_loop is None:
                self.music = ""
        return self._music_loop

    def _radioize(self, src: str, dst: str, edges: tuple = (True, True)) -> None:
        """Muzyka w tle i efekt radia: wczytuje dźwięk, przetwarza i zapisuje jako wav."""
        import numpy as np
        import pygame
        from . import radio
        freq, _, channels = pygame.mixer.get_init()
        if src.endswith(".wav"):
            x, sr = radio.read_wav(src)
        else:
            arr = pygame.sndarray.array(pygame.mixer.Sound(src)).astype(np.float64)
            if arr.ndim > 1:
                arr = arr.mean(axis=1)
            x, sr = arr / 32768.0, freq
        if self.music:
            loop = self._loop(sr)
            if loop is not None:
                from . import music
                x = music.mix(x, sr, loop, self.music_volume, key=int(hashlib.md5(src.encode()).hexdigest()[:6], 16))
        y = radio.apply(x, sr, self.radio_strength, open_=edges[0], close=edges[1]) if self.radio else x
        tmp = f"{dst}.{os.getpid()}.{threading.get_ident()}.part.wav"
        radio.write_wav(tmp, y, sr)
        try:
            os.replace(tmp, dst)
        except OSError:
            if not os.path.exists(dst):
                raise
            try:
                os.remove(tmp)
            except OSError:
                pass

    def _render(self, text: str, cache: bool, edges: tuple = (True, True)) -> tuple[str, list[str]]:
        """Zwraca (plik do odtworzenia, pliki tymczasowe do usunięcia)."""
        raw_ext = ".mp3" if self.engine == "edge" else ".wav"
        if cache:
            os.makedirs(self.cache_dir, exist_ok=True)
            final = self._cache_path(text, ".radio.wav" if self.fx else raw_ext)
            if os.path.exists(final):
                return final, []
            raw = self._cache_path(text, raw_ext)
            if not os.path.exists(raw):
                self._synth(text, raw)
            if self.fx:
                self._radioize(raw, final)
            return final, []
        t0 = time.monotonic()
        raw = self._take_prefetched(text)
        pre = raw is not None
        if raw is None:
            fd, raw = tempfile.mkstemp(suffix=raw_ext)
            os.close(fd)
            self._synth(text, raw)
        t1 = time.monotonic()
        try:
            from engineer.debuglog import DBG
            DBG.log("tts", text=text[:60], secs=round(t1 - t0, 2), pre=pre, waited=pre)
        except Exception:
            pass
        if not self.fx:
            return raw, [raw]
        final = raw + ".radio.wav"
        self._radioize(raw, final, edges)
        return final, [raw, final]

    def _play(self, path: str) -> None:
        import pygame
        if path.endswith(".wav"):
            snd = pygame.mixer.Sound(path)
            snd.set_volume(self.volume)
            ch = snd.play()
            while ch is not None and ch.get_busy():
                time.sleep(0.02)
        else:
            pygame.mixer.music.load(path)
            pygame.mixer.music.set_volume(self.volume)
            pygame.mixer.music.play()
            while pygame.mixer.music.get_busy():
                time.sleep(0.02)
            pygame.mixer.music.unload()

    def _speak(self, text: str, cache: bool, edges: tuple = (True, True)) -> bool:
        if self.engine == "sapi" and not self.fx:
            eng = self._sapi_engine()
            eng.say(text)
            eng.runAndWait()
            return True
        path, temps = self._render(text, cache, edges)
        try:
            from engineer.debuglog import DBG
            if DBG.enabled:
                DBG.audio_out(path, text, urgent=cache)
            if not cache:
                # w trakcie przygotowywania zwykłego komunikatu przyszło pilne ostrzeżenie: ono pierwsze
                with self.cv:
                    if any(x[1] for x in self.items):
                        return False
            self._play(path)
            return True
        finally:
            for f in temps:
                try:
                    os.remove(f)
                except OSError:
                    pass

    def prerender(self, phrases: list[str]) -> None:
        """Nagrywa w tle stałe zdania ostrzeżeń, żeby potem odtwarzały się bez opóźnienia."""
        if self.engine != "edge":
            return

        def run():
            for ph in phrases:
                try:
                    from engineer import i18n
                    ph = i18n.speech(ph, urgent=True)
                    self._render(pl_speak(ph) if i18n.LANG == "pl" else ph, cache=True)
                except Exception:
                    return  # brak internetu: spróbujemy przy następnym uruchomieniu
        threading.Thread(target=run, daemon=True).start()

    # ------------------------------------------------------------ kolejka
    def _stop_playback(self) -> None:
        try:
            import pygame
            if pygame.mixer.get_init():
                pygame.mixer.stop()
                pygame.mixer.music.stop()
            if self.engine == "sapi" and self._sapi is not None:
                self._sapi.stop()
        except Exception:
            pass

    def stop(self) -> None:
        """Przerwij mówienie i wyczyść kolejkę (np. gdy kierowca wcisnął przycisk mówienia)."""
        from engineer.debuglog import DBG
        DBG.log("speak_stop", dropped=len(self.items), current=self._current[0] if self._current else None)
        with self.cv:
            self.items.clear()
            self._current = None
            self._pre.clear()
        self._stop_playback()

    @staticmethod
    def _sentences(text: str) -> list[str]:
        import re
        parts = [p.strip() for p in re.split(r"(?<=[.!?])\s+", text) if p.strip()]
        return parts or [text]

    def say(self, text: str) -> None:
        from engineer import i18n
        text = i18n.speech(text)
        print(f"\n[INŻYNIER] {text}")
        text = pl_speak(text) if i18n.LANG == "pl" else text
        if self.engine == "print":
            return
        with self.cv:
            self._gid += 1
            cur = self._current[2] if self._current else None
            # gdy zebrało się dużo zwykłych komunikatów, starsze (jeszcze nie zaczęte) są już nieaktualne
            waiting = [g for g in dict.fromkeys(x[2] for x in self.items if not x[1]) if g != cur]
            keep = set(waiting[-1:]) | {cur}
            self.items = collections.deque(x for x in self.items if x[1] or x[2] in keep)
            parts = self._sentences(text)
            # długie pierwsze zdanie: krótki początek (do pierwszego przecinka) – szybciej słychać odpowiedź
            if len(parts[0]) > 50:
                import re
                m = re.match(r"^(.{12,45}?[,:;])\s+(.+)$", parts[0])
                if m:
                    parts = [m.group(1), m.group(2)] + parts[1:]
            for i, part in enumerate(parts):
                self.items.append((part, False, self._gid, (i == 0, i == len(parts) - 1)))
            self.cv.notify()
        for part in parts[1:4]:          # pierwsze syntezuje wątek mowy, kolejne od razu równolegle
            self._prefetch(part)

    def urgent(self, text: str) -> None:
        """Pilne ostrzeżenie: przerywa zwykły komunikat, a potem inżynier kończy go od przerwanego zdania."""
        from engineer import i18n
        text = i18n.speech(text, urgent=True)
        print(f"\n[!!] {text}")
        text = pl_speak(text) if i18n.LANG == "pl" else text
        if self.engine == "print":
            return
        with self.cv:
            c = self._current
            back = [(c[0], c[1], c[2], (True, c[3][1]))] if c and not c[1] else []   # wznowienie = nowe otwarcie
            self.items = collections.deque([x for x in self.items if x[1]] + [(text, True, 0, (True, True))] + back +
                                           [x for x in self.items if not x[1]])
            self.cv.notify()
        self._stop_playback()

    def _take_prefetched(self, text: str):
        with self.cv:
            item = self._pre.pop(text, None)
        if item is None:
            return None
        ev, box = item
        ev.wait(15)
        return box[0] if box else None

    def _prefetch_next(self) -> None:
        """W trakcie mówienia przygotowuje w tle następne zwykłe zdanie (synteza przez internet trwa najdłużej)."""
        with self.cv:
            nxt = next((x for x in self.items if not x[1]), None)
        if nxt is not None:
            self._prefetch(nxt[0])

    def _prefetch(self, text: str) -> None:
        """Synteza zdania w tle (równolegle z innymi), wynik odbiera _take_prefetched."""
        if self.engine != "edge":
            return
        with self.cv:
            if text in self._pre:
                return
            ev, box = threading.Event(), []
            self._pre[text] = (ev, box)

        def run():
            t0 = time.monotonic()
            try:
                fd, raw = tempfile.mkstemp(suffix=".mp3")
                os.close(fd)
                self._synth(text, raw)
                box.append(raw)
            except Exception:
                pass
            finally:
                ev.set()
                from engineer.debuglog import DBG
                DBG.log("tts", text=text[:60], secs=round(time.monotonic() - t0, 2), pre=True)
        threading.Thread(target=run, daemon=True).start()

    def _run(self) -> None:
        while True:
            with self.cv:
                while not self.items:
                    self.cv.wait()
                item = self.items.popleft()
                self._current = item
            text, is_urgent, _, edges = item
            done = True
            from engineer.debuglog import DBG
            DBG.log("speak", text=text, urgent=is_urgent, queued=len(self.items))
            try:
                if self.engine in ("edge", "sapi"):
                    self._prefetch_next()
                    # krótkie zdania, które są całą wypowiedzią („Nie zrozumiałem, powtórz.”, „Ok.”), też z pamięci –
                    # powtarzają się często, a przygotowanie przez internet trwa 1–3 s
                    short = not is_urgent and edges == (True, True) and len(text) <= 45
                    done = self._speak(text, cache=is_urgent or short, edges=edges)
            except Exception as e:
                print(f"[głos] błąd: {e}")
            if not done:
                DBG.log("speak_cut", text=text)
            with self.cv:
                if not done and self._current is item and not any(x[0] == item[0] and x[2] == item[2] for x in self.items):
                    # pilne ostrzeżenie wskoczyło przed to zdanie: wraca zaraz za ostrzeżeniami
                    urg = [x for x in self.items if x[1]]
                    item = (item[0], item[1], item[2], (True, item[3][1]))
                    self.items = collections.deque(urg + [item] + [x for x in self.items if not x[1]])
                self._current = None
