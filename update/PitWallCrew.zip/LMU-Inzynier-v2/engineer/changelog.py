"""Lista zmian z ZMIANY.md – do okna „Co nowego” po aktualizacji.

Ostatnio widzianą wersję zapisuje data/wersja_widziana.txt. Gdy program ma nowszą wersję (automatyczna aktualizacja
albo ręczne rozpakowanie paczki), aplikacja pokazuje wszystkie zmiany od tamtej wersji – także z pominiętych wersji.
"""

from __future__ import annotations

import os
import re

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SEEN = os.path.join(ROOT, "data", "wersja_widziana.txt")


def _vt(v: str) -> tuple:
    try:
        return tuple(int(x) for x in str(v).strip().split("."))
    except ValueError:
        return (0,)


def parse(text: str) -> list[tuple[str, str, list[str]]]:
    """[(wersja, nagłówek, [punkty])] w kolejności z pliku (najnowsze pierwsze)."""
    out: list[tuple[str, str, list[str]]] = []
    for line in text.splitlines():
        m = re.match(r"^##\s+(\d+(?:\.\d+)*)\s*(.*)$", line)
        if m:
            out.append((m.group(1), f"Wersja {m.group(1)} {m.group(2)}".strip(), []))
            continue
        if not out or not line.strip():
            continue
        s = line.strip()
        if s.startswith(("- ", "* ")):
            out[-1][2].append(s[2:].strip())
        elif out[-1][2]:
            out[-1][2][-1] += " " + s         # ciąg dalszy punktu w następnej linii
        else:
            out[-1][2].append(s)
    return out


def since(old: str, new: str, text: str | None = None) -> list[tuple[str, list[str]]]:
    """Zmiany z wersji nowszych niż old, do new włącznie: [(nagłówek, ["• punkt", …])]."""
    if text is None:
        try:
            with open(os.path.join(ROOT, "ZMIANY.md"), encoding="utf-8") as f:
                text = f.read()
        except OSError:
            return []
    return [(head, ["• " + p for p in pts]) for v, head, pts in parse(text) if _vt(old) < _vt(v) <= _vt(new)]


def seen_version() -> str:
    try:
        with open(SEEN, encoding="utf-8") as f:
            return f.read().strip()
    except OSError:
        return ""


def mark_seen(v: str) -> None:
    try:
        os.makedirs(os.path.dirname(SEEN), exist_ok=True)
        with open(SEEN, "w", encoding="utf-8") as f:
            f.write(v)
    except OSError:
        pass


def pending(current: str, after_update_from: str = "") -> list[tuple[str, list[str]]]:
    """Co pokazać przy starcie. Pierwsze uruchomienie (bez zapisu) – nic, tylko zapamiętaj wersję."""
    old = seen_version() or after_update_from
    if not old:
        mark_seen(current)
        return []
    if _vt(old) >= _vt(current):
        return []
    return since(old, current)
