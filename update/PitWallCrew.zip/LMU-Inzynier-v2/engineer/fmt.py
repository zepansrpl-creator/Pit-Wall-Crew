"""Formatowanie czasów i liczb (także do odczytu głosem)."""

from __future__ import annotations

import re


def fmt_time(s: float | None) -> str:
    if not s or s <= 0:
        return "-"
    m, sec = divmod(s, 60)
    return f"{int(m)}:{sec:06.3f}"


def fmt_clock(s: float | None) -> str:
    if s is None:
        return "-"
    s = max(0, int(s))
    h, rem = divmod(s, 3600)
    m, sec = divmod(rem, 60)
    return f"{h}:{m:02d}:{sec:02d}" if h else f"{m}:{sec:02d}"


def spoken_lap(s: float) -> str:
    """104.512 -> '1:44.5' (odczyt głosem: 'jeden czterdzieści cztery i pół', zob. plnum)."""
    m, sec = divmod(round(s, 1), 60)
    return f"{int(m)}:{sec:04.1f}" if m else f"{sec:.1f} s"


def spoken_delta(d: float) -> str:
    """0.31 -> 'plus 3 dziesiąte', -0.05 -> 'minus 5 setnych'."""
    sign = "plus" if d > 0 else "minus"
    a = abs(d)
    if a >= 0.95:
        return f"{sign} {a:.1f} sekundy".replace(".", ",")
    if a >= 0.1:
        t = int(round(a * 10))
        word = "dziesiąta" if t == 1 else ("dziesiąte" if t in (2, 3, 4) else "dziesiątych")
        return f"{sign} {t} {word}"
    h = int(round(a * 100))
    return f"{sign} {h} setnych"


def pl_numbers(text: str) -> str:
    """Kropka dziesiętna -> przecinek (polska synteza mowy czyta to naturalnie)."""
    return re.sub(r"(\d)\.(\d)", r"\1,\2", text)


def laps_word(n: float) -> str:
    """Polska odmiana: 1 okrążenie, 2 okrążenia, 5 okrążeń, 2,5 okrążenia."""
    if abs(n - round(n)) > 1e-9:
        return "okrążenia"
    n = int(round(n))
    if n == 1:
        return "okrążenie"
    if n % 10 in (2, 3, 4) and n % 100 not in (12, 13, 14):
        return "okrążenia"
    return "okrążeń"
