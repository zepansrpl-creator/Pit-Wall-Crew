"""Języki programu: polski (źródłowy), angielski, niemiecki, francuski.

Program powstaje po polsku, a tłumaczenie dzieje się „na brzegu”:
- mowa inżyniera: tuż przed syntezą głosu (Speaker.say / urgent) – katalog zdań (i18n/<język>.json, liczby jako {0}, {1}…),
  potem pamięć tłumaczeń (data/i18n_cache_<język>.json), a na końcu tłumaczenie AI (Groq) zapisywane w pamięci;
- pytania kierowcy: rozpoznane w jego języku i zamieniane na polskie (tabela zwrotów, potem AI), żeby zrozumiały je reguły;
- okno aplikacji: teksty etykiet i przycisków z katalogu (ui()).
"""

from __future__ import annotations

import json
import os
import re
import threading
from typing import Callable, Optional

LANGS = {"pl": "Polski", "en": "English", "de": "Deutsch", "fr": "Français"}
LANG = "pl"
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DIR = os.path.join(ROOT, "i18n")
_cat: dict = {}           # lang -> {"speech": {...}, "ui": {...}, "input": [...]}
_cache: dict = {}         # lang -> {masked_pl: masked_tr}
_cache_dirty = False
_lock = threading.Lock()
_done: set = set()        # teksty już przetłumaczone (żeby nie tłumaczyć drugi raz)
translator: Optional[Callable[[str, str, str], Optional[str]]] = None    # (tekst, z_języka, na_język) -> tłumaczenie
_NUM = re.compile(r"(?<=\b[TP])\d{1,2}(?![\w}])|"           # zakręt T5, pozycja P4: liczba osobno
                  r"(?<![\w{.])(?:\d+(?:\.\d+){2,}|\d{1,2}:\d{2}(?:[.,]\d+)?|[-+−]?\d+(?:[.,]\d+)?)(?![\w}])")


def detect() -> str:
    """Język Windows (pierwsze uruchomienie): pl / en / de / fr."""
    code = ""
    try:
        import ctypes
        import locale
        lid = ctypes.windll.kernel32.GetUserDefaultUILanguage()
        code = locale.windows_locale.get(lid, "")
    except Exception:
        try:
            import locale
            code = (locale.getlocale()[0] or "")
        except Exception:
            code = ""
    code = code.lower()[:2]
    return code if code in LANGS else ("pl" if code == "" else "en")


def set_lang(lang: str) -> None:
    global LANG
    LANG = lang if lang in LANGS else "pl"


def lang_from_cfg(cfg: dict) -> str:
    """[ui] lang w config.toml; pusty = język Windows (nowa instalacja); brak klucza = polski (starsze instalacje)."""
    ui_cfg = cfg.get("ui") or {}
    if "lang" not in ui_cfg:
        return "pl"
    lg = str(ui_cfg.get("lang") or "").lower()
    return lg if lg in LANGS else detect()


def _load(lang: str) -> dict:
    if lang not in _cat:
        try:
            with open(os.path.join(DIR, lang + ".json"), encoding="utf-8") as f:
                _cat[lang] = json.load(f)
        except (OSError, ValueError):
            _cat[lang] = {}
        _cat[lang].setdefault("speech", {})
        _cat[lang].setdefault("ui", {})
        for part in ("speech", "ui"):          # klucze bez podwójnych spacji (tak jak szukany tekst)
            _cat[lang][part] = {" ".join(k.split()): v for k, v in _cat[lang][part].items()}
        _cat[lang].setdefault("input", [])
        _cat[lang].setdefault("frag", {})
    return _cat[lang]


def _cache_path(lang: str) -> str:
    return os.path.join(ROOT, "data", f"i18n_cache_{lang}.json")


def _load_cache(lang: str) -> dict:
    if lang not in _cache:
        try:
            with open(_cache_path(lang), encoding="utf-8") as f:
                _cache[lang] = json.load(f)
        except (OSError, ValueError):
            _cache[lang] = {}
    return _cache[lang]


def save_cache() -> None:
    global _cache_dirty
    if not _cache_dirty:
        return
    with _lock:
        _cache_dirty = False
        for lang, c in _cache.items():
            try:
                os.makedirs(os.path.dirname(_cache_path(lang)), exist_ok=True)
                tmp = _cache_path(lang) + ".tmp"
                with open(tmp, "w", encoding="utf-8") as f:
                    json.dump(c, f, ensure_ascii=False, indent=0)
                os.replace(tmp, _cache_path(lang))
            except OSError:
                pass


def mask(text: str) -> tuple[str, list[str]]:
    """'Zjazd za 3 okrążenia, energia 45,5%' -> ('Zjazd za {0} okrążenia, energia {1}%', ['3', '45,5'])."""
    nums: list[str] = []

    def rep(m):
        nums.append(m.group(0))
        return "{%d}" % (len(nums) - 1)
    return _NUM.sub(rep, " ".join(text.split())), nums


def _num_out(n: str, lang: str) -> str:
    if n.count(".") >= 2:          # numer wersji 0.4.1.0
        return n
    n = n.replace("−", "-")
    return n.replace(",", ".") if lang == "en" else n.replace(".", ",")


def _fill(tmpl: str, nums: list[str], lang: str) -> Optional[str]:
    try:
        return tmpl.format(*[_num_out(n, lang) for n in nums])
    except (IndexError, KeyError, ValueError):
        return None


def _frag(val: str, lang: str) -> str:
    """Fragment w miejscu {a}: kierunek, opona, klasa… z tabeli „frag”; nazwiska i zakręty bez zmian."""
    fr = _load(lang).get("frag") or {}
    v = val.strip()
    if v in fr:
        return val.replace(v, fr[v])
    low = v[:1].lower() + v[1:]
    if low in fr:
        t = fr[low]
        return val.replace(v, t[:1].upper() + t[1:])
    return val


_pat_cache: dict = {}


def _patterns(table: dict) -> list:
    """Klucze z {a}, {b}, {c} = dowolny tekst (nazwisko, zakręt) przepisywany bez tłumaczenia."""
    tid = id(table)
    if tid not in _pat_cache or _pat_cache[tid][0] != len(table):
        pats = []
        for k, v in table.items():
            if "{a}" in k or "{b}" in k or "{c}" in k:
                rx = re.escape(k)
                for w in "abc":
                    rx = rx.replace(re.escape("{%s}" % w), "(?P<%s>.+?)" % w)
                try:
                    pats.append((re.compile("^" + rx + "$"), v))
                except re.error:
                    pass
        _pat_cache[tid] = (len(table), pats)
    return _pat_cache[tid][1]


def _lookup(table: dict, text: str, lang: str) -> Optional[str]:
    t = " ".join(text.split())
    if t in table:
        return table[t]
    key, nums = mask(t)
    if key in table:
        return _fill(table[key], nums, lang)
    for rx, v in _patterns(table):
        m = rx.match(key)
        if m:
            out = v
            for w, val in m.groupdict().items():
                out = out.replace("{%s}" % w, _frag(val, lang))
            return _fill(out, nums, lang)
    return None


def _sentences(text: str) -> list[str]:
    return [p for p in re.split(r"(?<=[.!?])\s+", text.strip()) if p]


_REC = os.environ.get("PWC_I18N_RECORD", "")


def record(text: str, kind: str = "speech") -> None:
    """Tylko do budowania katalogów (zmienna PWC_I18N_RECORD): zapis polskich tekstów."""
    if _REC and text:
        try:
            with open(_REC, "a", encoding="utf-8") as f:
                f.write(json.dumps({"k": kind, "t": text}, ensure_ascii=False) + "\n")
        except OSError:
            pass


def speech(text: str, urgent: bool = False, lang: str = "") -> str:
    """Komunikat inżyniera w języku kierowcy."""
    record(text)
    lang = lang or LANG
    if lang == "pl" or not text or text in _done:
        return text
    cat = _load(lang)["speech"]
    cache = _load_cache(lang)
    out = _lookup(cat, text, lang) or _lookup(cache, text, lang)
    if out is None:
        parts = _sentences(text)
        if len(parts) > 1:
            tr = [_lookup(cat, p, lang) or _lookup(cache, p, lang) for p in parts]
            if sum(1 for x in tr if x) * 2 >= len(parts):       # większość ze słownika – AI tylko dla brakujących zdań
                tr = [x or _ai(p, lang) for x, p in zip(tr, parts)]
            if all(tr):
                out = " ".join(tr)
    if out is None:
        out = _ai(text, lang)
    if out is None:
        out = text
    _done.add(out)
    if len(_done) > 5000:
        _done.clear()
    return out


def mark_done(text: str) -> None:
    """Tekst już w języku kierowcy (np. odpowiedź AI) – bez tłumaczenia."""
    if text:
        _done.add(text)


def _ai(text: str, lang: str, src: str = "pl") -> Optional[str]:
    """Tłumaczenie AI (Groq) z zapisem w pamięci tłumaczeń (liczby jako {0}… – działa też dla innych liczb)."""
    global _cache_dirty
    if translator is None:
        return None
    key, nums = mask(text)
    try:
        res = translator(key, src, lang)
    except Exception:
        res = None
    if not res:
        return None
    res = res.strip().strip('"')
    if all("{%d}" % i in res for i in range(len(nums))) and not re.search(r"\{\d+\}", re.sub(
            "|".join(re.escape("{%d}" % i) for i in range(len(nums))) or "^$", "", res)):
        if src == "pl":
            with _lock:
                _load_cache(lang)[key] = res
                _cache_dirty = True
        return _fill(res, nums, lang)
    return None


def to_polish(text: str, lang: str = "") -> str:
    """Pytanie kierowcy (w jego języku) -> po polsku, dla reguł inżyniera."""
    lang = lang or LANG
    if lang == "pl" or not text:
        return text
    low = " ".join(text.lower().split())
    for pat, pl in _load(lang)["input"]:
        try:
            m = re.search(pat, low)
        except re.error:
            continue
        if m:
            try:
                return m.expand(pl)
            except (re.error, IndexError):
                return pl
    if translator is not None:
        try:
            res = translator(text, lang, "pl")
            if res:
                return res.strip().strip('"')
        except Exception:
            pass
    return text


def ui(text: str, lang: str = "") -> str:
    """Tekst w oknie aplikacji."""
    lang = lang or LANG
    if _REC and isinstance(text, str):
        record(text, "ui")
    if lang == "pl" or not isinstance(text, str) or not text.strip():
        return text
    table = _load(lang)["ui"]
    core = text.strip()
    if core.startswith("•"):
        core = core[1:].strip()
    out = _lookup(table, core, lang)
    if out is not None:
        i = text.find(core)
        return text[:i] + out + text[i + len(core):]
    # dłuższy tekst z kilku zdań albo linii
    if "\n" in text:
        lines = text.split("\n")
        tr = [ui(x, lang) if x.strip() else x for x in lines]
        return "\n".join(tr)
    return text


STT_LANG = {"pl": "pl", "en": "en", "de": "de", "fr": "fr"}
VOICES = {
    "pl": [("pl-PL-MarekNeural", "+0Hz", "Marek (polski)")],
    "en": [("en-GB-RyanNeural", "+0Hz", "Ryan (British)"), ("en-US-GuyNeural", "+0Hz", "Guy (American)"),
           ("en-GB-SoniaNeural", "+0Hz", "Sonia (British)"), ("en-AU-WilliamNeural", "+0Hz", "William (Australian)")],
    "de": [("de-DE-ConradNeural", "+0Hz", "Conrad (Deutsch)"), ("de-DE-KillianNeural", "+0Hz", "Killian (Deutsch)"),
           ("de-DE-KatjaNeural", "+0Hz", "Katja (Deutsch)")],
    "fr": [("fr-FR-HenriNeural", "+0Hz", "Henri (français)"), ("fr-FR-RemyMultilingualNeural", "+0Hz", "Rémy (français)"),
           ("fr-FR-DeniseNeural", "+0Hz", "Denise (français)")],
}


def patch_tk() -> None:
    """Okno aplikacji w języku użytkownika bez zmian w kodzie okna: teksty przechodzą przez ui()."""
    if LANG == "pl":
        return
    import tkinter as tk
    from tkinter import messagebox
    orig = tk.Misc._options

    def _options(self, cnf, kw=None):
        for d in (cnf, kw):
            if isinstance(d, dict):
                for k in ("text", "label"):
                    if isinstance(d.get(k), str):
                        d[k] = ui(d[k])
        return orig(self, cnf, kw)
    tk.Misc._options = _options
    tins = tk.Text.insert

    def insert(self, index, chars, *args):
        return tins(self, index, ui(chars) if isinstance(chars, str) else chars, *args)
    tk.Text.insert = insert
    eins = tk.Entry.insert

    def einsert(self, index, string):
        return eins(self, index, ui(string) if isinstance(string, str) else string)
    tk.Entry.insert = einsert
    ttl = tk.Wm.wm_title

    def title(self, string=None):
        return ttl(self, ui(string) if isinstance(string, str) else string)
    tk.Wm.wm_title = tk.Wm.title = title
    for name in ("showinfo", "showwarning", "showerror", "askyesno", "askokcancel", "askyesnocancel", "askquestion"):
        f = getattr(messagebox, name)

        def wrap(title=None, message=None, _f=f, **kw):
            return _f(ui(title) if isinstance(title, str) else title, ui(message) if isinstance(message, str) else message, **kw)
        setattr(messagebox, name, wrap)
