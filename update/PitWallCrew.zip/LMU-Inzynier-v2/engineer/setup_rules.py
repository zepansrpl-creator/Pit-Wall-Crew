"""Wiedza setupowa: zasady dla AI i podpowiedzi liczone z danych (działają także bez AI)."""

from __future__ import annotations

import re
from typing import Optional

from .analysis.handling import OVER, UNDER, CornerHandling, HandlingReport

SETUP_GUIDE = """ZASADY SETUPU (GT3 / Hypercar w Le Mans Ultimate). Najpierw ustal FAZĘ zakrętu (wejście/hamowanie, środek, wyjście/gaz) i TYP (wolny/średni/szybki).

Podsterowność na wejściu (auto nie chce skręcić przy hamowaniu):
- w aucie: balans hamulców do tyłu o 0,5–1%; mniej ABS-u nie pomoże, raczej sprawdź blokowanie przodu
- w garażu: miększy przedni stabilizator; mniejszy preload dyferencjału; miększe przednie sprężyny
- jazda: wcześniej i stopniowo zwalniaj hamulec (trail braking), nie skręcaj przy pełnym hamowaniu
Nadsterowność na wejściu (tył ucieka przy hamowaniu):
- w aucie: balans hamulców do przodu o 0,5–1%
- w garażu: większy preload dyferencjału; twardszy przedni lub miększy tylny stabilizator
Podsterowność w środku, wolne zakręty (mechaniczny grip):
- miększy przedni stabilizator albo twardszy tylny; miększe przednie sprężyny; więcej negatywnego camberu z przodu, jeśli zewnętrzna krawędź przedniej opony jest gorętsza
Podsterowność w środku, szybkie zakręty (aerodynamika):
- więcej docisku przodu względem tyłu: mniej tylnego skrzydła albo większy rake (niżej przód / wyżej tył o 1–2 mm)
Nadsterowność w środku, szybkie zakręty:
- więcej tylnego skrzydła albo mniejszy rake
Nadsterowność w środku, wolne zakręty:
- miększy tylny stabilizator albo twardszy przedni
Podsterowność na wyjściu (przy gazie auto wypycha na zewnątrz):
- mniejszy preload dyferencjału; miększy przedni stabilizator; jazda: spokojniejsze otwieranie gazu, prostowanie kierownicy
Nadsterowność na wyjściu (tył ucieka na gazie):
- w aucie: TC Slip o 1 wyżej (tył ślizga się bokiem); gdy koła buksują – TC główne o 1 wyżej
- w garażu: miększy tylny stabilizator; miększe tylne sprężyny; mniejszy preload, jeśli tył jest nerwowy na lekkim gazie
- jazda: później i stopniowo gaz, mniej kąta skrętu przy otwieraniu gazu

Amortyzatory (tylko trening, w garażu; wolne = ruchy nadwozia przy hamowaniu, skręcie i gazie, szybkie = tarki i nierówności):
- twardsze tłumienie na jednej osi = szybszy transfer ciężaru na tej osi = mniej przyczepności tej osi w przejściu
- podsterowność na wejściu: miększe wolne dobicie (slow bump) przodu albo twardsze wolne odbicie (slow rebound) tyłu
- nadsterowność na wejściu: twardsze wolne dobicie przodu albo miększe wolne odbicie tyłu
- podsterowność na wyjściu: twardsze wolne dobicie tyłu albo miększe wolne odbicie przodu
- nadsterowność na wyjściu: miększe wolne dobicie tyłu albo twardsze wolne odbicie przodu
- auto podskakuje / odrywa koło na tarkach, nerwowe na nierównościach: miększe szybkie dobicie (fast bump), czasem miększe szybkie odbicie
- dobija do asfaltu (podłoga): prześwit wyżej o klik albo twardsze wolne dobicie / sprężyny na tej osi
Zbieżność (toe, tylko trening):
- przód: trochę rozbieżności (toe out) = lepsze wejście w zakręt, auto chętniej skręca; za dużo = nerwowe na prostej i gorętsze opony
- tył: zbieżność (toe in) = stabilny tył na wejściu i na prostej; tył nerwowy, pływa na prostych lub w szybkich łukach = więcej tylnej zbieżności; auto leniwe w wolnych zakrętach = mniej tylnej zbieżności
- duża zbieżność = wolniej na prostych i szybsze zużycie opon; zmieniaj o 1 klik

Opony: wewnętrzna krawędź o ponad 10°C gorętsza niż zewnętrzna = za dużo negatywnego camberu; zewnętrzna gorętsza = za mało. Środek gorętszy od krawędzi = ciśnienie za wysokie, chłodniejszy = za niskie.
Przełożenia: odcinanie na najwyższym biegu przed hamowaniem = ostatni bieg za krótki.

Sposób pracy:
Kontrola trakcji w LMU ma trzy ustawienia (wyżej = więcej ingerencji, bezpieczniej; typowy start 7-7-7, szybciej 6-6-6, bezpieczniej 9-9-9):
- TC (główne): ile buksowania kół napędowych jest dozwolone, zanim TC zadziała – na buksowanie na wyjściu,
- TC Cut: jak mocno TC odcina moc, gdy już działa – gdy TC dużo pracuje i auto wolno wychodzi z zakrętu, Cut niżej,
- TC Slip: ile poślizgu bocznego (kąta) jest dozwolone, zanim TC zadziała – na tył uciekający bokiem na gazie.
Zawsze nazywaj, które z trzech TC zmienić.
- W WYŚCIGU (GT3) nie proponuj stabilizatorów, sprężyn, amortyzatorów, zbieżności, skrzydła ani innych zmian garażowych – tylko balans hamulców, TC (główne, Cut, Slip), ABS, mapa silnika albo technika jazdy. Zmiany w garażu tylko w treningu.
- Jedna zmiana na raz, o 1–2 kliki. Najpierw rzeczy regulowane w aucie (balans hamulców, TC, ABS), potem garaż.
- Odczucia kierowcy są ważniejsze niż pojedynczy pomiar, ale gdy dane mówią co innego, powiedz to i zaproponuj, jak sprawdzić.
- Jeśli problem jest tylko w jednym zakręcie, a inne zakręty tego typu są dobre, najpierw zasugeruj zmianę techniki jazdy w tym zakręcie.
- Po zmianie poproś o 3 czyste okrążenia i powiedzenie "zmieniłem ..." — wtedy porównasz przed i po.
"""

SETUP_WORDS = (
    "setup", "ustawie", "podsterown", "nadsterown", "ucieka", "nie skręca", "nie chce skręcić", "wypycha",
    "stabilizator", "skrzydł", "docisk", "camber", "ciśnien", "balans", "podział", "dyferencjał", "preload", "sprężyn",
    "zawieszen", "przełożen", "bieg", "rake", "prześwit", "ślizga", "nerwow", "zmieniłem", "zmiana", "co zmienić",
    "trakcj", "tc ", "abs", "amortyz", "damper", "bump", "rebound", "dobicie", "odbicie", "zbieżn", "rozbieżn", "toe",
    "tark", "podskak", "dobija", "pływa",
)

FEEDBACK_WORDS = ("podsterown", "nadsterown", "ucieka", "nie skręca", "nie chce skręcić", "wypycha", "ślizga",
                  "nerwow", "blokuj", "tańczy", "pływa", "dobija", "podbija", "podskak", "odrywa")

CHANGE_RE = re.compile(r"\b(zmieniłem|zmieniłam|zmiana setupu|ustawiłem|dałem|przestawiłem)\b", re.IGNORECASE)


def is_setup_question(text: str) -> bool:
    t = text.lower()
    return any(w in t for w in SETUP_WORDS)


def is_feedback(text: str) -> bool:
    t = text.lower()
    return any(w in t for w in FEEDBACK_WORDS)


def is_setup_change(text: str) -> bool:
    return bool(CHANGE_RE.search(text))


def _phase_problem(c: CornerHandling) -> list[tuple[str, float]]:
    out = []
    for ph in ("entry", "mid", "exit"):
        v = getattr(c, ph)
        if v is not None and (v >= UNDER or v <= OVER):
            out.append((ph, v))
    return out


RACE_FIX = {   # w wyścigu (GT3): tylko to, co zmienisz z kokpitu, albo technika – bez stabilizatorów i garażu
    ("under", "entry"): "balans hamulców o 0,5% do tyłu",
    ("under", "mid"): "spokojniej na wejściu i późniejszy wierzchołek; ustawień w aucie na to nie ma",
    ("under", "exit"): "spokojniej otwieraj gaz i wyprostuj kierownicę przed pełnym gazem",
    ("over", "entry"): "balans hamulców o 0,5% do przodu",
    ("over", "mid"): "płynniej z kierownicą i gazem w środku zakrętu",
    ("over", "exit"): "TC Slip o 1 wyżej",
}


def fix_for(phase: str, speed_class: str, bal: float, race: bool = False) -> str:
    """Pierwsza zmiana do wypróbowania dla problemu w danej fazie i typie zakrętu.
    race=True: tylko regulacje z kokpitu (balans hamulców, TC, ABS) albo technika."""
    if race:
        return RACE_FIX[("under" if bal >= UNDER else "over", phase if phase in ("entry", "mid", "exit") else "mid")]
    if bal >= UNDER:
        if phase == "entry":
            return ("balans hamulców o 0,5% do tyłu, a jeśli nie pomoże, miększy przedni stabilizator o 1 klik "
                    "albo miększe wolne dobicie (slow bump) przodu")
        if phase == "mid" and speed_class == "szybki":
            return "mniej tylnego skrzydła o 1 klik albo większy rake"
        if phase == "mid":
            return "miększy przedni stabilizator o 1 klik, potem ewentualnie trochę rozbieżności przodu (toe out)"
        return "mniejszy preload dyferencjału albo miększe wolne odbicie (slow rebound) przodu o 1 klik"
    if phase == "entry":
        return ("balans hamulców o 0,5% do przodu albo większy preload dyferencjału, "
                "w garażu też miększe wolne odbicie (slow rebound) tyłu")
    if phase == "mid" and speed_class == "szybki":
        return "więcej tylnego skrzydła o 1 klik albo mniejszy rake; tył pływa – więcej tylnej zbieżności (toe in)"
    if phase == "mid":
        return "miększy tylny stabilizator o 1 klik"
    return "TC Slip o 1 wyżej, w garażu miększy tylny stabilizator albo miększe wolne dobicie (slow bump) tyłu"


PHASE_NAMES = {"entry": "na wejściu", "mid": "w środku", "exit": "na wyjściu"}


def corner_tip(c: CornerHandling, race: bool = False) -> str:
    probs = _phase_problem(c)
    if not probs:
        return f"Pomiar w {c.name} nie pokazuje wyraźnego problemu z balansem."
    ph, v = max(probs, key=lambda x: abs(x[1]))
    kind = "podsterowność" if v > 0 else "nadsterowność"
    return f"W {c.name} najmocniej {kind} {PHASE_NAMES[ph]} ({v:+.1f}°); do wypróbowania: {fix_for(ph, c.speed_class, v, race)}."


def suggestions(report: Optional[HandlingReport], race: bool = False) -> list[str]:
    """Podpowiedzi wynikające z samych danych, od najważniejszej."""
    if report is None:
        return []
    tips: list[tuple[float, str]] = []
    cls_gen = dict(wolny="wolnych", średni="średnich", szybki="szybkich")
    for cls, row in report.by_class().items():
        for ph, v in row.items():
            if v is None or OVER < v < UNDER:
                continue
            kind = "Podsterowność" if v > 0 else "Nadsterowność"
            tips.append((abs(v), f"{kind} {PHASE_NAMES[ph]} {cls_gen[cls]} zakrętów ({v:+.1f}°): {fix_for(ph, cls, v, race)}."))
    # pojedyncze zakręty z wyraźnym problemem
    for c in report.corners:
        probs = _phase_problem(c)
        if probs:
            ph, v = max(probs, key=lambda x: abs(x[1]))
            tips.append((abs(v) * 0.9, corner_tip(c, race)))
    for t in report.tyres:
        for n in t.notes:
            tips.append((0.5, f"Opona {t.wheel}: {n}."))
    for g in report.gearing:
        tips.append((0.4, f"Przełożenia: {g}."))
    tips.sort(key=lambda x: -x[0])
    return [t for _, t in tips]


def corner_from_text(text: str, report: Optional[HandlingReport]) -> Optional[CornerHandling]:
    """Rozpoznaje zakręt w wypowiedzi: 'T5', 'piątka', 'ostatni zakręt', 'pierwszy zakręt'."""
    if report is None or not report.corners:
        return None
    t = text.lower()
    m = re.search(r"\bt\s?(\d{1,2})\b", t) or re.search(r"zakr\w*\s+(?:nr\.?\s*|numer\s*)?(\d{1,2})\b", t)
    if m:
        k = int(m.group(1))
        return next((c for c in report.corners if c.position == k), None)
    if "przedostatni" in t and len(report.corners) > 1:
        return report.corners[-2]
    if "ostatni" in t:
        return report.corners[-1]
    if "pierwsz" in t:
        return report.corners[0]
    words = {"drugi": 2, "trzeci": 3, "czwart": 4, "piąt": 5, "szóst": 6, "siódm": 7, "ósm": 8, "dziewiąt": 9,
             "dziesiąt": 10}
    for w, k in words.items():
        if w in t:
            return next((c for c in report.corners if c.position == k), None)
    return None
