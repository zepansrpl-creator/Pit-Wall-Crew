"""Lista komend głosowych – do strony „Komendy” w aplikacji.

Przy dodawaniu nowej komendy w engineer/intents.py dopisz ją też tutaj.
"""

COMMANDS: list[tuple[str, list[tuple[str, str]]]] = [
    ("Sterowanie inżynierem", [
        ("„cisza” / „cicho” / „Inżynier, cicho” / „nie gadaj”", "„Ok.” i całkowita cisza (także bez ostrzeżeń); odezwie się po następnym naciśnięciu przycisku"),
        ("„<imię inżyniera>, cicho” (np. „Marku, cicho”)", "to samo, gdy nadałeś inżynierowi imię (Ustawienia → Głos)"),
        ("„tylko pilne” / „mów tylko, gdy pytam”", "mówi tylko pilne ostrzeżenia i odpowiedzi na pytania"),
        ("„możesz mówić” / „mów dalej”", "wraca do komunikatów o zmianach"),
        ("„powtórz” / „nie usłyszałem”", "powtarza ostatnią odpowiedź"),
        ("„radio test” / „słyszysz mnie?”", "sprawdzenie łączności"),
        ("„w których?” / „które zakręty?”", "pełna lista po skróconej odpowiedzi („w 6 zakrętach, najbardziej T3 i T11”), do 2 minut"),
        ("„co umiesz” / „pomoc”", "krótka lista tematów"),
        ("naciśnięcie przycisku mówienia", "przerywa to, co inżynier właśnie mówi"),
    ]),
    ("Włączanie i wyłączanie podpowiedzi", [
        ("„bez dublowania” / „mów o dublowaniu”", "ostrzeżenia o szybszej klasie z tyłu"),
        ("„trener” / „bez trenera”", "podpowiedzi przed zakrętem przy powtarzających się błędach"),
        ("„porównanie” / „bez porównania”", "„T5: hamujesz 15 metrów wcześniej” – porównanie z najlepszym okrążeniem"),
        ("„porównanie z zespołem” / „bez porównania z zespołem”", "„T5: Patryk hamuje 15 metrów później. Spróbuj hamować później.” – przed zakrętem, w którym kolega z zespołu jest wyraźnie szybszy w podobnych warunkach"),
        ("„komentarze” / „bez komentarzy”", "komentarz po wyprzedzeniu lub stracie pozycji"),
        ("„sugestie” / „bez sugestii”", "rady ustawień i techniki"),
    ]),
    ("Paliwo, energia, postój", [
        ("„ile paliwa?” / „starczy?”", "paliwo, na ile okrążeń, zapas"),
        ("„ile energii?” / „ile VE?”", "energia wirtualna"),
        ("„kiedy zjazd?” / „jaki plan postoju?”", "okrążenie zjazdu (przy wjeździe do boksu zostaje min. 0,2% energii), ile energii, które opony"),
        ("„ile trwa postój?”", "czas postoju z przejazdem aleją"),
        ("„które opony zmienić?” / „zmieniamy opony?”", "które opony zmienić na postoju (z planu zespołu albo ze zużycia) i dlaczego"),
        ("„ile oszczędzać?” / „jak oszczędzać?”", "cel zużycia na okrążenie, żeby zrobić postój mniej albo dojechać do zjazdu z grafiku"),
        ("„jak się zmienia zużycie?”", "trend zużycia paliwa i energii"),
        ("„ile do końca?” / „ile okrążeń zostało?”", "czas i okrążenia do mety"),
    ]),
    ("Czasy i jazda", [
        ("„jaki czas?” / „jak mi idzie?”", "ostatnie i najlepsze okrążenie, równość"),
        ("„gdzie tracę?” / „gdzie mogę zyskać?”", "zakręty z największą stratą"),
        ("„co z te pięć?” / „zakręt 5”", "szczegóły konkretnego zakrętu"),
        ("„czy tracę tempo?” / „czy jestem zmęczony?”", "zmęczenie i spadek tempa"),
        ("„która pozycja?”", "pozycja w klasie i ogólnie"),
    ]),
    ("Rywale", [
        ("„kto przede mną?” / „kogo gonię?”", "odstęp, tempo, trend"),
        ("„kto za mną?” / „kto mnie goni?”", "odstęp, tempo, trend"),
        ("„kiedy go dogonię?” / „czy mnie dogoni?”", "za ile okrążeń przy obecnym tempie"),
        ("„jakie tempo ma rywal?”", "tempo auta przed lub za Tobą"),
        ("„kto jedzie w aucie przed mną?” / „najszybszy kierowca rywala”", "kierowcy w aucie rywala i ich tempo"),
        ("„czy rywal zmienił opony?”", "szacunek opon rywala z ostatniego postoju"),
        ("„kiedy rywal zjedzie?”", "przewidywany postój rywala"),
        ("„za ile pierwszy hypercar będzie dublował?” / „kiedy dogoni mnie LMP2?”", "pierwsze auto szybszej klasy: za ile dojedzie i ile jest za Tobą; następne"),
        ("„prędkość maksymalna innych aut?” / „ile ma na prostej auto przede mną?” / „vmax hypercarów?”", "prędkość maksymalna rywali, Twoja i najszybszego w klasie"),
    ]),
    ("Auto", [
        ("„jak opony?” / „ciśnienia?”", "zużycie, temperatury, ciśnienia"),
        ("„hamulce?”", "zużycie i temperatury hamulców"),
        ("„porównaj mnie z Patrykiem” / „co Amadeusz robi inaczej?” / „gdzie kolega jest szybszy?”", "najszybsze okrążenie kolegi z zespołu na tej samej mieszance, przy podobnym zużyciu opon, paliwie i temperaturze toru: w których zakrętach jest szybszy, co robi inaczej (hamowanie, prędkość w środku, gaz, bieg) i rada; „w których?” – pełna lista"),
        ("„w jakich zakrętach Wieczorek jest wolniejszy ode mnie?” / „porównaj z Wieczorkiem”", "rywal z Twojej klasy: najlepsze okrążenia obu, w których zakrętach jest wolniejszy i szybszy, prędkość w zakręcie"),
        ("„porównaj temperatury opon i hamulców z 4. okrążeniem po pitstopie” / „… z poprzednim stintem” / „… z okrążeniem 12”", "ostatnie okrążenie wobec wskazanego: hamulce przód/tył, opony przód/tył, rada o chłodzeniu hamulców"),
        ("„uszkodzenia?” / „czy naprawiać?”", "uszkodzenia i strata czasu"),
        ("„naprawa trwa 30 sekund”", "czy opłaca się naprawiać przy takim czasie"),
        ("„silnik?” / „temperatura wody?” / „grill”", "temperatury silnika, rada o grillu"),
        ("„podsterowność na wejściu w ostatni zakręt”", "rada dla zakrętu i ustawień"),
        ("„zmieniłem balans na 54” / „czy pomogło?”", "zapis zmiany setupu i ocena po kilku okrążeniach"),
        ("„co zmienić w setupie?”", "propozycje zmian (w wyścigu tylko z kokpitu)"),
        ("„jakie mam mieć TC?” / „traction control?” / „ile ABS?”", "obecne ustawienie i rada z pomiaru (działa też bez AI)"),
    ]),
    ("Pogoda", [
        ("„jaka pogoda?” / „czy będzie padać?”", "deszcz, wilgotność, prognoza, temperatura toru"),
        ("„kiedy deszczowe?” / „kiedy slicki?”", "czy i kiedy opłaca się zmienić opony"),
    ]),
    ("Zespół i pamięć", [
        ("„zapamiętaj …” / „notatka …”", "notatka do pamięci zespołu (AI bierze ją pod uwagę)"),
        ("„powiadomienie na telefon Amadeusz: wstawaj, zaraz wsiadasz”", "od razu powiadomienie na telefon kolegi (ntfy); „powiadomienie dla wszystkich: …” – do całego zespołu"),
        ("„powiedz następnemu, że …” / „przekaż zmiennikowi …”", "notatka, którą inżynier przeczyta następnemu kierowcy na odprawie"),
        ("pytania analityczne: „porównaj…”, „jaka różnica…”, „o ile…”, „dlaczego…”, „kto najszybszy…”, z nazwiskiem rywala, o grill i chłodzenie", "odpowiada AI z pełnymi danymi wyścigu (odpowiedź programu jako pewne liczby)"),
        ("inne pytanie", "odpowiada AI (Groq); gdy rozpoznanie mowy jest niepewne – „Nie zrozumiałem, powtórz.”"),
    ]),
    ("Ściana boksów (dla zespołu)", [
        ("„Do kierowcy”", "wiadomość, którą inżynier przeczyta kierowcy („Wiadomość od Macieja: …”)"),
        ("„Zapytaj inżyniera”", "pytanie do inżyniera, odpowiedź słychać w radiu zespołu"),
        ("„Zapytaj (tylko tekst)”", "odpowiedź tylko na ścianie, kierowca jej nie słyszy"),
        ("„Do pamięci”", "notatka do pamięci zespołu"),
    ]),
    ("Problemy i sugestie", [
        ("Aplikacja → Pomoc → „Zgłoś problem” albo ściana boksów → Pomoc", "opisz problem lub pomysł – trafia prosto do autora programu"),
    ]),
]
