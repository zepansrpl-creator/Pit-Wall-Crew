"""Lista komend głosowych (i z Discorda) – do strony „Komendy” w aplikacji.

Przy dodawaniu nowej komendy w engineer/intents.py dopisz ją też tutaj.
"""

COMMANDS: list[tuple[str, list[tuple[str, str]]]] = [
    ("Sterowanie inżynierem", [
        ("„Inżynier, cicho” (albo „<imię>, cicho”)", "całkowita cisza; odezwie się po następnym naciśnięciu przycisku"),
        ("„cisza” / „nie gadaj”", "mówi tylko, gdy pytasz (pilne ostrzeżenia zostają)"),
        ("„możesz mówić” / „mów dalej”", "wraca do komunikatów o zmianach"),
        ("„powtórz” / „nie usłyszałem”", "powtarza ostatnią odpowiedź"),
        ("„radio test” / „słyszysz mnie?”", "sprawdzenie łączności"),
        ("„co umiesz” / „pomoc”", "krótka lista tematów"),
        ("naciśnięcie przycisku mówienia", "przerywa to, co inżynier właśnie mówi"),
    ]),
    ("Włączanie i wyłączanie podpowiedzi", [
        ("„bez dublowania” / „mów o dublowaniu”", "ostrzeżenia o szybszej klasie z tyłu"),
        ("„trener” / „bez trenera”", "podpowiedzi przed zakrętem przy powtarzających się błędach"),
        ("„porównanie” / „bez porównania”", "„T5: hamujesz 15 metrów wcześniej” – porównanie z najlepszym okrążeniem"),
        ("„komentarze” / „bez komentarzy”", "komentarz po wyprzedzeniu lub stracie pozycji"),
        ("„sugestie” / „bez sugestii”", "rady ustawień i techniki"),
    ]),
    ("Paliwo, energia, postój", [
        ("„ile paliwa?” / „starczy?”", "paliwo, na ile okrążeń, zapas"),
        ("„ile energii?” / „ile VE?”", "energia wirtualna"),
        ("„kiedy zjazd?” / „jaki plan postoju?”", "okrążenie zjazdu, co tankować, które opony"),
        ("„ile trwa postój?”", "czas postoju z przejazdem aleją"),
        ("„ile oszczędzać?” / „jak oszczędzać?”", "cel zużycia na okrążenie, żeby zrobić postój mniej"),
        ("„jak się zmienia zużycie?”", "trend zużycia paliwa i energii"),
        ("„ile do końca?” / „ile okrążeń zostało?”", "czas i okrążenia do mety"),
    ]),
    ("Czasy i jazda", [
        ("„jaki czas?” / „jak mi idzie?”", "ostatnie i najlepsze okrążenie, równość"),
        ("„gdzie tracę?” / „gdzie mogę zyskać?”", "zakręty z największą stratą"),
        ("„co z te pięć?” / „zakręt 5”", "szczegóły konkretnego zakrętu"),
        ("„czy tracę tempo?” / „czy jestem zmęczony?”", "zmęczenie i spadek tempa"),
        ("„która pozycja?”", "pozycja w klasie i ogólnie"),
    ]),
    ("Rywale", [
        ("„kto przede mną?” / „kogo gonię?”", "odstęp, tempo, trend"),
        ("„kto za mną?” / „kto mnie goni?”", "odstęp, tempo, trend"),
        ("„kiedy go dogonię?” / „czy mnie dogoni?”", "za ile okrążeń przy obecnym tempie"),
        ("„jakie tempo ma rywal?”", "tempo auta przed lub za Tobą"),
        ("„kto jedzie w aucie przed mną?” / „najszybszy kierowca rywala”", "kierowcy w aucie rywala i ich tempo"),
        ("„czy rywal zmienił opony?”", "szacunek opon rywala z ostatniego postoju"),
        ("„kiedy rywal zjedzie?”", "przewidywany postój rywala"),
        ("„czy dogoni mnie hypercar?” / „szybsza klasa”", "auta szybszej klasy dojeżdżające z tyłu"),
    ]),
    ("Auto", [
        ("„jak opony?” / „ciśnienia?”", "zużycie, temperatury, ciśnienia"),
        ("„hamulce?”", "zużycie i temperatury hamulców"),
        ("„uszkodzenia?” / „czy naprawiać?”", "uszkodzenia i strata czasu"),
        ("„naprawa trwa 30 sekund”", "czy opłaca się naprawiać przy takim czasie"),
        ("„silnik?” / „temperatura wody?” / „grill”", "temperatury silnika, rada o grillu"),
        ("„podsterowność na wejściu w ostatni zakręt”", "rada dla zakrętu i ustawień"),
        ("„zmieniłem balans na 54” / „czy pomogło?”", "zapis zmiany setupu i ocena po kilku okrążeniach"),
        ("„co zmienić w setupie?”", "propozycje zmian (w wyścigu tylko z kokpitu)"),
    ]),
    ("Pogoda", [
        ("„jaka pogoda?” / „czy będzie padać?”", "deszcz, wilgotność, prognoza, temperatura toru"),
        ("„kiedy deszczowe?” / „kiedy slicki?”", "czy i kiedy opłaca się zmienić opony"),
    ]),
    ("Zespół i pamięć", [
        ("„zapamiętaj …” / „notatka …”", "notatka do pamięci zespołu (AI bierze ją pod uwagę)"),
        ("inne pytanie", "odpowiada AI na serwerze zespołu (gdy działa)"),
    ]),
    ("Discord (kanał tekstowy)", [
        ("!i pytanie", "pytanie do inżyniera, odpowiedź głosem na kanale"),
        ("!w tekst", "wiadomość do kierowcy (inżynier ją przeczyta)"),
        ("!z tekst", "notatka do pamięci zespołu"),
        ("!stan", "pozycja, zjazd, najbliższe zmiany kierowców"),
    ]),
]
