"""Numer wersji Inżyniera LMU (plik VERSION w głównym folderze; podbijany przy każdej paczce)."""

import os


def version() -> str:
    try:
        with open(os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "VERSION"),
                  encoding="utf-8") as f:
            return f.read().strip() or "?"
    except OSError:
        return "?"
