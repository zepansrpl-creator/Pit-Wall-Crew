"""English help pages: commands, features, manual, about (Polish originals: commands.py, help_texts.py)."""

COMMANDS: list[tuple[str, list[tuple[str, str]]]] = [
    ("Controlling the engineer", [
        ("“quiet” / “silence” / “engineer, quiet” / “stop talking”", "“OK.” and complete silence (warnings too); speaks again after your next press of the radio button"),
        ("“<engineer's name>, quiet” (e.g. “Mark, quiet”)", "the same, when you gave the engineer a name (Settings → Voice)"),
        ("“urgent only” / “only when I ask”", "only urgent warnings and answers to your questions"),
        ("“you can talk” / “carry on”", "back to messages about changes"),
        ("“repeat” / “say again”", "repeats the last answer"),
        ("“radio check” / “can you hear me?”", "radio check"),
        ("“which ones?” / “which corners?”", "the full list after a short answer (“in 6 corners, mostly T3 and T11”), up to 2 minutes later"),
        ("“what can you do” / “help”", "short list of topics"),
        ("pressing the radio button", "interrupts what the engineer is saying"),
    ]),
    ("Turning hints on and off", [
        ("“no lapping calls” / “lapping calls on”", "warnings about faster classes behind you"),
        ("“coach” / “no coach”", "hints before a corner when the same mistake repeats"),
        ("“comparison” / “no comparison”", "“T5: you brake 15 metres earlier” – comparison with your best lap"),
        ("“team comparison” / “no team comparison”", "“T5: Patrick brakes 15 metres later. Try braking later.” – before a corner where a teammate is clearly faster in similar conditions"),
        ("“comments” / “no comments”", "a comment after you gain or lose a position"),
        ("“suggestions” / “no suggestions”", "setup and technique advice"),
    ]),
    ("Fuel, energy, pit stop", [
        ("“how much fuel?” / “will it last?”", "fuel, how many laps, margin"),
        ("“how much energy?” / “virtual energy?”", "virtual energy"),
        ("“when do I box?” / “what's the pit plan?”", "pit lap (at least 0.2% energy left at pit entry), how much energy, which tyres"),
        ("“how long is the stop?”", "stop time including the pit lane"),
        ("“which tyres do we change?” / “are we changing tyres?”", "which tyres to change at the stop (from the team plan or from wear) and why"),
        ("“how much to save?” / “how do I save?”", "consumption target per lap to save a stop or reach the planned pit lap"),
        ("“how is consumption changing?”", "fuel and energy consumption trend"),
        ("“how long to go?” / “how many laps left?”", "time and laps to the finish"),
    ]),
    ("Lap times and driving", [
        ("“what's my time?” / “how am I doing?”", "last and best lap, consistency"),
        ("“where am I losing time?” / “where can I gain?”", "corners with the biggest loss"),
        ("“what about turn five?” / “corner 5”", "details of a specific corner"),
        ("“am I losing pace?” / “am I tired?”", "fatigue and pace drop"),
        ("“what position?”", "position in class and overall"),
    ]),
    ("Rivals", [
        ("“who's ahead?” / “who am I chasing?”", "gap, pace, trend"),
        ("“who's behind?” / “who's chasing me?”", "gap, pace, trend"),
        ("“when will I catch him?” / “will he catch me?”", "in how many laps at the current pace"),
        ("“what's the rival's pace?”", "pace of the car ahead or behind"),
        ("“who's driving the car ahead?” / “rival's fastest driver”", "drivers in the rival car and their pace"),
        ("“did the rival change tyres?”", "estimate of the rival's tyres from the last stop"),
        ("“when will the rival pit?”", "predicted rival stop"),
        ("“when will the first hypercar lap me?” / “when will LMP2 catch me?”", "first car of a faster class: when it arrives and how far behind it is; the next ones"),
        ("“top speed of other cars?” / “what's the car ahead doing on the straight?” / “hypercar top speed?”", "rivals' top speed, yours and the fastest in class"),
    ]),
    ("Car", [
        ("“how are the tyres?” / “pressures?”", "wear, temperatures, pressures"),
        ("“brakes?”", "brake wear and temperatures"),
        ("“compare me with Patrick” / “what does Adam do differently?” / “where is my teammate faster?”", "your teammate's fastest lap on the same compound, with similar tyre wear, fuel and track temperature: in which corners he is faster, what he does differently (braking, minimum speed, throttle, gear) and advice; “which ones?” – full list"),
        ("“in which corners is Wieczorek slower than me?” / “compare with Wieczorek”", "a rival from your class: both best laps, where he is slower and faster, corner speed"),
        ("“compare tyre and brake temperatures with lap 4 after the stop” / “… with the previous stint” / “… with lap 12”", "last lap against the chosen one: front/rear brakes, front/rear tyres, brake cooling advice"),
        ("“damage?” / “should we repair?”", "damage and time loss"),
        ("“repair takes 30 seconds”", "whether repairing pays off with that time"),
        ("“engine?” / “water temperature?” / “grille”", "engine temperatures, grille advice"),
        ("“understeer on entry to the last corner”", "advice for the corner and setup"),
        ("“I changed brake bias to 54” / “did it help?”", "records the setup change and judges it after a few laps"),
        ("“what should I change in the setup?”", "suggested changes (in a race only cockpit adjustments)"),
        ("“what TC should I run?” / “traction control?” / “how much ABS?”", "current setting and advice from measurements (works without AI too)"),
    ]),
    ("Weather", [
        ("“what's the weather?” / “will it rain?”", "rain, wetness, forecast, track temperature"),
        ("“when do we go wets?” / “when slicks?”", "whether and when a tyre change pays off"),
    ]),
    ("Team and memory", [
        ("“remember …” / “note …”", "a note for the team memory (the AI takes it into account)"),
        ("“phone notification Adam: wake up, you're in next”", "instant phone notification to a teammate (ntfy); “notification to everyone: …” – to the whole team"),
        ("“tell the next driver that …” / “pass on to my teammate …”", "a note the engineer reads to the next driver at the handover briefing"),
        ("analytical questions: “compare…”, “what's the difference…”, “how much…”, “why…”, “who's fastest…”, with a rival's name, about the grille and cooling", "answered by the AI with full race data (the program's answer as reliable numbers)"),
        ("any other question", "answered by the AI (Groq); when speech recognition is unsure – “I didn't get that, say again.”"),
    ]),
    ("Pit wall (for the team)", [
        ("“To driver”", "a message the engineer reads to the driver (“Message from Matt: …”)"),
        ("“Ask the engineer”", "a question to the engineer, the answer is heard on the team radio"),
        ("“Ask (text only)”", "the answer appears only on the pit wall, the driver doesn't hear it"),
        ("“To memory”", "a note for the team memory"),
    ]),
    ("Problems and suggestions", [
        ("App → Help → “Report a problem” or pit wall → Help", "describe a problem or an idea – it goes straight to the author"),
    ]),
]

FEATURES: list[tuple[str, list[str]]] = [
    ("Pit Wall Crew in short", [
        "A voice race engineer for Le Mans Ultimate and a pit wall for the whole team. The engineer only talks about "
        "what changes something and answers your questions by voice. The team sees everything live in a browser and "
        "hears the engineer in their own app.",
    ]),
    ("Urgent warnings (immediately, short)", [
        "• Being lapped by a faster class: “Hypercar, 2 seconds”, groups of cars (“three hypercars”); not about cars that are stopped or entering the pits. On request: when the first hypercar / LMP2 will arrive.",
        "• Stopped or very slow car ahead (slow = below 55% of the usual speed at that spot), car off track.",
        "• Flags (including local yellows), FCY, penalties, track limits, green flag.",
        "• “Box, box” about 25 s before pit entry on the in-lap. After the chequered flag – no pit stop calls.",
    ]),
    ("Strategy", [
        "• Fuel and virtual energy: consumption measured the same way as in the game; how many laps are left, pit plan (how much energy, which tyres), stop time.",
        "• Pit as late as possible: at pit entry and at the finish at least 0.2% energy (0.3 l fuel) is left. When a little energy is missing to reach the planned pit lap – a consumption target per lap instead of pitting earlier.",
        "• Fuel ratio: a warning when fuel lasts fewer laps than energy.",
        "• Pit plan 3 laps before, a reminder on the in-lap, where you will rejoin after the stop.",
        "• Saving: when a few percent less consumption saves a stop – a target per lap and a check after every lap.",
        "• FCY: whether pitting now pays off. Damage: how many seconds it costs and whether to repair.",
        "• Tyres: wear and temperatures, when a new set pays off, “tyres up to temperature” after a change, pressures at night.",
        "• Weather: rain, drying track (“slicks faster in about X minutes”), when to change tyres.",
    ]),
    ("Rivals", [
        "• Gap and trend to the cars ahead and behind in your class, when you will catch them or who will catch you.",
        "• Rivals' top speed on the straight (car ahead, behind, fastest in class, other classes) compared with yours.",
        "• Pace of every driver in a rival car, predicted rival stop and their tyres.",
        "• A comment after gaining or losing a position – only once the position holds for 30 seconds.",
    ]),
    ("Coach and setup", [
        "• Coach before a corner when a mistake repeats over several laps (lock-ups, wheelspin, ABS/TC, throttle).",
        "• Comparison with your best lap on similar tyres: “T5: you brake 15 metres earlier”.",
        "• Comparison with a teammate: each driver's fastest laps (in different conditions) are saved in the team database automatically. The engineer picks a teammate's lap on the same compound with similar tyre wear, fuel and track temperature, tells you before a corner what the teammate does differently (“T5: Patrick brakes 15 metres later”) and, on request, where he is faster and what to change.",
        "• Corner comparison with a rival (“in which corners is Wieczorek slower?”) – from the car positions on track.",
        "• Setup suggestions from the cockpit (brake bias, TC, ABS) in a race, and in practice also garage changes (camber, brake ducts).",
        "• Describe the handling by voice (“understeer on entry to the last corner”) – the engineer checks the data and advises.",
        "• Driver fatigue: pace drop, worse consistency and mistakes.",
    ]),
    ("Team", [
        "• Pit wall in the browser (phone, computer): car status, track map with cars (Hypercar class leader marked), rivals with energy, stint schedule, team radio.",
        "• Schedule calculated live and phone notifications (ntfy) about 30 minutes before your stint and when it starts raining.",
        "• By voice: “phone notification Adam: wake up, you're in next” – the teammate gets a phone notification right away.",
        "• Messages from the pit wall to the driver (the engineer reads them) and “text only” questions.",
        "• Driver change briefing: damage, off-tracks and impacts of the previous driver, the plan, “tell the next driver …” notes; stint summary.",
        "• Team radio: when you're not driving, the app plays the engineer's messages from the team car (urgent ones only for the driver); on the pit wall “🔊 Listen to the engineer”.",
        "• Cloud AI (Groq, free): speech recognition (Whisper) and AI answers with no server and no load on the gaming PC.",
        "• Team memory: notes the AI takes into account (“ABS 9 too strong in the rain”).",
        "• Spectator link – live view only (the race, or the current driver's practice), no radio and no plan.",
    ]),
    ("Voice", [
        "• Natural voice with a radio effect and your own name for the engineer.",
        "• Radio button on the wheel or a key; pressing it interrupts the engineer. Silence in the recording (muted mic) – “I can't hear you”; unsure recognition – “I didn't get that, say again”.",
        "• Long lists shortened: “in 6 corners, mostly T3 and T11” – the full list with “which ones?”.",
        "• “Quiet” or “engineer, quiet” – “OK.” and complete silence (warnings too) until the next button press; “urgent only” – only warnings and answers. Solo mode – sharper tone, no team.",
    ]),
]

MANUAL: list[tuple[str, list[str]]] = [
    ("First start", [
        "• In LMU once: Settings → Gameplay → Enable Plugins = ON.",
        "• Team: enter the team code and password (from your teammates) or click “Create a new team…”. Click “Test connection” "
        "and choose your name. Share the code and password only privately.",
        "• Microphone and button: choose the microphone, “Test 3 s”, then “Set: press the button…” and press the button on your wheel.",
        "• Voice: choose the voice, speed, radio effect and name; “Listen”.",
        "• Click “Save and restart”.",
    ]),
    ("On race day", [
        "• Everyone in the team has the Pit Wall Crew app running – also when not driving. The program recognises who is driving.",
        "• AI: paste a free Groq key on the pit wall once (Team → Team AI). Nothing else to install.",
        "• Whoever isn't driving keeps the app running – they hear the engineer's messages (team radio). Talk to each other however you like (e.g. Discord).",
        "• 24 h race: whoever isn't driving may turn off LMU, the app and the computer. Before your stint (phone notification) start LMU and Pit Wall Crew before you get in the car – the plan, briefing, messages and teammates' data are in the team database.",
        "• Pit wall: the “Pit wall ↗” button in the app or the link/QR in the Team tab on the page.",
        "• Before the start check: green “Team” and “AI: Groq” in the app, “live” on the pit wall.",
    ]),
    ("Talking to the engineer", [
        "Hold the button, speak, release. You can also type a question on the “Engineer” page of the app. "
        "The full list of commands is on the “Commands” page. When the rules don't know the answer, the question goes to the AI (Groq).",
    ]),
    ("Pit wall (web page)", [
        "• Live: race, pit stop, tyres, weather, driver, track map, rivals, stint schedule, team radio.",
        "• Schedule and plan: race start, tyres per race, stint plan (driver from a list, laps, left / right tyre changes, times and time of day calculated automatically, tyre counter); paste a plan from a spreadsheet. The engineer changes tyres according to the plan unless one wouldn't last; the plan applies when the race has the planned length. After a stop: measured time vs plan and measured 0 / 2 / 4 tyre stop times with one button.",
        "• Team: code, QR, drivers and ntfy topics (Test button), spectator link.",
        "• Laps (with CSV download) and Team memory.",
        "• Radio: “To driver” – the engineer reads it; “Ask the engineer” – answer by voice; “Ask (text only)”; “To memory”.",
    ]),
    ("Phone notifications", [
        "• Install the free ntfy app (Google Play / App Store).",
        "• On the pit wall: Team tab → click 📱 next to your name – your topic and QR code appear.",
        "• In ntfy tap +, enter the topic and Subscribe (or scan the QR code).",
        "• On the pit wall click Test next to your name – “Pit Wall Crew – test” arrives on your phone.",
        "The notification comes about 30 minutes before your stint, and a second one if the stint moves by 10 minutes or more.",
    ]),
    ("Stint schedule (one person, before the race)", [
        "• Pit wall → Team: add the drivers and save.",
        "• Schedule and plan → 1. Race: start, length, lap time, tyres per race → Save.",
        "• 2. Stint plan → Generate plan automatically (laps, drivers, tyre wear “from measurements”, tyres optimally within the limit, stop times) → adjust the table: driver from the list, Left / Right tyres → Save plan. The counter shows whether you stay within the tyre allocation.",
        "• During the race the schedule recalculates itself from the real pace.",
    ]),
    ("When something doesn't work", [
        "• Pit wall: “no data from the game” – is the app running on the driver's PC with a green “Team”?",
        "• “Wrong team code or password” – fix it on the Team page, “Test connection”, “Save”.",
        "• The engineer can't hear you – Microphone and button page: “Test 3 s”; in Windows: Privacy → Microphone.",
        "• You don't hear the engineer when not driving – Team: “Listen to the engineer when I'm not driving”; the app must be running.",
        "• “AI: Groq – wrong key” – paste the key again on the pit wall (Team → Team AI).",
        "• No notifications – race start and drivers in the plan, topic in ntfy, Test button; the app running on any teammate's PC.",
        "• Without internet the engineer keeps working on its own and reconnects automatically.",
        "• Every message is heard twice – the program is running twice. Close the app and the “pythonw” processes in Task Manager, then start it once.",
        "• “I can't hear you” – the microphone is muted (button on the headset) or another microphone is selected.",
        "• Windows blocks files after unpacking (“Smart App Control”) – before unpacking: right-click the package → Properties → Unblock.",
        "• Game stutters – usually not enough graphics memory: lower textures, visible cars and shadows, close other programs.",
        "• Another problem or an idea – Help → “Report a problem” (in the app or on the pit wall). It goes straight to the author.",
        "• Crash reports: with your consent (asked on first start, changed on the “Report a problem” page) the program sends the author the error and the log of the last session – no voice recordings, keys or passwords.",
        "• Moving the program: move the whole folder and run skroty.bat (new desktop icon).",
    ]),
    ("Updates", [
        "The app checks for updates at start (before starting the engineer – never while driving), downloads the new "
        "version, replaces the files and restarts. Settings and data are kept. You can turn this off under Advanced; "
        "there is also “Check for updates now”.",
        "Testers with a code from the author (Advanced → Tester code) get new versions before everyone else.",
    ]),
]

ABOUT = [
    ("Pit Wall Crew", [
        "Voice race engineer and pit wall for Le Mans Ultimate.",
        "Created by Maciej Szczepaniak from FR Mods.",
    ]),
    ("Thanks", [
        "To Rett and Barny for helping with the tests.",
    ]),
]
