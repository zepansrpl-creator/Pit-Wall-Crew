"""Inżynier AI: odpowiada na pytania kierowcy na podstawie podsumowania stanu wyścigu."""

from __future__ import annotations

import os
from typing import Optional

from .setup_rules import SETUP_GUIDE

SYSTEM_PROMPT = """Jesteś inżynierem wyścigowym kierowcy w symulatorze Le Mans Ultimate. Rozmawiasz z nim przez radio podczas jazdy.

Zasady:
- Odpowiadaj po polsku, krótko, jak przez radio: 1–3 zdania, najważniejsza informacja na początku.
- Pytania o wyścig, auto i jazdę: używaj WYŁĄCZNIE liczb z bloku STAN. Nie wymyślaj danych. Jeśli czegoś nie ma w danych, powiedz to wprost i powiedz, czego brakuje (np. "potrzebuję jeszcze dwóch czystych okrążeń").
- Pytania niezwiązane z wyścigiem (wiedza ogólna, historia, wyścigi w realu, przepisy, luźna rozmowa): odpowiedz normalnie z własnej wiedzy, krótko i rzeczowo, bez wspominania o bloku STAN. Gdy nie jesteś pewien faktu, powiedz to.
- Zaokrąglaj: czasy okrążeń do dziesiątych, różnice do setnych lub dziesiątych, paliwo do pełnych litrów, okrążenia do jednego miejsca po przecinku.
- Pisz tekst do odczytu głosem: bez list, nagłówków, emotek i skrótów typu "okr." — pisz pełne słowa. Ułamki pisz z przecinkiem.
- Rady o technice jazdy opieraj na sekcji ZAKRĘTY (hamowanie, minimalna prędkość, moment gazu). Podawaj jedną konkretną rzecz do poprawy, nie listę.
- Rady o setupie dawaj ostrożnie: jedna zmiana na raz, wskaż, co obserwować na kolejnych okrążeniach. Opieraj je na temperaturach opon, ciśnieniach i opisie kierowcy.
- Gdy pytanie dotyczy strategii (pitstop, paliwo, VE), podaj konkretną liczbę i ewentualny zapas.
- Odpowiadaj dokładnie na zadane pytanie. Nie dodawaj ogólnych rad na koniec („trzymaj tempo”, „obserwuj temperatury opon”, „uważaj na hamulce”), jeśli nie wynikają z pytania.
- Liczby pisz cyframi, a rzeczownik po liczbie w poprawnej formie: 1 okrążenie, 2–4 okrążenia, 5 okrążeń, 22 okrążenia, 25 okrążeń; 1 sekunda, 2 sekundy, 5 sekund; 2 stopnie, 5 stopni; 1 litr, 3 litry, 7 litrów. Nie używaj skrótów ani symboli (km/h, %, ok., okr., l) – pisz „kilometrów na godzinę”, „procent”, „około”, „okrążeń”, „litrów”. Nie podawaj zakresów z myślnikiem i nie używaj nawiasów.
- Jeśli pytanie wygląda na źle rozpoznane i nie da się zgadnąć sensu, powiedz krótko „Nie zrozumiałem, powtórz” zamiast zgadywać.
- Tekst pytania pochodzi z rozpoznawania mowy i może mieć błędy (np. "te pięć" = T5, "pod sterowność" = podsterowność). Odgadnij sens; dopytaj tylko, gdy naprawdę nie wiadomo, o co chodzi.
"""

SETUP_PROMPT = """
Kierowca pyta o prowadzenie auta albo setup. Masz w STAN sekcje PROWADZENIE (pomiar balansu z kątów poślizgu opon, per zakręt i faza), PODPOWIEDZI WYNIKAJĄCE Z DANYCH, uwagi kierowcy i ewentualną ostatnią zmianę setupu z porównaniem przed/po.
Odpowiedz w 2–4 zdaniach: (1) potwierdź, czy dane zgadzają się z odczuciem kierowcy i w której fazie zakrętu jest problem, (2) zaproponuj JEDNĄ zmianę z konkretną wielkością (np. o 1 klik, o 0,5%), najlepiej regulowaną w aucie, (3) powiedz, co ma sprawdzić na kolejnych okrążeniach. Jeśli kierowca zgłasza zmianę setupu, oceń ją na podstawie porównania przed/po albo powiedz, ile czystych okrążeń jeszcze potrzeba.
""" + SETUP_GUIDE


class AIEngineer:
    def __init__(self, model: str = "claude-haiku-5-5", api_key: Optional[str] = None,
                 max_tokens: int = 300, history_turns: int = 6, setup_model: Optional[str] = None) -> None:
        self.model = model
        self.setup_model = setup_model or model
        self.max_tokens = max_tokens
        self.history_turns = history_turns
        self.history: list[dict] = []
        self.client = None
        key = api_key or os.environ.get("ANTHROPIC_API_KEY")
        if key:
            try:
                import anthropic
                self.client = anthropic.Anthropic(api_key=key)
            except ImportError:
                self.client = None

    @property
    def online(self) -> bool:
        return self.client is not None

    def ask(self, question: str, state: str, setup: bool = False) -> str:
        if self.client is None:
            return offline_answer(question, state, setup)
        user = f"STAN (aktualne dane z gry):\n{state}\n\nKIEROWCA MÓWI: {question}"
        messages = self.history[-self.history_turns * 2:] + [{"role": "user", "content": user}]
        try:
            resp = self.client.messages.create(
                model=self.setup_model if setup else self.model,
                max_tokens=self.max_tokens + (150 if setup else 0),
                system=SYSTEM_PROMPT + (SETUP_PROMPT if setup else ""),
                messages=messages,
            )
            answer = "".join(b.text for b in resp.content if getattr(b, "type", "") == "text").strip()
        except Exception as e:  # sieć, limit, zły klucz
            return f"Nie mam połączenia z serwerem AI ({type(e).__name__}). " + offline_answer(question, state, setup)
        # do historii trafia samo pytanie (bez starego stanu), żeby nie mieszać nieaktualnych liczb
        self.history += [{"role": "user", "content": question}, {"role": "assistant", "content": answer}]
        return answer


def _line(state: str, prefix: str) -> Optional[str]:
    for l in state.splitlines():
        if l.startswith(prefix):
            return l.split(":", 1)[1].strip()
    return None


def offline_answer(question: str, state: str, setup: bool = False) -> str:
    """Odpowiedzi bez AI: proste dopasowanie słów kluczowych do sekcji stanu."""
    q = question.lower()
    if setup:
        corner = _line(state, "PORADA DLA ZAKRĘTU")
        tips = _line(state, "PODPOWIEDZI WYNIKAJĄCE Z DANYCH")
        change = _line(state, "OSTATNIA ZMIANA SETUPU")
        if any(w in q for w in ("zmieniłem", "zmiana setupu", "ustawiłem", "dałem", "przestawiłem")):
            return "Przyjąłem zmianę. Zrób trzy czyste okrążenia, potem zapytaj, czy pomogło."
        if "pomog" in q or "lepiej" in q:
            return change or "Nie mam zapisanej zmiany setupu. Powiedz, co zmieniłeś."
        if corner:
            return corner
        if tips:
            return " ".join(tips.split(". ")[:2]).rstrip(".") + "."
        return "Za mało danych o prowadzeniu, potrzebuję czystych okrążeń."
    if any(w in q for w in ("paliw", "benzyn", "tank", "ve", "energi", "pitstop", "zjazd")):
        return _line(state, "PALIWO") or "Nie mam jeszcze danych o paliwie."
    if any(w in q for w in ("zakręt", "tracę", "trace", "gdzie", "czas", "hamow")):
        return _line(state, "ZAKRĘTY") or "Brak porównania zakrętów."
    if any(w in q for w in ("rywal", "tempo", "kto", "przed", "za mną", "goni")):
        return _line(state, "RYWALE W KLASIE") or _line(state, "NAJLEPSZE CZASY") or "Brak danych o rywalach."
    if any(w in q for w in ("opon", "ciśnien", "temperatur")):
        return _line(state, "OPONY") or "Brak danych o oponach."
    return "Bez połączenia z AI odpowiadam tylko o paliwie, zakrętach, rywalach i oponach."
