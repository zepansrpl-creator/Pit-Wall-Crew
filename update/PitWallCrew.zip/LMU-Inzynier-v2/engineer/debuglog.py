"""Dziennik diagnostyczny – w tej wersji wyłączony (pusta wersja)."""

FULL = False


class DebugLog:
    enabled = False
    path = ""
    game_t = None

    def start(self, folder: str = "recordings") -> None:
        return

    def log(self, _kind: str, /, **data) -> None:
        return

    def flush(self) -> None:
        return

    def close(self) -> None:
        return

    def state(self, *a, **k) -> None:
        return

    def audio_out(self, *a, **k) -> None:
        return

    def audio_in(self, *a, **k) -> None:
        return


DBG = DebugLog()
