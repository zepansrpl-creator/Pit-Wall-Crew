"""Symulowany wyścig do testów bez gry.

Fikcyjny tor 4,2 km z 7 zakrętami, kierowca z powtarzalnymi błędami
(późny gaz w T3, za wczesne hamowanie w T5 co kilka okrążeń) i 10 rywali w trzech klasach
(GT3, LMP2, Hypercar). Zdarzenia: auto stojące na torze (ok. 7. okrążenie), FCY (ok. 14.),
uszkodzenie Twojego auta (ok. 16.), auto stojące poza torem (ok. 19.), nierówne zużycie opon.
"""

from __future__ import annotations

import math
import random
from dataclasses import dataclass

from ..model import CarScoring, PlayerTelemetry, Snapshot, TyreState

TRACK_LEN = 4200.0


def demo_xy(dist: float) -> tuple[float, float]:
    """Kształt toru demo (do mapy): owal z szykaną."""
    a = 2 * math.pi * (dist % TRACK_LEN) / TRACK_LEN
    r = 1.0 + 0.18 * math.sin(3 * a) + 0.08 * math.cos(5 * a)
    return 900 * r * math.cos(a), 520 * r * math.sin(a)
STEP = 5.0           # rozdzielczość profilu prędkości (m)
VMAX = 82.0          # m/s (~295 km/h)
DECEL = 24.0         # m/s^2 hamowanie
ACCEL = 7.5          # m/s^2 przyspieszanie


@dataclass
class Corner:
    dist: float      # pozycja wierzchołka (m)
    vmin: float      # m/s
    direction: int   # -1 lewy, 1 prawy


CORNERS = [
    Corner(450, 22, 1), Corner(1100, 38, -1), Corner(1650, 26, 1),
    Corner(2300, 52, 1), Corner(2900, 20, -1), Corner(3400, 44, -1), Corner(3900, 33, 1),
]


def _profile(corners: list[Corner], brake_early: dict[int, float], vmin_delta: dict[int, float],
             accel_mult: dict[int, float]) -> list[float]:
    n = int(TRACK_LEN / STEP)
    v = [VMAX] * n
    for ci, c in enumerate(corners):
        vmin = c.vmin + vmin_delta.get(ci, 0.0)
        early = brake_early.get(ci, 0.0)
        acc = ACCEL * accel_mult.get(ci, 1.0)
        for i in range(n):
            d = i * STEP
            before = (c.dist - d) % TRACK_LEN
            after = (d - c.dist) % TRACK_LEN
            if before < 900:
                dist_to_brake = max(0.0, before - early)
                v[i] = min(v[i], math.sqrt(vmin ** 2 + 2 * DECEL * dist_to_brake))
            if after < 1500:
                v[i] = min(v[i], math.sqrt(vmin ** 2 + 2 * acc * after))
    return v


class _Rival:
    def __init__(self, cid, driver, vehicle, cls, base_lap, start_dist):
        self.cid, self.driver, self.vehicle, self.cls = cid, driver, vehicle, cls
        self.base_lap = base_lap
        self.dist_total = start_dist
        self.lap_time = base_lap
        self.laps_done = 0
        self.lap_start_t = 0.0
        self.last_lap = 0.0
        self.best_lap = 0.0
        self.pit_stops = 0
        self.in_pits_until = -1.0
        self.pit_lap = random.randint(9, 13)
        self.stopped_until = -1.0
        self.off_track = False


class DemoSource:
    def __init__(self, speed: float = 10.0, seed: int = 7) -> None:
        random.seed(seed)
        self.poll_interval = 0.05 / speed
        self.dt = 0.05
        self.t = 0.0
        self.race_len = 40 * 60.0
        self._lap = 0
        self._lap_dist = 0.0
        self._lap_start_t = 0.0
        self._laps_done = 0
        self._last_lap = 0.0
        self._best_lap = 0.0
        self._fuel = 70.0
        self._ve = 1.0
        self._wear = 0.0
        self._s1 = self._s2 = 0.0
        self._burn, self._ve_burn = 2.9, 0.045
        self._pitting, self._pit_wait, self._pit_stops = False, 0.0, 0
        self._last_s1 = self._last_s2 = 0.0
        self._new_lap_profile()
        self.rivals = [
            _Rival(1, "K. Nowak", "Porsche 911 GT3 R", "GT3", 70.6, 150.0),
            _Rival(2, "J. Smith", "BMW M4 GT3", "GT3", 69.9, 420.0),
            _Rival(3, "A. Rossi", "Ferrari 296 GT3", "GT3", 70.1, -120.0),
            _Rival(4, "P. Weber", "Aston Martin Vantage", "GT3", 70.9, -300.0),
            _Rival(5, "L. Moreau", "Ford Mustang GT3", "GT3", 71.6, -520.0),
            _Rival(6, "T. Kato", "Toyota GR010", "Hypercar", 62.8, -1300.0),
            _Rival(7, "M. Dubois", "Alpine A424", "Hypercar", 63.3, -1900.0),
            _Rival(8, "S. Berg", "Cadillac V-Series.R", "Hypercar", 63.0, 900.0),
            _Rival(9, "O. Janssen", "Oreca 07", "LMP2", 66.0, -2200.0),
            _Rival(10, "M. Kowal", "Oreca 07", "LMP2", 66.5, -800.0),
        ]
        self._tyre_age = 0
        self._damaged = False
        self._dents = [0] * 8
        self._impact_t = 0.0
        self._events_done: set[str] = set()
        for r in self.rivals:
            r.dist_total += 0.0

    def _new_lap_profile(self) -> None:
        brake_early = {4: 14.0} if self._lap % 3 == 1 else {}
        vmin_delta = {ci: random.uniform(-1.2, 0.6) for ci in range(len(CORNERS))}
        if 4 in brake_early:
            vmin_delta[4] = -2.5
        accel_mult = {2: 0.8} if self._lap % 2 == 0 else {}  # T3: co drugie okrążenie nieśmiały gaz
        if getattr(self, "_damaged", False):   # uszkodzone auto: wolniej we wszystkich zakrętach
            vmin_delta = {k: v - 1.1 for k, v in vmin_delta.items()}
        self._v = _profile(CORNERS, brake_early, vmin_delta, accel_mult)
        age = getattr(self, "_tyre_age", 0)
        self._v = [x * (1 - 0.0007 * age) for x in self._v]   # zużyte opony: wolniej
        self._brake_zone = brake_early

    def _v_at(self, d: float) -> float:
        i = int(d / STEP) % len(self._v)
        return self._v[i]

    def _water(self) -> float:
        """Woda: stabilnie ok. 91°C, od 9. okrążenia rośnie o ok. 1,3°C na okrążenie (jazda w ruchu)."""
        laps = self._laps_done + self._lap_dist / TRACK_LEN
        return 91.0 + max(0.0, laps - 8) * 1.3 + 0.4 * math.sin(self.t / 7)

    def close(self) -> None:
        pass

    def _event(self, name: str, t0: float) -> bool:
        if self.t >= t0 and name not in self._events_done:
            self._events_done.add(name)
            return True
        return False

    def read(self) -> Snapshot:
        self.t += self.dt
        player_total0 = self._laps_done * TRACK_LEN + self._lap_dist
        if self._event("crash1", 430):        # Weber staje na torze 900 m przed Tobą
            r = self.rivals[3]
            r.dist_total, r.stopped_until, r.off_track = player_total0 + 900, self.t + 60, False
        if self._event("crash2", 1300):       # Rossi stoi poza torem 700 m przed Tobą
            r = self.rivals[2]
            r.dist_total, r.stopped_until, r.off_track = player_total0 + 700, self.t + 40, True
        if self._event("damage", 1150):       # Twoje uderzenie
            self._dents = [0, 2, 1, 0, 0, 0, 0, 0]
            self._impact_t = self.t
            self._damaged = True
        fcy = 1000 <= self.t < 1070
        # --- gracz ---
        v = self._v_at(self._lap_dist)
        v_next = self._v_at(self._lap_dist + 15)
        braking = v_next < v - 0.4
        accelerating = v_next > v + 0.05
        in_pits = self._pitting and self._lap_dist < 450
        if in_pits:
            v = min(v, 22.0)  # ogranicznik w alei
            braking = accelerating = False
            if self._lap_dist >= 200 and self._pit_wait > 0:
                v = 0.0
                self._pit_wait -= self.dt
                if self._pit_wait <= 0:
                    self._fuel = min(100.0, self._fuel + 45.0)
                    self._ve = 1.0
                    self._wear = 0.0
                    self._tyre_age = 0
                    self._pit_stops += 1
        elif self._pitting:
            self._pitting = False
        self._lap_dist += v * self.dt
        frac = v * self.dt / TRACK_LEN
        self._fuel = max(0.5, self._fuel - self._burn * frac)
        self._ve = max(0.0, self._ve - self._ve_burn * frac)
        if self._lap_dist >= 1400 and self._s1 == 0:
            self._s1 = self.t - self._lap_start_t
        if self._lap_dist >= 2800 and self._s2 == 0:
            self._s2 = self.t - self._lap_start_t
        if self._lap_dist >= TRACK_LEN:
            self._lap_dist -= TRACK_LEN
            lap_time = self.t - self._lap_start_t
            self._last_lap = lap_time
            self._last_s1, self._last_s2 = self._s1, self._s2
            if self._best_lap <= 0 or lap_time < self._best_lap:
                self._best_lap = lap_time
            self._lap_start_t = self.t
            self._laps_done += 1
            self._lap += 1
            self._s1 = self._s2 = 0.0
            self._burn = random.uniform(2.8, 3.05)
            self._ve_burn = random.uniform(0.043, 0.047)
            self._wear += 0.018
            self._tyre_age += 1
            self._new_lap_profile()
            if self._ve < 0.07 or self._fuel < 6:
                self._pitting, self._pit_wait = True, 30.0

        nearest = min(CORNERS, key=lambda c: abs((self._lap_dist - c.dist + TRACK_LEN / 2) % TRACK_LEN - TRACK_LEN / 2))
        off = abs((self._lap_dist - nearest.dist + TRACK_LEN / 2) % TRACK_LEN - TRACK_LEN / 2)
        steer = nearest.direction * max(0.0, 1 - off / 120) * (40 / max(nearest.vmin, 15)) * 0.5
        lat_g = (v ** 2) * abs(steer) / 140 / 9.81 * nearest.direction
        # balans: ostatni zakręt (T7) podsterowny na wejściu i w środku, T3 nadsterowny na wyjściu
        rel7 = (self._lap_dist - CORNERS[6].dist + TRACK_LEN / 2) % TRACK_LEN - TRACK_LEN / 2
        rel3 = (self._lap_dist - CORNERS[2].dist + TRACK_LEN / 2) % TRACK_LEN - TRACK_LEN / 2
        base_slip = min(6.0, abs(lat_g) * 2.2)
        front_extra = 1.7 if -160 < rel7 < 20 else 0.0
        rear_extra = 1.5 if 20 < rel3 < 160 else 0.0
        tc_active = rear_extra > 0 and accelerating
        tyres = []
        for i in range(4):
            base = 86 + (6 if i < 2 else 2) + random.uniform(-0.5, 0.5)
            slip = base_slip + (front_extra if i < 2 else rear_extra) + random.uniform(-0.2, 0.2)
            # lewa/środek/prawa strona: przednie mocno gorętsze po wewnętrznej (dużo camberu)
            inner_hot = 13 if i < 2 else 4
            temps = (base - 3, base + 1, base - 3 + inner_hot) if i in (0, 2) else (base - 3 + inner_hot, base + 1, base - 3)
            tyres.append(TyreState(temp_c=temps, carcass_c=base, pressure_kpa=176 + i,
                                   wear=self._wear * (1.5, 1.0, 1.15, 0.9)[i], brake_c=420, optimal_c=90,
                                   slip_deg=slip if v > 5 else 0.0,
                                   # demo: kierowca blokuje przód na hamowaniu do drugiego zakrętu
                                   long_slip=0.45 if (i < 2 and braking and nearest is CORNERS[1] and v > 15)
                                   else 0.02))
        player = PlayerTelemetry(
            lap=self._lap, lap_dist=self._lap_dist, speed_kmh=v * 3.6,
            throttle=1.0 if accelerating or (not braking and v > VMAX - 1) else (0.0 if braking else 0.45),
            brake=0.95 if braking else 0.0, steering=steer, gear=max(1, min(6, int(v / 14) + 1)),
            rpm=4800 + (v % 14) / 14 * 3400, max_rpm=8500, fuel_l=self._fuel, fuel_capacity_l=100.0,
            virtual_energy=self._ve, in_pits=in_pits, lat_g=lat_g, tc_active=tc_active, lon_g=-2.3 if braking else 0.6, yaw_rate=steer * 0.6,
            tyres=tyres, compound_front="Medium", compound_rear="Medium", rear_brake_bias=0.44, tc=4, abs=6,
            dents=list(self._dents), last_impact_t=self._impact_t, last_impact_mag=3000 if self._impact_t else 0,
            water_c=self._water(), oil_c=self._water() + 18, overheating=self._water() > 109,
        )

        # --- rywale ---
        player_total = self._laps_done * TRACK_LEN + self._lap_dist
        cars = []
        for r in self.rivals:
            if self.t < r.in_pits_until or self.t < r.stopped_until:
                pass
            else:
                r.dist_total += TRACK_LEN / r.lap_time * self.dt
            done = int(r.dist_total // TRACK_LEN) if r.dist_total > 0 else 0
            if done > r.laps_done and r.dist_total > 0:
                lap_t = self.t - r.lap_start_t if r.laps_done > 0 else r.lap_time
                r.last_lap = lap_t
                if r.best_lap <= 0 or lap_t < r.best_lap:
                    r.best_lap = lap_t
                r.laps_done = done
                r.lap_start_t = self.t
                r.lap_time = r.base_lap + random.uniform(-0.4, 0.5) + 0.02 * done
                if done == r.pit_lap:
                    r.in_pits_until = self.t + 62
                    r.pit_stops += 1
            cars.append((r, r.dist_total))
        cars.append((None, player_total))
        cars.sort(key=lambda x: -x[1])
        # niebieska flaga: szybsza klasa tuż za Tobą
        blue = any(r is not None and r.cls in ("Hypercar", "LMP2") and 0 < (player_total - tot) % TRACK_LEN < 90
                   and self.t >= r.in_pits_until and self.t >= r.stopped_until for r, tot in cars)
        yellow_sector = [False, False, False]
        for r, tot in cars:
            if r is not None and self.t < r.stopped_until:
                yellow_sector[min(2, int((tot % TRACK_LEN) / 1400))] = True
        lead_total = cars[0][1]
        out = []
        for place, (r, total) in enumerate(cars, start=1):
            behind_m = lead_total - total
            if r is None:
                out.append(CarScoring(
                    car_id=0, driver="Maciej Szczepaniak", vehicle="Lamborghini Huracan GT3", car_class="GT3",
                    place=place, laps_done=self._laps_done, lap_dist=self._lap_dist, last_lap=self._last_lap,
                    best_lap=self._best_lap, last_s1=self._last_s1, last_s2=self._last_s2,
                    time_behind_leader=behind_m / 60.0, laps_behind_leader=int(behind_m // TRACK_LEN),
                    is_player=True, fuel_fraction=self._fuel / 100.0, in_pits=in_pits, pit_stops=self._pit_stops,
                    speed_kmh=v * 3.6, blue_flag=blue))
            else:
                out.append(CarScoring(
                    car_id=r.cid, driver=r.driver, vehicle=r.vehicle, car_class=r.cls, place=place,
                    laps_done=r.laps_done, lap_dist=max(0.0, total) % TRACK_LEN, last_lap=r.last_lap,
                    best_lap=r.best_lap, in_pits=self.t < r.in_pits_until, pit_stops=r.pit_stops,
                    time_behind_leader=behind_m / 60.0, laps_behind_leader=int(behind_m // TRACK_LEN),
                    speed_kmh=0.0 if self.t < r.stopped_until else (60.0 if self.t < r.in_pits_until
                                                                   else TRACK_LEN / r.lap_time * 3.6),
                    off_track=r.off_track and self.t < r.stopped_until,
                    path_lateral=(7.0 if r.off_track else -3.0) if self.t < r.stopped_until else 0.0))

        for c in out:
            c.x, c.z = demo_xy(c.lap_dist)
        return Snapshot(
            t=self.t, session="race", track="Demo Ring", track_length=TRACK_LEN,
            car_name="Lamborghini Huracan GT3", time_remaining=max(0.0, self.race_len - self.t), max_laps=None,
            phase=("fcy" if fcy else "green") if self.t < self.race_len else "over", air_temp=21.0, track_temp=29.0,
            rain=0.0, wetness=0.0, player=player, cars=out, sector_yellow=yellow_sector,
            yellow_state=(2 if self.t < 1020 else 4) if fcy else 0,
        )
