"""Odczyt Le Mans Ultimate z wbudowanej pamięci współdzielonej LMU_Data.

Wymaga: w grze Ustawienia -> Rozgrywka -> "Enable Plugins" = ON.
Działa tylko na Windows, na tym samym komputerze co gra.
"""

from __future__ import annotations

import math
import os
import sys
from typing import Optional

from ..model import CarScoring, PlayerTelemetry, Snapshot, TyreState

_VENDOR = os.path.join(os.path.dirname(__file__), "..", "..", "vendor")
if _VENDOR not in sys.path:
    sys.path.insert(0, os.path.abspath(_VENDOR))

from pyLMUSharedMemory import lmu_data  # noqa: E402
from pyLMUSharedMemory.lmu_mmap import MMapControl  # noqa: E402

KELVIN = 273.15
G = 9.81


def _txt(raw: bytes) -> str:
    return raw.split(b"\0", 1)[0].decode("utf-8", errors="ignore").strip()


def _session_name(code: int) -> str:
    if code == 0:
        return "test"
    if 1 <= code <= 4:
        return "practice"
    if 5 <= code <= 8:
        return "qualify"
    if code == 9:
        return "warmup"
    return "race"


def _phase_name(code: int) -> str:
    return {5: "green", 6: "fcy", 7: "stopped", 8: "over", 9: "paused"}.get(code, "before")


class LMUSource:
    """Źródło danych na żywo z LMU."""

    def __init__(self) -> None:
        # Pamięci wspólnej NIE tworzymy sami. mmap z nazwą w Windows tworzy ją, gdy jeszcze nie istnieje –
        # wtedy gra przy wejściu na serwer dostaje obszar założony przez nas (o rozmiarze z naszej wersji
        # struktury), co może ją wysypać. Podłączamy się dopiero, gdy gra sama ją utworzy.
        self._mmap = None
        self._rh = None          # szybki odczyt prześwitu (dobijanie trwa 10–20 ms)
        self._next_try = 0.0
        self._last_lap_dist = 0.0

    def close(self) -> None:
        if self._rh is not None:
            self._rh.stop()
        if self._mmap is not None:
            self._mmap.close()

    @staticmethod
    def _exists() -> bool:
        try:
            import ctypes
            k32 = ctypes.windll.kernel32
            k32.OpenFileMappingW.restype = ctypes.c_void_p
            h = k32.OpenFileMappingW(0x0004, False, lmu_data.LMUConstants.LMU_SHARED_MEMORY_FILE)  # FILE_MAP_READ
            if h:
                k32.CloseHandle(ctypes.c_void_p(h))
                return True
            return False
        except Exception:
            return False

    def read(self) -> Optional[Snapshot]:
        """Zwraca Snapshot albo None, gdy gra nie działa lub kierowca nie jest na torze."""
        if self._mmap is None:
            import time as _t
            if _t.monotonic() < self._next_try:
                return None
            self._next_try = _t.monotonic() + 2.0
            if not self._exists():
                return None
            m = MMapControl(lmu_data.LMUConstants.LMU_SHARED_MEMORY_FILE, lmu_data.LMUObjectOut)
            m.create(0)  # tryb kopii: stabilny odczyt
            self._mmap = m
            try:
                from .rideh import RideHeightSampler
                self._rh = RideHeightSampler(m._mmap_buffer, lmu_data)
                self._rh.start()
            except Exception:
                self._rh = None
        self._mmap.update()
        d = self._mmap.data
        if not d.generic.gameVersion:
            return None
        sc = d.scoring.scoringInfo
        tel = d.telemetry
        n = max(0, min(sc.mNumVehicles, lmu_data.LMUConstants.MAX_MAPPED_VEHICLES))
        if n == 0:
            return None

        cars: list[CarScoring] = []
        player_veh = None
        for i in range(n):
            v = d.scoring.vehScoringInfo[i]
            car = CarScoring(
                car_id=v.mID,
                driver=_txt(v.mDriverName),
                vehicle=_txt(v.mVehicleName),
                car_class=_txt(v.mVehicleClass),
                place=v.mPlace,
                laps_done=v.mTotalLaps,
                lap_dist=v.mLapDist,
                last_lap=v.mLastLapTime,
                best_lap=v.mBestLapTime,
                last_s1=v.mLastSector1,
                last_s2=v.mLastSector2,
                best_s1=v.mBestSector1,
                best_s2=v.mBestSector2,
                in_pits=bool(v.mInPits),
                pit_stops=v.mNumPitstops,
                time_behind_leader=v.mTimeBehindLeader,
                laps_behind_leader=v.mLapsBehindLeader,
                is_player=bool(v.mIsPlayer),
                fuel_fraction=v.mFuelFraction / 255.0,
                finished=v.mFinishStatus == 1,
                speed_kmh=math.sqrt(v.mLocalVel.x ** 2 + v.mLocalVel.y ** 2 + v.mLocalVel.z ** 2) * 3.6,
                off_track=abs(v.mPathLateral) > abs(v.mTrackEdge) + 1.0 if v.mTrackEdge else False,
                path_lateral=float(v.mPathLateral),
                blue_flag=v.mFlag == 6,
                penalties=v.mNumPenalties,
                pit_state=v.mPitState,
                control=int(v.mControl),
                x=float(v.mPos.x),
                z=float(v.mPos.z),
            )
            cars.append(car)
            if car.is_player:
                player_veh = v

        player = None
        if tel.playerHasVehicle and player_veh is not None:
            t = tel.telemInfo[tel.playerVehicleIdx]
            vel = t.mLocalVel
            speed_ms = math.sqrt(vel.x ** 2 + vel.y ** 2 + vel.z ** 2)
            # Scoring (dystans) odświeża się ~5 Hz, telemetria ~100 Hz: dystans ekstrapolujemy prędkością.
            dt = max(0.0, min(0.5, t.mElapsedTime - sc.mCurrentET))
            lap_dist = player_veh.mLapDist + speed_ms * dt
            if sc.mLapDist > 0 and lap_dist >= sc.mLapDist:
                lap_dist -= sc.mLapDist
            tyres = []
            rh_min = self._rh.take() if self._rh is not None else None
            for wi, w in enumerate(t.mWheels):
                long_v = max(3.0, abs(w.mLongitudinalGroundVel))
                tyres.append(TyreState(
                    slip_deg=abs(math.degrees(math.atan2(w.mLateralPatchVel, long_v))),
                    grip_fract=w.mGripFract,
                    long_slip=abs(w.mLongitudinalPatchVel) / long_v,
                    temp_c=tuple(x - KELVIN for x in w.mTemperature),
                    carcass_c=w.mTireCarcassTemperature - KELVIN,
                    pressure_kpa=w.mPressure,
                    wear=max(0.0, min(1.0, 1.0 - w.mWear)),  # gra podaje, ile ZOSTAŁO (1.0 = nowa); u nas 0 = nowa
                    brake_c=w.mBrakeTemp,
                    optimal_c=w.mOptimalTemp,
                    ride_h=min(w.mRideHeight, rh_min[wi]) if rh_min else w.mRideHeight,
                    load_n=w.mTireLoad,
                    surface=int(w.mSurfaceType),
                ))
            ve = float(t.mVirtualEnergy)
            player = PlayerTelemetry(
                lap=t.mLapNumber,
                lap_dist=max(0.0, lap_dist),
                speed_kmh=speed_ms * 3.6,
                throttle=t.mFilteredThrottle,
                brake=t.mFilteredBrake,
                steering=t.mFilteredSteering,
                ffb_torque=t.mSteeringShaftTorque,
                gear=t.mGear,
                rpm=t.mEngineRPM,
                max_rpm=t.mEngineMaxRPM,
                fuel_l=t.mFuel,
                fuel_capacity_l=t.mFuelCapacity,
                virtual_energy=ve if ve > 0 else None,
                lat_g=t.mLocalAccel.x / G,
                lon_g=-t.mLocalAccel.z / G,
                yaw_rate=t.mLocalRot.y,
                tc_active=bool(t.mTCActive),
                abs_active=bool(t.mABSActive),
                lap_invalid=bool(t.mLapInvalidated),
                in_pits=bool(player_veh.mInPits) or bool(t.mCurrentSector & 0x80000000),
                tyres=tyres,
                compound_front=_txt(t.mFrontTireCompoundName),
                compound_rear=_txt(t.mRearTireCompoundName),
                rear_brake_bias=t.mRearBrakeBias,
                tc=t.mTC,
                abs=t.mABS,
                front_arb=t.mFrontAntiSway if t.mFrontAntiSwayMax else -1,
                rear_arb=t.mRearAntiSway if t.mRearAntiSwayMax else -1,
                motor_map=t.mMotorMap if t.mMotorMapMax else -1,
                front_ride_height=t.mFrontRideHeight,
                rear_ride_height=t.mRearRideHeight,
                dents=list(t.mDentSeverity),
                parts_detached=bool(t.mDetached),
                wheel_flat=[bool(w.mFlat) for w in t.mWheels],
                wheel_detached=[bool(w.mDetached) for w in t.mWheels],
                last_impact_t=t.mLastImpactET,
                last_impact_mag=t.mLastImpactMagnitude,
                track_limit_steps=t.mTrackLimitsSteps,
                water_c=t.mEngineWaterTemp,
                oil_c=t.mEngineOilTemp,
                overheating=bool(t.mOverheating),
            )
            car_name = _txt(t.mVehicleModel) or _txt(t.mVehicleName)
        else:
            car_name = _txt(player_veh.mVehicleName) if player_veh is not None else ""

        time_remaining = None
        if sc.mEndET > 0:
            time_remaining = max(0.0, sc.mEndET - sc.mCurrentET)
        max_laps = sc.mMaxLaps if 0 < sc.mMaxLaps < 10000 else None

        return Snapshot(
            t=sc.mCurrentET,
            session=_session_name(sc.mSession),
            track=_txt(sc.mTrackName),
            track_length=sc.mLapDist,
            car_name=car_name,
            time_remaining=time_remaining,
            max_laps=max_laps,
            phase=_phase_name(sc.mGamePhase),
            air_temp=sc.mAmbientTemp,
            track_temp=sc.mTrackTemp,
            rain=sc.mRaining,
            wetness=sc.mAvgPathWetness,
            player=player,
            cars=cars,
            # wartości flag sektorowych w LMU: 1/2 = żółta (inne, np. 11 = brak); kolejność sektorów nieużywana
            sector_yellow=[v in (1, 2) for v in sc.mSectorFlag],
            yellow_state=(sc.mYellowFlagState[0] if isinstance(sc.mYellowFlagState, bytes) and sc.mYellowFlagState
                          else int(sc.mYellowFlagState or 0)),
            tl_steps_per_penalty=sc.mTrackLimitsStepsPerPenalty,
            tl_steps_per_point=sc.mTrackLimitsStepsPerPoint,
            dark_cloud=float(sc.mDarkCloud),
        )
