"""Nagrywanie sesji do pliku i odtwarzanie jej bez uruchamiania gry."""

from __future__ import annotations

import gzip
import json
import time
from typing import Optional

from ..model import Snapshot


class SnapshotWriter:
    """Zapisuje snapshoty do pliku .jsonl.gz (domyślnie 20 Hz)."""

    def __init__(self, path: str, hz: float = 20.0) -> None:
        self._f = gzip.open(path, "wt", encoding="utf-8")
        self._min_dt = 1.0 / hz
        self._last_t: Optional[float] = None

    def write(self, snap: Snapshot) -> None:
        if self._last_t is not None and 0 <= snap.t - self._last_t < self._min_dt:
            return
        self._last_t = snap.t
        self._f.write(json.dumps(snap.to_dict(), separators=(",", ":")) + "\n")

    def close(self) -> None:
        self._f.close()


class ReplaySource:
    """Odtwarza nagranie. speed=1 to czas rzeczywisty, speed=10 dziesięć razy szybciej."""

    def __init__(self, path: str, speed: float = 1.0) -> None:
        self._f = gzip.open(path, "rt", encoding="utf-8")
        self._speed = speed
        self._next: Optional[Snapshot] = None
        self._start_wall: Optional[float] = None
        self._start_t: Optional[float] = None
        self.finished = False
        self.poll_interval = 0.02
        self.drain = True  # pętla główna pobiera wszystkie zaległe snapshoty naraz

    def _load(self) -> Optional[Snapshot]:
        line = self._f.readline()
        if not line:
            self.finished = True
            return None
        return Snapshot.from_dict(json.loads(line))

    def read(self) -> Optional[Snapshot]:
        if self._next is None:
            self._next = self._load()
            if self._next is None:
                return None
        if self._start_wall is None:
            self._start_wall = time.monotonic()
            self._start_t = self._next.t
        sim_now = self._start_t + (time.monotonic() - self._start_wall) * self._speed
        if self._next.t > sim_now:
            return None
        current, self._next = self._next, self._load()
        return current

    def close(self) -> None:
        self._f.close()
