"""Szybki odczyt prześwitu przy kołach (100 razy na sekundę) – do wykrywania dobijania.

Dobicie podłogi trwa w LMU 10–20 ms (sprawdzone na telemetrii Le Mans), a główny odczyt gry idzie co 50 ms,
więc większość dobić by umknęła. Ten wątek czyta z pamięci gry tylko 4 liczby (prześwit przy każdym kole
auta gracza) i zapamiętuje najmniejszą wartość od ostatniego odbioru. Główny odczyt bierze to minimum,
dlatego w danych auta „prześwit przy kole” znaczy: najmniejszy w ostatnich 50 ms.
"""

from __future__ import annotations

import ctypes
import struct
import threading
import time
from typing import Optional


def offsets(L) -> tuple[int, int, int, int, int, int, int]:
    """(playerHasVehicle, playerVehicleIdx, początek telemInfo, rozmiar auta, mWheels w aucie, rozmiar koła,
    mRideHeight w kole) – z definicji struktur, więc pasuje do wersji biblioteki."""
    tel = L.LMUObjectOut.telemetry.offset
    return (tel + L.LMUTelemetryData.playerHasVehicle.offset,
            tel + L.LMUTelemetryData.playerVehicleIdx.offset,
            tel + L.LMUTelemetryData.telemInfo.offset,
            ctypes.sizeof(L.LMUVehicleTelemetry),
            L.LMUVehicleTelemetry.mWheels.offset,
            ctypes.sizeof(L.LMUWheel),
            L.LMUWheel.mRideHeight.offset)


class RideHeightSampler:
    def __init__(self, buf, L, hz: float = 100.0) -> None:
        self.buf = buf
        (self.o_has, self.o_idx, self.o_tel, self.s_veh, self.o_wheels, self.s_wheel,
         self.o_rh) = offsets(L)
        self.max_idx = L.LMUConstants.MAX_MAPPED_VEHICLES - 1
        self.period = 1.0 / hz
        self._min: Optional[list[float]] = None
        self._lock = threading.Lock()
        self._stop = threading.Event()
        self._th: Optional[threading.Thread] = None

    def read_once(self) -> Optional[list[float]]:
        b = self.buf
        try:
            if not b[self.o_has]:
                return None
            idx = min(b[self.o_idx], self.max_idx)
            base = self.o_tel + idx * self.s_veh + self.o_wheels + self.o_rh
            return [struct.unpack_from("<d", b, base + k * self.s_wheel)[0] for k in range(4)]
        except (ValueError, IndexError, struct.error):
            return None

    def sample(self) -> None:
        v = self.read_once()
        if v is None:
            return
        with self._lock:
            if self._min is None:
                self._min = v
            else:
                self._min = [min(a, x) for a, x in zip(self._min, v)]

    def take(self) -> Optional[list[float]]:
        """Najmniejszy prześwit przy każdym kole od poprzedniego wywołania (None = brak odczytów)."""
        with self._lock:
            v, self._min = self._min, None
        return v

    def start(self) -> None:
        if self._th is None:
            self._th = threading.Thread(target=self._run, name="przeswit", daemon=True)
            self._th.start()

    def stop(self) -> None:
        self._stop.set()

    def _run(self) -> None:
        nxt = time.perf_counter()
        while not self._stop.is_set():
            self.sample()
            nxt += self.period
            d = nxt - time.perf_counter()
            if d > 0:
                time.sleep(d)
            else:
                nxt = time.perf_counter()
