"""Wewnętrzny interfejs LMU (http://localhost:6397) – TYLKO odczyt (GET), w osobnym wątku.

Daje to, czego nie ma we wspólnej pamięci:
- prognozę pogody na sesję (5 punktów: start, 25%, 50%, 75%, meta: szansa deszczu, niebo, temperatura),
- stan hamulców (1.0 = nowe) i opon z /rest/garage/getVehicleCondition,
- aktualne ustawienie grilla w menu boksu.
Gdy gra nie odpowiada, wszystko zostaje puste i inżynier działa jak wcześniej.
"""

from __future__ import annotations

import json
import threading
import time
import urllib.request
from typing import Optional

# 127.0.0.1, nie „localhost”: Windows najpierw próbuje IPv6 (::1), na którym gra nie słucha, i każde zapytanie
# czekało przez to 1,5–2 s (część kończyła się błędem) – tak samo łączy się menu gry
BASE = "http://127.0.0.1:6397"
NODES = [("START", 0.0), ("NODE_25", 0.25), ("NODE_50", 0.5), ("NODE_75", 0.75), ("FINISH", 1.0)]
SKY_PL = {"Clear": "bezchmurnie", "Light Clouds": "lekkie chmury", "Partially Cloudy": "częściowe zachmurzenie",
          "Mostly Cloudy": "pochmurno", "Overcast": "całkowite zachmurzenie", "Light Rain": "lekki deszcz",
          "Rain": "deszcz", "Heavy Rain": "ulewa", "Storm": "burza"}
WHEN_PL = {0.0: "na starcie", 0.25: "po jednej czwartej", 0.5: "w połowie", 0.75: "po trzech czwartych", 1.0: "na mecie"}


def when_pl(f: float, session: str) -> str:
    noun = "wyścigu" if session == "RACE" else "sesji"
    if f >= 1.0:
        return "na mecie" if session == "RACE" else "na koniec sesji"
    if f <= 0.0:
        return "na starcie"
    return f"{WHEN_PL.get(f, 'później')} {noun}"


# dla dziennika przycięć: które zapytanie do gry właśnie trwa i ile trwały ostatnie
BUSY: dict = {"path": None, "t0": 0.0}
RECENT: list = []    # (czas zakończenia, ścieżka, sekundy)


def _get(path: str, timeout: float = 1.5):
    BUSY["path"], BUSY["t0"] = path, time.monotonic()
    try:
        with urllib.request.urlopen(BASE + path, timeout=timeout) as r:
            return json.loads(r.read().decode("utf-8"))
    finally:
        t1 = time.monotonic()
        RECENT.append((t1, path, t1 - BUSY["t0"]))
        del RECENT[:-30]
        BUSY["path"] = None


class LmuRest:
    def __init__(self, interval: float = 20.0) -> None:
        self.interval = interval
        self.weather: dict = {}            # sesja -> węzeł -> wartości
        self.session = ""                  # PRACTICE / QUALIFY / RACE
        self.completion: Optional[float] = None   # część sesji, która minęła (0..1)
        self.brakes: Optional[list[float]] = None  # 1.0 = nowe
        self.grille: Optional[str] = None  # tekst bieżącego ustawienia, np. "4"
        self.fuel_ratio: Optional[float] = None   # FUEL RATIO z menu boksu (litry na 1% energii / 100)
        self.usage: dict = {}              # kierowca -> lista okrążeń {lap, pit, stint, ve, [fuel, tyres]}
        self.standings: list = []          # /rest/watch/standings
        self.pit_estimate: Optional[dict] = None  # gra: szacowany czas postoju dla ustawień menu boksu
        self.setup: dict = {}              # klucz ustawienia -> (wartość, min, max, tekst)
        self.pit_entry: Optional[float] = None    # m od linii mety, gdzie zaczyna się aleja serwisowa
        self.suspension: Optional[list[float]] = None   # uszkodzenie zawieszenia 0..1 (LP, PP, LT, PT)
        self.body_damage: Optional[float] = None         # ogólne uszkodzenie auta z gry
        self.new_tyres: Optional[bool] = None             # czy w menu boksu są jeszcze nowe opony
        self.tyres_left: Optional[int] = None             # ile nowych opon zostało (gdy gra to pokazuje)
        self.tyres_parallel: Optional[bool] = None        # gra zmienia opony w trakcie tankowania
        # Zapytania tylko wtedy, gdy kierowca od jakiegoś czasu jedzie (ustawia program kierowcy).
        # Nie pytamy gry w trakcie wczytywania / wchodzenia na serwer.
        self.allow = lambda: True
        self.enabled = True
        self.ok = False
        self._lock = threading.Lock()

    def start(self) -> None:
        threading.Thread(target=self._loop, daemon=True).start()

    def _loop(self) -> None:
        n = 0
        while True:
            if not self.enabled or not self.allow():
                self.ok = False
                time.sleep(2.0)
                continue
            try:
                info = _get("/rest/watch/sessionInfo")
                sess = str(info.get("session", "")).upper()
                comp = (info.get("raceCompletion") or {}).get("timeCompletion")
                cond = _get("/rest/garage/getVehicleCondition")
                usage = _get("/rest/strategy/usage", timeout=3)
                stand = _get("/rest/watch/standings", timeout=3)
                est = _get("/rest/strategy/pitstop-estimate")
                try:
                    gsx = _get("/rest/sessions/GetGameState")
                    pe = float(gsx.get("PitEntryDist") or 0)
                    if pe > 0:
                        self.pit_entry = pe
                except Exception:
                    pass
                with self._lock:
                    self.usage = usage if isinstance(usage, dict) else {}
                    self.standings = stand if isinstance(stand, list) else []
                    self.pit_estimate = est if isinstance(est, dict) else None
                    self.session = next((k for k in ("RACE", "QUALIFY", "PRACTICE", "WARMUP") if sess.startswith(k)), sess)
                    self.completion = float(comp) if comp is not None else None
                    b = cond.get("brakeCondition")
                    self.brakes = [float(x) for x in b] if isinstance(b, list) and len(b) == 4 else None
                    sd = cond.get("suspensionDamage")
                    self.suspension = [float(x) for x in sd] if isinstance(sd, list) and len(sd) == 4 else None
                    try:
                        self.body_damage = float(cond.get("vehicleDamage"))
                    except (TypeError, ValueError):
                        self.body_damage = None
                    if isinstance(est, dict):
                        try:
                            ti, fu, ve, tot = (float(est.get(k) or 0) for k in ("tires", "fuel", "ve", "total"))
                            refuel = max(fu, ve)
                            if ti > 1 and refuel > 1:   # w menu jest i tankowanie, i opony: sprawdzamy, czy się sumują
                                self.tyres_parallel = tot < ti + refuel - 1.0
                        except (TypeError, ValueError):
                            pass
                if n % 6 == 0:   # prognoza i menu boksu rzadziej (co ok. 2 min)
                    w = _get("/rest/sessions/weather", timeout=3)
                    menu = _get("/rest/garage/PitMenu/receivePitMenu", timeout=3)
                    g = next((it for it in menu if isinstance(it, dict) and str(it.get("name", "")).startswith("GRILLE")), None)
                    fr = next((it for it in menu if isinstance(it, dict) and str(it.get("name", "")).startswith("FUEL RATIO")), None)
                    ti = next((it for it in menu if isinstance(it, dict) and str(it.get("name", "")).strip() == "TIRES"), None)
                    if ti and ti.get("settings"):
                        txts = [str(x.get("text", "")) for x in ti["settings"]]
                        self.new_tyres = any(t.startswith("New") and "Wet" not in t for t in txts)
                        # limit opon w wyścigu (jeśli gra go pokazuje w menu boksu, np. „New (12 left)”)
                        import re as _re
                        left = [int(m.group(1)) for t in txts for m in [_re.search(r"(\d+)\s*(?:left|remaining|avail)", t, _re.I)] if m]
                        self.tyres_left = max(left) if left else None
                    summ = _get("/rest/garage/summary", timeout=3)
                    setup = {}
                    for grp in (summ.get("settingSummaries") or {}).values():
                        for k, v in (grp.items() if isinstance(grp, dict) else []):
                            if isinstance(v, dict) and "value" in v:
                                setup[k] = (v.get("value"), v.get("minValue"), v.get("maxValue"), v.get("stringValue"))
                    with self._lock:
                        self.setup = setup
                        if fr and fr.get("settings"):
                            try:
                                i = int(fr.get("currentSetting", 0))
                                self.fuel_ratio = float(fr["settings"][min(i, len(fr["settings"]) - 1)]["text"])
                            except (ValueError, KeyError, TypeError):
                                pass
                        self.weather = w if isinstance(w, dict) else {}
                        if g and g.get("settings"):
                            i = int(g.get("currentSetting", 0))
                            txt = g["settings"][min(i, len(g["settings"]) - 1)].get("text", "")
                            self.grille = txt.split(" ")[0]
                self.ok = True
                n += 1
            except Exception:
                self.ok = False
            time.sleep(self.interval)

    # ------------------------------------------------------------ setup
    def at_min(self, key: str) -> bool:
        v = self.setup.get(key)
        return bool(v) and v[0] is not None and v[1] is not None and v[0] <= v[1]

    def at_max(self, key: str) -> bool:
        """maxValue w grze to liczba pozycji (ostatnia pozycja = max - 1)."""
        v = self.setup.get(key)
        return bool(v) and v[0] is not None and v[2] is not None and v[0] >= v[2] - 1

    def standing(self, name: str) -> Optional[dict]:
        for r in self.standings:
            if r.get("driverName") == name:
                return r
        return None

    # ------------------------------------------------------------ prognoza
    def forecast(self, frac: Optional[float] = None) -> list[tuple[float, int, str, float]]:
        """Węzły prognozy dla bieżącej sesji: (część sesji, szansa deszczu %, niebo, temperatura)."""
        with self._lock:
            nodes = self.weather.get(self.session) or {}
        out = []
        for key, f in NODES:
            v = nodes.get(key)
            if not v:
                continue
            try:
                out.append((f, int(v["WNV_RAIN_CHANCE"]["currentValue"]),
                            str(v["WNV_SKY"]["stringValue"]), float(v["WNV_TEMPERATURE"]["currentValue"])))
            except (KeyError, TypeError, ValueError):
                continue
        return out

    def upcoming(self, frac: Optional[float]) -> list[tuple[float, int, str, float]]:
        frac = self.completion if frac is None else frac
        nodes = self.forecast()
        if frac is None:
            return nodes
        return [n for n in nodes if n[0] > frac + 0.02]

    def forecast_text(self, frac: Optional[float] = None) -> str:
        nodes = self.upcoming(frac)
        if not nodes:
            return ""
        parts = []
        for f, rain, sky, temp in nodes:
            p = f"{when_pl(f, self.session)} {SKY_PL.get(sky, sky.lower())}, {temp:.0f} stopni"
            if rain > 0:
                p += f", deszcz {rain} procent"
            parts.append(p)
        txt = "Prognoza: " + "; ".join(parts) + "."
        if all(n[1] == 0 for n in nodes):
            txt += " Bez deszczu."
        return txt

    def rain_risk(self, frac: Optional[float] = None) -> Optional[tuple[float, int]]:
        """Najbliższy węzeł z szansą deszczu >= 30%."""
        for f, rain, _, _ in self.upcoming(frac):
            if rain >= 30:
                return f, rain
        return None
