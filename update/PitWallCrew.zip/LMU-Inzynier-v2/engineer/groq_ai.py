"""Groq (darmowy plan, chmura): rozpoznawanie mowy (Whisper) i AI na pytania spoza reguł.

Program kierowcy pyta Groq bezpośrednio – bez serwera AI zespołu i bez obciążania komputera gracza.
Klucz zespołu wpisuje się raz na ścianie boksów (zakładka Zespół) albo w config.toml ([ai] groq_key).
Limity darmowego planu (na konto): Whisper ok. 20/min i 2000/dzień, modele językowe ok. 30/min i 1000/dzień.
Gdy Groq odmówi (limit, brak internetu) – program wraca do serwera AI zespołu albo Google.
"""

from __future__ import annotations

import json
import time
import urllib.error
import urllib.request
import uuid
from typing import Optional

from .ai import SETUP_PROMPT, SYSTEM_PROMPT
from .local_ai import _clean

API = "https://api.groq.com/openai/v1"
STT_MODELS = ["whisper-large-v3-turbo", "whisper-large-v3"]
CHAT_MODELS = ["llama-3.3-70b-versatile", "meta-llama/llama-4-maverick-17b-128e-instruct", "qwen/qwen3-32b",
               "llama-3.1-8b-instant"]
# podpowiedź słownictwa dla Whispera (lepsze rozpoznanie nazw i komend)
STT_PROMPT = ("Inżynier, ile paliwa, energia, zjazd, box, opony, hamulce, Hypercar, LMP2, LMGT3, GT3, "
              "Porsche Curves, Mulsanne, Indianapolis, Arnage, Tertre Rouge, T5, cicho, setup, podsterowność.")


class GroqError(RuntimeError):
    pass


class GroqAI:
    def __init__(self, key: str, chat_model: str = "", stt_model: str = "", max_tokens: int = 220,
                 history_turns: int = 4, timeout: float = 12.0) -> None:
        self.key = (key or "").strip()
        self.chat_models = ([chat_model] if chat_model else []) + [m for m in CHAT_MODELS if m != chat_model]
        self.stt_models = ([stt_model] if stt_model else []) + [m for m in STT_MODELS if m != stt_model]
        self.max_tokens = max_tokens
        self.history_turns = history_turns
        self.timeout = timeout
        self.history: list[dict] = []
        self.status = "gotowy" if self.key else "brak klucza"
        self._cool_until = 0.0          # po odmowie z powodu limitu: krótka przerwa

    @property
    def ready(self) -> bool:
        return bool(self.key) and time.monotonic() >= self._cool_until

    # ------------------------------------------------------------------ http
    def _req(self, path: str, data: bytes, ctype: str, timeout: float) -> dict:
        req = urllib.request.Request(API + path, data=data, method="POST",
                                     headers={"Authorization": "Bearer " + self.key, "Content-Type": ctype,
                                              "User-Agent": "PitWallCrew"})
        try:
            with urllib.request.urlopen(req, timeout=timeout) as r:
                return json.loads(r.read().decode("utf-8"))
        except urllib.error.HTTPError as e:
            body = e.read().decode("utf-8", "replace")[:300]
            if e.code == 429:
                retry = e.headers.get("retry-after")
                self._cool_until = time.monotonic() + min(60.0, float(retry) if retry and retry.replace(".", "").isdigit() else 10.0)
                self.status = "limit Groq – chwilowa przerwa"
            elif e.code in (401, 403):
                self.status = "zły klucz Groq"
                self._cool_until = time.monotonic() + 300
            err = GroqError(f"{e.code}: {body}")
            err.code = e.code   # type: ignore[attr-defined]
            raise err

    # ------------------------------------------------------------------ mowa
    def transcribe_wav(self, wav: bytes, language: str = "pl") -> str:
        """Rozpoznanie mowy z pliku WAV (16 kHz mono). Zwraca tekst albo ''."""
        if not self.ready:
            return ""
        for model in list(self.stt_models):
            boundary = "----pwc" + uuid.uuid4().hex
            parts = []

            def field(name, value):
                parts.append(f"--{boundary}\r\nContent-Disposition: form-data; name=\"{name}\"\r\n\r\n{value}\r\n"
                             .encode("utf-8"))
            field("model", model)
            field("language", language)
            field("temperature", "0")
            field("response_format", "json")
            field("prompt", STT_PROMPT)
            parts.append(f"--{boundary}\r\nContent-Disposition: form-data; name=\"file\"; filename=\"mowa.wav\"\r\n"
                         f"Content-Type: audio/wav\r\n\r\n".encode("utf-8") + wav + b"\r\n")
            parts.append(f"--{boundary}--\r\n".encode("utf-8"))
            try:
                out = self._req("/audio/transcriptions", b"".join(parts), f"multipart/form-data; boundary={boundary}",
                                self.timeout)
                text = (out.get("text") or "").strip()
                return "" if _whisper_noise(text) else text
            except GroqError as e:
                if getattr(e, "code", 0) in (400, 404) and "model" in str(e).lower():
                    self.stt_models.remove(model)        # model wycofany – następny
                    continue
                raise
        return ""

    # ------------------------------------------------------------------ AI
    def ask(self, question: str, state: str, setup: bool = False) -> Optional[str]:
        if not self.ready:
            return None
        system = SYSTEM_PROMPT + (SETUP_PROMPT if setup else "") + \
            "\nOdpowiadaj wyłącznie po polsku, krótko (do 3 zdań), zwykłymi zdaniami do przeczytania przez radio."
        user = f"STAN (aktualne dane z gry):\n{state}\n\nKIEROWCA MÓWI: {question}"
        messages = [{"role": "system", "content": system}] + self.history[-self.history_turns * 2:] + \
                   [{"role": "user", "content": user}]
        for model in list(self.chat_models):
            body = {"model": model, "messages": messages, "temperature": 0.3,
                    "max_tokens": self.max_tokens + (120 if setup else 0)}
            try:
                out = self._req("/chat/completions", json.dumps(body).encode("utf-8"), "application/json",
                                self.timeout + 8)
            except GroqError as e:
                if getattr(e, "code", 0) in (400, 404) and "model" in str(e).lower():
                    self.chat_models.remove(model)
                    continue
                raise
            txt = ((out.get("choices") or [{}])[0].get("message") or {}).get("content") or ""
            import re
            txt = re.sub(r"<think>.*?</think>", "", txt, flags=re.S)     # modele „myślące”
            answer = _clean(txt)
            if not answer:
                return None
            self.history += [{"role": "user", "content": question}, {"role": "assistant", "content": answer}]
            self.status = f"gotowy ({model})"
            return answer
        return None


def _whisper_noise(text: str) -> bool:
    """Whisper przy ciszy potrafi „usłyszeć” typowe frazy z napisów filmowych."""
    t = text.lower().strip(" .!?")
    return not t or any(p in t for p in ("napisy", "dziękuję za uwagę", "subskryb", "amara.org", "transkrypcja"))
