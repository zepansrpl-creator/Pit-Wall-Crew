"""Groq (darmowy plan, chmura): rozpoznawanie mowy (Whisper) i AI na pytania spoza reguł.

Program kierowcy pyta Groq bezpośrednio – bez serwera i bez obciążania komputera gracza.
Klucz zespołu wpisuje się raz na ścianie boksów (zakładka Zespół) albo w config.toml ([ai] groq_key).
Limity darmowego planu (na konto): Whisper ok. 20/min i 2000/dzień, modele językowe ok. 30/min i 1000/dzień.
Gdy Groq odmówi (limit, brak internetu) – mowę rozpoznaje Google, a na pytania odpowiada sam program.
"""

from __future__ import annotations

import json
import time
import urllib.error
import urllib.request
import uuid
from typing import Optional

from .ai import SETUP_PROMPT, SYSTEM_PROMPT
from .local_ai import _clean

API = "https://api.groq.com/openai/v1"
# pełny large-v3 najpierw: dokładniejszy po polsku niż turbo (krótkie komendy, nazwiska), czas prawie ten sam
STT_MODELS = ["whisper-large-v3", "whisper-large-v3-turbo"]
# kolejność: najlepszy polski najpierw; każdy model ma osobny dzienny limit (ok. 1000 pytań, 200 tys. tokenów),
# więc po wyczerpaniu limitu jednego program przechodzi na następny
CHAT_MODELS = ["openai/gpt-oss-120b", "qwen/qwen3.8-27b", "openai/gpt-oss-20b", "llama-3.3-70b-versatile",
               "qwen/qwen3-32b", "llama-3.1-8b-instant"]
# podpowiedź słownictwa dla Whispera (lepsze rozpoznanie nazw i komend)
STT_PROMPT = ("Inżynier, ile paliwa, energia, zjazd, box, opony, hamulce, Hypercar, LMP2, LMGT3, GT3, "
              "Porsche Curves, Mulsanne, Indianapolis, Arnage, Tertre Rouge, T5, cicho, setup, podsterowność, "
              "zużycie, temperatura toru, prędkość maksymalna, flat spot, pit stop, ile okrążeń, dam radę.")


# poniżej tej średniej „pewności” Whispera rozpoznany tekst to zwykle zgadywanie („Lepki małto mnie ci late”)
MIN_LOGPROB = -0.85


def uncertain(g) -> bool:
    lp, ns = getattr(g, "last_logprob", None), getattr(g, "last_no_speech", None)
    return (lp is not None and lp < MIN_LOGPROB) or (ns is not None and ns > 0.6)


class GroqError(RuntimeError):
    pass


class GroqAI:
    def __init__(self, key: str, chat_model: str = "", stt_model: str = "", max_tokens: int = 220,
                 history_turns: int = 4, timeout: float = 12.0) -> None:
        self.key = (key or "").strip()
        self.chat_models = ([chat_model] if chat_model else []) + [m for m in CHAT_MODELS if m != chat_model]
        self.stt_models = ([stt_model] if stt_model else []) + [m for m in STT_MODELS if m != stt_model]
        self.max_tokens = max_tokens
        self.history_turns = history_turns
        self.timeout = timeout
        self.history: list[dict] = []
        self.status = "gotowy" if self.key else "brak klucza"
        self._cool_until = 0.0          # po odmowie z powodu limitu: krótka przerwa
        self._model_cool: dict = {}     # model -> do kiedy pomijać (wyczerpany limit)
        self.last_logprob: Optional[float] = None    # pewność ostatniego rozpoznania mowy (Whisper)
        self.last_no_speech: Optional[float] = None

    @property
    def ready(self) -> bool:
        return bool(self.key) and time.monotonic() >= self._cool_until

    # ------------------------------------------------------------------ http
    def _req(self, path: str, data: bytes, ctype: str, timeout: float) -> dict:
        req = urllib.request.Request(API + path, data=data, method="POST",
                                     headers={"Authorization": "Bearer " + self.key, "Content-Type": ctype,
                                              "User-Agent": "PitWallCrew"})
        try:
            with urllib.request.urlopen(req, timeout=timeout) as r:
                return json.loads(r.read().decode("utf-8"))
        except urllib.error.HTTPError as e:
            body = e.read().decode("utf-8", "replace")[:300]
            if e.code == 429:
                retry = e.headers.get("retry-after")
                self._cool_until = time.monotonic() + min(60.0, float(retry) if retry and retry.replace(".", "").isdigit() else 10.0)
                self.status = "limit Groq – chwilowa przerwa"
            elif e.code in (401, 403):
                self.status = "zły klucz Groq"
                self._cool_until = time.monotonic() + 300
            err = GroqError(f"{e.code}: {body}")
            err.code = e.code   # type: ignore[attr-defined]
            raise err

    # ------------------------------------------------------------------ mowa
    def transcribe_wav(self, wav: bytes, language: str = "pl", skip: str = "") -> str:
        """Rozpoznanie mowy z pliku WAV (16 kHz mono). Zwraca tekst albo ''. skip = pomiń ten model
        (druga próba innym modelem, gdy pierwsze rozpoznanie było niepewne)."""
        if not self.ready:
            return ""
        for model in [m for m in self.stt_models if m != skip]:
            boundary = "----pwc" + uuid.uuid4().hex
            parts = []

            def field(name, value):
                parts.append(f"--{boundary}\r\nContent-Disposition: form-data; name=\"{name}\"\r\n\r\n{value}\r\n"
                             .encode("utf-8"))
            field("model", model)
            field("language", language)
            field("temperature", "0")
            field("response_format", "verbose_json")      # z pewnością rozpoznania (avg_logprob)
            field("prompt", (STT_PROMPT + " " + self.stt_extra)[:600] if getattr(self, "stt_extra", "") else STT_PROMPT)
            parts.append(f"--{boundary}\r\nContent-Disposition: form-data; name=\"file\"; filename=\"mowa.wav\"\r\n"
                         f"Content-Type: audio/wav\r\n\r\n".encode("utf-8") + wav + b"\r\n")
            parts.append(f"--{boundary}--\r\n".encode("utf-8"))
            try:
                out = self._req("/audio/transcriptions", b"".join(parts), f"multipart/form-data; boundary={boundary}",
                                self.timeout)
                text = (out.get("text") or "").strip()
                segs = out.get("segments") or []
                if segs:
                    w = [max(0.1, float(sg.get("end", 0)) - float(sg.get("start", 0))) for sg in segs]
                    self.last_logprob = sum(float(sg.get("avg_logprob", 0)) * x for sg, x in zip(segs, w)) / sum(w)
                    self.last_no_speech = max(float(sg.get("no_speech_prob", 0)) for sg in segs)
                else:
                    self.last_logprob, self.last_no_speech = None, None
                self.last_model = model
                return "" if _whisper_noise(text) else text
            except GroqError as e:
                if getattr(e, "code", 0) in (400, 404) and "model" in str(e).lower():
                    self.stt_models.remove(model)        # model wycofany – następny
                    continue
                raise
        return ""

    # ------------------------------------------------------------------ AI
    def ask(self, question: str, state: str, setup: bool = False) -> Optional[str]:
        if not self.ready:
            return None
        system = SYSTEM_PROMPT + (SETUP_PROMPT if setup else "") + \
            "\nOdpowiadaj wyłącznie po polsku, krótko (do 3 zdań), zwykłymi zdaniami do przeczytania przez radio."
        user = f"STAN (aktualne dane z gry):\n{state}\n\nKIEROWCA MÓWI: {question}"
        messages = [{"role": "system", "content": system}] + self.history[-self.history_turns * 2:] + \
                   [{"role": "user", "content": user}]
        tried_limit = 0
        for model in list(self.chat_models):
            if time.monotonic() < self._model_cool.get(model, 0):
                continue
            body = {"model": model, "messages": messages, "temperature": 0.3,
                    "max_tokens": self.max_tokens + (120 if setup else 0) + (400 if "gpt-oss" in model else 0)}
            if "gpt-oss" in model:          # modele „myślące”: krótkie myślenie, bez treści myślenia w odpowiedzi
                body.update(reasoning_effort="low", include_reasoning=False)
            elif "qwen3" in model:
                body.update(reasoning_effort="none")
            out = None
            for attempt in (0, 1):
                try:
                    out = self._req("/chat/completions", json.dumps(body).encode("utf-8"), "application/json",
                                    self.timeout + 8)
                    break
                except GroqError as e:
                    code, msg = getattr(e, "code", 0), str(e).lower()
                    if code in (400, 404) and ("decommission" in msg or "does not exist" in msg or "not found" in msg):
                        self.chat_models.remove(model)          # model wycofany – następny
                        break
                    if code == 400 and attempt == 0 and ("reasoning" in msg or "property" in msg or "unsupported" in msg):
                        for k in ("reasoning_effort", "include_reasoning"):
                            body.pop(k, None)
                        continue
                    if code == 429:                              # limit tego modelu – następny model
                        self._cool_until = 0.0
                        self._model_cool[model] = time.monotonic() + (3600 if ("per day" in msg or "tpd" in msg
                                                                                or "rpd" in msg) else 60)
                        tried_limit += 1
                        break
                    raise
            if out is None:
                continue
            msg0 = (out.get("choices") or [{}])[0].get("message") or {}
            txt = msg0.get("content") or ""
            import re
            txt = re.sub(r"<think>.*?</think>", "", txt, flags=re.S)     # modele „myślące”
            answer = _clean(txt)
            if not answer:
                continue
            self.history += [{"role": "user", "content": question}, {"role": "assistant", "content": answer}]
            self.status = f"gotowy ({model})"
            return answer
        if tried_limit:
            self.status = "limit Groq wyczerpany na razie"
        return None


def _whisper_noise(text: str) -> bool:
    """Whisper przy ciszy potrafi „usłyszeć” typowe frazy z napisów filmowych."""
    t = text.lower().strip(" .!?")
    return not t or t in ("dziękuję", "dzięki", "dziękuję bardzo", "dziękujemy") or \
        any(p in t for p in ("napisy", "dziękuję za uwagę", "subskryb", "amara.org", "transkrypcja"))
