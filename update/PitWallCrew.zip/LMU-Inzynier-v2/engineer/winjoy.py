"""Odczyt przycisków kierownicy przez stary interfejs Windows (winmm, joyGetPosEx) – tylko odczyt.

Dlaczego nie pygame/SDL: SDL otwiera urządzenie (DirectInput / RawInput / Windows.Gaming.Input / HIDAPI),
a kierownica z force feedbackiem (np. MOZA) jest wtedy otwarta w dwóch programach naraz. Gdy gra przy
wejściu na serwer inicjuje FFB, może się to skończyć wysypaniem gry. winmm tylko czyta stan przycisków,
niczego nie otwiera na wyłączność i nie dotyka FFB. Obsługuje przyciski 0–31.
"""

from __future__ import annotations

import ctypes
import sys
from ctypes import wintypes
from typing import Optional

JOY_RETURNBUTTONS = 0x00000080
MAX_BUTTONS = 32


class JOYINFOEX(ctypes.Structure):
    _fields_ = [("dwSize", wintypes.DWORD), ("dwFlags", wintypes.DWORD), ("dwXpos", wintypes.DWORD),
                ("dwYpos", wintypes.DWORD), ("dwZpos", wintypes.DWORD), ("dwRpos", wintypes.DWORD),
                ("dwUpos", wintypes.DWORD), ("dwVpos", wintypes.DWORD), ("dwButtons", wintypes.DWORD),
                ("dwButtonNumber", wintypes.DWORD), ("dwPOV", wintypes.DWORD),
                ("dwReserved1", wintypes.DWORD), ("dwReserved2", wintypes.DWORD)]


class JOYCAPSW(ctypes.Structure):
    _fields_ = [("wMid", wintypes.WORD), ("wPid", wintypes.WORD), ("szPname", wintypes.WCHAR * 32),
                ("wXmin", wintypes.UINT), ("wXmax", wintypes.UINT), ("wYmin", wintypes.UINT),
                ("wYmax", wintypes.UINT), ("wZmin", wintypes.UINT), ("wZmax", wintypes.UINT),
                ("wNumButtons", wintypes.UINT), ("wPeriodMin", wintypes.UINT), ("wPeriodMax", wintypes.UINT),
                ("wRmin", wintypes.UINT), ("wRmax", wintypes.UINT), ("wUmin", wintypes.UINT),
                ("wUmax", wintypes.UINT), ("wVmin", wintypes.UINT), ("wVmax", wintypes.UINT),
                ("wCaps", wintypes.UINT), ("wMaxAxes", wintypes.UINT), ("wNumAxes", wintypes.UINT),
                ("wMaxButtons", wintypes.UINT), ("szRegKey", wintypes.WCHAR * 32),
                ("szOEMVxD", wintypes.WCHAR * 260)]


def available() -> bool:
    return sys.platform == "win32"


def _winmm():
    return ctypes.windll.winmm


def _oem_name(mid: int, pid: int) -> Optional[str]:
    try:
        import winreg
        key = (r"System\CurrentControlSet\Control\MediaProperties\PrivateProperties\Joystick\OEM"
               rf"\VID_{mid:04X}&PID_{pid:04X}")
        for root in (winreg.HKEY_CURRENT_USER, winreg.HKEY_LOCAL_MACHINE):
            try:
                with winreg.OpenKey(root, key) as k:
                    v, _ = winreg.QueryValueEx(k, "OEMName")
                    if v:
                        return str(v)
            except OSError:
                continue
    except Exception:
        pass
    return None


def buttons(dev: int) -> Optional[int]:
    """Maska wciśniętych przycisków albo None, gdy urządzenia nie ma."""
    info = JOYINFOEX()
    info.dwSize = ctypes.sizeof(JOYINFOEX)
    info.dwFlags = JOY_RETURNBUTTONS
    if _winmm().joyGetPosEx(dev, ctypes.byref(info)) != 0:
        return None
    return int(info.dwButtons)


def devices() -> list[tuple[int, str, int]]:
    """Podłączone kontrolery: (numer, nazwa, liczba przycisków)."""
    out = []
    w = _winmm()
    n = min(16, int(w.joyGetNumDevs()))
    for dev in range(n):
        if buttons(dev) is None:
            continue
        caps = JOYCAPSW()
        name = f"kontroler {dev}"
        nb = 0
        if w.joyGetDevCapsW(dev, ctypes.byref(caps), ctypes.sizeof(JOYCAPSW)) == 0:
            name = _oem_name(caps.wMid, caps.wPid) or caps.szPname or name
            nb = int(caps.wNumButtons)
        out.append((dev, name, nb))
    return out
