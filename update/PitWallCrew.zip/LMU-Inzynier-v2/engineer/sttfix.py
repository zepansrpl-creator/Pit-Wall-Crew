"""Wybór i poprawianie rozpoznanej mowy.

Whisper (Groq) i Google rozpoznają nagranie równolegle. Wynik, który lepiej pasuje do słownictwa inżyniera
(komendy, nazwy części auta, zakręty), wygrywa. Pojedyncze przekręcone słowa („homulców”) poprawiamy do
najbliższego słowa ze słownictwa – tylko gdy podobieństwo jest wysokie, a słowo nie jest znanym poprawnym słowem.
"""

from __future__ import annotations

import difflib
import re
from functools import lru_cache

_WORD = re.compile(r"[A-Za-zÀ-ÿĄĆĘŁŃÓŚŹŻąćęłńóśźż]+")


@lru_cache(maxsize=4)
def vocab(lang: str = "pl") -> tuple[frozenset, tuple]:
    """(wszystkie znane słowa, słowa do poprawiania) z listy komend i stron pomocy."""
    texts: list[str] = []
    try:
        if lang == "pl":
            from engineer.commands import COMMANDS
            from engineer.help_texts import FEATURES, MANUAL
        else:
            import importlib
            m = importlib.import_module("engineer.help_" + lang)
            COMMANDS, FEATURES, MANUAL = m.COMMANDS, m.FEATURES, m.MANUAL
        for _, items in COMMANDS:
            for a, b in items:
                texts += [a, b]
        for _, paras in list(FEATURES) + list(MANUAL):
            texts += paras
    except Exception:
        pass
    extra = {"pl": "paliwo paliwa energia energii zjazd zjazdu opony opon hamulce hamulców hamulcach postój postoju "
                   "okrążenie okrążenia okrążeń zakręt zakręcie rywal rywala przede mną za mną pogoda deszcz slicki "
                   "deszczowe silnik grill temperatura ciśnienia setup balans podsterowność nadsterowność cicho cisza "
                   "powtórz ile kiedy gdzie jak jaki jaka która tracę pozycja tempo czas hypercar dublowanie",
             "en": "fuel energy box pit stop tyres tyre brakes lap laps corner rival ahead behind weather rain slicks "
                   "wets engine grille temperature pressures setup bias understeer oversteer quiet repeat how much "
                   "when where what which position pace time hypercar lapping",
             "de": "sprit kraftstoff energie box boxenstopp reifen bremsen runde runden kurve gegner vorne hinten "
                   "wetter regen regenreifen slicks motor kühlergrill temperatur reifendruck setup bremsbalance "
                   "untersteuern übersteuern ruhig wiederhol wie viel wann wo was welche position tempo zeit "
                   "hypercar überrundung",
             "fr": "carburant essence énergie stand arrêt pneus freins tour tours virage rival devant derrière "
                   "météo pluie slicks moteur calandre température pressions réglage répartition sous-virage "
                   "survirage silence répète combien quand où quel quelle position rythme temps hypercar "
                   "dépassement"}.get(lang, "")
    texts.append(extra)
    words = set()
    for t in texts:
        for w in _WORD.findall(t.lower()):
            words.add(w)
    fix = tuple(sorted(w for w in words if len(w) >= 5))
    return frozenset(words), fix


def score(text: str, lang: str = "pl") -> float:
    """Jaka część słów pasuje do słownictwa inżyniera (0–1)."""
    ws = _WORD.findall((text or "").lower())
    if not ws:
        return 0.0
    known, _ = vocab(lang)
    return sum(1 for w in ws if w in known) / len(ws)


def correct(text: str, lang: str = "pl", keep: frozenset = frozenset()) -> str:
    """„temperatura homulców” -> „temperatura hamulców”. Nazwiska (z wielkiej litery) i słowa z `keep` bez zmian."""
    known, fix = vocab(lang)

    def rep(m):
        w = m.group(0)
        low = w.lower()
        if len(low) < 5 or low in known or w[:1].isupper() or low in keep:
            return w
        best = difflib.get_close_matches(low, fix, n=1, cutoff=0.8)
        if not best or best[0][:1] != low[:1] and best[0][:2] != low[:2]:
            return w
        return best[0]
    return _WORD.sub(rep, text or "")


def choose(whisper: str, google: str, whisper_uncertain: bool, lang: str = "pl") -> tuple[str, str]:
    """Lepszy z dwóch wyników: (tekst, źródło)."""
    w, g = (whisper or "").strip(), (google or "").strip()
    if not w:
        return g, "google"
    if not g:
        return w, "whisper"
    sw, sg = score(w, lang), score(g, lang)
    if whisper_uncertain:
        return (g, "google") if sg >= sw - 0.1 else (w, "whisper")
    return (g, "google") if sg > sw + 0.15 else (w, "whisper")
