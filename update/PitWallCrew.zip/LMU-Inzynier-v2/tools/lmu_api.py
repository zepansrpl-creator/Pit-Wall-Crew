"""Sprawdzenie wewnętrznego interfejsu LMU (http://localhost:6397), z którego korzysta menu gry.

Szuka danych, których nie ma w pamięci współdzielonej: prognozy pogody, zużycia hamulców, menu boksu.
Tylko ODCZYT (zapytania GET); pomija adresy, które wyglądają na zmieniające coś w grze.
Wyniki: folder lmu_api (pełne odpowiedzi) i plik lmu_api/RAPORT.txt.
Uruchom, gdy LMU działa i jesteś w sesji (najlepiej raz w garażu i raz na torze).
"""

from __future__ import annotations

import json
import os
import re
import sys
import time
import urllib.error
import urllib.request

BASE = os.environ.get("LMU_API_BASE", "http://localhost:6397")
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
OUT = os.path.join(ROOT, "lmu_api", time.strftime("%H%M%S"))

# słowa w adresie, które sugerują zmianę czegoś w grze – takich adresów nie wywołujemy
DANGER = ("set", "start", "stop", "exit", "quit", "restart", "delete", "remove", "save", "load", "drive", "skip",
          "advance", "change", "apply", "send", "kick", "reset", "update", "post", "join", "leave", "toggle",
          "pause", "resume", "buy", "purchase", "install", "uninstall", "create", "write", "upload", "request",
          "execute", "run", "launch", "go", "action", "command", "chat", "vote", "ban", "confirm", "accept",
          "uiscreen", "navigation", "navigate", "open", "close", "show", "hide", "select", "click", "press")
# znane i prawdopodobne adresy tylko do odczytu
CANDIDATES = [
    "/rest/sessions", "/rest/sessions/weather", "/rest/sessions/getSessionsInfoForEvent",
    "/rest/sessions/GetGameState", "/rest/sessions/getAllVehicles", "/rest/sessions/setting",
    "/rest/garage/getPlayerGarageData", "/rest/garage/PitMenu/receivePitMenu",
    "/rest/garage/getVehicleCondition", "/rest/garage/summary",
    "/rest/race/car", "/rest/strategy/usage", "/rest/strategy/pitstop-estimate", "/rest/watch/standings",
    "/rest/watch/sessionInfo",
]
KEYWORDS = {
    "pogoda / prognoza": ("weather", "forecast", "rain", "cloud", "wetness", "precip"),
    "hamulce": ("brake", "pad", "disc", "rotor"),
    "zużycie / stan auta": ("wear", "condition", "damage", "health", "life"),
    "menu boksu": ("pitmenu", "pit_menu", "refuel", "fuel", "tyre", "tire", "repair", "grille", "radiator", "ducts"),
    "silnik / chłodzenie": ("engine", "water", "oil", "cooling", "radiator", "grille"),
}


def safe(path: str) -> bool:
    low = path.lower()
    segs = re.split(r"[/?&=._-]+", low)
    for word in DANGER:
        for seg in segs:
            if seg == word or (seg.startswith(word) and word not in ("go", "run", "set", "post", "stop", "load")):
                return False
            if word in ("set", "post", "load", "stop") and (seg.startswith(word) and not seg.startswith("setting")):
                return False
    return True


def get(path: str, timeout: float = 4.0) -> tuple[int, str, bytes]:
    req = urllib.request.Request(BASE + path, headers={"Accept": "application/json, text/plain, */*"})
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            return r.status, r.headers.get("Content-Type", ""), r.read()
    except urllib.error.HTTPError as e:
        return e.code, "", b""
    except Exception as e:
        return 0, str(e), b""


def discover() -> set[str]:
    """Adresy /rest/... wyczytane ze stron i skryptów interfejsu gry."""
    found: set[str] = set()
    pages = ["/", "/index.html"]
    seen: set[str] = set()
    while pages and len(seen) < 60:
        p = pages.pop(0)
        if p in seen:
            continue
        seen.add(p)
        code, ctype, body = get(p, 6)
        if code != 200 or not body:
            continue
        text = body.decode("utf-8", errors="ignore")
        for m in re.finditer(r"""["'`](/rest/[A-Za-z0-9_/\-{}.$]+)""", text):
            found.add(m.group(1))
        for m in re.finditer(r"""(?:src|href)=["']([^"'#]+\.(?:js|html))["']""", text):
            u = m.group(1)
            if u.startswith("http"):
                if not u.startswith(BASE):
                    continue
                u = u[len(BASE):]
            if not u.startswith("/"):
                u = "/" + u
            pages.append(u)
    return found


def main() -> None:
    code, err, _ = get("/", 3)
    if code == 0:
        print(f"Nie mogę połączyć się z LMU na {BASE} ({err}). Uruchom grę, wejdź do sesji i spróbuj ponownie.")
        return
    os.makedirs(OUT, exist_ok=True)
    print("Szukam adresów w interfejsie gry...")
    paths = sorted(discover() | set(CANDIDATES))
    report, hits = [], {k: [] for k in KEYWORDS}
    skipped = []
    for p in paths:
        if "{" in p or "$" in p:
            report.append(f"(z parametrem, pominięty) {p}")
            continue
        if not safe(p):
            skipped.append(p)
            continue
        code, ctype, body = get(p)
        line = f"{code} {p} ({len(body)} B)"
        report.append(line)
        print(line)
        if code == 200 and body:
            name = re.sub(r"[^A-Za-z0-9]+", "_", p).strip("_") or "root"
            try:
                data = json.loads(body.decode("utf-8"))
                txt = json.dumps(data, ensure_ascii=False, indent=1)
                ext = ".json"
            except Exception:
                txt = body.decode("utf-8", errors="ignore")
                ext = ".txt"
            with open(os.path.join(OUT, name + ext), "w", encoding="utf-8") as f:
                f.write(txt)
            low = txt.lower()
            for k, words in KEYWORDS.items():
                if any(w in low for w in words):
                    hits[k].append(p)
    with open(os.path.join(OUT, "RAPORT.txt"), "w", encoding="utf-8") as f:
        f.write("ODPOWIEDZI:\n" + "\n".join(report) + "\n\nPOMINIĘTE (mogłyby coś zmienić w grze):\n"
                + "\n".join(skipped) + "\n\nZNALEZIONE TEMATY:\n")
        for k, v in hits.items():
            f.write(f"{k}: {', '.join(v) if v else '—'}\n")
    print("\nZNALEZIONE TEMATY:")
    for k, v in hits.items():
        print(f"  {k}: {len(v)} adresów")
    print(f"\nGotowe. Wyniki w folderze {OUT}")


if __name__ == "__main__":
    sys.exit(main())
