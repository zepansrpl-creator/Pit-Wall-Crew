﻿# Instalator Inżyniera LMU v2 – komputer kierowcy.
$ErrorActionPreference = "Continue"
$Here = Split-Path -Parent (Split-Path -Parent $MyInvocation.MyCommand.Path)
Set-Location $Here
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
. (Join-Path $Here "tools\common.ps1")

Step 1 6 "Python"
$python = Ensure-Python
Write-Host "Python: $python"

Step 2 6 "Środowisko programu"
$vpy = Ensure-Venv $python

Step 3 6 "Biblioteki (kilka minut)"
& $vpy -m pip install -r requirements.txt
if ($LASTEXITCODE -ne 0) { throw "Instalacja bibliotek nie powiodła się." }

Step 4 6 "Ustawienia (okno)"
Write-Host "Otwieram okno ustawień Pit Wall Crew: tryb (zespół / solo), zespół, mikrofon, przycisk, głos."
Write-Host "Kod i hasło zespołu dostaniesz od kolegów (albo kliknij Utwórz nowy zespół). Po zapisaniu zamknij okno, instalacja przejdzie dalej."
& $vpy tools\okno_ustawien.py --ustawienia
if ($LASTEXITCODE -ne 0) { & $vpy tools\configure.py }

Step 5 6 "Skróty na pulpicie"
New-Shortcut "Pit Wall Crew" "start.bat"

Step 6 6 "Gotowe"
Write-Host "GOTOWE." -ForegroundColor Green
Write-Host "Na pulpicie: 'Pit Wall Crew' (test bez gry i ustawienia są w aplikacji)."
Write-Host "W LMU włącz raz: Ustawienia -> Rozgrywka -> Enable Plugins = ON."
Write-Host "Wszystkie ustawienia zmienisz w aplikacji Pit Wall Crew (pasek po lewej)."
