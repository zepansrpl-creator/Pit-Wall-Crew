"""Konfiguracja po instalacji.

python tools/configure.py            kierowca: zespół (kod i hasło), przycisk na kierownicy, mikrofon
python tools/configure.py --team     tylko zespół (kod i hasło)
python tools/configure.py --mic      tylko test mikrofonu
python tools/configure.py --set klucz=wartość [--set ...]   bez pytań
"""

from __future__ import annotations

import os
import re
import shutil
import sys
import time

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
CFG = os.path.join(ROOT, "config.toml")
EXAMPLE = "config.example.toml"


def set_value(key: str, value: str) -> None:
    with open(CFG, encoding="utf-8") as f:
        text = f.read()
    text, n = re.subn(rf"(?m)^{re.escape(key)}\s*=.*$", lambda _: f"{key} = {value}", text, count=1)
    if n == 0:
        text += f"\n{key} = {value}\n"
    with open(CFG, "w", encoding="utf-8") as f:
        f.write(text)


def get_value(key: str) -> str:
    with open(CFG, encoding="utf-8") as f:
        m = re.search(rf"(?m)^{re.escape(key)}\s*=\s*(.*)$", f.read())
    return m.group(1).strip() if m else ""


def ask_api_key() -> None:
    current = get_value("api_key").strip('"')
    if current:
        print("Klucz AI jest już wpisany.")
        return
    print("Klucz AI (z console.anthropic.com -> API Keys). Bez klucza inżynier działa, ale odpowiada prostymi formułkami.")
    key = input("Wklej klucz i Enter (samo Enter = pomiń): ").strip()
    if key:
        set_value("api_key", f'"{key}"')
        print("Zapisane.")


def ask_button() -> None:
    os.environ["SDL_JOYSTICK_ALLOW_BACKGROUND_EVENTS"] = "1"
    try:
        import pygame
    except ImportError:
        return
    pygame.init()
    pygame.joystick.init()
    joys = []
    for i in range(pygame.joystick.get_count()):
        j = pygame.joystick.Joystick(i)
        j.init()
        joys.append(j)
    if not joys:
        print("Nie widzę kierownicy. Do mówienia działa klawisz F8; przycisk ustawisz później plikiem ustawienia.bat.")
        return
    print("Wciśnij na kierownicy przycisk, którego chcesz używać do mówienia (masz 20 sekund)...")
    pygame.event.pump()
    start = {(j.get_instance_id(), b): j.get_button(b) for j in joys for b in range(j.get_numbuttons())}
    end = time.monotonic() + 20
    while time.monotonic() < end:
        pygame.event.pump()
        for j in joys:
            for b in range(j.get_numbuttons()):
                if j.get_button(b) and not start.get((j.get_instance_id(), b)):
                    set_value("joystick_name", f'"{j.get_name()}"')
                    set_value("joystick_button", str(b))
                    print(f"Zapisane: {j.get_name()}, przycisk {b}.")
                    return
        time.sleep(0.01)
    print("Nie wykryłem wciśnięcia. Zostaje klawisz F8; przycisk ustawisz później plikiem ustawienia.bat.")


def _toml_str(v: str) -> str:
    return '"' + v.replace("\\", "\\\\").replace('"', '\\"') + '"'


def _from_toml(v: str) -> str:
    v = v.strip()
    if len(v) >= 2 and v[0] == v[-1] == '"':
        v = v[1:-1].replace('\\"', '"').replace("\\\\", "\\")
    return v


def check_mic() -> None:
    """Test mikrofonu: nagrywa 3 s; gdy cicho albo nie działa, pozwala wybrać inny (zapis po nazwie)."""
    sys.path.insert(0, ROOT)
    try:
        import numpy as np
        from engineer.listen import PRIVACY_HINT, Microphone, list_mics
    except Exception as e:
        print(f"Brak dostępu do mikrofonu: {e}")
        return
    for _ in range(4):
        wanted = _from_toml(get_value("mic_device")) or None
        mic, peak = None, 0
        try:
            mic = Microphone(wanted, quiet=True)
        except Exception as e:
            print(f"Nie udało się otworzyć mikrofonu: {e}")
        if mic is not None:
            if mic.fallback:
                print(f"Mikrofon z ustawień ({wanted}) jest niedostępny, sprawdzam: {mic.name}")
            input(f"Test mikrofonu ({mic.name}): naciśnij Enter i powiedz coś przez 3 sekundy...")
            mic.start()
            time.sleep(3)
            audio = mic.stop()
            mic.close()
            peak = int(np.abs(audio.astype(np.int32)).max()) if len(audio) else 0
            if peak > 1500:
                print("Mikrofon działa.")
                if wanted is None or mic.fallback or str(wanted).isdigit():
                    set_value("mic_device", _toml_str(mic.name))
                    print(f"Zapisane: {mic.name}")
                return
            if peak == 0:
                print(f"Zupełna cisza: Windows prawdopodobnie blokuje mikrofon. {PRIVACY_HINT}.")
            else:
                print("Prawie nic nie słychać.")
        mics = list_mics()
        if not mics:
            print(f"Nie widzę żadnego mikrofonu. Podłącz mikrofon/słuchawki. {PRIVACY_HINT}.")
            return
        print("Dostępne mikrofony:")
        for i, m in enumerate(mics, start=1):
            print(f"  {i}: {m['name']}")
        choice = input("Wpisz numer mikrofonu (samo Enter = zostaw): ").strip()
        if not (choice.isdigit() and 1 <= int(choice) <= len(mics)):
            return
        set_value("mic_device", _toml_str(mics[int(choice) - 1]["name"]))


def team_setup(choose_name: bool = True) -> None:
    """Kod i hasło zespołu (Firebase) – dołączenie do zespołu albo utworzenie nowego; potem wybór imienia."""
    import getpass
    sys.path.insert(0, ROOT)
    from tools.cfgfile import CfgFile
    from team.fbbackend import FbBackend
    from team.firebase import FbClient, load_config
    cf = CfgFile(CFG, os.path.join(ROOT, EXAMPLE))
    print("ZESPÓŁ (Pit Wall Crew)")
    if not load_config():
        print("Brak pliku firebase_config.json – zespół niedostępny. Inżynier działa sam.")
        return
    code, pw = str(cf.get("team", "code", "") or ""), str(cf.get("team", "password", "") or "")
    if code:
        print(f"Kod zespołu jest już wpisany ({code}). Enter = zostaw.")
    for _ in range(3):
        c = input("Kod zespołu (od kolegów; „nowy” = utwórz zespół; samo Enter = bez zespołu): ").strip().lower() or code
        if not c:
            print("Bez zespołu inżynier działa sam. Możesz to ustawić później w oknie ustawień.")
            return
        p = getpass.getpass("Hasło zespołu (nie będzie widoczne): ") or pw
        try:
            if c == "nowy":
                name = input("Nazwa zespołu: ").strip()
                cl = FbClient.create_team(p, name)
                print(f"Utworzono zespół. KOD: {cl.code} – podaj go kolegom razem z hasłem (prywatnie).")
            else:
                cl = FbClient(c, p)
            out = FbBackend(cl).call({"op": "view"})
        except Exception as e:
            print(f"Nie mogę się połączyć: {e}")
            continue
        cf.set("team", "code", cl.code)
        cf.set("team", "password", p)
        print(f"Połączono z zespołem „{out.get('team') or cl.code}”.")
        names = out.get("kierowcy") or []
        if choose_name and names:
            for i, n in enumerate(names, start=1):
                print(f"  {i}: {n}")
            k = input("Kim jesteś? Wpisz numer (albo imię): ").strip()
            nm = names[int(k) - 1] if k.isdigit() and 1 <= int(k) <= len(names) else k
            if nm:
                cf.set("team", "name", nm)
                print(f"Zapisane: {nm}.")
        elif choose_name:
            nm = input("Twoje imię (dodajcie kierowców na ścianie boksów, zakładka Zespół): ").strip()
            if nm:
                cf.set("team", "name", nm)
        return


def migrate() -> None:
    """Starszy config.toml (bez sekcji [team]) -> nowy wzór, z zachowaniem wpisanych wartości."""
    with open(CFG, encoding="utf-8") as f:
        old = f.read()
    if re.search(r"(?m)^\[team\]", old):
        return
    values = re.findall(r"(?m)^(\w+)\s*=\s*(.+)$", old)
    shutil.copy(os.path.join(ROOT, "config.example.toml"), CFG)
    for k, v in values:
        if get_value(k) != "":
            set_value(k, v.strip())


def main() -> None:
    if not os.path.exists(CFG):
        shutil.copy(os.path.join(ROOT, EXAMPLE), CFG)
    args = sys.argv[1:]
    migrate()
    if args == ["--team"]:
        try:
            team_setup()
        except (KeyboardInterrupt, EOFError):
            pass
        return
    # tryb nieinteraktywny: configure.py --set mode="local" --set local_model="..."
    if args == ["--mic"]:
        try:
            check_mic()
        except (KeyboardInterrupt, EOFError):
            pass
        return
    if args and args[0] == "--set":
        for i in range(0, len(args) - 1, 2):
            if args[i] == "--set" and "=" in args[i + 1]:
                k, v = args[i + 1].split("=", 1)
                v = v.strip()
                if not (v.startswith('"') or re.fullmatch(r"-?\d+(\.\d+)?|true|false", v)):
                    v = f'"{v}"'  # PowerShell gubi cudzysłowy w argumentach
                set_value(k.strip(), v)
        return
    try:
        team_setup()
        print()
        ask_button()
        print()
        check_mic()
    except (KeyboardInterrupt, EOFError):
        print("\nPominięto resztę konfiguracji.")


if __name__ == "__main__":
    sys.exit(main())
