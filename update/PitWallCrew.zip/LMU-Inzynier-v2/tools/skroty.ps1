﻿# Skróty na pulpicie z ikoną Pit Wall Crew (dla już zainstalowanego programu).
$Here = Split-Path -Parent (Split-Path -Parent $MyInvocation.MyCommand.Path)
Set-Location $Here
. (Join-Path $Here "tools\common.ps1")
if (Test-Path "config.toml") {
    New-Shortcut "Pit Wall Crew" "start.bat"
    New-Shortcut "Pit Wall Crew - test bez gry" "start_demo.bat"
    New-Shortcut "Pit Wall Crew - ustawienia" "ustawienia.bat"
}
if (Test-Path "serwer.toml") { New-Shortcut "Pit Wall Crew - serwer AI" "serwer.bat" }
