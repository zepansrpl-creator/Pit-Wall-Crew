"""Odczyt i zapis pojedynczych ustawień w config.toml z zachowaniem komentarzy (per sekcja)."""

from __future__ import annotations

import os
import re
import shutil
import tomllib

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


class CfgFile:
    def __init__(self, path: str, example: str) -> None:
        self.path = path
        if not os.path.exists(path):
            shutil.copy(example, path)

    def text(self) -> str:
        with open(self.path, encoding="utf-8") as f:
            return f.read()

    def data(self) -> dict:
        try:
            return tomllib.loads(self.text())
        except Exception:
            return {}

    def get(self, section: str, key: str, default=None):
        return self.data().get(section, {}).get(key, default)

    @staticmethod
    def fmt(v) -> str:
        if isinstance(v, bool):
            return "true" if v else "false"
        if isinstance(v, (int, float)):
            return repr(v)
        if isinstance(v, list):
            return "[" + ", ".join(CfgFile.fmt(x) for x in v) + "]"
        return '"' + str(v).replace("\\", "\\\\").replace('"', '\\"') + '"'

    def set(self, section: str, key: str, value) -> None:
        text = self.text()
        line = f"{key} = {self.fmt(value)}"
        m = re.search(rf"(?ms)^\[{re.escape(section)}\]\s*$(.*?)(?=^\[|\Z)", text)
        if m is None:
            text = text.rstrip("\n") + f"\n\n[{section}]\n{line}\n"
        else:
            body = m.group(1)
            rx = re.compile(rf"(?m)^{re.escape(key)}\s*=[^\n#]*?(\s*#.*)?$")
            if rx.search(body):
                body = rx.sub(lambda mm: line + (mm.group(1) or ""), body, count=1)
            else:
                body = "\n" + line + body if not body.strip() else body.rstrip("\n") + "\n" + line + "\n\n"
            text = text[:m.start(1)] + body + text[m.end(1):]
        with open(self.path, "w", encoding="utf-8") as f:
            f.write(text)
