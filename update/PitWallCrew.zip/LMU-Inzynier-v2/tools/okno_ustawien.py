"""Pit Wall Crew – aplikacja kierowcy (okno zamiast konsoli).

Strona „Inżynier”: stan połączeń, najważniejsze liczby z auta, komunikaty inżyniera i pole do pytań.
Inżynier (kierowca.py) działa jako osobny proces bez okna konsoli – aplikacja czyta jego komunikaty
i przekazuje pytania. Pozostałe strony: Zespół, Mikrofon i przycisk, Głos, Ostrzeżenia, Zaawansowane
(zapis do config.toml, komentarze w pliku zostają).

  pythonw tools/okno_ustawien.py            okno + start inżyniera (start.bat)
  pythonw tools/okno_ustawien.py --demo     test bez gry (symulowany wyścig)
  pythonw tools/okno_ustawien.py --ustawienia   tylko okno, inżynier nie startuje sam
"""

from __future__ import annotations

import json
import os
import queue
import subprocess
import sys
import threading
import time
import tkinter as tk
import urllib.request
from tkinter import messagebox, ttk

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)
sys.path.insert(0, os.path.join(ROOT, "tools"))
sys.path.insert(0, os.path.join(ROOT, "vendor"))
os.chdir(ROOT)

from cfgfile import CfgFile  # noqa: E402

CFG = CfgFile(os.path.join(ROOT, "config.toml"), os.path.join(ROOT, "config.example.toml"))
ICON = os.path.join(ROOT, "assets", "inzynier.ico")
LOGO = os.path.join(ROOT, "assets", "logo.png")

VOICES = [
    ("pl-PL-MarekNeural", "+0Hz", "Marek (polski)"),
    ("pl-PL-MarekNeural", "-8Hz", "Marek, niższy głos"),
    ("pl-PL-ZofiaNeural", "+0Hz", "Zofia (polski)"),
    ("en-US-AndrewMultilingualNeural", "+0Hz", "Andrew (lekki akcent)"),
    ("en-US-BrianMultilingualNeural", "+0Hz", "Brian (lekki akcent)"),
    ("de-DE-FlorianMultilingualNeural", "+0Hz", "Florian (niemiecki akcent)"),
    ("en-US-AvaMultilingualNeural", "+0Hz", "Ava (kobiecy, akcent)"),
]
RADIO = [(0.0, "bez efektu radia"), (0.5, "delikatne radio"), (1.0, "radio jak w transmisji"), (1.5, "mocno trzeszczy")]
SAMPLE = "Słuchaj, zjazd za dwa okrążenia. Energia do pełna, cztery opony. Hypercar, 2 sekundy."

# kolory (ciemny motyw Sun Valley = Windows 11)
BG, SIDE, CARD, LINE = "#1c1c1c", "#141414", "#262729", "#333438"
TEXT, MUTED, ACCENT = "#ececec", "#9a9da3", "#e8352e"
OK, WARN, BAD, INFO = "#4cc764", "#e3a72f", "#f2564b", "#5fb3ff"
NO_WINDOW = getattr(subprocess, "CREATE_NO_WINDOW", 0)
FONT, MONO = "Segoe UI", "Consolas"   # ustawiane w main() wg dostępnych czcionek


class EngineProc:
    """Inżynier (kierowca.py) jako proces w tle: komunikaty z jego wyjścia, pytania na jego wejście."""

    def __init__(self) -> None:
        self.p: subprocess.Popen | None = None
        self.lines: queue.Queue[str] = queue.Queue()
        self.demo = False

    @property
    def running(self) -> bool:
        return self.p is not None and self.p.poll() is None

    def start(self, demo: bool = False) -> None:
        if self.running:
            return
        self.demo = demo
        exe = sys.executable
        if exe.lower().endswith("pythonw.exe"):
            exe = exe[:-11] + "python.exe"
        env = dict(os.environ, PWC_GUI="1", PYTHONIOENCODING="utf-8", PYTHONUNBUFFERED="1", PYGAME_HIDE_SUPPORT_PROMPT="1")
        cmd = [exe, "-u", os.path.join(ROOT, "kierowca.py")] + (["--demo"] if demo else [])
        self.p = subprocess.Popen(cmd, cwd=ROOT, env=env, stdin=subprocess.PIPE, stdout=subprocess.PIPE,
                                  stderr=subprocess.STDOUT, text=True, encoding="utf-8", errors="replace",
                                  bufsize=1, creationflags=NO_WINDOW)
        threading.Thread(target=self._read, args=(self.p,), daemon=True).start()

    def _read(self, p) -> None:
        for line in p.stdout:
            self.lines.put(line.rstrip("\n"))
        self.lines.put("@@END")

    def send(self, text: str) -> None:
        if self.running:
            try:
                self.p.stdin.write(text.replace("\n", " ") + "\n")
                self.p.stdin.flush()
            except OSError:
                pass

    def stop(self, wait: float = 6.0) -> None:
        if not self.running:
            return
        self.send("koniec")
        try:
            self.p.wait(wait)
        except subprocess.TimeoutExpired:
            self.p.kill()



class App:
    def __init__(self, root: tk.Tk) -> None:
        self.root = root
        from engineer.version import version
        root.title(f"Pit Wall Crew {version()} – ustawienia")
        try:
            root.iconbitmap(ICON)
        except Exception:
            try:
                self._ico = tk.PhotoImage(file=LOGO)
                root.iconphoto(True, self._ico)
            except Exception:
                pass
        root.geometry("1060x720")
        root.minsize(880, 600)
        root.configure(bg=BG)
        d = CFG.data()
        self.d = d
        g = lambda s, k, v: d.get(s, {}).get(k, v)
        self.eng = EngineProc()
        self.state: dict = {}
        self.state_t = 0.0
        self.pages: dict = {}
        self.nav: dict = {}
        self.page = ""

        # ------------------------------------------------------------ pasek boczny
        side = tk.Frame(root, bg=SIDE, width=212)
        side.pack(side="left", fill="y")
        side.pack_propagate(False)
        head = tk.Frame(side, bg=SIDE)
        head.pack(fill="x", padx=16, pady=(18, 24))
        try:
            img = tk.PhotoImage(file=LOGO)
            f = max(1, img.width() // 44)
            self._logo = img.subsample(f, f)
            tk.Label(head, image=self._logo, bg=SIDE).pack(side="left", padx=(0, 10))
        except Exception:
            pass
        tt = tk.Frame(head, bg=SIDE)
        tt.pack(side="left")
        tk.Label(tt, text="Pit Wall Crew", bg=SIDE, fg=TEXT, font=(FONT, 13, "bold")).pack(anchor="w")
        tk.Label(tt, text=f"wersja {version()}", bg=SIDE, fg=MUTED, font=(FONT, 9)).pack(anchor="w")
        self.nav_box = tk.Frame(side, bg=SIDE)
        self.nav_box.pack(fill="x")
        foot = tk.Frame(side, bg=SIDE)
        foot.pack(side="bottom", fill="x", padx=14, pady=14)
        ttk.Button(foot, text="Ściana boksów  ↗", command=self._open_wall).pack(fill="x")

        # ------------------------------------------------------------ zawartość
        self.content = tk.Frame(root, bg=BG)
        self.content.pack(side="left", fill="both", expand=True)
        top = tk.Frame(self.content, bg=BG)
        top.pack(fill="x", padx=28, pady=(20, 4))
        self.title_lbl = tk.Label(top, text="", bg=BG, fg=TEXT, font=(FONT, 20, "bold"), anchor="w")
        self.title_lbl.pack(side="left")
        self.sub_lbl = tk.Label(top, text="", bg=BG, fg=MUTED, font=(FONT, 10), anchor="w")
        self.sub_lbl.pack(side="left", padx=(12, 0), pady=(8, 0))
        self.bar = tk.Frame(self.content, bg=BG)
        self.bar.pack(side="bottom", fill="x", padx=28, pady=(8, 18))
        self.body = tk.Frame(self.content, bg=BG)
        self.body.pack(fill="both", expand=True, padx=28, pady=(6, 0))
        nb = None
        self._engineer_page()

        # ------------------------------------------------------------ Zespół
        t = self._tab(nb, "Zespół", "kod i hasło zespołu, kim jesteś")
        self.mode = tk.StringVar(value=g("team", "mode", "zespol"))
        ttk.Label(t, text="Tryb pracy").grid(row=0, column=0, sticky="w")
        mf = ttk.Frame(t)
        mf.grid(row=0, column=1, sticky="w")
        ttk.Radiobutton(mf, text="Zespół (ściana boksów, Discord, zmiany kierowców)", variable=self.mode,
                        value="zespol", command=self._mode_changed).pack(anchor="w")
        ttk.Radiobutton(mf, text="Solo – jeden gracz, ostrzejszy ton; ściana boksów zostaje", variable=self.mode,
                        value="solo", command=self._mode_changed).pack(anchor="w")
        self.code = tk.StringVar(value=g("team", "code", ""))
        self.pw = tk.StringVar(value=g("team", "password", ""))
        self.name = tk.StringVar(value=g("team", "name", ""))
        self.discord = tk.BooleanVar(value=bool(g("team", "discord", True)))
        self.team_widgets = []   # tylko to, czego nie ma w trybie solo (ściana boksów zostaje)
        self._row(t, 1, "Kod zespołu", ttk.Entry(t, textvariable=self.code, width=16))
        self._row(t, 2, "Hasło zespołu", ttk.Entry(t, textvariable=self.pw, width=24, show="•"))
        bf = ttk.Frame(t)
        bf.grid(row=3, column=1, sticky="w", pady=4)
        ttk.Button(bf, text="Sprawdź połączenie", command=self._test_team).pack(side="left")
        ttk.Button(bf, text="Utwórz nowy zespół…", command=self._new_team).pack(side="left", padx=6)
        ttk.Button(bf, text="Otwórz ścianę boksów", command=self._open_wall).pack(side="left")
        self.name_cb = ttk.Combobox(t, textvariable=self.name, width=24)
        self._row(t, 4, "Kim jesteś (kierowca)", self.name_cb)
        c = ttk.Checkbutton(t, text="Komunikaty zespołowe mówi bot na Discordzie", variable=self.discord)
        c.grid(row=5, column=1, sticky="w")
        self.team_widgets.append(c)
        self.team_status = ttk.Label(t, text="", foreground=MUTED)
        self.team_status.grid(row=6, column=0, columnspan=2, sticky="w", pady=(8, 0))
        self._mode_changed()

        # ------------------------------------------------------------ Mikrofon i przycisk
        t = self._tab(nb, "Mikrofon i przycisk", "rozmowa z inżynierem")
        self.mic = tk.StringVar(value=g("listen", "mic_device", ""))
        self.mic_cb = ttk.Combobox(t, textvariable=self.mic, width=48)
        self._row(t, 0, "Mikrofon", self.mic_cb)
        mb = ttk.Frame(t)
        mb.grid(row=1, column=1, sticky="w", pady=4)
        ttk.Button(mb, text="Odśwież listę", command=self._load_mics).pack(side="left")
        ttk.Button(mb, text="Test 3 s", command=self._test_mic).pack(side="left", padx=6)
        self.level = ttk.Progressbar(t, length=300, maximum=32767)
        self.level.grid(row=2, column=1, sticky="w")
        self.mic_status = ttk.Label(t, text="", foreground=MUTED)
        self.mic_status.grid(row=3, column=1, sticky="w")
        ttk.Separator(t).grid(row=4, column=0, columnspan=2, sticky="ew", pady=10)
        self.ptt_key = tk.StringVar(value=g("listen", "ptt_key", "f8"))
        self._row(t, 5, "Klawisz mówienia", ttk.Entry(t, textvariable=self.ptt_key, width=10))
        self.joy_name = g("listen", "joystick_name", "")
        self.joy_button = int(g("listen", "joystick_button", -1))
        self.joy_lbl = ttk.Label(t, text=self._joy_text())
        self._row(t, 6, "Przycisk na kierownicy", self.joy_lbl)
        jb = ttk.Frame(t)
        jb.grid(row=7, column=1, sticky="w", pady=4)
        ttk.Button(jb, text="Ustaw: naciśnij przycisk…", command=self._find_button).pack(side="left")
        ttk.Button(jb, text="Bez kierownicy", command=self._no_button).pack(side="left", padx=6)
        self.mic_enabled = tk.BooleanVar(value=bool(g("listen", "enabled", True)))
        ttk.Checkbutton(t, text="Rozmowa głosowa włączona", variable=self.mic_enabled).grid(row=8, column=1, sticky="w")

        # ------------------------------------------------------------ Głos
        t = self._tab(nb, "Głos", "jak brzmi inżynier")
        cur_v, cur_p = g("voice", "edge_voice", "pl-PL-MarekNeural"), g("voice", "pitch", "+0Hz")
        labels = [v[2] for v in VOICES]
        idx = next((i for i, v in enumerate(VOICES) if v[0] == cur_v and v[1] == cur_p),
                   next((i for i, v in enumerate(VOICES) if v[0] == cur_v), 0))
        self.voice = tk.StringVar(value=labels[idx])
        self._row(t, 0, "Głos", ttk.Combobox(t, textvariable=self.voice, values=labels, state="readonly", width=34))
        rate = str(g("voice", "rate", "+10%")).strip("%+")
        self.rate = tk.IntVar(value=int(float(rate or 0)))
        self._row(t, 1, "Tempo mówienia", self._slider(t, self.rate, -20, 40, lambda v: f"{int(float(v)):+d}%"))
        self.volume = tk.DoubleVar(value=float(g("voice", "volume", 1.0)))
        self._row(t, 2, "Głośność", self._slider(t, self.volume, 0.2, 1.5, lambda v: f"{round(float(v) * 100)}%"))
        rs = float(g("voice", "radio_strength", 1.0)) if g("voice", "radio", True) else 0.0
        self.radio = tk.StringVar(value=min(RADIO, key=lambda r: abs(r[0] - rs))[1])
        self._row(t, 3, "Efekt radia", ttk.Combobox(t, textvariable=self.radio, values=[r[1] for r in RADIO],
                                                    state="readonly", width=26))
        self.fillers = tk.BooleanVar(value=bool(g("voice", "fillers", True)))
        ttk.Checkbutton(t, text="Mów naturalniej („Słuchaj,”, „Dobra,”)",
                        variable=self.fillers).grid(row=4, column=1, sticky="w", pady=4)
        self.eng_name = tk.StringVar(value=g("voice", "name", ""))
        self._row(t, 5, "Imię inżyniera", ttk.Entry(t, textvariable=self.eng_name, width=18))
        ttk.Label(t, text="Przedstawi się na początku jazdy; „<imię>, cicho” wycisza go jak „inżynier, cicho”.",
                  foreground=MUTED).grid(row=6, column=1, sticky="w")
        from engineer.style import PERSONAS
        self._personas = {v[0]: k for k, v in PERSONAS.items()}
        cur = PERSONAS.get(g("voice", "persona", "pro"), PERSONAS["pro"])[0]
        self.persona = tk.StringVar(value=cur)
        self._row(t, 7, "Styl", ttk.Combobox(t, textvariable=self.persona, values=list(self._personas),
                                             state="readonly", width=34))
        ttk.Button(t, text="▶ Odsłuchaj", command=self._play).grid(row=8, column=1, sticky="w", pady=6)
        self.voice_status = ttk.Label(t, text="", foreground=MUTED)
        self.voice_status.grid(row=9, column=1, sticky="w")

        # ------------------------------------------------------------ Ostrzeżenia
        t = self._tab(nb, "Ostrzeżenia", "co inżynier mówi bez pytania")
        self.lapping = tk.BooleanVar(value=bool(g("alerts", "lapping", True)))
        self.hazards = tk.BooleanVar(value=bool(g("alerts", "hazards", True)))
        self.flags = tk.BooleanVar(value=bool(g("alerts", "flags", True)))
        self.sugg = tk.BooleanVar(value=bool(g("alerts", "suggestions", True)))
        self.coach_on = tk.BooleanVar(value=bool(g("alerts", "coach", True)))
        self.cmp_best = tk.BooleanVar(value=bool(g("alerts", "compare_best", True)))
        self.overtakes = tk.BooleanVar(value=bool(g("alerts", "overtakes", True)))
        self.warn_s = tk.DoubleVar(value=float(g("alerts", "lapping_warn_s", 2)))
        self.chain_s = tk.DoubleVar(value=float(g("alerts", "lapping_chain_s", 1)))
        self.sugg_gap = tk.IntVar(value=int(g("alerts", "suggest_gap_min", 12)))
        r = 0
        r = self._section(t, r, "Pilne – zawsze od razu")
        r = self._check(t, r, "Dublowanie przez szybszą klasę", self.lapping, "głosem: „bez dublowania” / „mów o dublowaniu”")
        self._row(t, r, "Ostrzegaj, gdy szybsze auto jest (s)", ttk.Spinbox(t, from_=1, to=6, increment=0.5,
                                                                             textvariable=self.warn_s, width=6))
        self._row(t, r + 1, "Grupa aut („dwa hypercary”) do (s)", ttk.Spinbox(t, from_=0.5, to=3, increment=0.5,
                                                                               textvariable=self.chain_s, width=6))
        r += 2
        r = self._check(t, r, "Auto stojące / wolne przed Tobą", self.hazards)
        r = self._check(t, r, "Flagi, kary, limity toru", self.flags)
        r = self._section(t, r, "Podpowiedzi")
        r = self._check(t, r, "Trener przed zakrętem (powtarzające się błędy)", self.coach_on,
                        "głosem: „trener” / „bez trenera”")
        r = self._check(t, r, "Porównanie z najlepszym okrążeniem na podobnych oponach", self.cmp_best,
                        "np. „T5: hamujesz 15 metrów wcześniej” · głosem: „porównanie” / „bez porównania”")
        r = self._check(t, r, "Komentarz po wyprzedzeniu / stracie pozycji", self.overtakes,
                        "dopiero gdy pozycja utrzyma się 30 s · głosem: „komentarze” / „bez komentarzy”")
        r = self._check(t, r, "Sugestie ustawień i techniki", self.sugg, "głosem: „sugestie” / „bez sugestii”")
        self._row(t, r, "Przerwa między sugestiami (min)", ttk.Spinbox(t, from_=3, to=60, textvariable=self.sugg_gap,
                                                                        width=6))

        # ------------------------------------------------------------ Zaawansowane
        t = self._tab(nb, "Zaawansowane")
        self.tyre_set = tk.DoubleVar(value=float(g("strategy", "tyre_set_s", 12)))
        self._row(t, 0, "Zmiana kompletu opon (s)", ttk.Spinbox(t, from_=4, to=40, textvariable=self.tyre_set, width=6))
        self.rest = tk.BooleanVar(value=bool(g("rest", "enabled", True)))
        ttk.Checkbutton(t, text="Pytaj grę o prognozę, menu boksu i rywali",
                        variable=self.rest).grid(row=1, column=1, sticky="w", pady=4)
        self.diag = tk.BooleanVar(value=bool(g("diag", "enabled", True)))
        ttk.Checkbutton(t, text="Dziennik przycięć (recordings/przyciecia_*.txt)", variable=self.diag).grid(
            row=2, column=1, sticky="w")
        self.mark = tk.StringVar(value=g("diag", "mark_key", "f9"))
        self._row(t, 3, "Klawisz znacznika przycięcia", ttk.Entry(t, textvariable=self.mark, width=10))
        self.autostart = tk.BooleanVar(value=bool(g("ui", "autostart", True)))
        ttk.Checkbutton(t, text="Uruchamiaj inżyniera od razu po otwarciu aplikacji", variable=self.autostart).grid(
            row=4, column=1, sticky="w")
        ttk.Button(t, text="Utwórz skróty na pulpicie (z ikoną)", command=self._shortcuts).grid(
            row=5, column=1, sticky="w", pady=12)
        self.auto_update = tk.BooleanVar(value=bool(g("ui", "auto_update", True)))
        ttk.Checkbutton(t, text="Aktualizuj automatycznie przy starcie aplikacji (nigdy w trakcie jazdy)",
                        variable=self.auto_update).grid(row=6, column=1, sticky="w")
        ttk.Button(t, text="Sprawdź aktualizacje teraz", command=lambda: self._update(manual=True)).grid(
            row=7, column=1, sticky="w", pady=8)

        # ------------------------------------------------------------ pomoc
        from engineer.commands import COMMANDS
        from engineer.help_texts import FEATURES, MANUAL
        self._doc_page("Komendy", "co powiedzieć inżynierowi", [
            (sec, [f"• {cmd} — {what}" for cmd, what in items]) for sec, items in COMMANDS])
        self._doc_page("Co potrafi", "wszystkie funkcje", FEATURES)
        self._doc_page("Instrukcja", "jak używać", MANUAL)

        # ------------------------------------------------------------ przyciski (strony ustawień)
        self.status = tk.Label(self.bar, text="", bg=BG, fg=MUTED, font=(FONT, 10), anchor="w")
        self.status.pack(side="left", fill="x", expand=True)
        self.save_btns = [ttk.Button(self.bar, text="Zapisz i uruchom ponownie", style="Accent.TButton",
                                     command=self._save_restart),
                          ttk.Button(self.bar, text="Zapisz", command=self._save)]
        for bt in self.save_btns:
            bt.pack(side="right", padx=(8, 0))
        self.show("Inżynier")
        root.protocol("WM_DELETE_WINDOW", self._close)
        root.after(100, self._pump)
        root.after(200, self._load_mics)
        # lista kierowców od razu (z arkusza, gdy adres i klucz są wpisane)
        self.name_cb.configure(values=[x for x in dict.fromkeys([self.name.get()]) if x])
        if self.code.get().strip() and self.pw.get():
            root.after(300, self._test_team)

    # ----------------------------------------------------------------- strona „Inżynier”
    def _card(self, parent, caption):
        c = tk.Frame(parent, bg=CARD, highlightthickness=1, highlightbackground=LINE)
        tk.Label(c, text=caption.upper(), bg=CARD, fg=MUTED, font=(FONT, 8, "bold"), anchor="w").pack(
            fill="x", padx=14, pady=(10, 0))
        v = tk.Label(c, text="—", bg=CARD, fg=TEXT, font=(FONT, 20, "bold"), anchor="w")
        v.pack(fill="x", padx=14)
        n = tk.Label(c, text=" ", bg=CARD, fg=MUTED, font=(FONT, 9), anchor="w")
        n.pack(fill="x", padx=14, pady=(0, 10))
        return c, v, n

    def _chip(self, parent, text):
        f = tk.Frame(parent, bg=CARD, highlightthickness=1, highlightbackground=LINE)
        dot = tk.Label(f, text="●", bg=CARD, fg=MUTED, font=(FONT, 9))
        dot.pack(side="left", padx=(10, 4), pady=5)
        lbl = tk.Label(f, text=text, bg=CARD, fg=TEXT, font=(FONT, 9))
        lbl.pack(side="left", padx=(0, 12))
        f.pack(side="left", padx=(0, 8))
        return dot, lbl

    def _engineer_page(self):
        f = ttk.Frame(self.body)
        self.pages["Inżynier"] = (f, "")
        item = self._tab(None, "Inżynier")       # wpis w pasku bocznym
        self.pages["Inżynier"] = (f, "")
        item.destroy()

        top = tk.Frame(f, bg=BG)
        top.pack(fill="x", pady=(4, 12))
        self.chips = {k: self._chip(top, t) for k, t in
                      (("eng", "Inżynier"), ("game", "Gra"), ("team", "Zespół"), ("ai", "Serwer AI"))}
        self.run_btn = ttk.Button(top, text="▶  Uruchom", style="Accent.TButton", command=self._toggle)
        self.run_btn.pack(side="right")
        self.demo_btn = ttk.Button(top, text="Test bez gry", width=15, command=lambda: self._toggle(demo=True))
        self.demo_btn.pack(side="right", padx=8)

        grid = tk.Frame(f, bg=BG)
        grid.pack(fill="x")
        self.cards = {}
        for i, (k, cap) in enumerate((("pos", "Pozycja w klasie"), ("lap", "Okrążenie"), ("stop", "Zjazd"),
                                      ("fuel", "Energia / paliwo"), ("time", "Ostatnie / średnia"),
                                      ("remain", "Do mety"))):
            c, v, n = self._card(grid, cap)
            c.grid(row=i // 3, column=i % 3, sticky="nsew", padx=(0 if i % 3 == 0 else 6, 0 if i % 3 == 2 else 6),
                   pady=6)
            self.cards[k] = (v, n)
        for col in range(3):
            grid.columnconfigure(col, weight=1, uniform="c")

        tk.Label(f, text="KOMUNIKATY", bg=BG, fg=MUTED, font=(FONT, 8, "bold"), anchor="w").pack(fill="x", pady=(14, 4))
        box = tk.Frame(f, bg=CARD, highlightthickness=1, highlightbackground=LINE)
        box.pack(fill="both", expand=True)
        self.log = tk.Text(box, bg=CARD, fg=TEXT, relief="flat", bd=0, wrap="word", font=(FONT, 10),
                           padx=14, pady=10, height=8, insertbackground=TEXT, cursor="arrow")
        sb = ttk.Scrollbar(box, orient="vertical", command=self.log.yview)
        self.log.configure(yscrollcommand=sb.set)
        sb.pack(side="right", fill="y")
        self.log.pack(side="left", fill="both", expand=True)
        for tag, col in (("eng", TEXT), ("urgent", BAD), ("team", WARN), ("me", INFO), ("sys", MUTED), ("ai", "#b99cff")):
            self.log.tag_configure(tag, foreground=col, spacing1=3, spacing3=3)
        self.log.tag_configure("urgent", font=(FONT, 10, "bold"))
        self.log.tag_configure("t", foreground="#6c6f75", font=(MONO, 9))
        self.log.tag_configure("who", foreground=MUTED, font=(FONT, 9, "bold"))
        self.log.configure(state="disabled")

        ask = tk.Frame(f, bg=BG)
        ask.pack(fill="x", pady=(10, 0))
        self.q = tk.StringVar()
        e = ttk.Entry(ask, textvariable=self.q, font=(FONT, 10))
        e.pack(side="left", fill="x", expand=True)
        e.bind("<Return>", lambda ev: self._ask())
        ttk.Button(ask, text="Zapytaj inżyniera", command=self._ask).pack(side="left", padx=(8, 0))
        self._placeholder(e, "Napisz pytanie, np. „ile paliwa”, „kiedy zjazd”, „jak opony”…")

    def _placeholder(self, entry, text):
        def show(_=None):
            if not self.q.get():
                entry.configure(foreground=MUTED)
                self.q.set(text)
                entry._ph = True

        def hide(_=None):
            if getattr(entry, "_ph", False):
                self.q.set("")
                entry.configure(foreground=TEXT)
                entry._ph = False
        entry.bind("<FocusIn>", hide)
        entry.bind("<FocusOut>", show)
        self._ph_entry = entry
        show()

    def _ask(self):
        q = self.q.get().strip()
        if not q or getattr(self._ph_entry, "_ph", False):
            return
        if not self.eng.running:
            self._feed("sys", "Najpierw uruchom inżyniera.")
            return
        self.q.set("")
        self._feed("me", q, "TY")
        self.eng.send(q)

    def _toggle(self, demo=False):
        if self.eng.running:
            self.eng.stop()
            self._feed("sys", "Inżynier zatrzymany.")
        else:
            self.eng.start(demo=demo)
            self.state, self.state_t = {}, 0.0
            self._feed("sys", "Uruchamiam inżyniera" + (" – test bez gry (symulowany wyścig)…" if demo else "…"))
        self._refresh()

    def _feed(self, tag, text, who=""):
        self.log.configure(state="normal")
        self.log.insert("end", time.strftime("%H:%M:%S  "), "t")
        if who:
            self.log.insert("end", who + "  ", "who")
        self.log.insert("end", text + "\n", tag)
        lines = int(self.log.index("end-1c").split(".")[0])
        if lines > 600:
            self.log.delete("1.0", f"{lines - 500}.0")
        self.log.configure(state="disabled")
        self.log.see("end")

    def _line(self, line):
        """Linia z wyjścia inżyniera -> stan albo komunikat."""
        line = line.strip()
        if not line:
            return
        if line == "@@END":
            self._feed("sys", "Inżynier zakończył pracę.")
            self.state = {}
            return
        if line.startswith("@@ "):
            try:
                self.state, self.state_t = json.loads(line[3:]), time.monotonic()
            except ValueError:
                pass
            return
        rules = (("[!!] ", "urgent", "INŻYNIER"), ("[INŻYNIER AI → Discord] ", "ai", "INŻYNIER AI · Discord"),
                 ("[INŻYNIER → Discord] ", "eng", "INŻYNIER · Discord"), ("[INŻYNIER → ściana boksów] ", "eng", "INŻYNIER · ściana"),
                 ("[INŻYNIER – wyciszony] ", "sys", "INŻYNIER (wyciszony)"), ("[INŻYNIER] ", "eng", "INŻYNIER"),
                 ("[TY] ", "me", "TY"), ("[wiadomość – inżynier wyciszony] ", "team", "ZESPÓŁ"),
                 ("[zespół] ", "team", "ZESPÓŁ"), ("[AI] ", "sys", "AI"), ("[inżynier] ", "sys", ""))
        for pre, tag, who in rules:
            if line.startswith(pre):
                self._feed(tag, line[len(pre):], who)
                return
        if line.startswith("Możesz też wpisać pytanie") or line.startswith("Do usłyszenia"):
            return
        if line.startswith("Traceback") or line.startswith("  File") or "Error" in line[:40]:
            self._feed("urgent", line)
            return
        self._feed("sys", line)

    def _pump(self):
        n = 0
        while n < 200:
            try:
                line = self.eng.lines.get_nowait()
            except queue.Empty:
                break
            self._line(line)
            n += 1
        self._refresh()
        self.root.after(150 if n else 400, self._pump)

    def _set_chip(self, k, color, text):
        dot, lbl = self.chips[k]
        dot.configure(fg=color)
        lbl.configure(text=text)

    def _refresh(self):
        run = self.eng.running
        self.run_btn.configure(text="■  Zatrzymaj" if run else "▶  Uruchom")
        self.demo_btn.configure(state="disabled" if run else "normal")
        st = self.state if run else {}
        fresh = run and st and time.monotonic() - self.state_t < 8
        self._set_chip("eng", OK if run else MUTED,
                       ("Inżynier: test bez gry" if self.eng.demo else "Inżynier działa") if run else "Inżynier wyłączony")
        if not run:
            self._set_chip("game", MUTED, "Gra")
        elif fresh:
            self._set_chip("game", OK, "Jedziesz" if st.get("driving") else "Gra: podgląd (jedzie zmiennik)")
        else:
            self._set_chip("game", WARN, "Czekam na LMU")
        if not run or not st:
            self._set_chip("team", MUTED, "Zespół")
            self._set_chip("ai", MUTED, "Serwer AI")
        else:
            if not st.get("hub"):
                self._set_chip("team", MUTED, "Bez zespołu")
            else:
                self._set_chip("team", OK if st.get("hub_ok") else BAD,
                               ("Zespół: " + str(st.get("who") or "")) if st.get("hub_ok") else "Zespół: brak połączenia")
            on = st.get("bot") or st.get("ai")
            self._set_chip("ai", OK if on else MUTED,
                           "Serwer AI" + (": Discord" if st.get("bot") else "") + (", AI" if st.get("ai") else "")
                           if on else "Serwer AI wyłączony")
        c = self.cards
        fmt_lap = lambda x: "—" if not x or x <= 0 else f"{int(x // 60)}:{x % 60:06.3f}".replace(".", ",")
        if not fresh:
            for v, n in c.values():
                v.configure(text="—", fg=TEXT)
                n.configure(text=" ")
            if st.get("session"):
                c["pos"][1].configure(text=str(st.get("track") or ""))
            return
        sess = {"race": "wyścig", "practice": "trening", "qualy": "kwalifikacje", "warmup": "rozgrzewka"}.get(
            st.get("session"), st.get("session") or "")
        c["pos"][0].configure(text=f"P{st['pos_class']} / {st.get('n_class', '?')}" if st.get("pos_class") else "—")
        c["pos"][1].configure(text=" · ".join(x for x in (st.get("cls"), sess, st.get("track")) if x))
        ld = st.get("laps_done")
        c["lap"][0].configure(text=str(ld + 1) if ld is not None else "—")
        c["lap"][1].configure(text=f"w stincie {st['stint_laps']}" if st.get("stint_laps") is not None else " ")
        ll = st.get("laps_left")
        if st.get("in_pits"):
            c["stop"][0].configure(text="w alei", fg=WARN)
        elif ll is None:
            c["stop"][0].configure(text="—", fg=TEXT)
        else:
            c["stop"][0].configure(text="w tym okr." if ll < 1 else f"za {int(ll)} okr.", fg=BAD if ll < 2 else TEXT)
        c["stop"][1].configure(text="na tyle starczy energii / paliwa" if ll is not None else " ")
        if st.get("ve_pct") is not None:
            c["fuel"][0].configure(text=f"{st['ve_pct']:.0f}%".replace(".", ","))
            c["fuel"][1].configure(text=(f"{st['ve_per_lap']:.1f}% na okrążenie".replace(".", ",")
                                         if st.get("ve_per_lap") else "energia wirtualna"))
        elif st.get("fuel_l") is not None:
            c["fuel"][0].configure(text=f"{st['fuel_l']:.1f} l".replace(".", ","))
            c["fuel"][1].configure(text=(f"{st['fuel_per_lap']:.2f} l na okrążenie".replace(".", ",")
                                         if st.get("fuel_per_lap") else "paliwo"))
        c["time"][0].configure(text=fmt_lap(st.get("last_lap")))
        c["time"][1].configure(text="średnia " + fmt_lap(st.get("avg_lap")) + " · najl. " + fmt_lap(st.get("best_lap")))
        tr = st.get("time_remaining")
        if tr is not None and tr > 0:
            h, m = int(tr // 3600), int(tr % 3600 // 60)
            c["remain"][0].configure(text=f"{h} h {m:02d} min" if h else f"{m} min {int(tr % 60):02d} s")
        else:
            c["remain"][0].configure(text="—")
        c["remain"][1].configure(text="FCY / neutralizacja" if st.get("phase") == "fcy" else
                                 ("inżynier wyciszony" if st.get("muted") else " "))

    # ----------------------------------------------------------------- aktualizacje
    def _update(self, manual=False, then=None):
        """Sprawdza aktualizację (w tle). Gdy jest – instaluje i uruchamia aplikację ponownie; inaczej then()."""
        import updater
        if manual:
            self.status.configure(text="Sprawdzam aktualizacje…")

        def run():
            info = updater.check(8 if manual else 4)
            self._ui(done, info)

        def done(info):
            if not info:
                if manual:
                    self.status.configure(text=f"Masz najnowszą wersję ({updater.local_version()}).")
                if then:
                    then()
                return
            if manual and not messagebox.askyesno(
                    "Pit Wall Crew", f"Dostępna wersja {info['version']}.\n\n{info.get('notes', '')}\n\n"
                    "Zaktualizować teraz? Inżynier uruchomi się ponownie."):
                return
            if self.eng.running:
                self.eng.stop()
            self.show("Inżynier")
            self._feed("sys", f"Nowa wersja {info['version']} – aktualizuję…")

            def inst():
                ok = False
                try:
                    ok = updater.apply(info, say=lambda m: self._ui(self._feed, "sys", m))
                except Exception as e:
                    self._ui(self._feed, "urgent", f"Aktualizacja nie powiodła się: {e}")
                self._ui(finish, ok)
            threading.Thread(target=inst, daemon=True).start()

        def finish(ok):
            if ok:
                self._feed("sys", "Uruchamiam aplikację ponownie…")
                args = [a for a in sys.argv[1:] if a != "--po-aktualizacji"] + ["--po-aktualizacji"]
                subprocess.Popen([sys.executable, os.path.abspath(__file__)] + args, cwd=ROOT)
                self.root.after(300, self.root.destroy)
            elif then:
                then()
        threading.Thread(target=run, daemon=True).start()

    def _close(self):
        if self.eng.running:
            if not messagebox.askyesno("Pit Wall Crew", "Zamknąć aplikację? Inżynier przestanie działać."):
                return
            self.eng.stop(4)
        self.root.destroy()

    # ----------------------------------------------------------------- pomocnicze
    def _tab(self, nb, title, sub=""):
        """Strona w pasku bocznym (dawna zakładka)."""
        f = ttk.Frame(self.body, padding=(2, 8, 2, 2))
        f.columnconfigure(1, weight=1)
        self.pages[title] = (f, sub)
        item = tk.Frame(self.nav_box, bg=SIDE, cursor="hand2")
        item.pack(fill="x", padx=10, pady=1)
        mark = tk.Frame(item, bg=SIDE, width=3, height=18)
        mark.pack(side="left", padx=(0, 10))
        lbl = tk.Label(item, text=title, bg=SIDE, fg=MUTED, font=(FONT, 11), anchor="w", pady=8)
        lbl.pack(side="left", fill="x", expand=True)
        self.nav[title] = (item, mark, lbl)
        for w in (item, lbl, mark):
            w.bind("<Button-1>", lambda e, t=title: self.show(t))
            w.bind("<Enter>", lambda e, t=title: self._hover(t, True))
            w.bind("<Leave>", lambda e, t=title: self._hover(t, False))
        return f

    def _hover(self, title, on):
        item, mark, lbl = self.nav[title]
        bg = "#24262a" if (on or title == self.page) else SIDE
        for w in (item, lbl):
            w.configure(bg=bg)

    def show(self, title):
        for t, (f, _) in self.pages.items():
            f.pack_forget()
        f, sub = self.pages[title]
        f.pack(fill="both", expand=True)
        self.page = title
        self.title_lbl.configure(text=title)
        self.sub_lbl.configure(text=sub)
        for t, (item, mark, lbl) in self.nav.items():
            on = t == title
            for w in (item, lbl):
                w.configure(bg="#24262a" if on else SIDE)
            lbl.configure(fg=TEXT if on else MUTED, font=(FONT, 11, "bold" if on else "normal"))
            mark.configure(bg=ACCENT if on else SIDE)
        for bt in getattr(self, "save_btns", []):
            if title in ("Inżynier", "Komendy", "Co potrafi", "Instrukcja"):
                bt.pack_forget()
            elif not bt.winfo_ismapped():
                bt.pack(side="right", padx=(8, 0))
        if title == "Inżynier":
            self.status.configure(text="")

    def _doc_page(self, title, sub, blocks):
        """Strona tylko do czytania (komendy, opis, instrukcja): przewijany tekst z nagłówkami."""
        if not getattr(self, "_help_sep", False):
            self._help_sep = True
            tk.Label(self.nav_box, text="POMOC", bg=SIDE, fg="#6c6f75", font=(FONT, 8, "bold"), anchor="w").pack(
                fill="x", padx=26, pady=(16, 2))
        f = self._tab(None, title, sub)
        f.configure(padding=(0, 4, 0, 0))
        box = tk.Frame(f, bg=CARD, highlightthickness=1, highlightbackground=LINE)
        box.pack(fill="both", expand=True)
        txt = tk.Text(box, bg=CARD, fg=TEXT, relief="flat", bd=0, wrap="word", font=(FONT, 10), padx=18, pady=12,
                      cursor="arrow", spacing1=2, spacing3=2)
        sb = ttk.Scrollbar(box, orient="vertical", command=txt.yview)
        txt.configure(yscrollcommand=sb.set)
        sb.pack(side="right", fill="y")
        txt.pack(side="left", fill="both", expand=True)
        txt.tag_configure("h", font=(FONT, 12, "bold"), foreground=TEXT, spacing1=14, spacing3=4)
        txt.tag_configure("li", lmargin1=6, lmargin2=22)
        txt.tag_configure("cmd", foreground=INFO)
        txt.tag_configure("dim", foreground=MUTED)
        for i, (head, paras) in enumerate(blocks):
            txt.insert("end", head + "\n", "h")
            for para in paras:
                if para.startswith("• ") and " — " in para:
                    cmd, what = para[2:].split(" — ", 1)
                    txt.insert("end", "•  ", "li")
                    txt.insert("end", cmd, ("li", "cmd"))
                    txt.insert("end", "  " + what + "\n", ("li", "dim"))
                elif para.startswith("• "):
                    txt.insert("end", "•  " + para[2:] + "\n", "li")
                else:
                    txt.insert("end", para + "\n")
        txt.configure(state="disabled")
        txt.bind("<MouseWheel>", lambda e: txt.yview_scroll(int(-e.delta / 120), "units"))
        return f

    def _section(self, parent, r, title):
        tk.Label(parent, text=title.upper(), bg=BG, fg=MUTED, font=(FONT, 8, "bold"), anchor="w").grid(
            row=r, column=0, columnspan=2, sticky="w", pady=(14 if r else 0, 4))
        return r + 1

    def _check(self, parent, r, text, var, hint=""):
        ttk.Checkbutton(parent, text=text, variable=var).grid(row=r, column=0, columnspan=2, sticky="w", pady=(2, 0))
        if hint:
            tk.Label(parent, text=hint, bg=BG, fg=MUTED, font=(FONT, 9), anchor="w").grid(
                row=r + 1, column=0, columnspan=2, sticky="w", padx=(30, 0), pady=(0, 2))
            return r + 2
        return r + 1

    def _slider(self, parent, var, lo, hi, fmt):
        fr = ttk.Frame(parent)
        val = ttk.Label(fr, text=fmt(var.get()), width=6)
        sc = ttk.Scale(fr, from_=lo, to=hi, variable=var, length=280,
                       command=lambda v: val.configure(text=fmt(v)))
        sc.pack(side="left")
        val.pack(side="left", padx=(10, 0))
        return fr

    def _row(self, parent, r, label, widget):
        lbl = ttk.Label(parent, text=label)
        lbl.grid(row=r, column=0, sticky="w", padx=(0, 10), pady=3)
        widget.grid(row=r, column=1, sticky="w", pady=3)
        return [lbl, widget]

    def _mode_changed(self):
        st = "disabled" if self.mode.get() == "solo" else "normal"
        for w in self.team_widgets:
            try:
                w.configure(state=st)
            except tk.TclError:
                pass

    def _ui(self, fn, *a):
        self.root.after(0, lambda: fn(*a))

    # ----------------------------------------------------------------- zespół
    def _client(self):
        from team.firebase import FbClient, load_config
        if not load_config():
            raise RuntimeError("brak pliku firebase_config.json w folderze programu")
        return FbClient(self.code.get().strip().lower(), self.pw.get())

    def _test_team(self):
        if not self.code.get().strip() or not self.pw.get():
            self.team_status.configure(text="Wpisz kod i hasło zespołu (dostaniesz je od kolegów) albo utwórz nowy zespół.")
            return
        self.team_status.configure(text="Łączę…")

        def run():
            try:
                from team.fbbackend import FbBackend
                out = FbBackend(self._client()).call({"op": "view"})
            except Exception as e:
                self._ui(self.team_status.configure, {"text": f"Nie mogę się połączyć: {str(e)[:90]}"})
                return
            names = list(dict.fromkeys((out.get("kierowcy") or []) + ([self.name.get()] if self.name.get() else [])))
            self._ui(self.name_cb.configure, {"values": names})
            team = out.get("team") or self.code.get().strip()
            hint = "Wybierz swoje imię." if names else "Dodajcie kierowców na ścianie boksów (zakładka Zespół) albo wpisz imię."
            self._ui(self.team_status.configure, {"text": f"Połączono z zespołem „{team}”. {hint}"})
        threading.Thread(target=run, daemon=True).start()

    def _new_team(self):
        from tkinter import simpledialog
        name = simpledialog.askstring("Nowy zespół", "Nazwa zespołu (np. Ferrari 296 #51):", parent=self.root)
        if name is None:
            return
        pw = simpledialog.askstring("Nowy zespół", "Hasło zespołu (min. 6 znaków).\nPodasz je kolegom prywatnie:",
                                    parent=self.root, show="•")
        if not pw:
            return
        if len(pw) < 6:
            messagebox.showerror("Pit Wall Crew", "Hasło musi mieć co najmniej 6 znaków.")
            return
        self.team_status.configure(text="Tworzę zespół…")

        def run():
            try:
                from team.firebase import FbClient
                c = FbClient.create_team(pw, name.strip())
            except Exception as e:
                self._ui(self.team_status.configure, {"text": f"Nie utworzono zespołu: {str(e)[:90]}"})
                return
            self._ui(self.code.set, c.code)
            self._ui(self.pw.set, pw)
            self._ui(self.team_status.configure,
                     {"text": f"Utworzono zespół. Kod: {c.code} – zapisz ustawienia i podaj kolegom kod oraz hasło."})
        threading.Thread(target=run, daemon=True).start()

    def _open_wall(self):
        import webbrowser
        from team.firebase import load_config
        url = (load_config() or {}).get("wallUrl") or ""
        if not url:
            messagebox.showinfo("Pit Wall Crew", "Brak adresu ściany boksów w firebase_config.json.")
            return
        code = self.code.get().strip().lower()
        webbrowser.open(url + ("?team=" + code if code else ""))

    # ----------------------------------------------------------------- mikrofon
    def _load_mics(self):
        try:
            from engineer.listen import list_mics
            names = [m["name"] for m in list_mics()]
            self.mic_cb.configure(values=names)
            if not names:
                self.mic_status.configure(text="Nie widzę mikrofonu (Windows: Ustawienia → Prywatność → Mikrofon).")
        except Exception as e:
            self.mic_status.configure(text=f"Brak dostępu do mikrofonów: {str(e)[:80]}")

    def _test_mic(self):
        self.mic_status.configure(text="Mów przez 3 sekundy…")

        def run():
            try:
                import numpy as np
                from engineer.listen import Microphone
                mic = Microphone(self.mic.get() or None, quiet=True)
                mic.start()
                peak, t0 = 0, time.monotonic()
                while time.monotonic() - t0 < 3:
                    time.sleep(0.1)
                    fr = list(getattr(mic, "_frames", []))[-3:]
                    if fr:
                        cur = int(np.abs(np.concatenate(fr).astype(np.int32)).max())
                        self._ui(self.level.configure, {"value": cur})
                audio = mic.stop()
                mic.close()
                peak = int(np.abs(audio.astype(np.int32)).max()) if len(audio) else 0
                self._ui(self.level.configure, {"value": peak})
                if peak > 1500:
                    msg = f"Mikrofon działa ({mic.name}). Zapisz, żeby go zachować."
                    self._ui(self.mic.set, mic.name)
                elif peak == 0:
                    msg = "Zupełna cisza: Windows blokuje mikrofon albo jest wyciszony."
                else:
                    msg = "Bardzo cicho – sprawdź wyciszenie na słuchawkach albo wybierz inny mikrofon."
                self._ui(self.mic_status.configure, {"text": msg})
            except Exception as e:
                self._ui(self.mic_status.configure, {"text": f"Błąd mikrofonu: {str(e)[:90]}"})
        threading.Thread(target=run, daemon=True).start()

    def _joy_text(self):
        if self.joy_button < 0:
            return "brak (tylko klawisz)"
        return f"{self.joy_name or 'kontroler'}, przycisk {self.joy_button}"

    def _no_button(self):
        self.joy_button, self.joy_name = -1, ""
        self.joy_lbl.configure(text=self._joy_text())

    def _find_button(self):
        self.joy_lbl.configure(text="Naciśnij przycisk na kierownicy (15 s)…")

        def done(name, b):
            if b is None:
                self.joy_lbl.configure(text="Nie wykryłem przycisku. " + self._joy_text())
                return
            self.joy_name, self.joy_button = name, b
            self.joy_lbl.configure(text=self._joy_text() + "  ✓ (Zapisz)")

        def run():
            try:
                from engineer import winjoy
                if winjoy.available():
                    devs = winjoy.devices()
                    start = {d[0]: winjoy.buttons(d[0]) or 0 for d in devs}
                    end = time.monotonic() + 15
                    while time.monotonic() < end:
                        for dev, name, _ in devs:
                            now = winjoy.buttons(dev) or 0
                            new = now & ~start[dev]
                            if new:
                                b = (new & -new).bit_length() - 1
                                self._ui(done, name, b)
                                return
                            start[dev] = now
                        time.sleep(0.01)
                    self._ui(done, "", None)
                    return
            except Exception:
                pass
            self._ui(done, "", None)
        threading.Thread(target=run, daemon=True).start()

    # ----------------------------------------------------------------- głos
    def _voice(self):
        lab = self.voice.get()
        return next((v for v in VOICES if v[2] == lab), VOICES[0])

    def _play(self):
        self.voice_status.configure(text="Syntezuję próbkę…")

        def run():
            try:
                from engineer.style import Style
                from engineer.voice import Speaker
                v = self._voice()
                rs = next(r[0] for r in RADIO if r[1] == self.radio.get())
                sp = Speaker(engines=["edge", "sapi", "print"], edge_voice=v[0], pitch=v[1],
                             rate=f"{self.rate.get():+d}%", volume=float(self.volume.get()),
                             radio=rs > 0, radio_strength=rs or 1.0)
                from engineer.style import Style
                nm = self.eng_name.get().strip()
                st = Style(fillers=True, rate=1.0, persona=self._personas.get(self.persona.get(), "pro"))
                sp.say((f"Tu {nm}. " if nm else "") + st.apply(SAMPLE.replace("Słuchaj, ", ""), "inżynier"))
                self._ui(self.voice_status.configure, {"text": f"Głos: {sp.engine}"})
            except Exception as e:
                self._ui(self.voice_status.configure, {"text": f"Błąd odtwarzania: {str(e)[:90]}"})
        threading.Thread(target=run, daemon=True).start()

    # ----------------------------------------------------------------- zapis
    def _save(self):
        try:
            v = self._voice()
            rs = next(r[0] for r in RADIO if r[1] == self.radio.get())
            vals = [
                ("team", "mode", self.mode.get()), ("team", "code", self.code.get().strip().lower()),
                ("team", "password", self.pw.get()), ("team", "name", self.name.get().strip()),
                ("team", "discord", self.discord.get()),
                ("listen", "enabled", self.mic_enabled.get()), ("listen", "mic_device", self.mic.get().strip()),
                ("listen", "ptt_key", self.ptt_key.get().strip().lower()),
                ("listen", "joystick_name", self.joy_name), ("listen", "joystick_button", int(self.joy_button)),
                ("voice", "edge_voice", v[0]), ("voice", "pitch", v[1]), ("voice", "rate", f"{self.rate.get():+d}%"),
                ("voice", "volume", round(float(self.volume.get()), 2)), ("voice", "radio", rs > 0),
                ("voice", "radio_strength", rs or 1.0), ("voice", "fillers", self.fillers.get()),
                ("voice", "name", self.eng_name.get().strip()),
                ("voice", "persona", self._personas.get(self.persona.get(), "pro")),
                ("alerts", "coach", self.coach_on.get()), ("alerts", "compare_best", self.cmp_best.get()),
                ("alerts", "overtakes", self.overtakes.get()),
                ("alerts", "lapping", self.lapping.get()), ("alerts", "lapping_warn_s", float(self.warn_s.get())),
                ("alerts", "lapping_chain_s", float(self.chain_s.get())), ("alerts", "hazards", self.hazards.get()),
                ("alerts", "flags", self.flags.get()), ("alerts", "suggestions", self.sugg.get()),
                ("alerts", "suggest_gap_min", int(self.sugg_gap.get())),
                ("strategy", "tyre_set_s", float(self.tyre_set.get())),
                ("rest", "enabled", self.rest.get()), ("diag", "enabled", self.diag.get()),
                ("diag", "mark_key", self.mark.get().strip().lower()),
                ("ui", "autostart", self.autostart.get()), ("ui", "auto_update", self.auto_update.get()),
            ]
            for s, k, val in vals:
                CFG.set(s, k, val)
            self.status.configure(text="Zapisane. Zmiany zadziałają po ponownym uruchomieniu inżyniera.")
            return True
        except Exception as e:
            messagebox.showerror("Pit Wall Crew", f"Nie udało się zapisać: {e}")
            return False

    def _save_restart(self):
        """Zapisz i uruchom inżyniera od nowa z nowymi ustawieniami."""
        if not self._save():
            return
        demo = self.eng.demo
        self.eng.stop()
        self.eng.start(demo=demo)
        self._feed("sys", "Ustawienia zapisane, inżynier uruchomiony ponownie.")
        self.status.configure(text="Zapisane, inżynier uruchomiony ponownie.")

    def _shortcuts(self):
        try:
            import subprocess
            ps = os.path.join(ROOT, "tools", "skroty.ps1")
            subprocess.run(["powershell", "-NoProfile", "-ExecutionPolicy", "Bypass", "-File", ps], check=False,
                           creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
            self.status.configure(text="Skróty z ikoną są na pulpicie.")
        except Exception as e:
            messagebox.showerror("Pit Wall Crew", f"Nie udało się utworzyć skrótów: {e}")


def _dark_titlebar(root) -> None:
    """Ciemny pasek tytułu okna (Windows 10 20H1+ / 11)."""
    if sys.platform != "win32":
        return
    try:
        import ctypes
        root.update_idletasks()
        hwnd = ctypes.windll.user32.GetParent(root.winfo_id())
        val = ctypes.c_int(1)
        for attr in (20, 19):
            if ctypes.windll.dwmapi.DwmSetWindowAttribute(hwnd, attr, ctypes.byref(val), ctypes.sizeof(val)) == 0:
                break
    except Exception:
        pass


def main() -> None:
    global FONT, MONO
    if sys.platform == "win32":
        try:   # ostre okno na ekranach z powiększeniem i własna ikona na pasku zadań
            import ctypes
            ctypes.windll.shcore.SetProcessDpiAwareness(1)
            ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID("PitWallCrew.App")
        except Exception:
            pass
    try:
        from engineer.winaudio import set_mixer_name
        set_mixer_name()        # „Odsłuchaj” w mikserze jako Pit Wall Crew
    except Exception:
        pass
    root = tk.Tk()
    root.withdraw()
    from tkinter import font as tkfont
    fams = set(tkfont.families())
    FONT = next((f for f in ("Segoe UI Variable Text", "Segoe UI", "Inter", "DejaVu Sans") if f in fams), "TkDefaultFont")
    MONO = next((f for f in ("Cascadia Mono", "Consolas", "DejaVu Sans Mono") if f in fams), "TkFixedFont")
    try:
        import sv_ttk
        sv_ttk.set_theme("dark")
    except Exception:
        try:
            ttk.Style().theme_use("clam")
        except tk.TclError:
            pass
    for name in ("TkDefaultFont", "TkTextFont", "TkMenuFont"):
        try:
            tkfont.nametofont(name).configure(family=FONT, size=10)
        except tk.TclError:
            pass
    st = ttk.Style()
    st.configure("TFrame", background=BG)
    app = App(root)
    _dark_titlebar(root)
    try:   # nowa wersja: odśwież skróty na pulpicie (nazwa i ikona Pit Wall Crew) – raz, w tle
        from engineer.version import version
        if sys.platform == "win32" and CFG.get("ui", "shortcuts", "") != version():
            CFG.set("ui", "shortcuts", version())
            ps = os.path.join(ROOT, "tools", "skroty.ps1")
            subprocess.Popen(["powershell", "-NoProfile", "-ExecutionPolicy", "Bypass", "-File", ps],
                             creationflags=NO_WINDOW)
    except Exception:
        pass
    root.deiconify()
    def start():
        if "--demo" in sys.argv:
            app._toggle(demo=True)
        elif "--ustawienia" not in sys.argv and CFG.get("ui", "autostart", True):
            app._toggle()
    if "--po-aktualizacji" in sys.argv:
        from engineer.version import version as _v
        app._feed("sys", f"Zaktualizowano do wersji {_v()}. Zmiany: plik ZMIANY.md.")
        start()
    elif CFG.get("ui", "auto_update", True):
        app._feed("sys", "Sprawdzam aktualizacje…")
        app._update(then=start)        # najpierw aktualizacja, potem inżynier (nigdy w trakcie jazdy)
    else:
        start()
    if "--ustawienia" in sys.argv:
        app.show("Zespół")
    root.mainloop()
    app.eng.stop(3)


if __name__ == "__main__":
    main()
