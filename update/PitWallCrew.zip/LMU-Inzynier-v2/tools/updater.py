"""Automatyczne aktualizacje Pit Wall Crew.

Najnowsza paczka leży na stronie pit walla (GitHub Pages): update/latest.json + update/PitWallCrew.zip.
Aplikacja sprawdza ją przy starcie (zanim uruchomi inżyniera – nigdy w trakcie jazdy), pobiera, sprawdza
sumę kontrolną SHA-256 i podmienia pliki programu. Nie rusza:
- ustawień (config.toml, serwer.toml), danych (data/, recordings/, cache/), środowiska Pythona (.venv),
- pełnego dziennika diagnostycznego (engineer/debuglog.py), jeśli na tym komputerze jest pełna wersja.
Gdy zmienią się biblioteki (requirements*.txt) – doinstalowuje je. Poprzednie pliki trafiają do backup/.

  python tools/updater.py            sprawdź i zaktualizuj (konsola)
  python tools/updater.py --check    tylko sprawdź
"""

from __future__ import annotations

import hashlib
import io
import json
import os
import shutil
import subprocess
import sys
import urllib.request
import zipfile
from typing import Callable, Optional

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
PREFIX = "LMU-Inzynier-v2/"
KEEP = ("config.toml", "serwer.toml", "inzynier.pid")
KEEP_DIRS = ("data/", "recordings/", "cache/", ".venv/", "backup/", "lmu_api/")
DEBUGLOG = "engineer/debuglog.py"
NO_WINDOW = getattr(subprocess, "CREATE_NO_WINDOW", 0)


def _vt(v: str) -> tuple:
    """Klucz porównania wersji. Od 0.4.0.0 nowa numeracja (4 liczby, zaczyna się od 0): zawsze nowsza niż
    stare 3.x.y – liczona jak 10.0.4.0.0. W latest.json wersja z przedrostkiem „10.” (stare programy
    porównują liczby i inaczej nie zobaczyłyby nowszej wersji)."""
    try:
        t = tuple(int(x) for x in str(v).strip().split("."))
    except ValueError:
        return (0,)
    return (10,) + t if len(t) == 4 and t[0] == 0 else t


def local_version() -> str:
    try:
        with open(os.path.join(ROOT, "VERSION"), encoding="utf-8") as f:
            return f.read().strip()
    except OSError:
        return "0"


def base_url() -> str:
    try:
        with open(os.path.join(ROOT, "firebase_config.json"), encoding="utf-8") as f:
            url = json.load(f).get("wallUrl") or ""
    except (OSError, ValueError):
        url = ""
    return (url.rstrip("/") + "/update/") if url else ""


def server_url() -> str:
    """Prywatny serwer aktualizacji (paczki tylko dla testerów i aktywnych patronów); pusty = stary sposób (strona)."""
    try:
        with open(os.path.join(ROOT, "firebase_config.json"), encoding="utf-8") as f:
            return (json.load(f).get("updateUrl") or "").rstrip("/")
    except (OSError, ValueError):
        return ""


LAST_DENIED = {"reason": ""}       # „patron” – serwer odmówił (brak aktywnego wsparcia na Patreonie)


def _cfg_update() -> dict:
    try:
        sys.path.insert(0, ROOT)
        from engineer.tomlfix import loads_fixing
        with open(os.path.join(ROOT, "config.toml"), encoding="utf-8") as f:
            return loads_fixing(f.read()).get("update", {}) or {}
    except Exception:
        return {}


def patron_token() -> str:
    return str(_cfg_update().get("patron_token", "")).strip()


def save_patron_token(tok: str) -> None:
    try:
        sys.path.insert(0, os.path.join(ROOT, "tools"))
        from cfgfile import CfgFile
        CfgFile(os.path.join(ROOT, "config.toml")).set("update", "patron_token", tok)
    except Exception:
        pass


def _auth_headers() -> dict:
    h = {}
    if tester_code():
        h["X-PWC-Tester"] = tester_code()
    if patron_token():
        h["X-PWC-Token"] = patron_token()
    return h


def _get(url: str, timeout: float, auth: bool = False) -> bytes:
    hd = {"Cache-Control": "no-cache", "User-Agent": "PitWallCrew-updater"}
    if auth:
        hd.update(_auth_headers())
    req = urllib.request.Request(url, headers=hd)
    with urllib.request.urlopen(req, timeout=timeout) as r:
        new = r.headers.get("X-PWC-Token") if auth else None
        data = r.read()
    if new:                           # serwer przedłużył dostęp patrona (sprawdził członkostwo na Patreonie)
        save_patron_token(new)
    return data


def tester_code() -> str:
    """Kod testera z config.toml ([update] tester_code) – testerzy dostają nowe wersje przed wszystkimi."""
    return str(_cfg_update().get("tester_code", "")).strip()


def code_hash(code: str) -> str:
    return hashlib.sha256(("pwc-tester:" + code.strip().upper().replace(" ", "").replace("-", "")).encode()).hexdigest()


def tester_ok(code: str, base: str, timeout: float = 5.0) -> Optional[bool]:
    """True = ważny kod testera, False = nieważny, None = nie udało się sprawdzić."""
    if not code:
        return False
    try:
        codes = json.loads(_get(base + "tester/codes.json?v=" + local_version(), timeout).decode("utf-8"))
    except Exception:
        return None
    return code_hash(code) in set(codes.get("hashes", []))


def _latest(base: str, timeout: float) -> Optional[dict]:
    try:
        info = json.loads(_get(base + "latest.json?v=" + local_version(), timeout).decode("utf-8"))
    except Exception:
        return None
    info["zip_url"] = base + (info.get("url") or "PitWallCrew.zip")
    return info


def _server_latest(srv: str, ch: str, timeout: float) -> Optional[dict]:
    import urllib.error
    try:
        info = json.loads(_get(f"{srv}/latest?ch={ch}&v={local_version()}", timeout, auth=True).decode("utf-8"))
    except urllib.error.HTTPError as e:
        if e.code == 403 and ch == "stable":
            LAST_DENIED["reason"] = "patron"
        return None
    except Exception:
        return None
    info["zip_url"] = srv + info.get("url", f"/download?ch={ch}")
    info["auth"] = True
    if ch == "tester":
        info["tester"] = True
        info["display"] = (info.get("display") or info.get("version", "?")) + " (testowa)"
    return info


def check(timeout: float = 5.0) -> Optional[dict]:
    """Zwraca opis nowszej wersji ({version, sha256, url, notes}) albo None.
    Tester (ważny kod): nowsza z wersji testowej i zwykłej."""
    LAST_DENIED["reason"] = ""
    srv = server_url()
    if srv:      # prywatny serwer: testerzy i aktywni patroni
        found = [i for i in (_server_latest(srv, "stable", timeout),
                             _server_latest(srv, "tester", timeout) if tester_code() else None) if i]
        found = [i for i in found if _vt(i.get("version", "0")) > _vt(local_version())]
        return max(found, key=lambda i: _vt(i.get("version", "0"))) if found else None
    base = base_url()
    if not base:
        return None
    found = [i for i in [_latest(base, timeout)] if i]
    if tester_ok(tester_code(), base, timeout):
        t = _latest(base + "tester/", timeout)
        if t:
            t["tester"] = True
            t["display"] = (t.get("display") or t.get("version", "?")) + " (testowa)"
            found.append(t)
    found = [i for i in found if _vt(i.get("version", "0")) > _vt(local_version())]
    if not found:
        return None
    return max(found, key=lambda i: _vt(i.get("version", "0")))


def _full_debuglog() -> bool:
    try:
        with open(os.path.join(ROOT, DEBUGLOG), encoding="utf-8") as f:
            return f.read(40).startswith('"""Pełny dziennik')
    except OSError:
        return False


def _req_text() -> str:
    out = []
    for n in ("requirements.txt",):
        try:
            with open(os.path.join(ROOT, n), encoding="utf-8") as f:
                out.append(f.read())
        except OSError:
            out.append("")
    return "\n---\n".join(out)


def apply(info: dict, say: Callable[[str], None] = print, timeout: float = 60.0) -> bool:
    """Pobiera i instaluje aktualizację. True = gotowe (trzeba uruchomić program ponownie)."""
    say(f"Pobieram wersję {info['version']}…")
    if info.get("auth"):
        data = _get(info["zip_url"], timeout, auth=True)
    else:
        data = _get(info["zip_url"] + "?v=" + info["version"], timeout)
    if info.get("sha256") and hashlib.sha256(data).hexdigest() != info["sha256"]:
        say("Aktualizacja przerwana: plik jest uszkodzony (zła suma kontrolna).")
        return False
    z = zipfile.ZipFile(io.BytesIO(data))
    names = [n for n in z.namelist() if n.startswith(PREFIX) and not n.endswith("/")]
    if not names or PREFIX + "VERSION" not in names:
        say("Aktualizacja przerwana: nieprawidłowa paczka.")
        return False
    keep_log = _full_debuglog()
    req_before = _req_text()
    backup = os.path.join(ROOT, "backup", local_version())
    shutil.rmtree(os.path.join(ROOT, "backup"), ignore_errors=True)       # tylko jedna, ostatnia kopia
    n_files = 0
    for n in names:
        rel = n[len(PREFIX):]
        if rel in KEEP or rel.startswith(KEEP_DIRS) or (keep_log and rel == DEBUGLOG):
            continue
        dst = os.path.join(ROOT, *rel.split("/"))
        new = z.read(n)
        try:
            with open(dst, "rb") as f:
                if f.read() == new:
                    continue
            b = os.path.join(backup, *rel.split("/"))
            os.makedirs(os.path.dirname(b), exist_ok=True)
            shutil.copy2(dst, b)
        except OSError:
            pass
        os.makedirs(os.path.dirname(dst), exist_ok=True)
        with open(dst + ".new", "wb") as f:
            f.write(new)
        os.replace(dst + ".new", dst)
        n_files += 1
    say(f"Zaktualizowano {n_files} plików do wersji {info.get('display') or info['version']}.")
    if _req_text() != req_before:
        say("Doinstalowuję biblioteki (może potrwać kilka minut)…")
        py = os.path.join(ROOT, ".venv", "Scripts", "python.exe")
        py = py if os.path.exists(py) else sys.executable.replace("pythonw.exe", "python.exe")
        req = "requirements.txt"
        try:
            subprocess.run([py, "-m", "pip", "install", "-q", "-r", req], cwd=ROOT, creationflags=NO_WINDOW,
                           timeout=900, check=False)
        except Exception as e:
            say(f"Nie udało się doinstalować bibliotek: {e}")
    return True


def main() -> None:
    print(f"Pit Wall Crew {local_version()} – sprawdzam aktualizacje…")
    info = check(10)
    if not info:
        print("Masz najnowszą wersję.")
        return
    print(f"Dostępna wersja {info['version']}.")
    if info.get("notes"):
        print(info["notes"])
    if "--check" in sys.argv:
        return
    apply(info)


if __name__ == "__main__":
    main()


def patreon_login(open_browser: Callable[[str], None], wait_s: float = 300.0, say: Callable[[str], None] = print) -> bool:
    """Logowanie przez Patreon: przeglądarka -> Patreon -> serwer sprawdza wsparcie -> token zapisany w config.toml."""
    import secrets
    import time
    srv = server_url()
    if not srv:
        say("Serwer aktualizacji nie jest jeszcze ustawiony.")
        return False
    n = secrets.token_hex(16)
    open_browser(f"{srv}/patreon/login?n={n}")
    end = time.monotonic() + wait_s
    while time.monotonic() < end:
        time.sleep(3)
        try:
            d = json.loads(_get(f"{srv}/patreon/poll?n={n}", 10).decode("utf-8"))
        except Exception:
            continue
        if d.get("wait"):
            continue
        if d.get("token"):
            save_patron_token(d["token"])
            say("Patreon połączony – aktualizacje włączone.")
            return True
        say("Na tym koncie Patreon nie ma aktywnego wsparcia – program działa dalej, bez aktualizacji.")
        return False
    say("Logowanie przez Patreon nie zostało dokończone.")
    return False
