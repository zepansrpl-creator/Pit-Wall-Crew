﻿# Instalator serwera zespołu – laptop (rozpoznawanie mowy, AI, bot Discord). Działa przez cały wyścig.
$ErrorActionPreference = "Continue"
$Here = Split-Path -Parent (Split-Path -Parent $MyInvocation.MyCommand.Path)
Set-Location $Here
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
. (Join-Path $Here "tools\common.ps1")

Step 1 7 "Python"
$python = Ensure-Python
Write-Host "Python: $python"

Step 2 7 "Środowisko programu"
$vpy = Ensure-Venv $python

Step 3 7 "Biblioteki (ok. 2-3 GB z bibliotekami karty graficznej, kilka minut)"
& $vpy -m pip install -r requirements-serwer.txt
if ($LASTEXITCODE -ne 0) { throw "Instalacja bibliotek nie powiodła się." }

Step 4 7 "Model rozpoznawania mowy Whisper large-v3-turbo (ok. 1,6 GB, tylko raz)"
& $vpy -c "import sys; sys.path.insert(0, '.'); from laptop.stt import WhisperSTT; s = WhisperSTT(); print('Gotowe:', s.name)"
if ($LASTEXITCODE -ne 0) { Write-Host "Model nie załadował się – serwer spróbuje ponownie przy starcie." -ForegroundColor Yellow }

Step 5 7 "Model AI Bielik w Ollamie (ok. 5 GB)"
$model = "SpeakLeash/bielik-4.5b-v3.0-instruct:Q8_0"
$ollama = (Get-Command ollama -ErrorAction SilentlyContinue).Source
$local = Join-Path $env:LOCALAPPDATA "Programs\Ollama\ollama.exe"
if (-not $ollama -and (Test-Path $local)) { $ollama = $local }
if (-not $ollama) {
    Write-Host "Instaluję Ollamę..."
    winget install -e --id Ollama.Ollama --accept-package-agreements --accept-source-agreements
    if (Test-Path $local) { $ollama = $local } else { $ollama = (Get-Command ollama -ErrorAction SilentlyContinue).Source }
}
if ($ollama) {
    $running = $false
    try { Invoke-WebRequest -Uri "http://localhost:11434/api/tags" -UseBasicParsing -TimeoutSec 3 | Out-Null; $running = $true } catch {}
    if (-not $running) { Start-Process -FilePath $ollama -ArgumentList "serve" -WindowStyle Hidden; Start-Sleep -Seconds 5 }
    & $ollama pull $model
    if ($LASTEXITCODE -ne 0) { Write-Host "Model nie pobrał się. Serwer będzie działał bez AI (reguły, mowa i Discord działają)." -ForegroundColor Yellow }
} else {
    Write-Host "Nie udało się zainstalować Ollamy. Serwer będzie działał bez AI." -ForegroundColor Yellow
}

Step 6 7 "Ściana boksów i bot Discord"
& $vpy tools\configure.py --server

Step 7 7 "Skrót na pulpicie"
New-Shortcut "Pit Wall Crew - serwer AI" "serwer.bat"
Write-Host ""
Write-Host "GOTOWE." -ForegroundColor Green
Write-Host "W dniu wyścigu uruchom 'Pit Wall Crew - serwer AI' (komputer podłączony do ładowarki) i zostaw włączony."
