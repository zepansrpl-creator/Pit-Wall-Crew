"""Wybór głosu inżyniera: odtwarza próbki, pyta o numer i zapisuje wybór w config.toml."""

from __future__ import annotations

import os
import re
import shutil
import sys
import tempfile

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)

from engineer.voice import Speaker  # noqa: E402

CFG = os.path.join(ROOT, "config.toml")
TEXT = "Radio sprawdzone. Hypercar za Tobą, 4 sekundy. Zjazd za 2 okrążenia, zmień przednie opony."

VOICES = [
    ("pl-PL-MarekNeural", "+0Hz", "Marek (polski, domyślny)"),
    ("pl-PL-MarekNeural", "-8Hz", "Marek, niższy głos"),
    ("pl-PL-ZofiaNeural", "+0Hz", "Zofia (polski)"),
    ("en-US-AndrewMultilingualNeural", "+0Hz", "Andrew (wielojęzyczny, lekki akcent)"),
    ("en-US-BrianMultilingualNeural", "+0Hz", "Brian (wielojęzyczny, lekki akcent)"),
    ("de-DE-FlorianMultilingualNeural", "+0Hz", "Florian (wielojęzyczny, niemiecki akcent)"),
    ("en-US-AvaMultilingualNeural", "+0Hz", "Ava (wielojęzyczny, kobiecy)"),
    ("en-US-EmmaMultilingualNeural", "+0Hz", "Emma (wielojęzyczny, kobiecy)"),
    ("en-IN-PrabhatNeural", "+0Hz", "Prabhat (hinduski, męski; nie zna polskiego, mocny akcent)"),
    ("hi-IN-MadhurNeural", "+0Hz", "Madhur (hinduski, męski; nie zna polskiego, mocny akcent)"),
    ("en-IN-NeerjaNeural", "+0Hz", "Neerja (hinduska, kobiecy; nie zna polskiego, mocny akcent)"),
]
STRENGTHS = [(0.0, "bez efektu radia"), (0.5, "delikatne radio"), (1.0, "radio jak w transmisji"), (1.5, "mocno trzeszczy")]


def set_voice(key: str, value: str) -> None:
    """Ustawia wartość w sekcji [voice] (dopisuje brakującą linię w tej sekcji)."""
    if not os.path.exists(CFG):
        shutil.copy(os.path.join(ROOT, "config.example.toml"), CFG)
    with open(CFG, encoding="utf-8") as f:
        text = f.read()
    m = re.search(r"(?ms)^\[voice\]\s*$(.*?)(?=^\[|\Z)", text)
    if m is None:
        text += f"\n[voice]\n{key} = {value}\n"
    else:
        body = m.group(1)
        if re.search(rf"(?m)^{key}\s*=", body):
            body = re.sub(rf"(?m)^{key}\s*=.*$", f"{key} = {value}", body, count=1)
        else:
            body = body.rstrip("\n") + f"\n{key} = {value}\n\n"
        text = text[:m.start(1)] + body + text[m.end(1):]
    with open(CFG, "w", encoding="utf-8") as f:
        f.write(text)


MUSIC = [("", "bez muzyki"), ("indyjska", "muzyka indyjska (sitar, tabla, tanpura)")]
MUSIC_CACHE = os.path.join(ROOT, "cache", "voice")


def get_voice(key: str, default: str = "") -> str:
    try:
        with open(CFG, encoding="utf-8") as f:
            text = f.read()
    except OSError:
        return default
    m = re.search(r"(?ms)^\[voice\]\s*$(.*?)(?=^\[|\Z)", text)
    v = re.search(rf"(?m)^{key}\s*=\s*\"?([^\"#\n]*)\"?", m.group(1)) if m else None
    return v.group(1).strip() if v else default


def play(voice: str, pitch: str, strength: float, cache: str, music: str = "") -> bool:
    sp = Speaker(["edge"], edge_voice=voice, pitch=pitch, radio=strength > 0, radio_strength=strength or 1.0,
                 cache_dir=MUSIC_CACHE, music=music)
    if sp.engine != "edge":
        print("  Głosy Microsoft niedostępne (potrzebny internet i zainstalowane biblioteki).")
        return False
    try:
        sp._speak(TEXT, cache=False)
        return True
    except Exception as e:
        print(f"  Ten głos nie zadziałał: {e}")
        return False


def pick(title: str, items: list[str], listen, enter: str = "wyjście bez zmian") -> int | None:
    """Pokazuje listę; kierowca wpisuje numer, żeby posłuchać, a potem decyduje, czy to zapisać."""
    while True:
        print(f"\n{title}")
        for i, label in enumerate(items, start=1):
            print(f"  {i}. {label}")
        a = input(f"\nKtórą próbkę odsłuchać? (1-{len(items)}, Enter = {enter}): ").strip()
        if a == "":
            return None
        if not (a.isdigit() and 1 <= int(a) <= len(items)):
            print(f"  Wpisz numer od 1 do {len(items)}.")
            continue
        k = int(a)
        while True:
            print(f"\nOdtwarzam: {items[k - 1]}")
            if not listen(k - 1):
                break
            b = input("Zapisać? t = tak, p = posłuchaj jeszcze raz, Enter = wróć do listy: ").strip().lower()
            if b in ("t", "tak", "y"):
                return k - 1
            if b != "p":
                break


def main() -> None:
    cache = tempfile.mkdtemp()
    try:
        mus = get_voice("music")
        names = [name for _, _, name in VOICES]
        title = "GŁOSY INŻYNIERA (próbki z efektem radia" + (" i muzyką w tle):" if mus else "):")
        v = pick(title, names, lambda i: play(VOICES[i][0], VOICES[i][1], 1.0, cache, mus))
        if v is None:
            print("Bez zmian.")
            return
        voice, pitch, name = VOICES[v]
        labels = [label for _, label in STRENGTHS]
        j = pick(f"EFEKT RADIA dla głosu: {name}", labels,
                 lambda i: play(voice, pitch, STRENGTHS[i][0], cache, mus) or True, enter="radio jak w transmisji")
        st = STRENGTHS[2 if j is None else j][0]
        cur = next((label for key, label in MUSIC if key == mus), mus or "bez muzyki")
        k = pick("MUZYKA W TLE, gdy inżynier mówi:", [label for _, label in MUSIC],
                 lambda i: play(voice, pitch, st, cache, MUSIC[i][0]) or True, enter=f"zostaw: {cur}")
        if k is not None:
            mus = MUSIC[k][0]
        set_voice("edge_voice", f'"{voice}"')
        set_voice("pitch", f'"{pitch}"')
        set_voice("radio", "true" if st > 0 else "false")
        if st > 0:
            set_voice("radio_strength", f"{st:g}")
        set_voice("music", f'"{mus}"')
        mlabel = next((label for key, label in MUSIC if key == mus), mus or "bez muzyki")
        print(f"\nZapisane: {name}, {STRENGTHS[2 if j is None else j][1]}, {mlabel}. "
              "Zmiana działa od następnego uruchomienia inżyniera.")
    finally:
        shutil.rmtree(cache, ignore_errors=True)


if __name__ == "__main__":
    main()
