﻿# Wspólne funkcje instalatorów.
function Step($n, $all, $text) { Write-Host ""; Write-Host "[$n/$all] $text" -ForegroundColor Cyan }

function Find-Python {
    $candidates = @(
        "$env:LOCALAPPDATA\Programs\Python\Python312\python.exe",
        "$env:LOCALAPPDATA\Programs\Python\Python313\python.exe",
        "$env:LOCALAPPDATA\Programs\Python\Python311\python.exe",
        "C:\Program Files\Python312\python.exe",
        "C:\Program Files\Python313\python.exe",
        "C:\Program Files\Python311\python.exe"
    )
    foreach ($c in $candidates) { if (Test-Path $c) { return $c } }
    $py = Get-Command py -ErrorAction SilentlyContinue
    if ($py) {
        foreach ($v in @("3.12", "3.13", "3.11")) {
            $p = & py "-$v" -c "import sys; print(sys.executable)" 2>$null
            if ($LASTEXITCODE -eq 0 -and $p) { return $p.Trim() }
        }
    }
    return $null
}

function Ensure-Python {
    $python = Find-Python
    if (-not $python) {
        Write-Host "Nie znalazłem Pythona – instaluję Python 3.12..."
        $winget = Get-Command winget -ErrorAction SilentlyContinue
        if ($winget) {
            # wyjście winget na ekran, nie do wyniku funkcji (inaczej zamiast ścieżki do Pythona wraca cały tekst)
            winget install -e --id Python.Python.3.12 --scope user --accept-package-agreements --accept-source-agreements | Out-Host
        } else {
            $url = "https://www.python.org/ftp/python/3.12.10/python-3.12.10-amd64.exe"
            $exe = Join-Path $env:TEMP "python-3.12.10-amd64.exe"
            Invoke-WebRequest -Uri $url -OutFile $exe | Out-Null
            Start-Process -FilePath $exe -ArgumentList "/quiet InstallAllUsers=0 PrependPath=1 Include_test=0" -Wait | Out-Null
        }
        $python = Find-Python
        if (-not $python) { throw "Instalacja Pythona się nie udała. Zainstaluj go z python.org i uruchom instalator ponownie." }
    }
    return ([string]$python).Trim()
}

function Ensure-Venv($python) {
    if (-not (Test-Path ".venv\Scripts\python.exe")) { & $python -m venv .venv | Out-Host }
    $vpy = Join-Path (Get-Location) ".venv\Scripts\python.exe"
    if (-not (Test-Path $vpy)) { throw "Nie udało się utworzyć środowiska programu (.venv). Uruchom instalator jeszcze raz." }
    & $vpy -m pip install --upgrade pip --quiet | Out-Host
    return $vpy
}

function New-Shortcut($name, $target) {
    $desktop = [Environment]::GetFolderPath("Desktop")
    $ws = New-Object -ComObject WScript.Shell
    $lnk = $ws.CreateShortcut((Join-Path $desktop ($name + ".lnk")))
    $lnk.TargetPath = Join-Path (Get-Location) $target
    $lnk.WorkingDirectory = (Get-Location).Path
    $ico = Join-Path (Get-Location) "assets\inzynier.ico"
    if (Test-Path $ico) { $lnk.IconLocation = "$ico,0" }
    if ($target -ne "serwer.bat") { $lnk.WindowStyle = 7 }   # okno aplikacji zamiast konsoli: bez migania
    $lnk.Save()
}
