"""Pakuje wyniki testu (nagrania sesji, rozmowy, odczyty interfejsu LMU) do wyniki_testu.zip w folderze programu."""
import os
import zipfile

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
out = os.path.join(ROOT, "wyniki_testu.zip")
n = 0
with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as z:
    for folder in ("recordings", "lmu_api", "data"):
        base = os.path.join(ROOT, folder)
        for dp, _, files in os.walk(base):
            for f in files:
                full = os.path.join(dp, f)
                z.write(full, os.path.relpath(full, ROOT))
                n += 1
print(f"Spakowano {n} plików do {out} ({os.path.getsize(out) / 1e6:.1f} MB).")
