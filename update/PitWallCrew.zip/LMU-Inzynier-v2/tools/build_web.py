"""Wpisuje konfigurację z firebase_config.json do strony web/index.html -> web_dist/index.html (do GitHub Pages)."""
import json, os, re, sys
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
cfg = json.load(open(os.path.join(ROOT, "firebase_config.json"), encoding="utf-8"))
pub = {k: cfg[k] for k in ("apiKey", "authDomain", "databaseURL", "projectId", "appId") if k in cfg}
html = open(os.path.join(ROOT, "web", "index.html"), encoding="utf-8").read()
html, n = re.subn(r"/\*FIREBASE_CONFIG\*/.*?/\*END\*/", lambda _: "/*FIREBASE_CONFIG*/" + json.dumps(pub) + "/*END*/", html)
assert n == 1
out = sys.argv[1] if len(sys.argv) > 1 else os.path.join(ROOT, "web_dist")
os.makedirs(out, exist_ok=True)
open(os.path.join(out, "index.html"), "w", encoding="utf-8").write(html)
print("OK", os.path.join(out, "index.html"))
