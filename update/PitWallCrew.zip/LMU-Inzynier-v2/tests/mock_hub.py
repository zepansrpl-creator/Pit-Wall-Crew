"""Testowe centrum zespołu: ten sam protokół co Kod.gs (Apps Script), ale lokalnie w pamięci.

python tests/mock_hub.py 8765   -> http://localhost:8765/exec  (klucz: test)
Strona ściany boksów: http://localhost:8765/?k=test
"""

from __future__ import annotations

import json
import os
import subprocess
import sys
import threading
import time
import uuid
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

KEY = "test"
HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)


class Hub:
    def __init__(self) -> None:
        self.lock = threading.Lock()
        self.live = None
        self.jobs: list[dict] = []
        self.results: dict[str, dict] = {}
        self.msgs: list[dict] = []
        self.asks: list[dict] = []
        self.worker = None
        self.laps: list[dict] = []
        self.calls: dict[str, int] = {}

    def bot(self) -> bool:
        return bool(self.worker and time.time() - self.worker["t"] < 45 and self.worker.get("discord"))

    def add_msg(self, frm, text, kind, delivered=""):
        m = {"id": uuid.uuid4().hex[:8], "t": int(time.time() * 1000), "from": frm, "text": text, "kind": kind,
             "delivered": delivered}
        self.msgs.append(m)
        self.msgs = self.msgs[-40:]
        return m

    def add_job(self, kind, who, payload):
        jid = uuid.uuid4().hex[:8]
        if kind == "say" and not payload.get("nolog"):
            self.add_msg(payload.get("from", "inżynier"), payload.get("text", ""), payload.get("kind", "inżynier"),
                         "discord")
        self.jobs.append({"id": jid, "kind": kind, "who": who, "t": time.time(), "taken": False, "payload": payload})
        return jid

    def team_msg(self, frm, text, kind):
        delivered = ""
        if kind == "wiadomość" and self.bot():
            self.add_job("say", frm, {"text": f"Wiadomość. {frm}: {text}", "nolog": True})
            delivered = "discord"
        m = self.add_msg(frm, text, kind, delivered)
        if kind == "pytanie":
            self.asks.append({"id": m["id"], "from": frm, "text": text, "t": m["t"]})
        return m

    def handle(self, b: dict) -> dict:
        if b.get("k") != KEY:
            return {"ok": False, "error": "zły klucz"}
        op = b.get("op")
        self.calls[op] = self.calls.get(op, 0) + 1
        if op == "state":
            with self.lock:
                now = time.time()
                if b.get("driving") or not self.live or now - self.live["_t"] / 1000 > 20 or not self.live["driving"]:
                    self.live = {"_t": int(now * 1000), "who": b.get("who"), "driving": bool(b.get("driving")),
                                 "state": b.get("state") or {}}
                self.laps += b.get("laps") or []
                fresh = self.worker and now - self.worker["t"] < 45
                out = {"ok": True, "bot": self.bot(), "ai": bool(fresh and self.worker.get("ai")),
                       "stt": bool(fresh and self.worker.get("stt")),
                       "targets": {"ve_per_lap": 4.4, "fuel_per_lap": 2.0, "wear": [1.0, 0.9, 0.8, 0.8],
                                   "stint_laps": 11, "lap_time": 72, "pit_call_s": 25, "service": "Paliwo + 4 opony"}}
                if b.get("driving"):
                    out["msgs"] = [{"id": m["id"], "from": m["from"], "text": m["text"]} for m in self.msgs
                                   if m["kind"] == "wiadomość" and not m["delivered"]]
                    out["asks"], self.asks = self.asks, []
                return out
        if op == "job":
            with self.lock:
                return {"ok": True, "id": self.add_job(b.get("kind"), b.get("who"), b.get("payload") or {})}
        if op == "wait":
            end = time.time() + min(25, b.get("wait", 15))
            while time.time() < end:
                if b["id"] in self.results:
                    return {"ok": True, "done": True, "result": self.results[b["id"]]}
                time.sleep(0.05)
            return {"ok": True, "done": False}
        if op == "work":
            self.worker = {"t": time.time(), "discord": bool(b.get("discord")), "ai": bool(b.get("ai")),
                           "stt": bool(b.get("stt"))}
            end = time.time() + min(25, b.get("wait", 20))
            while time.time() < end:
                with self.lock:
                    mine = [j for j in self.jobs if not j["taken"]]
                    for j in mine:
                        j["taken"] = True
                if mine:
                    return {"ok": True, "jobs": mine, "live": self.live}
                time.sleep(0.05)
            return {"ok": True, "jobs": []}
        if op == "result":
            self.results[b["id"]] = b.get("result") or {}
            return {"ok": True}
        if op in ("msg", "ask"):
            with self.lock:
                return {"ok": True, "msg": self.team_msg(b.get("from", "zespół"), b.get("text", ""),
                                                         "wiadomość" if op == "msg" else "pytanie")}
        if op == "delivered":
            for m in self.msgs:
                if m["id"] in b.get("ids", []):
                    m["delivered"] = b.get("how", "kierowca")
            return {"ok": True}
        if op == "log":
            self.add_msg(b.get("from", "inżynier"), b.get("text", ""), b.get("kind", "inżynier"), "kierowca")
            return {"ok": True}
        if op == "view":
            return self.view()
        return {"ok": False, "error": "nieznana operacja"}

    def view(self) -> dict:
        st = (self.live or {}).get("state") or {}
        live = None
        if st.get("session") == "race":
            live = {"stint": (st.get("pit_stops") or 0) + 1, "stintLaps": st.get("stint_laps"),
                    "lapsLeft": st.get("laps_left"), "avgLap": 250, "maxStintLaps": None,
                    "timeRemaining": 20 * 3600}
        script = os.path.join(HERE, "project_cli.js")
        try:
            out = subprocess.run(["node", script, json.dumps(live)], capture_output=True, text=True, timeout=10)
            proj = json.loads(out.stdout)
        except Exception:
            proj = {"stints": [], "source": "?"}
        now = time.time()
        return {"ok": True, "now": int(now * 1000), "live": self.live,
                "age": int(now - self.live["_t"] / 1000) if self.live else None,
                "grafik": proj["stints"][:12], "zrodlo": proj.get("source"), "raceEnd": proj.get("raceEnd"),
                "msgs": list(reversed(self.msgs[-15:])),
                "laptop": {"online": bool(self.worker and now - self.worker["t"] < 45),
                           "discord": self.bot(), "ai": bool(self.worker and self.worker.get("ai"))},
                "kierowcy": ["Maciej", "Patryk", "Amadeusz"]}


HUB = Hub()


class Handler(BaseHTTPRequestHandler):
    def log_message(self, *a):
        pass

    def _send(self, code: int, body: bytes, ctype: str) -> None:
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_POST(self):
        n = int(self.headers.get("Content-Length", 0))
        try:
            body = json.loads(self.rfile.read(n).decode("utf-8"))
            out = HUB.handle(body)
        except Exception as e:
            out = {"ok": False, "error": str(e)}
        self._send(200, json.dumps(out, ensure_ascii=False).encode("utf-8"), "application/json")

    def do_GET(self):
        with open(os.path.join(ROOT, "apps_script", "Strona.html"), encoding="utf-8") as f:
            html = f.read().replace("<?= klucz ?>", KEY).replace("<?= kto ?>", "Patryk")
        self._send(200, html.encode("utf-8"), "text/html; charset=utf-8")


def serve(port: int) -> ThreadingHTTPServer:
    srv = ThreadingHTTPServer(("127.0.0.1", port), Handler)
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    return srv


if __name__ == "__main__":
    port = int(sys.argv[1]) if len(sys.argv) > 1 else 8765
    serve(port)
    print(f"Testowe centrum zespołu: http://127.0.0.1:{port}/exec  (strona: http://127.0.0.1:{port}/?k={KEY})")
    while True:
        time.sleep(3600)
