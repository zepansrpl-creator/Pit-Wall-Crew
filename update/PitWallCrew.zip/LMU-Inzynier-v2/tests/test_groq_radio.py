"""Groq (atrapa serwera API), radio zespołu i liczenie grafiku przez jedną aplikację."""

from __future__ import annotations

import json
import os
import sys
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from engineer import groq_ai  # noqa: E402
from team.radio import TeamRadio, spoken_text  # noqa: E402

CALLS = []


class H(BaseHTTPRequestHandler):
    def log_message(self, *a):
        pass

    def do_POST(self):
        n = int(self.headers.get("Content-Length") or 0)
        body = self.rfile.read(n)
        CALLS.append((self.path, self.headers.get("Authorization"), self.headers.get("Content-Type"), body))
        if self.headers.get("Authorization") != "Bearer gsk_test":
            return self._send(401, {"error": {"message": "Invalid API Key"}})
        if self.path.endswith("/audio/transcriptions"):
            if b'name="model"\r\n\r\nwhisper-large-v3-turbo' not in body or b'name="file"' not in body:
                return self._send(400, {"error": {"message": "bad multipart"}})
            return self._send(200, {"text": " Ile mam paliwa? "})
        if self.path.endswith("/chat/completions"):
            req = json.loads(body)
            if req["model"] == "openai/gpt-oss-120b":
                return self._send(404, {"error": {"message": "The model `openai/gpt-oss-120b` has been decommissioned"}})
            assert req["messages"][0]["role"] == "system" and "KIEROWCA MÓWI" in req["messages"][-1]["content"]
            return self._send(200, {"choices": [{"message": {"content": "<think>x</think>**Masz** 40 litrów.\n- Starczy na 5 okrążeń."}}]})
        self._send(404, {})

    def _send(self, code, obj):
        b = json.dumps(obj).encode()
        self.send_response(code)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(b)))
        self.end_headers()
        self.wfile.write(b)


def main() -> None:
    srv = ThreadingHTTPServer(("127.0.0.1", 8823), H)
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    groq_ai.API = "http://127.0.0.1:8823/openai/v1"
    g = groq_ai.GroqAI("gsk_test")
    assert g.transcribe_wav(b"RIFF....WAVEfmt ") == "Ile mam paliwa?"
    a = g.ask("ile paliwa", "PALIWO: 40 l")
    assert a == "Masz 40 litrów. Starczy na 5 okrążeń.", a
    assert g.chat_models[0] != "openai/gpt-oss-120b"          # wycofany model pominięty
    bad = groq_ai.GroqAI("gsk_zly")
    try:
        bad.transcribe_wav(b"x")
        raise AssertionError("brak błędu przy złym kluczu")
    except groq_ai.GroqError:
        pass
    assert not bad.ready and "zły klucz" in bad.status
    srv.shutdown()

    # radio zespołu: co słyszy kolega, który nie jedzie
    now = int(time.time() * 1000)
    assert spoken_text({"t": now, "voice": True, "src": "Maciej", "text": "Zjazd za 3"}, "Patryk") == "Zjazd za 3"
    assert spoken_text({"t": now, "voice": True, "src": "Patryk", "text": "x"}, "Patryk") is None
    assert spoken_text({"t": now, "kind": "ostrzeżenie", "text": "Hypercar"}, "Patryk") is None
    assert spoken_text({"t": now, "kind": "wiadomość", "from": "Amadeusz", "text": "deszcz"}, "Patryk") == \
        "Wiadomość od Amadeusza: deszcz"
    assert spoken_text({"t": now - 60000, "voice": True, "src": "M", "text": "stare"}, "Patryk") is None

    heard = []

    class FakeStream:
        def stream(self, path, query, on_event, stop):
            assert path == "msgs" and query()["orderBy"] == "t"
            on_event("put", "/", {"a": {"t": now, "text": "1"}})
            on_event("put", "/b", {"t": now + 1, "text": "2"})
            on_event("put", "/b", {"t": now + 1, "text": "2"})          # powtórka – raz
            on_event("patch", "/b/delivered", "x")                       # zmiana pola – ignorujemy
    r = TeamRadio(FakeStream(), lambda m: heard.append(m["text"]))
    r._run()
    assert heard == ["1", "2"], heard
    assert r.last_t >= now + 1

    # grafik liczy jedna aplikacja naraz
    from tests.test_firebase import FakeClient
    from team.fbbackend import FbBackend
    db: dict = {}
    a1, a2 = FbBackend(FakeClient(db)), FbBackend(FakeClient(db))
    a1._planning_tick(who="Patryk")
    assert db["teams"]["abc123"]["planner"]["who"] == "Patryk"
    a2._planning_tick(who="Amadeusz")
    assert db["teams"]["abc123"]["planner"]["who"] == "Patryk"     # Patryk liczy, Amadeusz czeka
    a2._plan_t = 0
    a2._planning_tick(who="Maciej", force=True)                    # jadący przejmuje
    assert db["teams"]["abc123"]["planner"]["who"] == "Maciej"
    print("OK: Groq (mowa, AI, wycofany model, zły klucz), radio zespołu, jeden liczący grafik")


if __name__ == "__main__":
    main()
