"""Testy doradcy deszczu, zmęczenia i odczytu liczb: python tests/test_analysis.py"""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from engineer.analysis.fatigue import FatigueMonitor  # noqa: E402
from engineer.analysis.laps import LapTrace  # noqa: E402
from engineer.analysis.weather import WeatherAdvisor  # noqa: E402
from engineer.plnum import speak  # noqa: E402


def lap(n, t, wet=0.0, comp="Medium", off=0, valid=True):
    l = LapTrace(lap=n, track="LM", car="Ferrari", track_length=13600, lap_time=t, wetness=wet, compound=comp,
                 off_tracks=off, valid=valid, track_temp=30)
    l.t = [0.0, t]
    return l


def test_rain():
    w = WeatherAdvisor({"rain_pit_cost_s": 47})
    for i in range(5):
        w.add_lap(lap(i, 245.0))
    a = w.advise(0.0, 0.0, "Medium", 8, 30)
    assert a.action in ("", "zostań") and a.gain_per_lap is not None and a.gain_per_lap < 0, a
    # pada coraz mocniej, slicki tracą coraz więcej
    times = [(0.05, 248), (0.12, 252), (0.2, 258), (0.28, 266)]
    for i, (wt, t) in enumerate(times):
        w.add_lap(lap(10 + i, t, wt))
    a = w.advise(0.6, 0.28, "Medium", 8, 30)
    assert a.action == "zjedź teraz", a
    a2 = w.advise(0.6, 0.28, "Medium", 1, 30)
    assert a2.action == "na najbliższym postoju", a2
    msg = w.proactive(a, 1000)
    assert msg and "deszczowe" in msg, msg
    # na deszczowych, tor wysycha -> slicki przy postoju
    w2 = WeatherAdvisor()
    for i in range(5):
        w2.add_lap(lap(i, 245.0))
    for i, wt in enumerate([0.12, 0.08, 0.05, 0.03]):
        w2.add_lap(lap(20 + i, 252 - i, wt, "Wet"))
    b = w2.advise(0.0, 0.03, "Wet", 6, 30)
    assert b.action in ("zjedź teraz", "na najbliższym postoju") and "slicki" in b.text.lower(), b
    print("deszcz OK:", a.text, "|", b.text)


def test_weather_changes():
    w = WeatherAdvisor()
    said = []
    t = 0.0
    # 20 min: chmury z 30% do 80%, bez deszczu -> zapowiedź deszczu
    for i in range(40):
        t += 30
        m = w.sample(t, 0.0, 0.3 + 0.5 * i / 39, 0.0)
        if m:
            said.append(m)
    # pada lekko, potem mocniej, potem przestaje
    for rain in [0.08] * 6 + [0.45] * 10 + [0.0] * 4:
        t += 30
        m = w.sample(t, rain, 0.9, 0.2)
        if m:
            said.append(m)
    joined = " | ".join(said)
    assert said and said[0].startswith("Chmury ciemnieją"), said
    assert "Zaczyna padać" in joined and "Deszcz się nasila" in joined and "Przestało padać" in joined, said
    assert len(said) == 4, said
    print("zmiany pogody OK:", joined)


def test_fatigue():
    f = FatigueMonitor()
    f.reset_driver(0)
    base = [246.0, 245.2, 245.1, 245.3, 245.0, 245.2, 245.1, 245.3]
    t = 0
    for i, x in enumerate(base):
        t += x
        assert f.add_lap(lap(i, x), t) is None
    assert f.last.level == "ok", f.last
    tired = [(246.4, 0), (247.9, 1), (246.2, 0), (248.3, 1), (247.0, 1)]
    msgs = []
    for i, (x, off) in enumerate(tired):
        t += x
        m = f.add_lap(lap(20 + i, x, off=off), t)
        if m:
            msgs.append(m)
    assert f.last.level == "zmęczenie", f.last
    assert len(msgs) == 1, msgs
    print("zmęczenie OK:", f.last.describe(), "|", msgs[0])


def test_speech():
    cases = {
        "Zjazd za 3 okrążenia.": "Zjazd za trzy okrążenia.",
        "Rossi za Tobą, 0.7 s, odrabia 0.2 s na okrążenie": "Rossi za Tobą, siedem dziesiątych sekundy, odrabia dwie dziesiąte sekundy na okrążenie",
        "Zużycie energii wzrosło do 9.4% na okrążenie.": "Zużycie energii wzrosło do dziewięciu i czterech dziesiątych procent na okrążenie.",
        "Postój około 32 sekund, razem z aleją 62.": "Postój około trzydziestu dwóch sekund, razem z aleją sześćdziesiąt dwa.",
        "Zatankuj 28 litrów": "Zatankuj dwadzieścia osiem litrów",
        "Hypercar za Tobą, 4 sekundy.": "Hajperkar za Tobą, cztery sekundy.",
        "2 błędy w ostatnich 5 okrążeniach": "dwa błędy w ostatnich pięciu okrążeniach",
        "o 1.5 s": "o półtorej sekundy",
    }
    bad = []
    for src, want in cases.items():
        got = speak(src)
        if got != want:
            bad.append(f"{src!r} -> {got!r} (oczekiwane {want!r})")
    assert not bad, "\n".join(bad)
    print("liczby OK")


if __name__ == "__main__":
    test_speech()
    test_rain()
    test_weather_changes()
    test_fatigue()
