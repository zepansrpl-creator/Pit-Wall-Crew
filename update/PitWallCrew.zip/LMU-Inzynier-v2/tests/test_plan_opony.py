"""Plan stintów: opony na postoju z planu (lewe/prawe/4), powiadomienia po imieniu, inżynier według planu."""

import os
import sys

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from team import planning  # noqa: E402
from engineer.analysis.strategy import TyreAdvice, follow_plan  # noqa: E402


def main():
    rows = planning.plan_of([
        {"n": 1, "laps": 11, "driver": "Maciej", "tyreL": False, "tyreR": False, "service": "Tankowanie"},
        {"n": 2, "laps": 11, "driver": "Patryk", "tyreL": True, "tyreR": True},
        {"n": 3, "laps": 11, "driver": "Maciej", "tyreL": True, "tyreR": False},
        {"n": 4, "laps": 11, "service": "Paliwo + 4 opony"},       # stary plan
        {"n": 5, "laps": 3, "service": "META"},
    ])
    assert [r["tyres"] for r in rows] == ["bez zmiany opon", "wszystkie cztery", "lewe", "wszystkie cztery", None]
    cfg = planning.settings_of({"tyreBudget": 58})
    t = planning.targets(cfg, rows, {"pit_stops": 2})
    assert t["tyres"] == "lewe" and t["tyre_budget"] == 58 and t["stint"] == 3
    assert planning.same_name("Maciej", "maciej ") and planning.same_name("Maciej Szczepaniak", "Maciej")
    assert not planning.same_name("Maciej", "Patryk")

    # inżynier: plan mówi „lewe”, prawe opony dojadą → lewe
    adv = TyreAdvice("wszystkie cztery", "x", [0.3, 0.3, 0.3, 0.3], [0.02, 0.02, 0.02, 0.02], None, 10)
    out = follow_plan("lewe", adv, [], 2, 11, 0.85, None)
    assert out.option == "lewe" and "planu" in out.reason
    # prawe by nie dojechały (0,7 + 13 × 0,02 = 0,96 > 0,85) → zostaje rada inżyniera z wyjaśnieniem
    adv = TyreAdvice("wszystkie cztery", "x", [0.3, 0.7, 0.3, 0.7], [0.02] * 4, None, 10)
    out = follow_plan("lewe", adv, [], 2, 11, 0.85, None)
    assert out.option == "wszystkie cztery" and "plan zespołu mówi" in out.reason
    # brak nowych opon w menu – plan zmiany nie ma sensu
    assert follow_plan("lewe", None, [], 2, 11, 0.85, False) is None
    # postój zmierzony a plan
    from engineer.analysis.strategy import PitParams, check_stop, pit_times
    ok = check_stop({"stop_s": 73.4, "tyres": 4, "typical": True}, 72, "wszystkie cztery", 5)
    assert "zgadza się" in ok and "stincie 5" in ok, ok
    bad = check_stop({"stop_s": 81, "tyres": 4, "typical": True}, 72, "wszystkie cztery", 6)
    assert "dłużej o 9 s" in bad and "Użyj zmierzonych" in bad, bad
    assert "nie porównuję" in check_stop({"stop_s": 140, "tyres": 0, "typical": False}, 60, None, 7)
    pp = PitParams()
    assert pit_times(pp) is None
    pp.learned = [{"stop_s": 60, "lane_s": 90, "fuel": 0, "ve": 95, "tyres": 0}]
    pt = pit_times(pp)
    assert pt["0"] < pt["2"] < pt["4"], pt
    assert planning.targets(cfg, rows, {"pit_stops": 1})["stop_s"] == 60 and \
        planning.targets(cfg, rows, {"pit_stops": 1})["race_hours"] == 24
    print("ok")


if __name__ == "__main__":
    main()


def test_wearlog():
    from engineer.analysis.laps import LapTrace
    from team.wearlog import sample
    laps = []
    for i in range(5):
        l = LapTrace(lap=i + 1, track="Circuit de la Sarthe", car="Ferrari 296 LMGT3", track_length=13600, lap_time=240,
                     driver="Maciej Szczepaniak", track_temp=30, compound="Medium")
        l.t = [0.0]
        l.wear_tyres = [0.017 * i, 0.016 * i, 0.014 * i, 0.013 * i]
        laps.append(l)
    tc, k, rec = sample(laps, "10221500", 2)
    assert tc == "Circuit_de_la_Sarthe__Ferrari_296_LMGT3" and k.startswith("Maciej_Szczepaniak_10221500_2")
    assert rec["rates"] == [1.7, 1.6, 1.4, 1.3] and rec["laps"] == 4 and rec["temp"] == 30, rec
    assert sample(laps[:2], "x", 1) is None
    print("zużycie ok")


test_wearlog()


def test_plan_fits():
    import time as _t
    now = _t.time() * 1000
    plan = planning.plan_of([{"n": k, "laps": 11, "driver": "Patryk" if k % 2 else "Maciej", "stopS": 72,
                              "tyreL": True, "tyreR": True} for k in range(1, 30)])
    cfg = planning.settings_of({"raceHours": 24, "raceStartMs": now + 2 * 86400000, "lapTime": 240,
                                "drivers": [{"name": "Patryk", "topic": "t"}]})
    live = {"_t": now, "who": "Maciej", "state": {"session": "race", "pit_stops": 0, "stint_laps": 3, "laps_left": 5,
                                                  "avg_lap": 240, "time_remaining": 7000, "race_h": 2.4,
                                                  "max_stint_laps": 11}}
    lv = planning.live_for_plan(live, cfg, now)
    pr = planning.project(plan, cfg, lv, now)
    assert pr["planFits"] is False and "bez planu" in pr["source"]
    assert all(s["driver"] == "Maciej" for s in pr["stints"]), pr["stints"][:3]
    assert all(s.get("deltaMin") is None for s in pr["stints"]) and not any("opony" in (s["service"] or "") for s in pr["stints"])
    assert planning.due_notifications(pr, {}, now + 3600000, 600) == []
    live["state"]["race_h"] = 24.0
    pr2 = planning.project(plan, cfg, planning.live_for_plan(live, cfg, now), now)
    assert pr2["planFits"] and pr2["stints"][1]["driver"] == "Maciej"   # stint 2 z planu
    print("plan a długość wyścigu ok")


test_plan_fits()


def test_laps_said():
    from engineer.analysis.strategy import StrategyPlan
    p = StrategyPlan(True, 4, 0, 100, None, None, None, None, 30, 60, "", False, frac=0.01)
    assert p.laps_said() == 5 and p.short().startswith("Zjazd za 5 okrążeń"), p.short()
    p.frac = 0.95
    assert p.laps_said() == 4
    # energia do wjazdu do alei (Le Mans: 12 678 m z 13 624 m): 45,6% przy 9,18%/okr. na starcie okrążenia → 4 pełne
    import math
    stint_left, frac, reserve, entry = 45.6 / 9.18, 0.002, 0.2 / 9.18, 12678 / 13624
    assert math.floor(stint_left - (1 - frac) - reserve + (1 - entry) + 1e-9) == 4
    print("zjazd jak liczy kierowca ok")


test_laps_said()
