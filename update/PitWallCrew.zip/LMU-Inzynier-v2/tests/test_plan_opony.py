"""Plan stintów: opony na postoju z planu (lewe/prawe/4), powiadomienia po imieniu, inżynier według planu."""

import os
import sys

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from team import planning  # noqa: E402
from engineer.analysis.strategy import TyreAdvice, follow_plan  # noqa: E402


def main():
    rows = planning.plan_of([
        {"n": 1, "laps": 11, "driver": "Maciej", "tyreL": False, "tyreR": False, "service": "Tankowanie"},
        {"n": 2, "laps": 11, "driver": "Patryk", "tyreL": True, "tyreR": True},
        {"n": 3, "laps": 11, "driver": "Maciej", "tyreL": True, "tyreR": False},
        {"n": 4, "laps": 11, "service": "Paliwo + 4 opony"},       # stary plan
        {"n": 5, "laps": 3, "service": "META"},
    ])
    assert [r["tyres"] for r in rows] == ["bez zmiany opon", "wszystkie cztery", "lewe", "wszystkie cztery", None]
    cfg = planning.settings_of({"tyreBudget": 58})
    t = planning.targets(cfg, rows, {"pit_stops": 2})
    assert t["tyres"] == "lewe" and t["tyre_budget"] == 58 and t["stint"] == 3
    assert planning.same_name("Maciej", "maciej ") and planning.same_name("Maciej Szczepaniak", "Maciej")
    assert not planning.same_name("Maciej", "Patryk")

    # inżynier: plan mówi „lewe”, prawe opony dojadą → lewe
    adv = TyreAdvice("wszystkie cztery", "x", [0.3, 0.3, 0.3, 0.3], [0.02, 0.02, 0.02, 0.02], None, 10)
    out = follow_plan("lewe", adv, [], 2, 11, 0.85, None)
    assert out.option == "lewe" and "planu" in out.reason
    # prawe by nie dojechały (0,7 + 13 × 0,02 = 0,96 > 0,85) → zostaje rada inżyniera z wyjaśnieniem
    adv = TyreAdvice("wszystkie cztery", "x", [0.3, 0.7, 0.3, 0.7], [0.02] * 4, None, 10)
    out = follow_plan("lewe", adv, [], 2, 11, 0.85, None)
    assert out.option == "wszystkie cztery" and "plan zespołu mówi" in out.reason
    # brak nowych opon w menu – plan zmiany nie ma sensu
    assert follow_plan("lewe", None, [], 2, 11, 0.85, False) is None
    print("ok")


if __name__ == "__main__":
    main()
