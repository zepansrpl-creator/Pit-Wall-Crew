"""Dwóch z zespołu jedzie naraz różne wyścigi – osobne podglądy; zmiana kierowcy w tym samym aucie – jeden."""

import os
import sys
import time

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
sys.path.insert(0, os.path.dirname(__file__))

from team import planning  # noqa: E402
from team.fbbackend import FbBackend  # noqa: E402
from test_firebase import FakeClient  # noqa: E402


def main():
    planning.ntfy = lambda *a, **k: None
    db = {"teams": {"abc123": {"meta": {"name": "T"}, "settings": {"raceHours": 24}}}}
    pat = FbBackend(FakeClient(db))
    mac = FbBackend(FakeClient(db))
    st_p = {"session": "race", "time_remaining": 1200, "laps_done": 9}
    st_m = {"session": "race", "time_remaining": 8000, "laps_done": 1}
    pat.call({"op": "state", "who": "Patryk", "driving": True, "state": st_p})
    mac.call({"op": "state", "who": "Maciej", "driving": True, "state": st_m})
    pat.call({"op": "state", "who": "Patryk", "driving": True, "state": dict(st_p, laps_done=10)})
    team = db["teams"]["abc123"]
    assert team["live"]["race"]["who"] == "Patryk" and team["live"]["race"]["state"]["laps_done"] == 10, team["live"]["race"]
    assert team["live"]["race:Maciej"]["who"] == "Maciej" and team["live"]["race:Maciej"]["state"]["laps_done"] == 1
    assert team["feeds"]["race:Maciej"]["session"] == "race"

    # zmiana kierowcy w tym samym aucie: ten sam czas do mety → ten sam podgląd „race”
    db2 = {"teams": {"abc123": {"meta": {"name": "T"}, "settings": {"raceHours": 24}}}}
    a = FbBackend(FakeClient(db2))
    b = FbBackend(FakeClient(db2))
    a.call({"op": "state", "who": "Maciej", "driving": True, "state": {"session": "race", "time_remaining": 50000}})
    time.sleep(0.05)
    b.call({"op": "state", "who": "Amadeusz", "driving": True, "state": {"session": "race", "time_remaining": 49990}})
    assert db2["teams"]["abc123"]["live"]["race"]["who"] == "Amadeusz" and "race:Amadeusz" not in db2["teams"]["abc123"]["live"]
    print("ok")


if __name__ == "__main__":
    main()
