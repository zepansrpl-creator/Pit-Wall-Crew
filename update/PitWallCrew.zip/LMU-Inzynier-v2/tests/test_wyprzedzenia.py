"""Komentarze po wyprzedzeniu (z opóźnieniem), porównanie z najlepszym okrążeniem, mapa toru, styl i imię."""

from __future__ import annotations

import os
import sys
import tempfile
from types import SimpleNamespace as NS

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from engineer.analysis.compare_best import BestCompare  # noqa: E402
from engineer.analysis.overtakes import OvertakeWatch  # noqa: E402
from engineer.analysis.trackmap import TrackMap  # noqa: E402
from engineer.model import CarScoring, Snapshot  # noqa: E402
from engineer.style import Style  # noqa: E402


def car(cid, place, me=False, pits=False, name="X"):
    return CarScoring(car_id=cid, driver=name, vehicle="v", car_class="GT3", place=place, laps_done=5,
                      lap_dist=100.0 * place, last_lap=240, best_lap=239, is_player=me, in_pits=pits)


def snap(t, cars, phase="green"):
    return Snapshot(t=t, session="race", track="T", track_length=4000, car_name="c", time_remaining=1000,
                    max_laps=None, phase=phase, air_temp=20, track_temp=25, rain=0, wetness=0, player=None, cars=cars)


class Riv:
    def rivals(self, s, a, b):
        return [NS(car=c, gap_s=-0.8 if c.place < 3 else 0.8, laps_diff=0) for c in s.cars if not c.is_player]


def test_overtakes():
    w, r = OvertakeWatch(), Riv()
    base = [car(1, 1, name="A Rossi"), car(2, 2, name="K Moreau"), car(9, 3, me=True)]
    assert w.update(snap(0, base), r) is None
    passed = [car(1, 1), car(9, 2, me=True), car(2, 3, name="K Moreau")]
    assert w.update(snap(10, passed), r) is None
    assert w.update(snap(25, passed), r) is None                  # jeszcze nie 30 s
    out = w.update(snap(41, passed), r)
    assert out and out.startswith("Dobra robota, P2.") and "Moreau" in out, out
    # wyprzedził i zaraz stracił: brak komentarza
    w2 = OvertakeWatch()
    w2.update(snap(0, base), r)
    w2.update(snap(10, passed), r)
    w2.update(snap(20, base), r)
    assert w2.update(snap(60, base), r) is None
    # zmiana przez postój rywala: bez komentarza
    w3 = OvertakeWatch()
    w3.update(snap(0, base), r)
    pit = [car(1, 1), car(9, 2, me=True), car(2, 3, pits=True)]
    w3.update(snap(10, pit), r)
    assert w3.update(snap(50, [car(1, 1), car(9, 2, me=True), car(2, 3)]), r) is None
    # twardziel
    w4 = OvertakeWatch(persona="twardziel")
    w4.update(snap(0, base), r)
    w4.update(snap(10, passed), r)
    assert "Nie oddawaj" in w4.update(snap(45, passed), r)


def test_compare_best():
    b = BestCompare()
    c = NS(name="T5", start=1000.0)
    d = NS(corner=c, time_loss=0.35, brake_point_diff=-17.0, min_speed_diff=-1.0, throttle_point_diff=None)
    b.end_lap([d], pit=False)
    p = NS(in_pits=False, speed_kmh=200.0, lap_dist=880.0)
    s = NS(player=p, track_length=4000)
    assert b.update(s, [c], coach_said=False) == "T5: hamujesz 15 metrów wcześniej niż na najlepszym."
    assert b.update(s, [c], coach_said=False) is None              # raz na okrążenie
    b.end_lap([d], pit=False)
    assert b.pending is None                                        # ten sam zakręt dopiero po 3 okrążeniach
    b.enabled = False
    for _ in range(3):
        b.end_lap([d], pit=False)
    assert b.update(s, [c], coach_said=False) is None


def test_trackmap():
    from engineer.sources.demo import DemoSource
    src, tm = DemoSource(speed=1000), TrackMap(tempfile.mkdtemp())
    pts = None
    for _ in range(40000):
        s = src.read()
        if s is not None and tm.update(s):
            pts = tm.points
            break
    assert pts and len(pts) == 400
    live = tm.live(s, "GT3")
    assert live["cls"][0] == "GT3" and any(c[5] == 1 for c in live["cars"])
    tm2 = TrackMap(os.path.dirname(tm.dir))
    tm2.update(s)
    assert tm2.points == pts            # wczytana z pliku


def test_style():
    st = Style(persona="analityk", seed=1)
    assert all(st.apply("Zjazd za trzy okrążenia, energia do pełna.", "inżynier") ==
               "Zjazd za trzy okrążenia, energia do pełna." for _ in range(20))
    tw = Style(persona="twardziel")
    assert tw.solo and "Pobudka" in tw.team_to_solo("Jeśli jesteś zmęczony, zgłoś zmianę.")
    import kierowca
    assert kierowca._is_mute_cmd("Marku, cicho", "Marek") and not kierowca._is_mute_cmd("Marku, ile paliwa", "Marek")



def test_fair_ref():
    from engineer.analysis.laps import LapTrace
    from engineer.core import Engineer
    eng = Engineer(data_dir=tempfile.mkdtemp())

    def lap(n, t, wear, fuel=60, wet=0.0, tt=25):
        return LapTrace(lap=n, track="T", car="c", track_length=4000, lap_time=t, wear_tyres=[wear] * 4,
                        fuel_start=fuel, wetness=wet, track_temp=tt, t=[0.0] * 10)
    fresh = lap(1, 100.0, 0.02, fuel=90)
    worn_best = lap(5, 101.0, 0.30, fuel=50)
    eng.laps = [fresh, lap(2, 100.5, 0.10, fuel=80), worn_best]
    cur = lap(6, 101.6, 0.33, fuel=45)
    eng.laps.append(cur)
    ref, similar = eng._fair_ref(cur)
    assert ref is worn_best and similar                      # podobne opony, nie najlepsze w ogóle
    cur2 = lap(7, 101.8, 0.60, fuel=40)
    eng.laps.append(cur2)
    ref, similar = eng._fair_ref(cur2)
    assert ref is fresh and not similar                      # brak podobnych: najlepsze ze stintu, tylko technika
    wet = lap(8, 110.0, 0.62, wet=0.4)
    ref, _ = eng._fair_ref(wet)
    assert ref is None                                       # inne warunki: bez porównań
    eng.saver.state = object()
    assert eng._fair_ref(cur)[0] is None                     # oszczędzanie: bez porównań


if __name__ == "__main__":
    test_overtakes()
    test_compare_best()
    test_trackmap()
    test_style()
    test_fair_ref()
    print("OK: wyprzedzenia z opóźnieniem, porównanie z najlepszym, mapa toru, styl i imię, uczciwy wzorzec dla zużytych opon")
