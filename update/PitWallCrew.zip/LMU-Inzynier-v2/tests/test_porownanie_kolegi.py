"""Porównanie z kolegą z zespołu (okrążenia w bazie zespołu) i z rywalem (z pozycji na torze)."""

import os
import sys

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from engineer.analysis.corners import detect_corners  # noqa: E402
from engineer.analysis.laps import BIN, LapTrace  # noqa: E402
from engineer.analysis.teamlaps import TeamLaps, describe, mate_deltas, name_match, pack, unpack  # noqa: E402
from engineer.analysis.compare_best import BestCompare  # noqa: E402
from engineer.fmt import spoken_lap  # noqa: E402
from team.fbbackend import FbBackend  # noqa: E402

L = 4000.0
N = int(L / BIN)


def lap(driver, brake_at=1000.0, vmin=90.0, throttle_at=1180.0, wear=0.2, fuel=60.0, temp=30.0, gear=2):
    """Prosta 0–1000 m 250 km/h, zakręt (apex 1100 m), prosta; drugi zakręt przy 2600 m taki sam dla wszystkich."""
    sp, th, br, gr = [], [], [], []
    for i in range(N):
        x = i * BIN
        if brake_at <= x < 1100:
            v = 250 - (250 - vmin) * (x - brake_at) / (1100 - brake_at)
            th.append(0.0), br.append(0.9)
        elif 1100 <= x < throttle_at:
            v = vmin + (x - 1100) * 0.3
            th.append(0.5), br.append(0.0)
        elif 2450 <= x < 2600:
            v = 250 - 140 * (x - 2450) / 150
            th.append(0.0), br.append(0.9)
        elif 2600 <= x < 2700:
            v = 110 + (x - 2600) * 0.5
            th.append(0.5), br.append(0.0)
        else:
            v = min(250, (vmin + (throttle_at - 1100) * 0.3) + max(0, x - throttle_at) * 0.4) if 1100 <= x < 2450 else 250
            th.append(1.0), br.append(0.0)
        sp.append(max(60.0, v))
        gr.append(gear if 1050 <= x <= 1150 else 6)
    t, acc = [], 0.0
    for v in sp:
        t.append(acc)
        acc += BIN / (v / 3.6)
    lt = LapTrace(lap=3, track="Le Mans", car="Ferrari 296", track_length=L, lap_time=acc + 0.1, driver=driver,
                  compound="Medium", wear_tyres=[wear] * 4, fuel_start=fuel, track_temp=temp)
    lt.t, lt.speed, lt.throttle, lt.brake, lt.gear, lt.tc = t, sp, th, br, gr, [0] * N
    return lt


class FakeClient:
    def __init__(self):
        self.db = {}

    def get(self, path, *a, **k):
        cur = self.db
        for p in path.split("/"):
            if not isinstance(cur, dict) or p not in cur:
                return None
            cur = cur[p]
        return cur

    def put(self, path, value):
        parts = path.split("/")
        cur = self.db
        for p in parts[:-1]:
            cur = cur.setdefault(p, {})
        cur[parts[-1]] = value


def main():
    me = lap("Maciej Szczepaniak", brake_at=950, vmin=85, throttle_at=1200)
    mate = lap("Patryk Jaskulski", brake_at=990, vmin=95, throttle_at=1170)
    corners = detect_corners(mate)
    assert len(corners) >= 2, corners

    # pakowanie: ~15 KB na okrążenie Le Mans, czasy dokładne do 1 ms
    z = pack(mate)
    back = unpack({"lap_time": mate.lap_time, "driver": mate.driver, "len": L}, z)
    assert abs(back.t[-1] - mate.t[-1]) < 0.01 and back.speed[500] == round(mate.speed[500])

    # baza zespołu: Patryk wysyła, Maciej pobiera i porównuje
    fb = FbBackend(FakeClient())
    call = lambda p: fb.call(p)   # noqa: E731
    tp = TeamLaps(call)
    assert tp.upload(mate)
    assert not tp.upload(lap("Patryk Jaskulski", brake_at=900, vmin=80))   # wolniejsze nie nadpisuje
    tm = TeamLaps(call)
    tm.prepare(me)
    assert tm.match is not None and tm.match[0]["driver"] == "Patryk Jaskulski" and tm.match[2]
    assert tm.teammates() == ["Maciej Szczepaniak", "Patryk Jaskulski"] or "Patryk Jaskulski" in tm.teammates()

    m, ref, strict = tm.match
    ds = mate_deltas(me, ref, corners)
    t1 = max(ds, key=lambda d: d.time_loss)
    assert t1.corner.name == "T1" and t1.time_loss > 0.15, t1
    text, full = describe(me, m, ref, strict, corners, spoken_lap)
    print(text)
    assert "Patryk" in text and "hamuje" in text and "T1" in text and "Rada" in text, text

    # inne warunki (deszcz): brak porównania
    wet = lap("Maciej Szczepaniak", brake_at=950, vmin=85, throttle_at=1200)
    wet.wetness, wet.rain = 0.5, 0.4
    assert tm.find(wet) is None

    # podpowiedź przed zakrętem z okrążenia kolegi
    bc = BestCompare({})
    bc.end_lap([], False, speed_ok=True, mate=(m, ds, strict))
    assert bc.pending and bc.pending[0] == "T1" and "Patryk" in bc.pending[1], bc.pending
    print(bc.pending[1])
    bc.mate_enabled = False
    bc.end_lap([], False, mate=(m, ds, strict))
    assert bc.pending is None

    # odmiana imion
    assert name_match("porównaj z Patrykiem", "Patryk Jaskulski")
    assert name_match("gdzie Wieczorek jest wolniejszy", "John Wieczorek")
    assert not name_match("gdzie tracę", "Tracy Smith")

    # rywal z pozycji na torze
    from engineer.analysis.rivals import RivalCorners
    from engineer.model import CarScoring

    class S:
        pass

    rc = RivalCorners()
    me_tr, his_tr = me, lap("John Wieczorek", brake_at=1000, vmin=100, throttle_at=1160)
    for k in range(2):
        tt = 0.0
        for i in range(0, N, 3):
            s = S()
            s.track_length, s.phase = L, "green"
            a = CarScoring(car_id=1, driver="Maciej Szczepaniak", vehicle="F", car_class="GT3", place=5, laps_done=k,
                           lap_dist=i * BIN, last_lap=me_tr.lap_time, best_lap=0, is_player=True, speed_kmh=me_tr.speed[i])
            b = CarScoring(car_id=2, driver="John Wieczorek", vehicle="F", car_class="GT3", place=6, laps_done=k,
                           lap_dist=i * BIN, last_lap=his_tr.lap_time, best_lap=0, speed_kmh=his_tr.speed[i])
            # dwa auta w tym samym czasie gry: każde w swoim punkcie; osobne aktualizacje z własnym czasem
            for c, tr in ((a, me_tr), (b, his_tr)):
                s.t = k * 1000 + tr.t[i]
                s.cars = [a, b] if c is a else [b, a]
                s.player_scoring = (lambda a=a: a)
                rc.cur.setdefault(c.car_id, None)
                rc.update(_only(s, c, a))
    # zamknięcie okrążenia
    s = S()
    s.track_length, s.phase, s.t = L, "green", 3000
    a = CarScoring(car_id=1, driver="Maciej Szczepaniak", vehicle="F", car_class="GT3", place=5, laps_done=2,
                   lap_dist=5, last_lap=me_tr.lap_time, best_lap=0, is_player=True, speed_kmh=200)
    b = CarScoring(car_id=2, driver="John Wieczorek", vehicle="F", car_class="GT3", place=6, laps_done=2,
                   lap_dist=5, last_lap=his_tr.lap_time, best_lap=0, speed_kmh=200)
    s.cars, s.player_scoring = [a, b], (lambda: a)
    rc.update(s)
    res = rc.compare(a, b, corners)
    assert res is not None, rc.laps.keys()
    t1r = next(r for r in res[2] if r[0] == "T1")
    assert t1r[1] < -0.1 and t1r[2] > 5, t1r      # Wieczorek szybszy w T1 i ma większą prędkość
    print("T1 rywal:", t1r)
    print("ok")


def _only(s, c, me):
    class V:
        pass
    v = V()
    v.track_length, v.phase, v.t = s.track_length, s.phase, s.t
    v.cars = [c]
    v.player_scoring = lambda: me
    return v


if __name__ == "__main__":
    main()
