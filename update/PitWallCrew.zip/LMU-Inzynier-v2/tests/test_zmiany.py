"""Okno „Co nowego”: python -m tests.test_zmiany"""
import os
import sys
import tempfile

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from engineer import changelog  # noqa: E402

TXT = """# Zmiany
## 3.6.2 (21.10.2026)
- C
## 3.6.1 (21.10.2026)
- B1, ciąg
  dalszy
- B2
## 3.5.2 (20.10.2026)
- A
"""


def main() -> None:
    out = changelog.since("3.5.2", "3.6.2", TXT)
    assert [h for h, _ in out] == ["Wersja 3.6.2 (21.10.2026)", "Wersja 3.6.1 (21.10.2026)"], out
    assert out[1][1] == ["• B1, ciąg dalszy", "• B2"], out
    changelog.SEEN = os.path.join(tempfile.mkdtemp(), "data", "w.txt")
    assert changelog.pending("3.6.2") == [] and changelog.seen_version() == "3.6.2"   # pierwsze uruchomienie: nic
    changelog.mark_seen("3.5.2")
    assert [h for h, _ in changelog.pending("3.6.2")][-1].startswith("Wersja 3.6.0")   # z prawdziwego ZMIANY.md
    changelog.SEEN += ".brak"
    assert changelog.pending("3.6.2", after_update_from="3.6.1")[0][0].startswith("Wersja 3.6.2")
    assert changelog.pending("3.6.2", after_update_from="3.6.2") == []
    print("OK: lista zmian po aktualizacji")


if __name__ == "__main__":
    main()
