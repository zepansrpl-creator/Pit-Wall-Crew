"""Szybki test całości na symulowanym wyścigu: python -m tests.test_demo"""
import os
import sys
import tempfile

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from engineer.core import Engineer  # noqa: E402
from engineer.sources.demo import DemoSource  # noqa: E402


def main() -> None:
    src = DemoSource(speed=1000)
    eng = Engineer(data_dir=tempfile.mkdtemp())
    texts, urgent = [], []
    while src.t < 25 * 72:
        for m in eng.update(src.read()):
            (urgent if m.urgent else texts).append(m.text)
    u = " | ".join(urgent)
    assert "Hypercar, " in u and "LMP 2, " in u, u
    assert "Stoi auto z lewej" in u and "Auto poza torem z prawej" in u, u
    assert "Full course yellow" in u and "Zielona flaga" in u, u
    import re
    coach = [x for x in urgent if re.match(r"^T\d+: ", x)]
    assert coach, "trener nie podpowiedział przed zakrętem (demo blokuje przód w T2)"
    assert len(urgent) - len(coach) < 30, f"za dużo pilnych komunikatów: {len(urgent)}"
    joined = " ".join(texts)
    assert len(eng.corners) == 7, eng.corners
    # bez pytania: żadnych raportów czasu okrążenia ani analizy zakrętu po każdym okrążeniu
    assert "T5" not in joined and "Najlepsze okrążenie" not in joined, joined
    assert len(texts) < 25, f"za dużo komunikatów bez pytania: {len(texts)}"
    if os.environ.get("SHOW"):
        print("\n".join(texts))
    assert any(not l.clean and l.pit for l in eng.laps), "brak okrążenia z pitstopem"
    s = eng.summary()
    for section in ("SESJA", "KIEROWCA", "PALIWO", "OPONY", "ZAKRĘTY", "RYWALE"):
        assert section in s, section
    st = eng.summary(setup=True, question="na ostatnim zakręcie podsterownie")
    assert "PORADA DLA ZAKRĘTU: W T7 najmocniej podsterowność" in st, st
    assert "T3" in st and "nadsterowność" in st
    from engineer.intents import RuleEngineer
    from engineer.brain import Brain  # noqa
    r = RuleEngineer(eng)
    cases = {
        "ile mam paliwa?": "litr", "ile VE": "Energii", "kiedy zjazd": "", "ile do końca": "końca",
        "gdzie tracę czas": "", "co z te pięć": "T5", "kto przede mną": "", "kto mnie goni": "",
        "jak opony": "Opony", "na ostatnim zakręcie podsterowność": "T7", "tył ucieka na wyjściu z trójki": "T3",
        "co zmienić w setupie": "", "jaka pogoda": "Powietrze", "co umiesz": "paliwo",
    }
    cases.update({"jaki plan": "", "które opony zmienić": "", "ile trwa postój": "aleją", "czy naprawiać": "",
                  "naprawa trwa 30 sekund": "", "bez dublowania": "dublowaniu", "mów o dublowaniu": "dublowaniu"})
    for q, must in cases.items():
        a = r.answer(q)
        assert a, f"brak odpowiedzi na: {q}"
        assert must in a, f"{q} -> {a}"
    assert r.answer("jaki jest kurs dolara") is None
    b = Brain(eng, {"mode": "free"})
    now, job = b.handle("jaki jest kurs dolara")
    assert job is None and now.startswith("Nie zrozumiałem")
    print("OK:", len(eng.laps), "okrążeń,", len(texts), "komunikatów")


if __name__ == "__main__":
    main()
