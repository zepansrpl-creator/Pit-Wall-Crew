"""Test centrum zespołu w Firebase na atrapie bazy (bez internetu): ten sam przepływ co ściana boksów."""

from __future__ import annotations

import copy
import itertools
import os
import sys
import threading
import time

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from team import planning  # noqa: E402
from team.fbbackend import FbBackend  # noqa: E402
from team.hub import Hub  # noqa: E402


class FakeClient:
    """Atrapa FbClient: drzewo w pamięci, ścieżki względne do /teams/<kod>."""
    _ids = itertools.count(1)

    def __init__(self, root: dict, code: str = "abc123") -> None:
        self.root, self.code = root, code
        self.lock = threading.Lock()

    def _node(self, path: str, create: bool = False, root: bool = False):
        parts = [p for p in ((path if root else f"teams/{self.code}/{path}").split("/")) if p]
        cur = self.root
        for p in parts[:-1]:
            if p not in cur or not isinstance(cur[p], dict):
                if not create:
                    return None, None
                cur[p] = {}
            cur = cur[p]
        return cur, parts[-1]

    def get(self, path, query=None, timeout=20.0):
        with self.lock:
            par, k = self._node(path)
            return copy.deepcopy(par.get(k)) if par is not None else None

    def put(self, path, value, root=False):
        with self.lock:
            par, k = self._node(path, True, root)
            if value is None:
                par.pop(k, None)
            else:
                par[k] = copy.deepcopy(value)

    def put_root(self, path, value):
        self.put(path, value, root=True)

    def patch(self, path, value, root=False):
        with self.lock:
            par, k = self._node(path, True, root)
            cur = par.setdefault(k, {})
            for kk, v in value.items():
                node, parts = cur, kk.split("/")
                for p in parts[:-1]:
                    node = node.setdefault(p, {})
                if v is None:
                    node.pop(parts[-1], None)
                else:
                    node[parts[-1]] = copy.deepcopy(v)

    def patch_root(self, path, value):
        self.patch(path, value, root=True)

    def post(self, path, value):
        k = f"-id{next(self._ids):05d}"
        self.put(f"{path}/{k}", value)
        return k

    def delete(self, path):
        with self.lock:
            par, k = self._node(path)
            if par is not None:
                par.pop(k, None)


def main() -> None:
    db: dict = {}
    sent_ntfy = []
    planning.ntfy = lambda topic, title, body: sent_ntfy.append((topic, title, body))
    c = FakeClient(db)
    now = int(time.time() * 1000)
    c.put("meta", {"name": "Test", "obs": "oxyz"})
    c.put_root("obs/oxyz/team", "abc123")
    c.put("settings", {"raceStartMs": now - 3600000, "raceHours": 24, "notifyMin": 30, "lapTime": 240,
                       "drivers": [{"name": "Maciej", "topic": "t-m"}, {"name": "Patryk", "topic": "t-p"}]})
    c.put("plan", [{"n": 1, "laps": 10, "driver": "Maciej", "stopS": 60, "service": "Tylko paliwo"},
                   {"n": 2, "laps": 11, "driver": "Patryk", "stopS": 72, "service": "Paliwo + 4 opony"},
                   {"n": 3, "laps": 11, "driver": "Maciej", "stopS": 60}])

    drv = Hub("", "", "Maciej", backend=FbBackend(c))
    srv = Hub("", "", "serwer AI", backend=FbBackend(FakeClient(db)))
    wall = FbBackend(FakeClient(db))

    st = {"session": "race", "pit_stops": 0, "stint_laps": 8, "laps_left": 2, "avg_lap": 240,
          "time_remaining": 20 * 3600, "weather": {"rain": 0.0}}
    out = drv.call({"op": "state", "who": "Maciej", "driving": True, "state": st,
                    "laps": [{"lap": 8, "stint": 1, "time": 241.2}]})
    assert out["targets"]["stint_laps"] == 10, out
    assert db["teams"]["abc123"]["live"]["race"]["who"] == "Maciej"
    assert db["obs"]["oxyz"]["live"]["state"].get("targets") is None
    assert db["teams"]["abc123"]["laps"]["1_8"]["time"] == 241.2
    g = db["teams"]["abc123"]["grafik"]["rows"]
    assert g[0]["current"] and g[1]["driver"] == "Patryk", g[:2]
    assert any(t == "t-p" for t, _, _ in sent_ntfy), sent_ntfy        # Patryk za ~8 min: powiadomienie
    n_before = len(sent_ntfy)
    drv.backend._plan_t = -1e9
    drv.call({"op": "state", "who": "Maciej", "driving": True, "state": st})
    assert len(sent_ntfy) == n_before, "powiadomienie wysłane drugi raz"

    # zapis różnicowy: tylko zmienione pola, wynik taki sam jak pełny zapis
    st2 = dict(st, laps_left=1, stint_laps=9)
    st2.pop("weather")
    drv.call({"op": "state", "who": "Maciej", "driving": True, "state": st2})
    live = db["teams"]["abc123"]["live"]["race"]["state"]
    assert live["laps_left"] == 1 and "weather" not in live and live["session"] == "race", live
    assert db["obs"]["oxyz"]["live"]["state"]["laps_left"] == 1 and "targets" not in db["obs"]["oxyz"]["live"]["state"]

    # ściana: wiadomość do kierowcy i pytanie „tylko tekst”
    wall.call({"op": "msg", "from": "Patryk", "text": "Zjedź na deszczowe", "feed": "race"})
    wall.call({"op": "ask", "from": "Patryk", "text": "ile paliwa", "feed": "race", "silent": True})
    out = drv.call({"op": "state", "who": "Maciej", "driving": True, "state": st})
    assert out["msgs"][0]["text"] == "Zjedź na deszczowe" and out["asks"][0]["silent"], out
    drv.call({"op": "delivered", "ids": [out["msgs"][0]["id"]], "how": "głos u kierowcy"})
    assert db["teams"]["abc123"]["msgs"][out["msgs"][0]["id"]]["delivered"] == "głos u kierowcy"
    out = drv.call({"op": "state", "who": "Maciej", "driving": True, "state": st})
    assert not out["msgs"] and not out["asks"], "wiadomość dostarczona dwa razy"

    # zadanie dla serwera AI: pytanie kierowcy -> odpowiedź
    res = {}

    def server():
        w = srv.call({"op": "work", "discord": True, "ai": True, "stt": True, "wait": 5})
        j = w["jobs"][0]
        srv.call({"op": "result", "id": j["id"], "result": {"text": "Odpowiedź AI", "log": {"from": "inżynier"}}})
    th = threading.Thread(target=server)
    th.start()
    jid = drv.job("ask", {"question": "co z oponami"})
    res = drv.wait(jid, total=10)
    th.join()
    assert res and res["text"] == "Odpowiedź AI", res
    out = drv.call({"op": "state", "who": "Maciej", "driving": True, "state": st})
    assert out["ai"] and out["bot"], out

    # wiadomość, gdy bot Discord działa: czyta ją bot (zadanie say), nie kierowca
    wall.call({"op": "msg", "from": "Patryk", "text": "Dobra robota", "feed": "race"})
    out = drv.call({"op": "state", "who": "Maciej", "driving": True, "state": st})
    assert not out["msgs"], out
    jobs = db["teams"]["abc123"].get("jobs") or {}
    assert any("Wiadomość od Patryka" in j["payload"]["text"] for j in jobs.values()), jobs

    # zmiana kierowcy: odprawa raz dla Patryka
    drv.call({"op": "handover", "who": "Maciej", "feed": "race", "text": "Zjazd za 5", "summary": "Stint: Maciej"})
    pat = Hub("", "", "Patryk", backend=FbBackend(FakeClient(db)))
    o1 = pat.call({"op": "state", "who": "Patryk", "driving": True, "state": st})
    o2 = pat.call({"op": "state", "who": "Patryk", "driving": True, "state": st})
    assert o1.get("handover", {}).get("text") == "Zjazd za 5" and "handover" not in o2, (o1, o2)

    # pamięć zespołu
    drv.call({"op": "remember", "who": "Maciej", "text": "ABS 9 za mocny w deszczu", "track": "Le Mans"})
    notes = srv.call({"op": "memory", "track": "le mans"})["notes"]
    assert notes and notes[-1]["text"].startswith("ABS"), notes
    assert srv.call({"op": "view"})["kierowcy"] == ["Maciej", "Patryk"]
    print("OK: Firebase – stan, grafik i powiadomienia, wiadomości, pytania, serwer AI, Discord, odprawa, pamięć")


if __name__ == "__main__":
    main()
