"""Test całego zespołu bez gry i bez Google: testowe centrum + laptop (atrapa modeli) + kierowca na demo.

python tests/test_team.py
"""
import os
import sys
import tempfile
import threading
import time
from types import SimpleNamespace

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)
sys.path.insert(0, os.path.join(ROOT, "tests"))
os.chdir(tempfile.mkdtemp())

import numpy as np  # noqa: E402

import mock_hub  # noqa: E402
from serwer import Server  # noqa: E402
from kierowca import Driver  # noqa: E402
from engineer.sources.demo import DemoSource  # noqa: E402


def main() -> None:
    srv = mock_hub.serve(8799)
    url = "http://127.0.0.1:8799/exec"
    team = {"url": url, "key": "test"}
    laptop = Server({"team": team}, fake=True)
    threading.Thread(target=laptop.run, daemon=True).start()

    args = SimpleNamespace(demo=True, no_voice=True, quiet=False)
    d = Driver({"team": dict(team, name="Maciej"), "engineer": {"data_dir": tempfile.mkdtemp()}}, args)
    d.hub.start(interval=0.5)
    src = DemoSource(speed=1000)
    hub = mock_hub.HUB

    def run(sim_s: float) -> None:
        end = src.t + sim_s
        while src.t < end:
            d.tick(src.read())
            d.team_inbox()
            while not d.questions.empty():
                _, who, q = d.questions.get()
                d.answer(q)
            if int(src.t * 20) % 200 == 0:
                time.sleep(0.01)

    run(300)
    time.sleep(1.5)
    assert d.hub.ok and d.hub.bot and d.hub.stt and d.hub.ai, (d.hub.ok, d.hub.bot, d.hub.error)
    assert hub.live and hub.live["driving"] and hub.live["who"] == "Maciej"
    st = hub.live["state"]
    for k in ("pos_class", "laps_done", "laps_left", "tyres", "weather", "fatigue", "targets"):
        assert k in st, k
    assert hub.laps, "okrążenia nie trafiły do arkusza"
    # demo to krótki wyścig: plan z arkusza (pod 24h) nie jest używany, strategia z czasu do mety
    assert d.eng.targets == {} and d._plan_mode is False, d.eng.targets

    # 1) wiadomość ze ściany boksów -> bot mówi na Discordzie
    hub.handle({"k": "test", "op": "msg", "from": "Patryk", "text": "Za dwa okrążenia zmiana"})
    time.sleep(1.0)
    said = [m for m in hub.msgs if m["kind"] == "wiadomość"]
    assert said and said[-1]["delivered"] == "discord", said

    # 2) pytanie zespołu do inżyniera -> kierowca odpowiada regułami -> Discord
    hub.handle({"k": "test", "op": "ask", "from": "Amadeusz", "text": "ile zostało paliwa?"})
    t0 = time.time()
    while time.time() - t0 < 5:
        run(2)
        if any(m["kind"] == "odpowiedź" for m in hub.msgs):
            break
        time.sleep(0.2)
    ans = [m for m in hub.msgs if m["kind"] == "odpowiedź"]
    assert ans and ("paliw" in ans[-1]["text"].lower() or "litr" in ans[-1]["text"].lower()), hub.msgs

    # 3) przycisk mówienia: nagranie -> laptop rozpoznaje -> odpowiedź
    d.on_audio((np.sin(np.arange(16000 * 2) / 7) * 3000).astype(np.int16))
    q = d.questions.get(timeout=5)
    assert q[2] == "ile mam paliwa", q

    # 4) pytanie spoza reguł -> AI na laptopie
    d.answer("jaka jest stolica Francji")
    t0 = time.time()
    while time.time() - t0 < 6 and not any("Odpowiedź testowa" in m["text"] for m in hub.msgs):
        time.sleep(0.2)
    assert any("Odpowiedź testowa" in m["text"] for m in hub.msgs), hub.msgs

    # 5) laptop wyłączony -> wiadomość idzie do kierowcy i jest czytana lokalnie, tylko raz
    hub.worker = None
    time.sleep(1.0)
    hub.handle({"k": "test", "op": "msg", "from": "Patryk", "text": "Test bez laptopa"})
    spoken = []
    d.speaker.say = lambda t: spoken.append(t)
    for _ in range(8):
        time.sleep(0.4)
        d.team_inbox()
    assert spoken.count("Wiadomość od Patryka: Test bez laptopa") <= 1
    assert any("Test bez laptopa" in s for s in spoken), spoken
    assert sum("Test bez laptopa" in s for s in spoken) == 1, spoken
    print("OK: zespół –", len(hub.laps), "okrążeń w arkuszu,", len(hub.msgs), "wpisów w radiu zespołu,",
          "zapytań do centrum:", hub.calls)
    srv.shutdown()


if __name__ == "__main__":
    main()
