"""Dublowanie: stojące auto szybszej klasy, które właśnie minąłeś, nie daje ostrzeżenia: python -m tests.test_dublowanie"""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from engineer.analysis.hazards import HazardMonitor  # noqa: E402
from engineer.model import CarScoring, PlayerTelemetry, Snapshot  # noqa: E402


def snap(t, other_dist, other_v):
    me = CarScoring(car_id=1, driver="Ja", vehicle="Ferrari", car_class="GT3", place=10, laps_done=5, lap_dist=3000,
                    last_lap=240, best_lap=238, is_player=True, speed_kmh=200)
    lmp = CarScoring(car_id=2, driver="Rywal", vehicle="Oreca", car_class="LMP2", place=5, laps_done=6,
                     lap_dist=other_dist, last_lap=220, best_lap=215, speed_kmh=other_v)
    return Snapshot(t=t, session="race", track="Le Mans", track_length=13626, car_name="Ferrari", time_remaining=3600,
                    max_laps=None, phase="green", air_temp=20, track_temp=25, rain=0, wetness=0,
                    player=PlayerTelemetry(lap=5, lap_dist=3000, speed_kmh=200), cars=[me, lmp])


def main() -> None:
    h = HazardMonitor()
    said = []
    for i in range(20):        # stoi 50 m za Tobą (właśnie go minąłeś)
        said += [a.text for a in h.update(snap(100 + i * 0.5, 2950, 0)) if a.kind == "lapping"]
    assert not said, said
    h = HazardMonitor()
    for i in range(20):        # jedzie 260 km/h tuż za Tobą
        said += [a.text for a in h.update(snap(200 + i * 0.5, 2900, 260)) if a.kind == "lapping"]
    assert any("LMP" in x for x in said), said
    # okrążenie wzorcowe z „dziurą” (powrót do boksu / przerwa w odczycie) jest odrzucane
    from engineer.analysis.laps import LapTrace
    n = 2725
    t = [i * 5 / 60.0 for i in range(n)]
    good = LapTrace(lap=3, track="Le Mans", car="Ferrari", track_length=13624, lap_time=t[-1] + 1, t=t,
                    speed=[216.0] * n)
    assert good.plausible()
    t2 = t[:1980] + [t[1980] + (i - 1980) * 0.003 for i in range(1980, 2140)] + \
        [x - (t[2140] - t[1980]) + 160 * 0.003 for x in t[2140:]]
    bad = LapTrace(lap=3, track="Le Mans", car="Ferrari", track_length=13624, lap_time=t2[-1] + 1, t=t2,
                   speed=[216.0] * n)
    assert not bad.plausible()
    print("OK: dublowanie – stojące auto bez ostrzeżenia, szybkie z ostrzeżeniem")


if __name__ == "__main__":
    main()
