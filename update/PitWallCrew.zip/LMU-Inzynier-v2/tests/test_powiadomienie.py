"""Komenda „powiadomienie na telefon <imię>: <treść>”: python -m tests.test_powiadomienie"""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from team.notify_cmd import match_names, parse  # noqa: E402

N = ["Maciej", "Patryk", "Amadeusz"]


def main() -> None:
    cases = {
        "Powiadomienie na telefon Amadeusz: wstawaj, zaraz wsiadasz": (["Amadeusz"], "Wstawaj, zaraz wsiadasz"),
        "Inżynier, powiadom Amadeusza, że zaraz wsiada": (["Amadeusz"], "Zaraz wsiada"),
        "wyślij Patrykowi powiadomienie: zjedź do boksu": (["Patryk"], "Zjedź do boksu"),
        "wyślij Maćkowi na telefon: wstawaj": (["Maciej"], "Wstawaj"),
        "powiadomienie dla wszystkich: zaczyna padać": (N, "Zaczyna padać"),
    }
    for q, (who, text) in cases.items():
        p = parse(q)
        assert p is not None and match_names(p[0], N) == who and p[1] == text, (q, p)
    for q in ("ile paliwa", "czy Amadeusz dostał powiadomienie", "powiedz następnemu, że T5 śliskie",
              "wyślij mi plan postoju"):
        assert parse(q) is None, q
    assert parse("powiadomienie na telefon") == ("", "")
    assert match_names("kowalski", N) == []

    # backend: ntfy tylko do wskazanego kierowcy z tematem
    from team import fbbackend, planning
    sent = []
    planning.ntfy = lambda topic, title, body: sent.append((topic, title, body))
    b = fbbackend.FbBackend.__new__(fbbackend.FbBackend)
    b._cfg = lambda: {"drivers": [{"name": "Amadeusz", "topic": "pwc-a"}, {"name": "Patryk", "topic": ""},
                                  {"name": "Maciej", "topic": "pwc-m"}]}
    b._log = lambda *a, **k: ""
    out = b.op_notify({"who": "Patryk", "to": "amadeusza", "text": "Wstawaj, zaraz wsiadasz"})
    assert out["sent"] == ["Amadeusz"] and sent == [("pwc-a", "Pit Wall Crew – od Patryk", "Wstawaj, zaraz wsiadasz")], sent
    out = b.op_notify({"who": "Maciej", "to": "patrykowi", "text": "x"})
    assert out["sent"] == [] and out["no_phone"] == ["Patryk"], out
    sent.clear()
    out = b.op_notify({"who": "Maciej", "to": "*", "text": "Pada"})
    assert out["sent"] == ["Amadeusz"], out          # bez nadawcy i bez kierowcy bez telefonu
    print("OK: powiadomienie na telefon głosem")


if __name__ == "__main__":
    main()
