"""Centrum zespołu w Firebase – te same operacje co wcześniej w Apps Script (Hub.call z {"op": …}).

Układ bazy (/teams/<kod>/…):
  meta {name, created, obs}           settings {…}            plan [stinty]
  live/<podgląd> {_t, who, driving, state, feed}               feeds/<podgląd> {t, who, session, driving}
  msgs/<id> radio zespołu             pending/<podgląd>/<id> wiadomości i pytania czekające na kierowcę
  handover/<podgląd>                  laps/<id>     memory/<id>     grafik, notified, rain_ntfy
  tlaps, tlapsi (okrążenia do porównań w zespole), wear (zużycie opon), tracks (mapy torów)
Obserwatorzy: /obs/<token> {team, live, grafik, raceEnd} – tylko do odczytu, bez radia i planu.
"""

from __future__ import annotations

import threading
import time
from typing import Optional

from . import planning
from .firebase import FbClient


def _now() -> int:
    return int(time.time() * 1000)


def feed_key(st: dict, who: str) -> str:
    s = (st or {}).get("session") or "?"
    return "race" if s == "race" else f"{s}:{who or '?'}".replace(".", "_").replace("/", "_")


class FbBackend:
    def __init__(self, client: FbClient) -> None:
        self.c = client
        self._plan_t = -1e9
        self._cache: dict = {}
        self._cache_t = 0.0
        self._obs: Optional[str] = None
        self._rain_prev: Optional[float] = None
        self._clean_t = 0
        self._sent: dict = {}          # podgląd -> (czas pełnego zapisu, ostatnio wysłany stan)
        self._lock = threading.Lock()

    # ------------------------------------------------------------ pomocnicze
    def _team(self, fresh: bool = False) -> dict:
        """Ustawienia, plan i meta (pamiętane 60 s)."""
        if fresh or time.monotonic() - self._cache_t > 60 or not self._cache:
            d = {"settings": self.c.get("settings") or {}, "plan": self.c.get("plan") or [],
                 "meta": self.c.get("meta") or {}}
            self._cache, self._cache_t = d, time.monotonic()
            self._obs = (d["meta"] or {}).get("obs")
        return self._cache

    def _cfg(self) -> dict:
        return planning.settings_of(self._team()["settings"])

    def _plan(self) -> list[dict]:
        return planning.plan_of(self._team()["plan"])

    def _default_feed(self) -> Optional[str]:
        feeds = self.c.get("feeds") or {}
        best, best_k = None, None
        now = _now()
        for k, f in feeds.items():
            score = (1e15 if f.get("session") == "race" and now - float(f.get("t") or 0) < 120000 else 0) + float(f.get("t") or 0)
            if best is None or score > best:
                best, best_k = score, k
        return best_k

    def _log(self, frm: str, text: str, kind: str, delivered: str = "", feed: str = "", extra: Optional[dict] = None) -> str:
        rec = {"t": _now(), "from": frm, "text": str(text)[:400], "kind": kind, "delivered": delivered, "feed": feed}
        if extra:
            rec.update(extra)
        return self.c.post("msgs", rec)

    # ------------------------------------------------------------ operacje
    def call(self, b: dict) -> dict:
        op = b.get("op")
        fn = getattr(self, "op_" + str(op), None)
        if fn is None:
            return {"ok": False, "error": "nieznana operacja"}
        out = fn(b)
        out.setdefault("ok", True)
        return out

    def op_state(self, b: dict) -> dict:
        now = _now()
        st = b.get("state") or {}
        who = b.get("who") or ""
        feed = feed_key(st, who)
        driving = bool(b.get("driving"))
        # mały wpis feeds/<podgląd> zamiast całego stanu: kto i kiedy ostatnio pisał (oszczędza transfer)
        cur = None if driving else self.c.get(f"feeds/{feed}")
        if driving or not cur or now - float(cur.get("t") or 0) > 20000 or not cur.get("driving"):
            rec = {"_t": now, "who": who, "driving": driving, "state": st, "feed": feed}
            diff = self._diff(feed, rec, now)
            try:
                if diff is None:
                    self.c.put(f"live/{feed}", rec)
                else:
                    self.c.patch(f"live/{feed}", diff)
            except Exception:
                self._sent.pop(feed, None)      # następnym razem pełny zapis
                raise
            self.c.put(f"feeds/{feed}", {"t": now, "who": who, "session": st.get("session") or "?", "driving": driving})
            if driving and feed == "race":
                self._rain(st)
            if driving and (feed == "race" or not self._race_live(now)):
                # obserwatorzy: wyścig, a gdy go nie ma – trening / kwalifikacje jadącego kierowcy
                if getattr(self, "_obs_feed", None) != feed:
                    self._obs_feed, diff = feed, None      # zmiana podglądu: pełny zapis
                self._mirror_obs(rec, diff)
        for lap in b.get("laps") or []:
            key = f"{lap.get('stint')}_{lap.get('lap')}".replace(".", "_")
            self.c.put(f"laps/{key}", dict(lap, who=who, t=now))
        cfg = self._cfg()
        out = {"targets": planning.targets(cfg, self._plan(), st), "groq": str(cfg.get("groqKey") or "")}
        if driving or feed != "race":
            # wiadomości i pytania: w wyścigu tylko do jadącego; poza wyścigiem podgląd jest osobny dla każdego,
            # więc odpowiada aplikacja tej osoby także w menu albo w garażu
            ho = self.c.get(f"handover/{feed}") if driving else None
            if ho and ho.get("from") != who and now - float(ho.get("t") or 0) < 900000 and not (ho.get("got") or {}).get(who):
                out["handover"] = {"from": ho.get("from"), "text": ho.get("text")}
                self.c.put(f"handover/{feed}/got/{who}", now)
            pend = self.c.get(f"pending/{feed}") or {}
            msgs, asks = [], []
            for mid, m in sorted(pend.items(), key=lambda kv: kv[1].get("t", 0)):
                if m.get("kind") == "pytanie":
                    asks.append({"id": mid, "from": m.get("from"), "text": m.get("text"), "t": m.get("t"),
                                 "feed": feed, "silent": bool(m.get("silent"))})
                    self.c.delete(f"pending/{feed}/{mid}")
                else:
                    msgs.append({"id": mid, "from": m.get("from"), "text": m.get("text")})
                    self.c.delete(f"pending/{feed}/{mid}")
            out["msgs"], out["asks"] = msgs, asks
        if driving and feed == "race":
            self._planning_tick(live={"_t": now, "state": st}, who=who, force=True)
        elif not driving:
            self._planning_tick(who=who)     # grafik i powiadomienia liczy każda włączona aplikacja (jedna naraz)
        self._wall_log(feed, who, driving, st, out)
        return out

    def _wall_log(self, feed: str, who: str, driving: bool, st: dict, out: dict) -> None:
        """Pełny dziennik (tylko wersja testowa): co 5 s dokładnie to, co trafia na ścianę boksów –
        do odtworzenia ściany po jeździe i sprawdzenia, czy wszystko się zgadza."""
        try:
            from engineer.debuglog import DBG
            if not DBG.enabled or time.monotonic() - getattr(self, "_wall_t", -1e9) < 5:
                return
            self._wall_t = time.monotonic()
            o = {k: v for k, v in out.items() if k != "groq"}         # bez klucza AI
            DBG.log("wall", feed=feed, who=who, driving=driving, state=st, out=o,
                    grafik=getattr(self, "_last_grafik", None))
        except Exception:
            pass

    def _race_live(self, now: int) -> bool:
        """Czy ktoś z zespołu jedzie teraz wyścig (wpis feeds/race z ostatnich 2 minut)."""
        try:
            if now - getattr(self, "_race_chk_t", 0) > 15000:
                self._race_chk_t = now
                r = self.c.get("feeds/race") or {}
                self._race_live_v = bool(r.get("driving")) and now - float(r.get("t") or 0) < 120000
            return getattr(self, "_race_live_v", False)
        except Exception:
            return False

    def _diff(self, feed: str, rec: dict, now: int) -> Optional[dict]:
        """Tylko zmienione pola stanu (PATCH „state/klucz”): ściana boksów i obserwatorzy pobierają mniej.

        Co 60 s (i przy zmianie podglądu albo kierowcy) pełny zapis, żeby nic się nie rozjechało.
        None = trzeba zapisać całość."""
        prev = self._sent.get(feed)
        full = prev is None or now - prev[0] > 60000 or prev[1].get("who") != rec["who"] or \
            prev[1].get("driving") != rec["driving"]
        self._sent[feed] = (prev[0] if prev and not full else now, rec)
        if full:
            return None
        old = prev[1].get("state") or {}
        new = rec.get("state") or {}
        d = {"_t": rec["_t"]}
        for k, v in new.items():
            if old.get(k) != v:
                d["state/" + k] = v
        for k in old:
            if k not in new:
                d["state/" + k] = None
        return d

    def _mirror_obs(self, rec: dict, diff: Optional[dict] = None) -> None:
        obs = self._obs or (self._team()["meta"] or {}).get("obs")
        if not obs:
            return
        try:
            if diff is None:
                st = dict(rec.get("state") or {})
                st.pop("targets", None)        # plan zespołu zostaje w zespole
                self.c.patch_root(f"obs/{obs}", {"team": self.c.code, "live": dict(rec, state=st)})
            else:
                d = {k: v for k, v in diff.items() if k != "state/targets"}
                self.c.patch_root(f"obs/{obs}/live", d)
        except Exception:
            pass

    def _rain(self, st: dict) -> None:
        now_r = (st.get("weather") or {}).get("rain") or 0
        was, self._rain_prev = (self._rain_prev if self._rain_prev is not None else now_r), now_r
        kind = "start" if (was < 0.05 <= now_r) else ("stop" if (was >= 0.05 and now_r < 0.02) else "")
        if not kind:
            return
        last = self.c.get("rain_ntfy") or {}
        if _now() - float(last.get("t") or 0) < 1200000:
            return
        self.c.put("rain_ntfy", {"t": _now(), "kind": kind})
        title = "Zaczęło padać na torze" if kind == "start" else "Przestało padać"
        body = (f"Intensywność {round(now_r * 100)}%. Sprawdź ścianę boksów (rada o oponach)." if kind == "start"
                else "Tor zacznie wysychać. Sprawdź ścianę boksów.")
        for d in self._cfg().get("drivers") or []:
            if d.get("topic"):
                planning.ntfy(d["topic"], title, body)
        self._log("ściana boksów", f"{title}. {body}", "pogoda", "ntfy")

    def _planning_tick(self, live: Optional[dict] = None, who: str = "aplikacja", force: bool = False) -> None:
        """Co minutę: prognoza grafiku na ścianę i powiadomienia ntfy przed zmianą kierowcy.

        Liczy jedna aplikacja naraz (wpis „planner” w bazie): kierowca, który jedzie, przejmuje zawsze,
        inne – gdy nikt nie liczył od 90 s (powiadomienia przed startem: wystarczy włączona aplikacja u kogokolwiek)."""
        if time.monotonic() - self._plan_t < 60:
            return
        self._plan_t = time.monotonic()
        try:
            now0 = _now()
            if not force:
                lock = self.c.get("planner") or {}
                if lock.get("who") and lock.get("who") != who and now0 - float(lock.get("t") or 0) < 90000:
                    return
            self.c.put("planner", {"who": who, "t": now0})
        except Exception:
            pass
        try:
            t = self._team(fresh=True)
            cfg, plan = planning.settings_of(t["settings"]), planning.plan_of(t["plan"])
            now = _now()
            if live is None:
                live = self.c.get("live/race")
            lv = planning.live_for_plan(live, cfg, now)
            proj = planning.project(plan, cfg, lv, now)
            view = {"t": now, "rows": planning.grafik_view(proj), "source": proj["source"],
                    "raceEnd": planning.clock(proj["raceEnd"]) if proj["raceEnd"] else None}
            self.c.put("grafik", view)
            self._last_grafik = view
            if self._obs:
                try:
                    self.c.patch_root(f"obs/{self._obs}", {"grafik": view})
                except Exception:
                    pass
            self._cleanup(now)
            sent = self.c.get("notified") or {}
            for n in planning.due_notifications(proj, sent, now, float(cfg["notifyMin"])):
                who = next((d for d in cfg.get("drivers") or [] if d.get("name") == n["driver"]), None) or \
                    next((d for d in cfg.get("drivers") or [] if planning.same_name(d.get("name"), n["driver"])), None)
                if not who or not who.get("topic"):
                    continue
                title, body = planning.notification_text(n, now)
                self.c.put(f"notified/{n['key']}", n["start"])   # najpierw zapis: bez dubli
                planning.ntfy(who["topic"], title, body)
                self._log("ściana boksów", f"{n['driver']}: {body}", "powiadomienie", "ntfy")
        except Exception as e:
            print(f"[grafik] {e}")

    def _cleanup(self, now: int) -> None:
        """Co 10 min: stare wyniki zadań i wiadomości, których nikt nie odebrał (nie zajmują miejsca w bazie)."""
        if now - self._clean_t < 600000:
            return
        self._clean_t = now
        try:
            for old in ("jobs", "results", "worker"):      # pozostałości po serwerze AI zespołu (usunięty)
                if self.c.get(old) is not None:
                    self.c.delete(old)
            for feed, items in (self.c.get("pending") or {}).items():
                for mid, m in (items or {}).items():
                    if now - float((m or {}).get("t") or 0) > 1800000:
                        self.c.delete(f"pending/{feed}/{mid}")
        except Exception:
            pass

    def _team_message(self, frm: str, text: str, kind: str, feed: str = "", silent: bool = False) -> dict:
        feed = feed or self._default_feed() or "race"
        text = str(text or "")[:300]
        delivered = ""
        if kind == "pytanie" and silent:
            delivered = "tylko na ścianie"
        mid = self._log(frm, text, kind, delivered, feed)
        if kind == "pytanie" or not delivered:
            self.c.put(f"pending/{feed}/{mid}", {"t": _now(), "from": frm, "text": text, "kind": kind,
                                                 "silent": bool(silent)})
        return {"id": mid, "from": frm, "text": text, "kind": kind, "delivered": delivered, "feed": feed}

    def op_msg(self, b: dict) -> dict:
        return {"msg": self._team_message(b.get("from") or "zespół", b.get("text"), "wiadomość", b.get("feed") or "")}

    def op_ask(self, b: dict) -> dict:
        return {"msg": self._team_message(b.get("from") or "zespół", b.get("text"), "pytanie", b.get("feed") or "",
                                          bool(b.get("silent")))}

    def op_delivered(self, b: dict) -> dict:
        for mid in b.get("ids") or []:
            try:
                self.c.patch(f"msgs/{mid}", {"delivered": b.get("how") or "kierowca"})
            except Exception:
                pass
        return {}

    def op_remember(self, b: dict) -> dict:
        text = str(b.get("text") or "").strip()[:300]
        if not text:
            return {"ok": False, "error": "pusta notatka"}
        self.c.post("memory", {"t": _now(), "when": time.strftime("%Y-%m-%d %H:%M"), "who": b.get("who") or "zespół",
                               "track": b.get("track") or "", "car": b.get("car") or "", "text": text})
        return {}

    def op_memory(self, b: dict) -> dict:
        rows = list((self.c.get("memory") or {}).values())
        rows.sort(key=lambda r: r.get("t", 0))
        t = str(b.get("track") or "").lower()
        rows = [r for r in rows if not t or not r.get("track") or str(r["track"]).lower() == t]
        return {"notes": rows[-40:]}

    def op_log(self, b: dict) -> dict:
        extra = {"voice": True, "src": str(b.get("src") or "")} if b.get("voice") else None
        self._log(b.get("from") or "inżynier", b.get("text") or "", b.get("kind") or "inżynier", b.get("how") or "kierowca",
                  extra=extra)
        return {}

    def op_notify(self, b: dict) -> dict:
        """Powiadomienie na telefon (ntfy) od członka zespołu: {who, to (słowo z komendy albo „*”), text}."""
        from .notify_cmd import match_names
        drivers = [d for d in self._cfg().get("drivers") or [] if d.get("name")]
        names = match_names(str(b.get("to") or ""), [d["name"] for d in drivers])
        who = str(b.get("who") or "zespół")
        text = str(b.get("text") or "")[:300]
        sent, no_phone = [], []
        for d in drivers:
            if d["name"] not in names or d["name"] == who and b.get("to") == "*":
                continue
            if d.get("topic"):
                planning.ntfy(d["topic"], f"Pit Wall Crew – od {who}", text)
                sent.append(d["name"])
            else:
                no_phone.append(d["name"])
        if sent:
            self._log(who, f"📱 {', '.join(sent)}: {text}", "powiadomienie", "ntfy")
        return {"sent": sent, "no_phone": no_phone, "known": bool(names)}

    def op_handover(self, b: dict) -> dict:
        feed = b.get("feed") or "race"
        self.c.put(f"handover/{feed}", {"t": _now(), "from": b.get("who") or "?", "text": str(b.get("text") or "")[:700],
                                        "got": {}})
        if b.get("summary"):
            self._log("inżynier", str(b["summary"]), "podsumowanie stintu", "tylko na ścianie")
        return {}

    def op_trackmap(self, b: dict) -> dict:
        """Kształt toru (raz na tor) – do mapy na ścianie boksów i u obserwatorów."""
        key = str(b.get("key") or "")[:60]
        pts = b.get("points") or []
        if not key or len(pts) < 50:
            return {"ok": False, "error": "brak mapy"}
        rec = {"track": str(b.get("track") or key)[:80], "points": pts, "t": _now()}
        self.c.put(f"tracks/{key}", rec)
        obs = self._obs or (self._team()["meta"] or {}).get("obs")
        if obs:
            try:
                self.c.put_root(f"obs/{obs}/tracks/{key}", rec)
            except Exception:
                pass
        return {}

    # ---------------------------------------------------------- okrążenia do porównań w zespole
    @staticmethod
    def _k(x) -> str:
        import re
        return re.sub(r"[^A-Za-z0-9_-]+", "_", str(x or ""))[:60] or "x"

    def op_tlap_put(self, b: dict) -> dict:
        """Najszybsze okrążenie kierowcy w danych warunkach (koszyk) – nadpisuje tylko wolniejsze."""
        trk, drv, bk = self._k(b.get("trk")), self._k(b.get("drv")), self._k(b.get("bucket"))
        m, z = b.get("meta") or {}, str(b.get("z") or "")
        if not z or len(z) > 120000 or not m.get("lap_time"):
            return {"stored": False}
        old = self.c.get(f"tlapsi/{trk}/{drv}/{bk}")
        if isinstance(old, dict) and float(old.get("lap_time") or 1e9) <= float(m["lap_time"]):
            return {"stored": False}
        self.c.put(f"tlaps/{trk}/{drv}/{bk}", {"meta": m, "z": z})
        self.c.put(f"tlapsi/{trk}/{drv}/{bk}", m)
        return {"stored": True}

    def op_tlap_index(self, b: dict) -> dict:
        return {"index": self.c.get(f"tlapsi/{self._k(b.get('trk'))}") or {}}

    def op_tlap_get(self, b: dict) -> dict:
        return {"lap": self.c.get(f"tlaps/{self._k(b.get('trk'))}/{self._k(b.get('drv'))}/{self._k(b.get('bucket'))}")}

    def op_wear(self, b: dict) -> dict:
        """Zużycie opon w stincie (team/wearlog.py) – do planu opon na ścianie boksów."""
        rec = b.get("rec") or {}
        if not isinstance(rec.get("rates"), list) or len(rec["rates"]) != 4:
            return {"stored": False}
        self.c.put(f"wear/{self._k(b.get('tc'))}/{self._k(b.get('key'))}", rec)
        return {"stored": True}

    def op_view(self, b: dict) -> dict:
        """Skrót stanu (test połączenia w ustawieniach)."""
        t = self._team(fresh=True)
        cfg = planning.settings_of(t["settings"])
        feed = b.get("feed") or self._default_feed()
        live = self.c.get(f"live/{feed}") if feed else None
        g = self.c.get("grafik") or {}
        return {"kierowcy": [d.get("name") for d in cfg.get("drivers") or [] if d.get("name")],
                "team": (t["meta"] or {}).get("name"), "live": live,
                "age": round((_now() - float(live.get("_t") or 0)) / 1000) if live else None,
                "grafik": g.get("rows") or []}
