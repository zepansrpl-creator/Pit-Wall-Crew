"""Grafik stintów i powiadomienia przed zmianą kierowcy (przeniesione z Apps Script do programu).

Plan i ustawienia zespołu leżą w Firebase (/teams/<kod>/plan, /settings), edytuje się je na ścianie boksów.
Przelicza je co minutę program kierowcy, który jedzie (albo serwer AI zespołu): zapisuje prognozę grafiku
(/grafik) i wysyła powiadomienia ntfy przed zmianą i o deszczu.
"""

from __future__ import annotations

import json
import math
import time
import urllib.request
from datetime import datetime
from typing import Optional

DEFAULTS = {
    "raceStartMs": None, "raceHours": 24, "notifyMin": 30, "stintCorr": 0, "pitCallS": 25,
    "rainSlickK": 0.30, "rainWetBase": 0.06, "rainPitCost": 47, "lapTime": 245, "vePerLap": 9,
    "fuelPerLap": 7.5, "wear": [0, 0, 0, 0], "drivers": [],
}


def settings_of(raw: Optional[dict]) -> dict:
    s = dict(DEFAULTS)
    for k, v in (raw or {}).items():
        if v is not None and v != "":
            s[k] = v
    return s


def tyres_of(r: dict) -> Optional[str]:
    """Opony na postoju po stincie: „lewe”, „prawe”, „wszystkie cztery”, „bez zmiany opon”; None = plan nie mówi."""
    if "tyreL" in r or "tyreR" in r:
        L, R = bool(r.get("tyreL")), bool(r.get("tyreR"))
    else:
        sv = str(r.get("service") or "").lower()
        if not sv or "meta" in sv:
            return None
        L = any(w in sv for w in ("4 opony", "komplet", "lewe"))
        R = any(w in sv for w in ("4 opony", "komplet", "prawe"))
    return "wszystkie cztery" if L and R else "lewe" if L else "prawe" if R else "bez zmiany opon"


def same_name(a: str, b: str) -> bool:
    """„Maciej” = „maciej ” = „Maciej Szczepaniak” (lista kierowców na ścianie a wybór w planie)."""
    a, b = (a or "").strip().lower(), (b or "").strip().lower()
    return bool(a and b) and (a == b or a.split()[0] == b.split()[0])


def plan_of(raw) -> list[dict]:
    """Stinty z bazy (lista albo słownik numer -> stint), posortowane."""
    rows = list(raw.values()) if isinstance(raw, dict) else list(raw or [])
    out = []
    for r in rows:
        if not isinstance(r, dict):
            continue
        try:
            n = int(r.get("n") or 0)
        except (TypeError, ValueError):
            continue
        if n <= 0:
            continue
        out.append({"n": n, "laps": float(r.get("laps") or 0), "offsetMin": float(r.get("offsetMin") or 0),
                    "driver": str(r.get("driver") or "").strip(), "stopS": float(r.get("stopS") or 60),
                    "service": str(r.get("service") or ""), "lapsActual": float(r.get("lapsActual") or 0),
                    "tyres": tyres_of(r)})
    return sorted(out, key=lambda x: x["n"])


def live_for_plan(live: Optional[dict], cfg: dict, now_ms: float) -> Optional[dict]:
    if not live or now_ms - float(live.get("_t") or 0) > 120000:
        return None
    st = live.get("state") or {}
    if st.get("session") != "race":
        return None
    return {"stint": int(st.get("pit_stops") or 0) + 1 + int(cfg.get("stintCorr") or 0),
            "stintLaps": st.get("stint_laps"), "lapsLeft": st.get("laps_left"), "avgLap": st.get("avg_lap"),
            "maxStintLaps": st.get("max_stint_laps"), "timeRemaining": st.get("time_remaining"),
            "inPits": st.get("in_pits")}


def project(plan: list[dict], cfg: dict, live: Optional[dict], now_ms: float) -> dict:
    """Prognoza grafiku od bieżącej sytuacji (ta sama logika co wcześniej w arkuszu)."""
    lap = live["avgLap"] if (live and live.get("avgLap") and 60 < live["avgLap"] < 600) else float(cfg["lapTime"])
    by_n = {s["n"]: s for s in plan}
    planned = {}
    start_ms = cfg.get("raceStartMs")
    if start_ms:
        tp = float(start_ms)
        for s0 in plan:
            tp += s0["offsetMin"] * 60000
            planned[s0["n"]] = tp
            tp += (s0["lapsActual"] or s0["laps"]) * float(cfg["lapTime"]) * 1000 + s0["stopS"] * 1000
    stints = []
    if live:
        race_end = now_ms + live["timeRemaining"] * 1000 if live.get("timeRemaining") else \
            (float(start_ms) + float(cfg["raceHours"]) * 3600000 if start_ms else now_ms + float(cfg["raceHours"]) * 3600000)
        k = max(1, int(live.get("stint") or 1))
        laps_left = live["lapsLeft"] if live.get("lapsLeft") is not None else \
            ((by_n[k]["laps"] if k in by_n else 11) - (live.get("stintLaps") or 0))
        if k in by_n and live.get("stintLaps") is not None:
            laps_left = min(laps_left, max(0, by_n[k]["laps"] - live["stintLaps"]))
        t = now_ms + max(0, laps_left) * lap * 1000
        stints.append({"n": k, "driver": by_n[k]["driver"] if k in by_n else "", "start": None, "end": t,
                       "laps": None, "service": by_n[k]["service"] if k in by_n else "", "current": True})
        t += (by_n[k]["stopS"] if k in by_n else 60) * 1000
        k += 1
    else:
        if not start_ms:
            return {"stints": [], "raceEnd": None, "source": "brak daty wyścigu"}
        race_end = float(start_ms) + float(cfg["raceHours"]) * 3600000
        t = float(start_ms)
        k = 1
    max_laps = live["maxStintLaps"] if (live and live.get("maxStintLaps")) else 99
    guard = 0
    while t < race_end and guard < 80:
        guard += 1
        s = by_n.get(k) or {"n": k, "laps": plan[-1]["laps"] if plan else 11, "offsetMin": 0, "driver": "",
                            "stopS": 60, "service": ""}
        t += (s["offsetMin"] or 0) * 60000
        start = t
        laps = min(s["laps"] or 11, max_laps)
        end = start + laps * lap * 1000
        fin = False
        if end >= race_end:
            laps = math.ceil((race_end - start) / (lap * 1000))
            end = start + laps * lap * 1000
            fin = True
        stints.append({"n": k, "driver": s["driver"], "start": start, "end": end, "laps": laps,
                       "service": "META" if fin else s["service"], "current": False, "final": fin,
                       "deltaMin": round((start - planned[k]) / 60000) if k in planned else None})
        t = end + (s["stopS"] or 60) * 1000
        k += 1
    return {"stints": stints, "raceEnd": race_end, "source": "na żywo" if live else "plan"}


def due_notifications(proj: dict, sent: dict, now_ms: float, notify_min: float) -> list[dict]:
    out = []
    lst = proj["stints"]
    for i, s in enumerate(lst):
        if s.get("current") or not s["driver"] or s["start"] is None:
            continue
        prev = lst[i - 1]["driver"] if i > 0 else ""
        if prev and prev == s["driver"]:
            continue
        key = f"{s['n']}|{s['driver']}"
        for ch in ".#$[]/":
            key = key.replace(ch, "_")
        lead = (s["start"] - now_ms) / 60000
        if lead > notify_min or lead < -10:
            continue
        service = lst[i - 1]["service"] if i > 0 else ""
        if key not in sent:
            out.append({"key": key, "driver": s["driver"], "start": s["start"], "kind": "zmiana", "stint": s["n"],
                        "laps": s["laps"], "service": service})
        elif abs(s["start"] - float(sent[key])) >= 10 * 60000 and lead > 0:
            out.append({"key": key, "driver": s["driver"], "start": s["start"], "kind": "przesunięcie",
                        "stint": s["n"], "laps": s["laps"], "service": service, "oldStart": float(sent[key])})
    return out


def clock(ms: float) -> str:
    return datetime.fromtimestamp(ms / 1000).strftime("%H:%M")


def notification_text(n: dict, now_ms: float) -> tuple[str, str]:
    mins = max(0, round((n["start"] - now_ms) / 60000))
    if n["kind"] == "przesunięcie":
        return (f"Zmiana przesunięta: {n['driver']}",
                f"Twoja zmiana (stint {n['stint']}) przesunęła się na ok. {clock(n['start'])} "
                f"(było {clock(n['oldStart'])}), czyli za ok. {mins} min.")
    parts = [f"Stint {n['stint']}, start ok. {clock(n['start'])}"]
    if n.get("laps"):
        parts.append(f"ok. {n['laps']} okrążeń")
    body = ", ".join(parts) + "."
    if n.get("service"):
        body += f" Postój przed zmianą: {n['service']}."
    return f"Za {mins} min Twoja zmiana, {n['driver']}", body


def ntfy(topic: str, title: str, body: str) -> None:
    try:
        req = urllib.request.Request("https://ntfy.sh/", data=json.dumps(
            {"topic": topic, "title": title, "message": body, "priority": 4, "tags": ["checkered_flag"]}).encode("utf-8"),
            headers={"Content-Type": "application/json"})
        urllib.request.urlopen(req, timeout=10).read()
    except Exception as e:
        print(f"[powiadomienia] ntfy: {e}")


def targets(cfg: dict, plan: list[dict], st: Optional[dict]) -> dict:
    """Cele z planu zespołu dla inżyniera (to, co wcześniej dawał arkusz)."""
    stint = int((st or {}).get("pit_stops") or 0) + 1 + int(cfg.get("stintCorr") or 0)
    row = next((s for s in plan if s["n"] == stint), None)
    return {"ve_per_lap": cfg["vePerLap"], "fuel_per_lap": cfg["fuelPerLap"], "wear": cfg["wear"],
            "lap_time": cfg["lapTime"], "stint_laps": row["laps"] if row else None, "stint": stint,
            "service": row["service"] if row else "", "tyres": row["tyres"] if row else None,
            "tyre_budget": cfg.get("tyreBudget"), "pit_call_s": cfg["pitCallS"],
            "rain_slick_k": cfg["rainSlickK"], "rain_wet_base": cfg["rainWetBase"],
            "rain_pit_cost_s": cfg["rainPitCost"]}


def grafik_view(proj: dict) -> list[dict]:
    return [{"n": s["n"], "driver": s["driver"], "start": clock(s["start"]) if s["start"] else "jedzie",
             "end": clock(s["end"]), "laps": s["laps"], "service": s["service"], "current": bool(s.get("current")),
             "final": bool(s.get("final")), "delta": s.get("deltaMin")} for s in proj["stints"][:12]]
