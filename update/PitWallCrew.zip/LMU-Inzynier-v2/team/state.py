"""Stan auta do wysłania na ścianę boksów (małe JSON, co kilka sekund)."""

from __future__ import annotations

from typing import Optional

from engineer.analysis.fuel import fuel_report
from engineer.core import Engineer
from engineer.fmt import fmt_time
from engineer.model import Snapshot


def driving(snap: Snapshot) -> bool:
    """Czy na tym komputerze ktoś teraz prowadzi auto (a nie ogląda zmiennika)."""
    ps = snap.player_scoring()
    return snap.player is not None and ps is not None and ps.control == 0


def build(eng: Engineer, snap: Snapshot) -> dict:
    ps = snap.player_scoring()
    st: dict = {"session": snap.session, "phase": snap.phase, "track": snap.track, "car": snap.car_name,
                "time_remaining": snap.time_remaining, "fcy": snap.phase == "fcy"}
    from engineer.version import version
    st["version"] = version()
    if ps is None:
        return st
    cp, cn = eng.rivals.class_position(snap)
    st.update({"cls": ps.car_class, "pos": ps.place, "pos_class": cp, "n_class": cn, "laps_done": ps.laps_done,
               "last_lap": ps.last_lap, "best_lap": ps.best_lap, "in_pits": ps.in_pits, "pit_stops": ps.pit_stops,
               "driver": ps.driver})
    clean = [l for l in eng.laps if l.clean][-5:]
    if clean:
        st["avg_lap"] = round(sorted(l.lap_time for l in clean)[len(clean) // 2], 3)
    st["stint_laps"] = len(eng._stint_laps())
    fr = fuel_report(snap, eng.laps, eng.fuel_margin_laps)
    if fr:
        st["fuel_l"] = round(fr.fuel_l, 1)
        st["fuel_per_lap"] = round(fr.per_lap_l, 2) if fr.per_lap_l else None
        st["ve_pct"] = round(fr.ve * 100, 1) if fr.ve is not None else None
        st["ve_per_lap"] = round(fr.ve_per_lap * 100, 2) if fr.ve_per_lap else None
        st["laps_left"] = round(fr.stint_laps_left, 1) if fr.stint_laps_left is not None else None
        st["limiting"] = fr.limiting
        full = None
        if fr.ve_per_lap:
            full = 1.0 / fr.ve_per_lap
        if fr.per_lap_l and fr.capacity_l:
            full = min(full or 1e9, fr.capacity_l / fr.per_lap_l)
        st["max_stint_laps"] = int(full) if full else None
    p = snap.player
    if p is not None:
        st["tyres"] = [round(t.wear * 100, 1) for t in p.tyres]
        stint = [l for l in eng._stint_laps() if l.clean and len(l.wear_tyres) == 4]
        if len(stint) >= 2:
            n = len(stint) - 1
            st["tyre_rates"] = [round((stint[-1].wear_tyres[k] - stint[0].wear_tyres[k]) / n * 100, 2)
                                for k in range(4)]
        # temperatury opon: bieżnik (lewa/środek/prawa krawędź), karkas, ciśnienie, optimum z gry
        st["tyre_temps"] = [[round(x) for x in t.temp_c] for t in p.tyres]
        st["tyre_carcass"] = [round(t.carcass_c) for t in p.tyres]
        st["tyre_press"] = [round(t.pressure_kpa) for t in p.tyres]
        opt = [t.optimal_c for t in p.tyres if t.optimal_c and t.optimal_c > 0]
        st["tyre_opt"] = round(opt[0] - 273.15 if opt[0] > 200 else opt[0]) if opt else None
        st["compound"] = p.compound_front
        from engineer.analysis.damage_now import describe, level
        st["damage"] = level(snap, getattr(eng, "rest", None))
        st["damage_text"] = ", ".join(describe(snap, getattr(eng, "rest", None)))
        st["flat"] = any(p.wheel_flat)
    plan = None
    if snap.session == "race":
        plan, nxt = eng._laps_to_stop(snap)
        st["next_stop_laps"] = nxt
        sp = getattr(eng, "save_to_plan", None)
        st["save_to_plan"] = f"{sp[0]:.2f}".replace(".", ",") + sp[1] if sp else None
    if plan:
        st["plan_text"] = plan.speech() + ((" " + plan.outline) if plan.outline else "")
        sv = eng.saver.text() if hasattr(eng, "saver") else ""
        if sv:
            st["plan_text"] += " " + sv
        if plan.damage and plan.damage.loss_per_lap is not None:
            st["damage_loss"] = round(plan.damage.loss_per_lap, 2)
    if snap.session == "race":
        for r in eng.rivals.rivals(snap, ahead=1, behind=1):
            if r.gap_s is None:
                continue
            key = "behind" if r.gap_s > 0 else "ahead"
            if key not in st:
                st[key] = {"name": r.car.driver, "gap": round(r.gap_s, 1),
                           "trend": round(r.trend, 2) if r.trend is not None else None}
    if eng.weather.last is not None:
        st["weather"] = eng.weather.last.to_dict()
    else:
        st["weather"] = {"rain": snap.rain, "wetness": snap.wetness, "track_temp": snap.track_temp}
    st["weather"]["rain"] = snap.rain
    st["weather"]["wetness"] = snap.wetness
    st["weather"].update(eng.weather.sky())
    r = getattr(eng, "rest", None)
    if r is not None and r.ok:
        fc = r.forecast_text()
        if fc:
            st["weather"]["text"] = ((st["weather"].get("text") or "") + " " + fc).strip()
        if r.brakes:
            st["brakes_left"] = [round(b * 100) for b in r.brakes]
        pe = r.pit_estimate or {}
        if pe.get("total"):
            st["pit_estimate_game"] = round(float(pe["total"]), 1)
        if r.fuel_ratio:
            st["fuel_ratio"] = r.fuel_ratio
    if eng.engine.water > 0:
        st["engine"] = eng.engine.report().to_dict()
    rep = eng.fatigue.last or eng.fatigue.report(snap.t)
    st["fatigue"] = rep.to_dict()
    st["targets"] = eng.targets
    try:   # rywale w klasie: 4 przed, 4 za – odstęp, ostatnie okrążenie, kiedy zjadą, opony, aleja
        fr = fuel_report(snap, eng.laps, eng.fuel_margin_laps)
        typical = (1.0 / fr.ve_per_lap) if fr and fr.ve_per_lap else \
            ((fr.capacity_l / fr.per_lap_l) if fr and fr.per_lap_l and fr.capacity_l else None)
        st["rivals_table"] = eng.rival_pits.table(snap, eng.rivals, r, eng.strategist.params, typical)
        for row in st["rivals_table"]:
            if row["me"] and st.get("next_stop_laps") is not None:
                row["pit_in"] = st["next_stop_laps"]
    except Exception as e:
        st["rivals_error"] = str(e)[:100]
    return st


def lap_row(eng: Engineer, lap, stint: Optional[int]) -> dict:
    """Okrążenie do zakładki „Okrążenia” w arkuszu."""
    notes = []
    if lap.pit:
        notes.append("aleja")
    if lap.fcy:
        notes.append("FCY")
    if not lap.valid and not lap.incomplete:
        notes.append("nieważne")
    if lap.off_tracks:
        notes.append(f"poza torem x{lap.off_tracks}")
    if lap.impact:
        notes.append("uderzenie")
    return {"lap": lap.lap, "stint": stint, "time": round(lap.lap_time, 3), "time_txt": fmt_time(lap.lap_time),
            "fuel": round(lap.fuel_used, 2), "ve": round(lap.ve_used * 100, 2) if lap.ve_used else "",
            "wet": round(lap.wetness * 100), "track_temp": lap.track_temp, "compound": lap.compound,
            "notes": ", ".join(notes)}
