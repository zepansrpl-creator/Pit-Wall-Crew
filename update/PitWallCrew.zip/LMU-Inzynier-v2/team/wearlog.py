"""Zużycie opon zmierzone w jeździe – zapis do bazy zespołu (do planu opon na pit wallu).

Po każdym czystym okrążeniu (od 3 czystych okrążeń w stincie) program kierowcy zapisuje zużycie każdej opony
na okrążenie w tym stincie: /wear/<tor__auto>/<próbka> = {rates [LP, PP, LT, PT] w % na okrążenie, laps,
temp (średnia temperatura toru), compound, driver, t}. Próbka = jeden stint (nadpisywana, gdy stint rośnie).
Trening też się liczy – ważne, żeby to był ten sam tor i to samo auto. Na mokrym torze nie zapisujemy.
Pit wall liczy z próbek średnią (ważoną liczbą okrążeń) i to, o ile mniej opony zużywają się w chłodzie (noc).
"""

from __future__ import annotations

import re
import time
from typing import Optional


def _key(s: str) -> str:
    tr = str.maketrans("ąćęłńóśźżĄĆĘŁŃÓŚŹŻ", "acelnoszzACELNOSZZ")
    return re.sub(r"[^A-Za-z0-9_-]+", "_", (s or "").translate(tr)).strip("_")[:50] or "x"


def track_car_key(track: str, car: str) -> str:
    return f"{_key(track)}__{_key(car)}"


def sample(laps: list, session_tag: str, stint_no: int) -> Optional[tuple[str, str, dict]]:
    """(klucz tor__auto, klucz próbki, rekord) z okrążeń bieżącego stintu albo None."""
    stint = [l for l in laps if l.clean and not l.pit and len(l.wear_tyres) == 4 and l.wetness < 0.1]
    if len(stint) < 3:
        return None
    n = len(stint) - 1
    rates = [round((stint[-1].wear_tyres[k] - stint[0].wear_tyres[k]) / n * 100, 3) for k in range(4)]
    if any(r < 0 or r > 10 for r in rates) or max(rates) <= 0:
        return None                     # zmiana opon w środku albo błąd odczytu
    temps = [l.track_temp for l in stint if l.track_temp]
    last = stint[-1]
    rec = {"rates": rates, "laps": n, "temp": round(sum(temps) / len(temps), 1) if temps else None,
           "compound": last.compound or "", "driver": last.driver or "", "track": last.track, "car": last.car,
           "t": int(time.time() * 1000)}
    return track_car_key(last.track, last.car), f"{_key(last.driver)}_{session_tag}_{stint_no}_{stint[0].lap}", rec
