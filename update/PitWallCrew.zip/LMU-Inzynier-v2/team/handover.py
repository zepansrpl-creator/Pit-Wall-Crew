"""Zmiana kierowcy w wyścigu.

- Kierowca, który wsiada: krótka odprawa od swojego inżyniera z bieżących danych auta
  (pozycja, czas do mety, energia/paliwo, opony, uszkodzenia).
- Kierowca, który wysiada: jego inżynier zostawia na pit wallu odprawę dla następnego (plan, zużycie,
  oszczędzanie, ciśnienia, uwagi) – inżynier następnego kierowcy ją przeczyta – oraz podsumowanie stintu.
"""

from __future__ import annotations

import statistics
from typing import Optional

from engineer.analysis.damage_now import describe
from engineer.analysis.fuel import fuel_report
from engineer.fmt import fmt_time
from engineer.plnum import duration, ordinal, plural


def incoming_brief(eng, snap) -> Optional[str]:
    p, ps = snap.player, snap.player_scoring()
    if p is None or ps is None:
        return None
    parts = []
    cp, cn = eng.rivals.class_position(snap)
    if cp:
        parts.append(f"Jesteś {ordinal(cp)} w klasie")
    if snap.time_remaining:
        parts.append(f"do mety {duration(snap.time_remaining)}")
    head = ", ".join(parts)
    out = [head[0].upper() + head[1:] + "." if head else ""]
    res = []
    if p.virtual_energy is not None:
        res.append(f"energia {p.virtual_energy * 100:.0f}%")
    elif p.fuel_l:
        res.append(f"paliwo {p.fuel_l:.0f} litrów")
    if p.tyres and len(p.tyres) == 4:
        res.append(f"opony {100 - max(t.wear for t in p.tyres) * 100:.0f}%")
    if res:
        t = ", ".join(res)
        out.append(t[0].upper() + t[1:] + ".")
    dmg = describe(snap, getattr(eng, "rest", None))
    out.append(("Uszkodzenia: " + "; ".join(dmg) + ".") if dmg else "Auto bez uszkodzeń.")
    return " ".join(x for x in out if x)


def incidents_text(laps) -> str:
    """„W stincie 2 wyjazdy poza tor i 1 uderzenie.” albo „Stint bez wyjazdów i uderzeń.”"""
    off = sum(l.off_tracks for l in laps)
    imp = sum(1 for l in laps if l.impact)
    if not off and not imp:
        return "Stint czysty, bez wyjazdów poza tor i uderzeń."
    parts = []
    if off:
        parts.append(f"{off} {plural(off, 'wyjazd', 'wyjazdy', 'wyjazdów')} poza tor")
    if imp:
        parts.append(f"{imp} {plural(imp, 'uderzenie', 'uderzenia', 'uderzeń')}")
    return "W stincie " + " i ".join(parts) + "."


def outgoing(eng, snap, start_idx: int, who: str) -> tuple[str, str]:
    """(odprawa dla następnego kierowcy, podsumowanie stintu na pit wall)"""
    laps = eng.laps[start_idx:]
    brief = []
    # notatki kierowcy dla następnego („powiedz następnemu …”) – najważniejsze, więc pierwsze
    hn = list(getattr(eng, "handover_notes", []) or [])
    if hn:
        brief.append(("Notatka dla Ciebie: " if len(hn) == 1 else "Notatki dla Ciebie: ") + "; ".join(hn) + ".")
        eng.handover_notes = []
    brief.append(incidents_text(laps))
    dmg = describe(snap, getattr(eng, "rest", None))
    if dmg:
        brief.append("Auto zjechało z uszkodzeniami: " + "; ".join(dmg) + ".")
    plan = eng.plan()
    if plan is not None:
        if plan.outline:
            brief.append(plan.outline)
        elif plan.short():
            brief.append(plan.short())
    fr = fuel_report(snap, eng.laps, eng.fuel_margin_laps)
    if fr is not None:
        if fr.ve_per_lap:
            brief.append(f"Energia {fr.ve_per_lap * 100:.1f}% na okrążenie.".replace(".", ",", 1))
        elif fr.per_lap_l:
            brief.append(f"Paliwo {fr.per_lap_l:.1f} litra na okrążenie.".replace(".", ",", 1))
    sv = eng.saver.text()
    if sv:
        brief.append(sv)
    pr = eng.pressures.phrase()
    if pr:
        brief.append(pr[0].upper() + pr[1:] + " na następnym postoju.")
    notes = [n for n in getattr(eng, "notes_log", [])[-2:] if n not in hn]
    if notes:
        brief.append("Uwagi: " + "; ".join(notes) + ".")

    clean = [l for l in laps if l.clean and l.lap_time > 0]
    s = [f"Stint: {who}, {len(laps)} okr."]
    if clean:
        times = [l.lap_time for l in clean]
        s.append(f"średnio {fmt_time(statistics.mean(times))}, najlepsze {fmt_time(min(times))}")
        if len(times) >= 3:
            s.append(f"równość ±{statistics.pstdev(times):.1f} s")
    ve = [l.ve_used for l in clean if l.ve_used]
    if ve:
        s.append(f"energia {statistics.mean(ve) * 100:.1f}%/okr.")
    else:
        fu = [l.fuel_used for l in clean if l.fuel_used > 0]
        if fu:
            s.append(f"paliwo {statistics.mean(fu):.1f} l/okr.")
    off = sum(l.off_tracks for l in laps)
    imp = sum(1 for l in laps if l.impact)
    s.append(f"wyjazdy poza tor: {off}, uderzenia: {imp}")
    return " ".join(brief), ", ".join(s) + "."
