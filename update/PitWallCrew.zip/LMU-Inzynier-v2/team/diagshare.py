"""Diagnostyka za zgodą użytkownika: raporty awarii i dziennik ostatniej sesji dołączany do zgłoszenia.

Nic nie wychodzi z komputera bez zgody ([privacy] share_diag = true albo zaznaczone pole przy zgłoszeniu).
Przed wysłaniem tekst jest czyszczony: klucze, hasła, tokeny i nazwa użytkownika Windows w ścieżkach znikają.
Nagrania głosu nigdy nie są wysyłane.
"""

from __future__ import annotations

import collections
import hashlib
import json
import os
import re
import threading
import time

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
LOG = os.path.join(ROOT, "data", "ostatnia_sesja.log")
SENT = os.path.join(ROOT, "data", "raporty_awarii.json")
MAX_LOG = 20000           # znaków dziennika w jednym zgłoszeniu
MAX_CRASH_PER_DAY = 3

_lock = threading.Lock()
_tail: collections.deque[str] = collections.deque(maxlen=400)
_fh = None

_SECRET = [
    (re.compile(r"gsk_[A-Za-z0-9]{10,}"), "gsk_***"),                       # klucz Groq
    (re.compile(r"AIza[0-9A-Za-z_\-]{20,}"), "AIza***"),                    # klucze Google
    (re.compile(r"(?i)\b(key|klucz|password|has[łl]o|token|secret|auth)(\s*[:=]\s*)\S+"), r"\1\2***"),
    (re.compile(r"(?i)([A-Z]:\\Users\\)[^\\/\s]+"), r"\1~"),                # C:\Users\<nazwa>
    (re.compile(r"(/home/|/Users/)[^/\s]+"), r"\1~"),
    (re.compile(r"[A-Za-z0-9_\-]{40,}"), "***"),                            # długie tokeny
    (re.compile(r"[\w.+-]+@[\w-]+\.[\w.]+"), "***@***"),                    # adresy e-mail
]


def clean(text: str) -> str:
    for rx, rep in _SECRET:
        text = rx.sub(rep, text)
    return text


def session_start() -> None:
    """Nowa sesja inżyniera: dziennik od zera (tylko na tym komputerze)."""
    global _fh
    with _lock:
        _tail.clear()
        try:
            if _fh:
                _fh.close()
            os.makedirs(os.path.dirname(LOG), exist_ok=True)
            _fh = open(LOG, "w", encoding="utf-8")
        except OSError:
            _fh = None


def add(line: str) -> None:
    if line.startswith("@@ "):        # stan dla okna – za dużo danych, nie do dziennika
        return
    s = f"{time.strftime('%H:%M:%S')} {line}"
    with _lock:
        _tail.append(s)
        if _fh:
            try:
                _fh.write(s + "\n")
                _fh.flush()
            except OSError:
                pass


def last_log() -> str:
    """Koniec dziennika ostatniej sesji (z pamięci albo z pliku), już wyczyszczony."""
    with _lock:
        lines = list(_tail)
    if not lines:
        try:
            with open(LOG, encoding="utf-8", errors="replace") as f:
                lines = f.read().splitlines()[-400:]
        except OSError:
            lines = []
    return clean("\n".join(lines))[-MAX_LOG:]


def _post(rec: dict, timeout: float = 15.0) -> bool:
    import urllib.request
    from team.firebase import load_config
    try:
        url = load_config()["databaseURL"].rstrip("/") + "/feedback.json"
        req = urllib.request.Request(url, data=json.dumps(rec).encode("utf-8"), method="POST",
                                     headers={"Content-Type": "application/json"})
        with urllib.request.urlopen(req, timeout=timeout) as r:
            r.read()
        return True
    except Exception:
        return False


def _allowed_today(sig: str) -> bool:
    day = time.strftime("%Y-%m-%d")
    try:
        with open(SENT, encoding="utf-8") as f:
            d = json.load(f)
    except (OSError, ValueError):
        d = {}
    if d.get("day") != day:
        d = {"day": day, "sigs": []}
    if sig in d["sigs"] or len(d["sigs"]) >= MAX_CRASH_PER_DAY:
        return False
    d["sigs"].append(sig)
    try:
        with open(SENT, "w", encoding="utf-8") as f:
            json.dump(d, f)
    except OSError:
        pass
    return True


def send_crash(trace: str, where: str, lang: str = "pl", background: bool = True) -> bool:
    """Raport awarii (tylko gdy użytkownik się zgodził – sprawdza wywołujący). Ten sam błąd raz dziennie."""
    trace = clean(trace or "").strip()
    if not trace:
        return False
    last = [ln for ln in trace.splitlines() if ln.strip()][-3:]
    sig = hashlib.sha1("\n".join(re.sub(r"line \d+", "", x) for x in last).encode()).hexdigest()[:12]
    if not _allowed_today(sig):
        return False
    try:
        from engineer.version import version
        ver = version()
    except Exception:
        ver = "?"
    rec = {"t": int(time.time() * 1000), "kind": "awaria", "text": (where + ": " + last[-1])[:3000],
           "log": (trace[-8000:] + "\n\n--- dziennik ---\n" + last_log())[-MAX_LOG:], "version": ver,
           "from": "aplikacja", "lang": lang}
    if background:
        threading.Thread(target=_post, args=(rec,), daemon=True).start()
        return True
    return _post(rec)
