"""Komenda głosowa „powiadomienie na telefon <imię>: <treść>” – natychmiastowe powiadomienie ntfy do kolegi.

Przykłady: „Powiadomienie na telefon Amadeusz: wstawaj, zaraz wsiadasz”, „powiadom Amadeusza, że zaraz wsiada”,
„wyślij Patrykowi powiadomienie: zjedź do boksu”, „powiadomienie dla wszystkich: zaczyna padać”.
Imię może być w dowolnym przypadku (Amadeusz, Amadeusza, Amadeuszowi, Maćkowi) – dopasowanie po początku imienia.
"""

from __future__ import annotations

import re
import unicodedata
from typing import Optional

FILLER = {"inzynier", "inzynierze", "wyslij", "wysli", "powiadomienie", "powiadomienia", "powiadom", "push", "na",
          "telefon", "telefonu", "do", "dla", "sms", "wiadomosc", "ze", "prosze", "pilne", "pilnie"}
ALL = {"wszystkim", "wszystkich", "wszyscy", "zespol", "zespolowi", "calemu", "caly", "ekipie", "ekipa"}


def _fold(s: str) -> str:
    s = s.lower().replace("ł", "l")
    return "".join(c for c in unicodedata.normalize("NFD", s) if unicodedata.category(c) != "Mn")


def parse(raw: str) -> Optional[tuple[str, str]]:
    """(do kogo – słowo albo „*” dla wszystkich, treść) albo None, gdy to nie jest ta komenda."""
    words = raw.strip().split()
    folded = [re.sub(r"[^a-z0-9]", "", _fold(w)) for w in words]
    j = 1 if folded and folded[0].startswith("inzynier") else 0      # „Inżynier, powiadom …”
    first = folded[j] if j < len(folded) else ""
    if not (first.startswith("powiadom") or first == "push"
            or (first.startswith("wysl") and any(w.startswith(("telefon", "powiadom")) for w in folded[j:j + 4]))):
        return None
    i = 0
    while i < len(words) and folded[i] in FILLER:
        i += 1
    if i >= len(words):
        return ("", "")
    if folded[i] in ALL:
        to = "*"
        i += 1
        while i < len(words) and folded[i] in ALL:
            i += 1
    else:
        to = folded[i]
        i += 1
    while i < len(words) and folded[i] in FILLER:      # „… Amadeuszowi powiadomienie: …”, „…, że …”
        i += 1
    text = " ".join(words[i:]).strip(" ,:;-–")
    return (to, text[:1].upper() + text[1:] if text else "")


def match_names(word: str, names: list[str]) -> list[str]:
    """Kierowcy pasujący do słowa (Amadeuszowi → Amadeusz, Maćkowi → Maciej). „*” = wszyscy."""
    if word == "*":
        return list(names)
    w = _fold(word)
    best, best_n = [], 0
    for n in names:
        f = re.sub(r"[^a-z0-9]", "", _fold(n.split()[0] if n.split() else n))
        k = 0
        while k < min(len(f), len(w)) and f[k] == w[k]:
            k += 1
        if k >= 3 and (k >= len(f) - 2 or k >= 4 or len(w) <= len(f) + 4):
            if k > best_n:
                best, best_n = [n], k
            elif k == best_n:
                best.append(n)
    return best
