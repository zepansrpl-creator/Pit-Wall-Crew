"""Radio zespołu: komunikaty inżyniera słyszą wszyscy członkowie zespołu we własnej aplikacji.

Program kierowcy, który jedzie, zapisuje każdy zwykły (niepilny) komunikat w radiu zespołu (msgs, voice=True).
Aplikacje pozostałych członków zespołu nasłuchują radia (Firebase, Server-Sent Events) i odtwarzają je tym
samym głosem inżyniera. Pilne ostrzeżenia słyszy tylko kierowca.
"""

from __future__ import annotations

import threading
import time
from typing import Callable, Optional


class TeamRadio:
    def __init__(self, client, on_msg: Callable[[dict], None]) -> None:
        self.c = client
        self.on_msg = on_msg
        self.stop = threading.Event()
        self.last_t = int(time.time() * 1000)
        self._seen: set = set()

    def start(self) -> None:
        threading.Thread(target=self._run, daemon=True).start()

    def _query(self) -> dict:
        return {"orderBy": "t", "startAt": self.last_t}

    def _run(self) -> None:
        self.c.stream("msgs", self._query, self._event, self.stop)

    def _event(self, event: str, path: str, data) -> None:
        items: list[tuple[str, dict]] = []
        if path == "/" and isinstance(data, dict):            # stan początkowy (od ostatniej wiadomości)
            items = [(k, v) for k, v in data.items() if isinstance(v, dict)]
        elif path.count("/") == 1 and isinstance(data, dict):  # nowa wiadomość
            items = [(path[1:], data)]
        for mid, m in sorted(items, key=lambda kv: kv[1].get("t", 0)):
            if mid in self._seen:
                continue
            self._seen.add(mid)
            self.last_t = max(self.last_t, int(m.get("t") or 0))
            try:
                self.on_msg(dict(m, id=mid))
            except Exception:
                pass


def spoken_text(m: dict, me: str) -> Optional[str]:
    """Co odczytać z wiadomości radia zespołu u członka zespołu, który nie jedzie (None = nic)."""
    if time.time() * 1000 - float(m.get("t") or 0) > 30000:
        return None                                   # stare (np. po przerwie w połączeniu)
    kind = m.get("kind") or ""
    frm = str(m.get("from") or "")
    if kind == "ostrzeżenie" or m.get("delivered") == "tylko na ścianie" or m.get("how") == "tylko na ścianie":
        return None
    if m.get("voice"):
        return None if m.get("src") == me else str(m.get("text") or "")
    if kind == "wiadomość" and frm and frm != me:
        from engineer.plnum import genitive_name
        return f"Wiadomość od {genitive_name(frm)}: {m.get('text') or ''}"
    return None
