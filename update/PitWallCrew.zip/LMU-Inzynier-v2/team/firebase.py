"""Firebase (darmowy plan Spark): logowanie zespołu i Realtime Database przez REST – bez dodatkowych bibliotek.

Zespół = konto e-mail/hasło w Firebase Authentication o adresie <kod>@pitwallcrew.team (adres nie musi istnieć).
Kod zespołu i hasło znają tylko członkowie. Reguły bazy wpuszczają do /teams/<kod> tylko zalogowanych tym kontem.
"""

from __future__ import annotations

import json
import os
import random
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
from typing import Any, Optional

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
CONFIG_FILE = os.path.join(ROOT, "firebase_config.json")
DOMAIN = "pitwallcrew.team"
ALPHABET = "abcdefghjkmnpqrstuvwxyz23456789"   # bez 0/o, 1/l/i – łatwo podyktować


class FirebaseError(RuntimeError):
    pass


def load_config() -> dict:
    """Konfiguracja projektu (apiKey, databaseURL…) – plik firebase_config.json w folderze programu."""
    try:
        with open(CONFIG_FILE, encoding="utf-8") as f:
            cfg = json.load(f)
        if cfg.get("apiKey") and cfg.get("databaseURL"):
            return cfg
    except (OSError, ValueError):
        pass
    return {}


def team_email(code: str) -> str:
    return f"{code.strip().lower()}@{DOMAIN}"


def new_code(n: int = 6) -> str:
    return "".join(random.choice(ALPHABET) for _ in range(n))


_local = threading.local()
SILENT = {"print": "silent"}   # Firebase nie odsyła zapisanych danych (204) – mniej pobranych bajtów


def _err(msg, status: int) -> FirebaseError:
    try:
        m = json.loads(msg)
        m = (m.get("error") or {}).get("message") if isinstance(m.get("error"), dict) else m.get("error")
    except Exception:
        m = msg
    err = FirebaseError(str(m or status))
    err.status = status   # type: ignore[attr-defined]
    return err


def _keepalive(method: str, url: str, data: Optional[bytes], timeout: float) -> Any:
    """Zapytanie przez trwałe połączenie HTTPS (jedno na wątek i serwer).

    Firebase liczy do darmowego limitu także narzut szyfrowania: nowe połączenie przy każdym zapytaniu
    (uścisk dłoni TLS, kilka KB) kosztowałoby setki MB na dobę. Trwałe połączenie – kilkaset bajtów na zapytanie.
    """
    import http.client
    u = urllib.parse.urlsplit(url)
    pool = getattr(_local, "pool", None)
    if pool is None:
        pool = _local.pool = {}
    path = u.path + ("?" + u.query if u.query else "")
    headers = {"Content-Type": "application/json", "Connection": "keep-alive"}
    for attempt in (0, 1):
        conn = pool.get(u.netloc)
        if conn is None:
            conn = pool[u.netloc] = http.client.HTTPSConnection(u.netloc, timeout=timeout)
        try:
            conn.timeout = timeout
            if conn.sock is not None:
                conn.sock.settimeout(timeout)
            conn.request(method, path, body=data, headers=headers)
            r = conn.getresponse()
            raw = r.read().decode("utf-8")
            if r.status >= 400:
                raise _err(raw, r.status)
            return json.loads(raw) if raw else None
        except FirebaseError:
            raise
        except Exception:
            conn.close()
            pool.pop(u.netloc, None)
            if attempt:
                raise
    return None


def _http(method: str, url: str, body: Any = None, timeout: float = 20.0) -> Any:
    data = None if body is None else json.dumps(body).encode("utf-8")
    if not (os.environ.get("HTTPS_PROXY") or os.environ.get("https_proxy")):
        return _keepalive(method, url, data, timeout)
    req = urllib.request.Request(url, data=data, method=method, headers={"Content-Type": "application/json"})
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            raw = r.read().decode("utf-8")
    except urllib.error.HTTPError as e:
        raise _err(e.read().decode("utf-8", "replace"), e.code)
    return json.loads(raw) if raw else None


AUTH_ERRORS = {
    "EMAIL_EXISTS": "taki zespół już istnieje",
    "EMAIL_NOT_FOUND": "nie ma zespołu o tym kodzie",
    "INVALID_PASSWORD": "złe hasło zespołu",
    "INVALID_LOGIN_CREDENTIALS": "zły kod albo hasło zespołu",
    "WEAK_PASSWORD : Password should be at least 6 characters": "hasło musi mieć co najmniej 6 znaków",
    "TOO_MANY_ATTEMPTS_TRY_LATER": "za dużo prób, spróbuj za kilka minut",
    "OPERATION_NOT_ALLOWED": "w projekcie Firebase nie włączono logowania e-mail/hasło",
}


def _auth_error(e: FirebaseError) -> FirebaseError:
    s = str(e)
    for k, v in AUTH_ERRORS.items():
        if s.startswith(k.split(" :")[0]):
            return FirebaseError(v)
    return FirebaseError(s)


class FbClient:
    """Zalogowany klient bazy jednego zespołu. Ścieżki są względne do /teams/<kod>."""

    def __init__(self, code: str, password: str, cfg: Optional[dict] = None) -> None:
        self.cfg = cfg or load_config()
        if not self.cfg:
            raise FirebaseError("brak pliku firebase_config.json")
        self.code = code.strip().lower()
        self.password = password
        self.api_key = self.cfg["apiKey"]
        self.db = self.cfg["databaseURL"].rstrip("/")
        self._id_token: Optional[str] = None
        self._refresh: Optional[str] = None
        self._exp = 0.0
        self._lock = threading.Lock()

    # ------------------------------------------------------------ konto zespołu
    @classmethod
    def create_team(cls, password: str, name: str = "", cfg: Optional[dict] = None, code: str = "") -> "FbClient":
        cfg = cfg or load_config()
        for _ in range(5):
            c = code or new_code()
            try:
                out = _http("POST", "https://identitytoolkit.googleapis.com/v1/accounts:signUp?key=" + cfg["apiKey"],
                            {"email": team_email(c), "password": password, "returnSecureToken": True})
            except FirebaseError as e:
                if "EMAIL_EXISTS" in str(e) and not code:
                    continue
                raise _auth_error(e)
            cl = cls(c, password, cfg)
            cl._set_tokens(out)
            obs = "o" + new_code(15)
            cl.put("meta", {"name": name or c.upper(), "created": int(time.time() * 1000), "obs": obs})
            cl.put_root(f"obs/{obs}/team", c)
            return cl
        raise FirebaseError("nie udało się wylosować wolnego kodu zespołu")

    def _set_tokens(self, out: dict) -> None:
        self._id_token = out.get("idToken") or out.get("id_token")
        self._refresh = out.get("refreshToken") or out.get("refresh_token") or self._refresh
        self._exp = time.time() + int(out.get("expiresIn") or out.get("expires_in") or 3600) - 120

    def sign_in(self) -> None:
        try:
            out = _http("POST", "https://identitytoolkit.googleapis.com/v1/accounts:signInWithPassword?key=" + self.api_key,
                        {"email": team_email(self.code), "password": self.password, "returnSecureToken": True})
        except FirebaseError as e:
            raise _auth_error(e)
        self._set_tokens(out)

    def token(self) -> str:
        with self._lock:
            if self._id_token and time.time() < self._exp:
                return self._id_token
            if self._refresh:
                try:
                    body = urllib.parse.urlencode({"grant_type": "refresh_token", "refresh_token": self._refresh}).encode()
                    req = urllib.request.Request("https://securetoken.googleapis.com/v1/token?key=" + self.api_key,
                                                 data=body, headers={"Content-Type": "application/x-www-form-urlencoded"})
                    with urllib.request.urlopen(req, timeout=20) as r:
                        self._set_tokens(json.loads(r.read().decode("utf-8")))
                    return self._id_token  # type: ignore[return-value]
                except Exception:
                    pass
            self.sign_in()
            return self._id_token  # type: ignore[return-value]

    # ------------------------------------------------------------ baza
    def _url(self, path: str, root: bool = False, query: Optional[dict] = None) -> str:
        base = self.db + "/" + (path if root else f"teams/{self.code}/{path}").strip("/") + ".json"
        q = {"auth": self.token()}
        if query:
            q.update({k: (json.dumps(v) if isinstance(v, str) and k in ("orderBy", "startAt", "endAt", "equalTo")
                          else v) for k, v in query.items()})
        return base + "?" + urllib.parse.urlencode(q)

    def _req(self, method: str, path: str, body: Any = None, root: bool = False, query: Optional[dict] = None,
             timeout: float = 20.0) -> Any:
        try:
            return _http(method, self._url(path, root, query), body, timeout)
        except FirebaseError as e:
            if getattr(e, "status", 0) == 401:     # token wygasł mimo wszystko: zaloguj ponownie i powtórz
                with self._lock:
                    self._id_token = None
                    self._exp = 0
                return _http(method, self._url(path, root, query), body, timeout)
            raise

    def stream(self, path: str, query: Optional[dict], on_event, stop: threading.Event) -> None:
        """Nasłuch zmian (Server-Sent Events) aż do stop. on_event(rodzaj, ścieżka, dane).

        Po zerwaniu połączenia albo wygaśnięciu tokenu łączy się ponownie (query może być funkcją,
        żeby po przerwie zacząć od ostatniej wiadomości)."""
        backoff = 1.0
        while not stop.is_set():
            try:
                q = query() if callable(query) else query
                req = urllib.request.Request(self._url(path, query=q), headers={"Accept": "text/event-stream"})
                with urllib.request.urlopen(req, timeout=75) as r:
                    backoff = 1.0
                    event = None
                    while not stop.is_set():
                        line = r.readline()
                        if not line:
                            break
                        line = line.decode("utf-8").rstrip("\r\n")
                        if line.startswith("event:"):
                            event = line[6:].strip()
                        elif line.startswith("data:") and event:
                            raw = line[5:].strip()
                            if event in ("put", "patch"):
                                try:
                                    d = json.loads(raw)
                                    on_event(event, d.get("path", "/"), d.get("data"))
                                except Exception:
                                    pass
                            elif event in ("auth_revoked", "cancel"):
                                with self._lock:
                                    self._exp = 0          # nowy token przy ponownym połączeniu
                                break
                            event = None
            except Exception:
                stop.wait(backoff)
                backoff = min(30.0, backoff * 2)

    def get(self, path: str, query: Optional[dict] = None, timeout: float = 20.0) -> Any:
        return self._req("GET", path, query=query, timeout=timeout)

    def put(self, path: str, value: Any) -> Any:
        return self._req("PUT", path, value, query=SILENT)   # bez odsyłania zapisanych danych (transfer)

    def patch(self, path: str, value: dict) -> Any:
        return self._req("PATCH", path, value, query=SILENT)

    def post(self, path: str, value: Any) -> str:
        return (self._req("POST", path, value) or {}).get("name", "")

    def delete(self, path: str) -> None:
        self._req("DELETE", path, query=SILENT)

    def put_root(self, path: str, value: Any) -> Any:
        return self._req("PUT", path, value, root=True, query=SILENT)

    def patch_root(self, path: str, value: dict) -> Any:
        return self._req("PATCH", path, value, root=True, query=SILENT)
