"""Zgłoszenia problemów i sugestii: zapis do bazy Pit Wall Crew (feedback/), czyta je tylko autor programu."""

from __future__ import annotations

import json
import time
import urllib.request

from team.firebase import load_config


def send(kind: str, text: str, contact: str = "", who: str = "", team: str = "", lang: str = "pl",
         timeout: float = 15.0, log: str = "") -> tuple[bool, str]:
    """Wysyła zgłoszenie. Zwraca (udało się, komunikat dla użytkownika)."""
    text = (text or "").strip()
    if len(text) < 5:
        return False, "Napisz kilka słów."
    try:
        from engineer.version import version
        ver = version()
    except Exception:
        ver = "?"
    rec = {"t": int(time.time() * 1000), "kind": kind if kind in ("problem", "sugestia") else "problem",
           "text": text[:3000], "contact": (contact or "").strip()[:120], "who": (who or "")[:40],
           "team": (team or "")[:20], "version": ver, "from": "aplikacja", "lang": lang}
    if log:     # dziennik ostatniej sesji – tylko gdy użytkownik zaznaczył (już wyczyszczony z kluczy i haseł)
        rec["log"] = log[-20000:]
    try:
        url = load_config()["databaseURL"].rstrip("/") + "/feedback.json"
        req = urllib.request.Request(url, data=json.dumps(rec).encode("utf-8"), method="POST",
                                     headers={"Content-Type": "application/json"})
        with urllib.request.urlopen(req, timeout=timeout) as r:
            r.read()
        return True, "Dziękuję! Zgłoszenie wysłane."
    except Exception as e:
        return False, f"Nie udało się wysłać ({str(e)[:80]}). Sprawdź internet i spróbuj jeszcze raz."
