"""Połączenie z centrum zespołu (Firebase, przez team.fbbackend; adres HTTP tylko w testach).

Wszystko idzie przez jeden adres …/exec (POST z JSON). Apps Script odpowiada przekierowaniem 302,
które urllib wykonuje jako GET – tak działa każdy klient aplikacji internetowych Google.
Wysyłanie stanu odbywa się w osobnym wątku, żeby powolna sieć nigdy nie blokowała inżyniera.
"""

from __future__ import annotations

import json
import threading
import time
import urllib.request
from typing import Optional


class Hub:
    def __init__(self, url: str, key: str, who: str, timeout: float = 30.0, backend=None) -> None:
        self.backend = backend           # Firebase (team/fbbackend.py); bez niego – stary adres Apps Script
        self.url = url.strip()
        self.key = key.strip()
        self.who = who.strip() or "kierowca"
        self.timeout = timeout
        self.ok = False                  # ostatnie połączenie się udało
        self.error = ""
        self.bot = False                 # bot Discord na laptopie działa
        self.ai = False                  # AI na laptopie działa
        self.stt = False                 # rozpoznawanie mowy na laptopie działa
        self.groq_key = ""               # klucz Groq zespołu (z ustawień na ścianie boksów)
        self._seen_msgs: set[str] = set()
        self.targets: dict = {}          # plan zespołu z arkusza
        self.inbox: list[dict] = []      # wiadomości zespołu do przeczytania kierowcy
        self.asks: list[dict] = []       # pytania zespołu do inżyniera
        self.handover: Optional[dict] = None   # odprawa od kierowcy, który wysiadł
        self._lock = threading.Lock()
        self._pending_laps: list[dict] = []
        self._state: Optional[dict] = None
        self._driving = False
        self._wake = threading.Event()
        self.events: list[str] = []      # diagnostyka do dziennika rozmowy (błędy, wolne połączenia)
        self.enabled = bool(backend) or bool(self.url and self.key)

    # ------------------------------------------------------------ niski poziom
    def call(self, payload: dict, timeout: Optional[float] = None) -> dict:
        if self.backend is not None:
            out = self.backend.call(dict(payload))
            if not out.get("ok", False):
                raise RuntimeError(out.get("error", "błąd centrum zespołu"))
            return out
        body = dict(payload, k=self.key)
        req = urllib.request.Request(self.url, data=json.dumps(body).encode("utf-8"),
                                     headers={"Content-Type": "text/plain;charset=utf-8"})
        with urllib.request.urlopen(req, timeout=timeout or self.timeout) as r:
            out = json.loads(r.read().decode("utf-8"))
        if not out.get("ok", False):
            raise RuntimeError(out.get("error", "błąd centrum zespołu"))
        return out

    # ------------------------------------------------------------ stan auta
    def start(self, interval: float = 4.0) -> None:
        if not self.enabled:
            return
        threading.Thread(target=self._loop, args=(interval,), daemon=True).start()

    def push(self, state: dict, driving: bool) -> None:
        with self._lock:
            self._state = state
            self._driving = driving

    def add_lap(self, lap: dict) -> None:
        with self._lock:
            self._pending_laps.append(lap)

    def _loop(self, interval: float) -> None:
        while True:
            with self._lock:
                state, driving, laps = self._state, self._driving, list(self._pending_laps)
            payload = {"op": "state", "who": self.who, "driving": driving, "state": state or {}, "laps": laps}
            t0 = time.monotonic()
            try:
                out = self.call(payload, timeout=20)
                dt = time.monotonic() - t0
                with self._lock:
                    if not self.ok and self.error:
                        self.events.append(f"połączenie wróciło ({dt:.1f} s)")
                    elif dt > 8:
                        self.events.append(f"wolne połączenie ze ścianą boksów: {dt:.1f} s")
                self.ok, self.error = True, ""
                with self._lock:
                    del self._pending_laps[:len(laps)]
                    self.bot, self.ai = bool(out.get("bot")), bool(out.get("ai"))
                    self.stt = bool(out.get("stt"))
                    self.groq_key = out.get("groq") or ""
                    if out.get("targets"):
                        self.targets = out["targets"]
                    new = [m for m in out.get("msgs", []) if m["id"] not in self._seen_msgs]
                    self._seen_msgs.update(m["id"] for m in new)
                    self.inbox += new
                    self.asks += out.get("asks", [])
                    if out.get("handover"):
                        self.handover = out["handover"]
            except Exception as e:  # sieć, limit Google, zły klucz – próbujemy dalej
                if self.ok or not self.error:
                    with self._lock:
                        self.events.append(f"błąd połączenia po {time.monotonic() - t0:.1f} s: {str(e)[:100]}")
                self.ok, self.error = False, str(e)[:120]
            self._wake.wait(interval)
            self._wake.clear()

    def remember(self, text: str, track: str = "", car: str = "") -> None:
        """Notatka do pamięci zespołu (zakładka „Pamięć zespołu”), czytana przez AI przy pytaniach."""
        if self.enabled:
            self._bg({"op": "remember", "who": self.who, "text": text, "track": track, "car": car})

    def take_handover(self) -> Optional[dict]:
        with self._lock:
            h, self.handover = self.handover, None
        return h

    def send_handover(self, text: str, summary: str) -> None:
        if self.enabled:
            self._bg({"op": "handover", "who": self.who, "feed": "race", "text": text, "summary": summary})

    def take_inbox(self) -> list[dict]:
        with self._lock:
            m, self.inbox = self.inbox, []
        return m

    def take_asks(self) -> list[dict]:
        with self._lock:
            a, self.asks = self.asks, []
        return a

    def delivered(self, ids: list[str], how: str = "kierowca") -> None:
        if ids:
            self._bg({"op": "delivered", "ids": ids, "how": how})

    # ------------------------------------------------------------ zadania dla laptopa
    def job(self, kind: str, payload: dict) -> str:
        return self.call({"op": "job", "kind": kind, "who": self.who, "payload": payload})["id"]

    def wait(self, job_id: str, total: float = 25.0) -> Optional[dict]:
        end = time.monotonic() + total
        while time.monotonic() < end:
            left = max(1.0, min(20.0, end - time.monotonic()))
            out = self.call({"op": "wait", "id": job_id, "wait": left}, timeout=left + 15)
            if out.get("done"):
                return out.get("result") or {}
        return None

    def say(self, text: str, kind: str = "inżynier") -> None:
        """Odczyt na Discordzie przez bota na laptopie (w tle)."""
        self._bg({"op": "job", "kind": "say", "who": self.who, "payload": {"text": text, "kind": kind}})

    def _bg(self, payload: dict) -> None:
        def run():
            try:
                self.call(payload, timeout=20)
            except Exception as e:
                self.error = str(e)[:120]
        threading.Thread(target=run, daemon=True).start()


def make_hub(team_cfg: dict, who: str = "") -> "Hub":
    """Hub z ustawień [team]: kod i hasło zespołu = Firebase; bez nich hub wyłączony (tryb bez zespołu)."""
    who = who or team_cfg.get("name", "kierowca")
    code, pw = str(team_cfg.get("code") or "").strip(), str(team_cfg.get("password") or "")
    if code and pw:
        from .fbbackend import FbBackend
        from .firebase import FbClient, load_config
        if load_config():
            return Hub("", "", who, backend=FbBackend(FbClient(code, pw)))
        print("[zespół] Brak pliku firebase_config.json – działam bez zespołu.")
    url = str(team_cfg.get("url") or "")
    if url.startswith("http://127.0.0.1"):          # tylko testy (tests/mock_hub.py)
        return Hub(url, team_cfg.get("key", ""), who)
    return Hub("", "", who)
