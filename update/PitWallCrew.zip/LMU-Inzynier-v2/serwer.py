"""Serwer AI zespołu (Pit Wall Crew).

Działa cały wyścig. Łączy się wyłącznie „na zewnątrz” (do arkusza Google i do Discorda),
więc nie trzeba nic ustawiać w routerze. Robi:
- rozpoznawanie mowy z przycisku kierowcy (Whisper na karcie graficznej),
- odpowiedzi AI na pytania spoza reguł (Ollama z Bielikiem albo Claude),
- bota Discord, który mówi głosem inżyniera na kanale zespołu i przyjmuje komendy !i / !w / !stan.

Uruchomienie: python serwer.py      (albo skrót „Pit Wall Crew - serwer AI”)
"""

from __future__ import annotations

import argparse
import base64
import os
import sys
import threading
import time
import tomllib
from concurrent.futures import ThreadPoolExecutor

from team.hub import Hub, make_hub  # noqa: F401


def load_config(path: str) -> dict:
    for p in (path, "serwer.example.toml"):
        if os.path.exists(p):
            with open(p, "rb") as f:
                return tomllib.load(f)
    return {}


class Server:
    def __init__(self, cfg: dict, no_discord: bool = False, fake: bool = False) -> None:
        team, ai, voice, dc = cfg.get("team", {}), cfg.get("ai", {}), cfg.get("voice", {}), cfg.get("discord", {})
        self.hub = make_hub(team, "serwer AI")
        if not self.hub.enabled:
            sys.exit("Brak kodu i hasła zespołu w serwer.toml (sekcja [team]) – uruchom ustawienia serwera.")
        self.pool = ThreadPoolExecutor(max_workers=4)
        self.stt = self.llm = self.bot = self.tts = None
        self.fake = fake
        self.say_lock = threading.Lock()

        # rozpoznawanie mowy
        if fake:
            self.stt = _FakeSTT()
        elif cfg.get("listen", {}).get("enabled", True):
            try:
                from laptop.stt import WhisperSTT
                lc = cfg.get("listen", {})
                print("[mowa] Ładuję Whisper (za pierwszym razem pobiera model)...")
                self.stt = WhisperSTT(lc.get("whisper_model", "large-v3-turbo"), lc.get("device", "auto"),
                                      lc.get("cpu_model", "small"))
                print(f"[mowa] Gotowe: {self.stt.name}.")
            except Exception as e:
                print(f"[mowa] Rozpoznawanie mowy niedostępne: {e}")

        # AI
        mode = ai.get("mode", "local")
        if fake:
            self.llm = _FakeLLM()
        elif mode == "local":
            from engineer.local_ai import DEFAULT_MODEL, OllamaEngineer
            llm = OllamaEngineer(model=ai.get("local_model") or DEFAULT_MODEL,
                                 url=ai.get("ollama_url", "http://localhost:11434"))
            llm.ensure_running()
            if llm.available():
                llm.warm_up()
                self.llm = llm
                print(f"[AI] Lokalny model: {llm.model}.")
            else:
                print(f"[AI] Lokalny model niedostępny: {llm.status}.")
        elif mode == "claude":
            from engineer.ai import AIEngineer
            llm = AIEngineer(model=ai.get("model", "claude-haiku-5-5"), api_key=ai.get("api_key") or None)
            if llm.online:
                self.llm = llm
                print(f"[AI] Claude: {llm.model}.")

        # głos i Discord
        if not no_discord and dc.get("token"):
            from laptop.discord_bot import DiscordBot
            from laptop.tts import TTS
            self.tts = TTS(voice.get("edge_voice", "pl-PL-MarekNeural"), voice.get("rate", "+10%"),
                           voice.get("pitch", "+0Hz"), bool(voice.get("radio", True)),
                           float(voice.get("radio_strength", 1.0)), str(voice.get("music", "")),
                           float(voice.get("music_volume", 0.18)))
            self.bot = DiscordBot(dc["token"], dc.get("voice_channel", ""), dc.get("text_channel", ""),
                                  dc.get("server", ""), on_ask=self.discord_ask, on_msg=self.discord_msg, on_note=self.discord_note,
                                  on_status=self.discord_status)
            self.bot.start()
        elif fake:
            self.bot = _FakeBot()
        else:
            print("[discord] Bot wyłączony (brak tokenu w serwer.toml).")

    # -------------------------------------------------------------- Discord -> zespół
    def discord_ask(self, who: str, text: str) -> None:
        self.hub.call({"op": "ask", "from": who, "text": text})

    def discord_note(self, who: str, text: str) -> None:
        self.hub.call({"op": "remember", "who": who, "text": text})

    def memory_text(self, track: str = "") -> str:
        """Pamięć zespołu z arkusza (odświeżana co 3 min) jako dodatek do danych dla AI."""
        now = time.monotonic()
        cache = getattr(self, "_mem", None)
        if cache is None or now - cache[0] > 180 or cache[1] != track:
            try:
                notes = self.hub.call({"op": "memory", "track": track}, timeout=15).get("notes") or []
            except Exception:
                notes = cache[2] if cache else []
            self._mem = cache = (now, track, notes)
        notes = cache[2]
        if not notes:
            return ""
        lines = [f"- {n.get('when', '')} {n.get('who', '')}: {n.get('text', '')}" for n in notes[-30:]]
        return ("\n\nPAMIĘĆ ZESPOŁU (notatki z wcześniejszych jazd i wyścigów – uwzględnij je, "
                "gdy dotyczą pytania; nowsze ważniejsze):\n" + "\n".join(lines))

    def discord_msg(self, who: str, text: str) -> None:
        self.hub.call({"op": "msg", "from": who, "text": text})

    def discord_status(self) -> str:
        v = self.hub.call({"op": "view"})
        live = v.get("live") or {}
        st = live.get("state") or {}
        if not st:
            return "Brak danych z auta."
        lines = [f"Jedzie: {live.get('who')} ({'na żywo' if (v.get('age') or 99) < 30 else 'dane sprzed ' + str(v.get('age')) + ' s'})",
                 f"P{st.get('pos_class')}/{st.get('n_class')} w klasie, okrążenie {(st.get('laps_done') or 0) + 1}",
                 f"Zjazd za ok. {st.get('laps_left')} okr. – {st.get('plan_text') or ''}"]
        nxt = [g for g in v.get("grafik", []) if not g.get("current")][:3]
        for g in nxt:
            lines.append(f"Stint {g['n']}: {g.get('driver') or '—'} od {g['start']}")
        return "\n".join(lines)

    # -------------------------------------------------------------- zadania
    def speak_discord(self, text: str) -> bool:
        if self.bot is None or not self.bot.ready:
            return False
        try:
            pcm = self.tts.pcm(text) if self.tts else b""
            return self.bot.say_pcm(pcm)
        except Exception as e:
            print(f"[głos] {e}")
            return False

    def handle(self, job: dict) -> None:
        kind, p = job.get("kind"), job.get("payload") or {}
        res: dict = {}
        t0 = time.monotonic()
        try:
            if kind == "stt":
                from engineer.listen import from_wav_bytes
                audio, rate = from_wav_bytes(base64.b64decode(p.get("audio", "")))
                res["text"] = self.stt.transcribe(audio, rate) if self.stt else ""
                print(f"[mowa] {job.get('who')}: {res['text']}  ({time.monotonic() - t0:.1f} s)")
            elif kind == "ask":
                q = p.get("question", "")
                summary = p.get("summary", "") + self.memory_text(p.get("track", ""))
                a = self.llm.ask(q, summary, setup=bool(p.get("setup"))) if self.llm else None
                res["text"] = a or "Nie mam teraz dostępu do AI. Zapytaj o paliwo, zjazd, czasy, rywali albo opony."
                print(f"[AI] {p.get('from')}: {q} -> {res['text']}  ({time.monotonic() - t0:.1f} s)")
                if p.get("speak", True) and self.speak_discord(res["text"]):
                    res["spoken"] = "discord"
                self.hub._bg({"op": "log", "from": "inżynier (AI)", "text": f"{q} → {res['text']}",
                              "kind": "odpowiedź", "how": "kierowca" if p.get("speak", True) else "tylko na ścianie"})
            elif kind == "say":
                res["spoken"] = "discord" if self.speak_discord(p.get("text", "")) else ""
                print(f"[Discord] {p.get('text', '')}")
        except Exception as e:
            res["error"] = str(e)
            print(f"[zadanie {kind}] błąd: {e}")
        try:
            self.hub.call({"op": "result", "id": job["id"], "result": res})
        except Exception as e:
            print(f"[zespół] nie wysłałem wyniku: {e}")

    def run(self, minutes: float = 0) -> None:
        end = time.monotonic() + minutes * 60 if minutes else None
        print("[zespół] Czekam na zadania od kierowców...")
        state = None
        while end is None or time.monotonic() < end:
            try:
                out = self.hub.call({"op": "work", "wait": 20, "discord": bool(self.bot and self.bot.ready),
                                     "ai": self.llm is not None, "stt": self.stt is not None}, timeout=45)
                if state is not True:
                    state = True
                    print("[zespół] Połączono ze ścianą boksów.")
                for job in out.get("jobs", []):
                    self.pool.submit(self.handle, job)
            except Exception as e:
                if state is not False:
                    state = False
                    print(f"[zespół] Brak połączenia ze ścianą boksów: {e}. Ponawiam...")
                time.sleep(5)


class _FakeSTT:
    name = "test"

    def transcribe(self, audio, rate=16000) -> str:
        return "ile mam paliwa"


class _FakeLLM:
    def ask(self, q, state, setup=False):
        return f"Odpowiedź testowa na: {q}. Mam {len(state)} znaków danych."


class _FakeBot:
    ready = True
    spoken: list = []

    def say_pcm(self, pcm):
        return True


def main() -> None:
    try:
        from engineer.winicon import set_console_icon
        set_console_icon()
    except Exception:
        pass
    ap = argparse.ArgumentParser(description="Pit Wall Crew - serwer AI")
    ap.add_argument("--config", default="serwer.toml")
    ap.add_argument("--no-discord", action="store_true")
    ap.add_argument("--fake", action="store_true", help="(test) bez modeli i Discorda")
    ap.add_argument("--minutes", type=float, default=0)
    ap.add_argument("--po-aktualizacji", action="store_true", help=argparse.SUPPRESS)
    args = ap.parse_args()
    cfg = load_config(args.config)
    if not args.fake and cfg.get("update", {}).get("auto", True) and "--po-aktualizacji" not in sys.argv:
        try:   # aktualizacja przy starcie serwera (nie w trakcie pracy)
            sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "tools"))
            import updater
            info = updater.check(5)
            if info and updater.apply(info):
                print("[aktualizacja] Uruchamiam serwer ponownie…")
                import subprocess
                sys.exit(subprocess.call([sys.executable] + sys.argv + ["--po-aktualizacji"]))
        except SystemExit:
            raise
        except Exception as e:
            print(f"[aktualizacja] {e}")
    Server(cfg, args.no_discord, args.fake).run(args.minutes)


if __name__ == "__main__":
    main()
