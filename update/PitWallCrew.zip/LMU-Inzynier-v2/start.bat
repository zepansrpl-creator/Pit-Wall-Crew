@echo off
chcp 65001 >nul
cd /d "%~dp0"
if exist ".venv\Scripts\python.exe" (set PY=.venv\Scripts\python.exe) else (set PY=python)
if exist ".venv\Scripts\pythonw.exe" (set PYW=.venv\Scripts\pythonw.exe) else (set PYW=pythonw)
rem Pit Wall Crew: okno aplikacji (inzynier dziala w tle, bez konsoli)
%PY% -c "import tkinter" 2>nul
if errorlevel 1 (
  echo Brak modulu okien (tkinter^) - inzynier w trybie konsoli.
  %PY% kierowca.py
  pause
  exit /b
)
start "" "%PYW%" tools\okno_ustawien.py %*
