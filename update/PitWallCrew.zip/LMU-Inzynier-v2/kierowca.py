"""Pit Wall Crew – program kierowcy (każdy z zespołu uruchamia go u siebie).

Bez AI na tym komputerze (nic nie obciąża gry). Robi:
- odczyt LMU, ostrzeżenia (dublowanie, przeszkody, flagi), plan postoju, okrążenie zjazdowe i „box, box”,
- komunikaty tylko o zmianach (zużycie, opony, rywale, pogoda, zmęczenie), odpowiedzi na pytania z reguł,
- wysyła stan auta na ścianę boksów i odbiera wiadomości zespołu (radio zespołu w aplikacji każdego z Was),
- nagranie z przycisku mówienia: rozpoznawanie mowy i AI przez Groq (darmowa chmura).

Uruchomienie:  python kierowca.py            (na żywo z LMU)
               python kierowca.py --demo     (symulowany wyścig, test bez gry)
"""

from __future__ import annotations

import argparse
import base64
import json
import os
import queue
import sys
import threading
import time
import tomllib
from typing import Optional

from engineer.debuglog import DBG
from datetime import datetime

from engineer.brain import NOT_UNDERSTOOD
from engineer.core import Engineer
from engineer.intents import RuleEngineer
from engineer.voice import Speaker
from team.hub import Hub, make_hub  # noqa: F401
from team import state as team_state


GUI = os.environ.get("PWC_GUI") == "1"
INTRO = {"pro": "Tu {name}, jestem z Tobą. Powodzenia.", "kumpel": "Siema, tu {name}. Jedziemy razem, powodzenia!",
         "twardziel": "Tu {name}. Skup się, robimy robotę.", "analityk": "Tu {name}. Dane są, zaczynamy."}   # uruchomiony z okna aplikacji (bez konsoli)


def load_config(path: str) -> dict:
    for p in (path, os.path.join(os.path.dirname(path) or ".", "config.example.toml")):
        if os.path.exists(p):
            with open(p, "rb") as f:
                return tomllib.load(f)
    return {}


def make_source(args):
    if args.demo:
        from engineer.sources.demo import DemoSource
        return DemoSource(speed=args.speed)
    if args.replay:
        from engineer.sources.replay import ReplaySource
        return ReplaySource(args.replay, speed=args.speed)
    if sys.platform != "win32":
        sys.exit("Odczyt na żywo działa tylko na Windows z uruchomionym LMU. Użyj --demo.")
    from engineer.sources.lmu import LMUSource
    src = LMUSource()
    src.poll_interval = 0.05   # 20 odczytów na sekundę – mniej pracy dla procesora, na którym działa gra
    return src


class Driver:
    """Łączy inżyniera, głos, centrum zespołu i rozmowę."""

    def __init__(self, cfg: dict, args) -> None:
        self.args = args
        voice_cfg, eng_cfg, team_cfg = cfg.get("voice", {}), cfg.get("engineer", {}), cfg.get("team", {})
        self.listen_cfg = cfg.get("listen", {})
        self.speaker = Speaker(
            engines=["print"] if args.no_voice else voice_cfg.get("engines", ["edge", "sapi", "print"]),
            edge_voice=voice_cfg.get("edge_voice", "pl-PL-MarekNeural"), rate=voice_cfg.get("rate", "+10%"),
            pitch=voice_cfg.get("pitch", "+0Hz"), volume=voice_cfg.get("volume", 1.0),
            radio=voice_cfg.get("radio", True), radio_strength=float(voice_cfg.get("radio_strength", 1.0)),
            music=str(voice_cfg.get("music", "")), music_volume=float(voice_cfg.get("music_volume", 0.18)))
        self.eng = Engineer(data_dir=eng_cfg.get("data_dir", "data"),
                            reference_file=eng_cfg.get("reference_file") or None,
                            fuel_margin_laps=eng_cfg.get("fuel_margin_laps", 0.5),
                            fuel_warn_laps=eng_cfg.get("fuel_warn_laps", 3.0),
                            alerts_cfg=cfg.get("alerts", {}), strategy_cfg=cfg.get("strategy", {}),
                            engine_cfg=cfg.get("engine", {}))
        self.rules = RuleEngineer(self.eng)
        # tryb solo: jeden gracz – ściana boksów zostaje (podgląd), bez zmian kierowców; ostrzejszy ton
        self.solo = str(team_cfg.get("mode", "zespol")).lower() == "solo"
        self.eng.fatigue.solo = self.solo
        from engineer.style import Style
        self.persona = str(voice_cfg.get("persona", "pro") or "pro")
        self.eng_name = str(voice_cfg.get("name", "") or "").strip()
        self.style = Style(fillers=bool(voice_cfg.get("fillers", True)),
                           rate=float(voice_cfg.get("fillers_rate", 0.3)), solo=self.solo, persona=self.persona)
        self.eng.overtakes.persona = self.style.persona
        self._intro_done = False
        # radio zespołu: niejadący członkowie zespołu słyszą komunikaty inżyniera we własnej aplikacji
        self.listen_team = bool(team_cfg.get("listen", True)) and not self.solo
        # true = na każde pytanie (poza komendami) odpowiada AI z pełnymi danymi, program jest zapasem
        # opcja „AI odpowiada na wszystkie pytania” wyłączona u wszystkich (oszczędzanie limitu Groq);
        # AI odpowiada tylko na pytania spoza programu, analityczne i o rywali
        self.ai_all = False
        ai_cfg = cfg.get("ai", {})
        self._groq_cfg = (str(ai_cfg.get("groq_key") or "").strip(), str(ai_cfg.get("groq_model") or ""))
        self._groq = None
        self._groq_key_used = ""
        self._mem = None
        self.hub = make_hub(team_cfg, team_cfg.get("name", "kierowca"))
        if self.hub.enabled:   # notatki do pamięci zespołu (kto: ten kierowca)
            self.eng.remember_cb = lambda text, track, car: self.hub.remember(text, track, car)
        if self.hub.backend is not None:   # porównanie z kolegami z zespołu (ich okrążenia w bazie zespołu)
            from engineer.analysis.teamlaps import TeamLaps
            self.eng.teamlaps = TeamLaps(call=lambda p: self.hub.call(p, timeout=8))
        self.questions: queue.Queue[tuple[str, str, str]] = queue.Queue()  # (źródło, od kogo, tekst)
        self.driving = False
        self.muted = False            # „inżynier cicho”: nic nie mówi do następnego naciśnięcia przycisku
        self.diag = None              # dziennik przycięć (engineer/diag.py)
        self._drive_since: Optional[float] = None   # od kiedy na tym komputerze ktoś prowadzi
        self._drive_start_lap = 0     # indeks pierwszego okrążenia tego kierowcy (podsumowanie stintu)
        self._brief_due: Optional[float] = None
        self._laps_seen = 0
        self._session_tag = datetime.now().strftime("%m%d%H%M")   # próbki zużycia opon: osobno dla każdego uruchomienia
        self._last_push = 0.0
        from engineer.analysis.trackmap import TrackMap
        self.trackmap = TrackMap(eng_cfg.get("data_dir", "data"))
        self._map_t = 0.0
        os.makedirs("recordings", exist_ok=True)
        self.log_file = open(os.path.join("recordings", datetime.now().strftime("rozmowa_%Y%m%d_%H%M%S.txt")),
                             "a", encoding="utf-8")

    # ------------------------------------------------------------ głos
    def log(self, who: str, text: str) -> None:
        self.log_file.write(f"{datetime.now():%H:%M:%S} {who}: {text}\n")
        self.log_file.flush()

    def mute(self) -> None:
        self.muted = True
        print("[mowa] Inżynier wyciszony – odezwie się po naciśnięciu przycisku mówienia.")

    def on_ptt(self) -> None:
        """Naciśnięcie przycisku mówienia: przerwij mowę, a po „inżynier cicho” – włącz inżyniera z powrotem."""
        DBG.log("ptt", muted=self.muted, speaking=bool(getattr(self.speaker, "_current", None)))
        if self.muted:
            self.muted = False
            print("[mowa] Inżynier znów mówi.")
        self.speaker.stop()

    def _silent(self, text: str, team: bool, kind: str) -> None:
        """Wyciszony: tylko w oknie, w dzienniku i na ścianie boksów."""
        DBG.log("say", route="wyciszony", text=text, team=team, kind=kind)
        print(f"\n[INŻYNIER – wyciszony] {text}")
        self.log("INŻYNIER (wyciszony)", text)
        if team and self.hub.ok:
            self.hub._bg({"op": "log", "from": "inżynier", "text": text, "kind": kind, "how": "tylko na ścianie"})

    def say(self, text: str, team: bool = False, kind: str = "inżynier") -> None:
        """Komunikat inżyniera: głos u kierowcy, a ważne dla zespołu – też w radiu zespołu (aplikacje i ściana boksów)."""
        if self.muted:
            return self._silent(text, team, kind)
        text = self.style.apply(text, kind)
        self.log("INŻYNIER", text)
        DBG.log("say", route="lokalnie", text=text, team=team, kind=kind)
        self.speaker.say(text)
        self._to_radio(text, kind, team)

    def _to_radio(self, text: str, kind: str, team: bool) -> None:
        """Komunikat do radia zespołu (ściana boksów; gdy jedziesz – także głosem u kolegów z zespołu)."""
        if not (self.hub.enabled and self.hub.ok) or not (team or self.driving):
            return
        rec = {"op": "log", "from": "inżynier", "text": text, "kind": kind}
        if self.driving and not self.solo:
            rec.update(voice=True, src=self.hub.who)
        self.hub._bg(rec)

    def on_radio(self, m: dict) -> None:
        """Wiadomość z radia zespołu (gdy nie jedziesz): inżynier mówi ją u Ciebie."""
        if self.driving or self.muted or not self.listen_team:
            return
        from team.radio import spoken_text
        txt = spoken_text(m, self.hub.who)
        if not txt:
            return
        print(f"\n[INŻYNIER → zespół] {txt}")
        self.log("RADIO ZESPOŁU", txt)
        self.speaker.say(txt)

    @property
    def groq(self):
        """Groq (darmowa chmura): mowa i AI. Najpierw własny klucz kierowcy (config.toml / Zaawansowane),
        a gdy jego limit się wyczerpie albo go nie ma – klucz zespołu ze ściany boksów."""
        keys = [k for k in (self._groq_cfg[0], getattr(self.hub, "groq_key", "")) if k]
        if not keys:
            return None
        if not hasattr(self, "_groqs"):
            self._groqs = {}
        from engineer.groq_ai import GroqAI
        first = None
        for k in dict.fromkeys(keys):
            g = self._groqs.get(k)
            if g is None:
                g = self._groqs[k] = GroqAI(k, self._groq_cfg[1])
                print("[AI] Groq gotowy: " + ("własny klucz" if k == self._groq_cfg[0] else "klucz zespołu") + ".")
            first = first or g
            if g.ready and "wyczerpany" not in g.status:
                self._groq = g
                return g
        self._groq = first
        return first

    def _memory_text(self) -> str:
        """Pamięć zespołu (odświeżana co 3 min) jako dodatek do danych dla AI."""
        if not self.hub.enabled:
            return ""
        track = self.eng.snap.track if self.eng.snap else ""
        now = time.monotonic()
        if self._mem is None or now - self._mem[0] > 180 or self._mem[1] != track:
            try:
                notes = self.hub.call({"op": "memory", "track": track}, timeout=10).get("notes") or []
            except Exception:
                notes = self._mem[2] if self._mem else []
            self._mem = (now, track, notes)
        notes = self._mem[2]
        if not notes:
            return ""
        lines = [f"- {n.get('when', '')} {n.get('who', '')}: {n.get('text', '')}" for n in notes[-30:]]
        return ("\n\nPAMIĘĆ ZESPOŁU (notatki z wcześniejszych jazd – uwzględnij je, gdy dotyczą pytania; "
                "nowsze ważniejsze):\n" + "\n".join(lines))

    def urgent(self, text: str, team: bool = False) -> None:
        """Pilne: zawsze lokalnie, bez opóźnienia sieci. Zespół widzi je na ścianie boksów."""
        if self.muted:
            return self._silent(text, team, "ostrzeżenie")
        self.log("OSTRZEŻENIE", text)
        DBG.log("say", route="pilne", text=text, team=team)
        self.speaker.urgent(text)
        if team and self.hub.ok:
            self.hub._bg({"op": "log", "from": "inżynier", "text": text, "kind": "ostrzeżenie"})

    # ------------------------------------------------------------ rozmowa
    def on_audio(self, audio) -> None:
        """Nagranie z przycisku mówienia: Groq (chmura), a gdy go nie ma albo nie odpowiada – Google."""
        text = ""
        t0 = time.monotonic()
        src = ""
        try:
            import numpy as _npq
            peak = int(_npq.abs(audio).max()) if len(audio) else 0
        except Exception:
            peak = 99999
        if peak < 400:
            # cisza w nagraniu: mikrofon wyciszony (np. przycisk na słuchawkach) albo inny mikrofon.
            # Nie wysyłamy do rozpoznawania – Whisper „słyszy” wtedy zmyślone słowa („Dziękuję.”).
            DBG.log("stt", src="cisza", text="", secs=0, peak=peak, dur=round(len(audio) / 16000, 2))
            now = time.monotonic()
            if now - getattr(self, "_mic_warned", 0) > 20:
                self._mic_warned = now
                self.say("Nie słyszę Cię. Sprawdź, czy mikrofon nie jest wyciszony.", kind="odpowiedź")
            print(f"[mowa] cisza w nagraniu (poziom {peak}/32767) – mikrofon wyciszony albo wybrany inny mikrofon")
            return
        g = self.groq
        conf = None
        if g is not None and g.ready:
            try:
                from engineer.listen import prep_stt, to_wav_bytes
                from engineer.groq_ai import uncertain
                try:     # nazwiska rywali z klasy jako podpowiedź słownictwa („Mateo”, „Wieczorek”)
                    sn = self.eng.snap
                    me = sn.player_scoring() if sn else None
                    names = [c.driver.split()[-1] for c in (sn.cars if sn else [])
                             if me and c.car_class == me.car_class and not c.is_player and c.driver]
                    g.stt_extra = ", ".join(dict.fromkeys(names))[:300]
                except Exception:
                    pass
                wav = to_wav_bytes(prep_stt(audio[: 16000 * 12]))
                text, src = g.transcribe_wav(wav), "groq"
                conf = (g.last_logprob, g.last_no_speech)
                if text and uncertain(g):
                    # druga próba drugim modelem Whispera – bierzemy pewniejsze rozpoznanie
                    first = (text, g.last_logprob, g.last_no_speech)
                    try:
                        t2 = g.transcribe_wav(wav, skip=getattr(g, "last_model", ""))
                    except Exception:
                        t2 = ""
                    DBG.log("stt_retry", first=first[0], lp1=first[1], second=t2, lp2=g.last_logprob)
                    if t2 and not uncertain(g):
                        text, src = t2, "groq2"
                        conf = (g.last_logprob, g.last_no_speech)
                    else:
                        g.last_logprob, g.last_no_speech = first[1], first[2]
                if text and uncertain(g):
                    DBG.log("stt_uncertain", text=text, logprob=g.last_logprob, no_speech=g.last_no_speech)
                    print(f"[mowa] niepewne rozpoznanie: {text!r} – proszę o powtórzenie")
                    self.say("Nie zrozumiałem, powtórz.", kind="odpowiedź")
                    return
            except Exception as e:
                print(f"[mowa] Groq: {str(e)[:100]}")
                src = "groq✗"
        if not text:
            src = (src + "→" if src else "") + "google"
            text = self._google_stt(audio)
        try:
            import numpy as _np0
            mic = getattr(self, "mic", None) or getattr(getattr(self, "listener", None), "mic", None)
            DBG.log("stt", src=src, text=text, secs=round(time.monotonic() - t0, 2),
                    peak=int(_np0.abs(audio).max()) if len(audio) else 0, dur=round(len(audio) / 16000, 2),
                    raw_peak=getattr(mic, "last_raw_peak", None), gain=getattr(mic, "last_gain", None),
                    logprob=None if not conf or conf[0] is None else round(conf[0], 3),
                    no_speech=None if not conf or conf[1] is None else round(conf[1], 3))
            if DBG.enabled:
                from engineer.listen import to_wav_bytes as _tw
                DBG.audio_in(_tw(audio[: 16000 * 30]), text, src, time.monotonic() - t0)
        except Exception:
            pass
        if not text:
            try:
                import numpy as _np
                pk = int(_np.abs(audio).max()) if len(audio) else 0
                dl = len(audio) / 16000
            except Exception:
                pk, dl = -1, 0.0
            hint = (" – prawie cisza: mikrofon wyciszony albo zły mikrofon (uruchom test_mikrofonu.bat)" if 0 <= pk < 1500
                    else "")
            print(f"[mowa] nic nie zrozumiałem (nagranie {dl:.1f} s, poziom {pk}/32767{hint}, próbowałem: {src})")
            return
        print(f"[TY] {text}   ({time.monotonic() - t0:.1f} s, {src})")
        self.questions.put(("mic", self.hub.who, text))

    def _google_stt(self, audio) -> str:
        try:
            from engineer.listen import GoogleSTT
            if not hasattr(self, "_gstt"):
                self._gstt = GoogleSTT()
            return self._gstt.transcribe(audio)
        except Exception:
            return ""

    def answer(self, q: str, from_team: bool = False, who: str = "", silent: bool = False) -> None:
        self.log(who or "KIEROWCA", q)
        if not from_team:
            self.eng.driver_said(q)
        if not from_team and _is_mute_cmd(q, self.eng_name):
            self.say("Ok.")
            self.mute()
            return
        if self.hub.enabled:
            from team.notify_cmd import parse as parse_notify
            nc = parse_notify(q)
            if nc is not None:
                threading.Thread(target=self._send_notify, args=(nc, who, from_team, silent), daemon=True).start()
                return
        a = self.rules.answer(q)
        # Gdy Groq działa, na każde pytanie (poza komendami) odpowiada AI z pełnymi danymi wyścigu, a odpowiedź
        # programu dostaje jako pewne liczby. Gdy AI nie zdąży (ok. 4 s) albo nie odpowie – mówi odpowiedź programu.
        # Komendy (cisza, powtórz, zapamiętaj, przełączniki…) odpowiada program od razu (trace puste = komenda).
        if a is not None:
            g0 = self.groq
            command = not self.rules.trace or any(t in ("setup_change", "help") for t in self.rules.trace) or \
                getattr(self.rules, "_final", False)
            if g0 is not None and g0.ready and self.ai_all and not command and not any(
                    w in q.lower() for w in ("powtórz", "powtorz", "cisza", "zmieniłem", "zmienilem")) \
                    or g0 is not None and g0.ready and not command and (
                        _analytic(q) or _mentions_rival(q, self.eng.snap)):
                DBG.log("ask", q=q, from_team=from_team, who=who, silent=silent, intent=list(self.rules.trace),
                        answer=a, to_ai=True, analytic=True)
                threading.Thread(target=self._ask_ai, args=(q, who, silent, a), daemon=True).start()
                return
        DBG.log("ask", q=q, from_team=from_team, who=who, silent=silent, intent=list(self.rules.trace), answer=a,
                to_ai=a is None)
        control = any(w in q.lower() for w in ("powtórz", "powtorz", "cisza", "zmieniłem", "zmienilem"))
        g = self.groq
        if a is None and not control and g is not None and g.ready:
            threading.Thread(target=self._ask_ai, args=(q, who, silent), daemon=True).start()
            return
        if a is None and not control:
            a = self._no_ai_text()
        if silent:
            self._quiet_reply(a or NOT_UNDERSTOOD)
            return
        self.say(a or NOT_UNDERSTOOD, team=from_team, kind="odpowiedź")

    def _no_ai_text(self) -> str:
        """Reguły nie znają odpowiedzi, a AI nie działa: powiedz dlaczego (zamiast samego „nie zrozumiałem”)."""
        g = self._groq if getattr(self, "_groq", None) is not None else None
        if g is None and not (self._groq_cfg[0] or getattr(self.hub, "groq_key", "")):
            why = ("AI jest wyłączone, bo nie ma klucza Groq. Wklejcie go na ścianie boksów w zakładce Zespół."
                   if self.hub.enabled else "AI jest wyłączone, bo nie ma klucza Groq.")
        elif g is not None and "klucz" in g.status:
            why = "AI nie działa, zły klucz Groq. Wklejcie go ponownie na ścianie boksów."
        else:
            why = "AI teraz nie odpowiada, pewnie limit Groq albo brak internetu."
        return "Tego nie wiem. " + why

    def _send_notify(self, nc: tuple, who: str, from_team: bool, silent: bool) -> None:
        """„Powiadomienie na telefon Amadeusz: wstawaj, zaraz wsiadasz” → ntfy do Amadeusza od razu."""
        to, text = nc
        if not to or not text:
            a = "Powiedz: powiadomienie na telefon, imię i treść."
        else:
            try:
                out = self.hub.call({"op": "notify", "who": who or self.hub.who, "to": to, "text": text}, timeout=10)
                sent, no_phone = out.get("sent") or [], out.get("no_phone") or []
                if sent:
                    a = "Wysłane na telefon: " + ", ".join(sent) + "."
                    if no_phone:
                        a += " Bez telefonu w ustawieniach: " + ", ".join(no_phone) + "."
                elif no_phone:
                    a = ", ".join(no_phone) + " nie ma ustawionego telefonu na ścianie boksów."
                else:
                    a = "Nie znam takiego kierowcy w zespole."
            except Exception as e:
                print(f"[powiadomienie] {e}")
                a = "Nie udało się wysłać powiadomienia, brak połączenia z zespołem."
        DBG.log("notify_cmd", to=to, text=text, answer=a)
        if silent:
            self._quiet_reply(a)
        else:
            self.say(a, team=from_team, kind="odpowiedź")

    def _quiet_reply(self, text: str, log_hub: bool = True) -> None:
        """Odpowiedź na pytanie „tylko tekst” ze ściany boksów: bez głosu, tylko w radiu zespołu."""
        print(f"\n[INŻYNIER → ściana boksów] {text}")
        self.log("INŻYNIER (tylko tekst)", text)
        if self.hub.ok and log_hub:
            self.hub._bg({"op": "log", "from": "inżynier", "text": text, "kind": "odpowiedź",
                          "how": "tylko na ścianie"})

    def _ask_ai(self, q: str, who: str, silent: bool = False, hint: Optional[str] = None) -> None:
        from engineer import setup_rules
        setup = setup_rules.is_setup_question(q)
        g = self.groq
        if g is not None and g.ready:
            text, t0 = None, time.monotonic()
            extra = ("\nODPOWIEDŹ PROGRAMU NA TO PYTANIE (liczby pewne, możesz je wykorzystać i uzupełnić): " + hint) \
                if hint else ""
            state = self.eng.summary(setup=setup, question=q) + self._memory_text() + extra
            box: dict = {}
            done = threading.Event()

            def run():
                try:
                    box["text"] = g.ask(q, state, setup)
                except Exception as e:
                    print(f"[AI] Groq: {str(e)[:100]}")
                    DBG.log("ai_err", q=q, err=str(e)[:200])
                DBG.log("ai_done", q=q, answer=box.get("text"), secs=round(time.monotonic() - t0, 2),
                        model=getattr(g, "status", ""))
                done.set()
            threading.Thread(target=run, daemon=True).start()
            # z gotową odpowiedzią programu nie czekamy długo; bez niej – do limitu czasu Groq
            done.wait(4.5 if hint else 25)
            text = box.get("text")
            DBG.log("ai_full", q=q, hint=hint, answer=text, model=getattr(g, "status", ""),
                    secs=round(time.monotonic() - t0, 2), late=not done.is_set(), prompt_chars=len(state),
                    state=state)
            if hint and not done.is_set():
                DBG.log("ai", q=q, text=None, src="groq", ok=False, secs=4.5, timeout=True)
            DBG.log("ai", q=q, text=text, src="groq", ok=bool(text), secs=round(time.monotonic() - t0, 2))
            if text:
                self.rules.last_answer = text
                if silent:
                    self._quiet_reply(text)
                else:
                    self.say(text, team=bool(who and who != self.hub.who), kind="odpowiedź")
                return
        if hint:                      # Groq nie odpowiedział: zostaje odpowiedź reguł
            if silent:
                self._quiet_reply(hint)
            else:
                self.say(hint, team=bool(who and who != self.hub.who), kind="odpowiedź")
            return
        # Groq nie działa albo nie odpowiedział: powiedz dlaczego
        if silent:
            self._quiet_reply(self._no_ai_text())
        else:
            self.say(self._no_ai_text(), kind="odpowiedź")

    # ------------------------------------------------------------ pętla
    def tick(self, snap) -> None:
        drv = team_state.driving(snap) or self.args.demo
        if self.diag is not None:
            self.diag.tick(snap, drv)
        if drv and self._drive_since is None:
            self._drive_since = time.monotonic()
        elif not drv:
            self._drive_since = None
        if drv and not self.driving:
            self.eng.fatigue.reset_driver(snap.t)
            if not self.solo:
                print("[zespół] Prowadzisz auto – inżynier mówi do Ciebie.")
            if self.eng_name and not self._intro_done:
                self._intro_done = True
                self.say(INTRO.get(self.style.persona, INTRO["pro"]).format(name=self.eng_name), kind="odprawa")
            self._drive_start_lap = len(self.eng.laps)
            ps = snap.player_scoring()
            if snap.session == "race" and ps is not None and ps.laps_done > 0 and not self.args.demo and not self.solo:
                self._brief_due = time.monotonic() + 4   # przejęcie auta w trakcie wyścigu: odprawa
        elif self.driving and not drv:
            print("[zespół] Auto prowadzi zmiennik – tylko podgląd.")
            self._brief_due = None
            if snap.session == "race" and self.hub.ok and not self.solo:
                try:
                    from team.handover import outgoing
                    text, summary = outgoing(self.eng, snap, self._drive_start_lap, self.hub.who)
                    self.hub.send_handover(text, summary)
                    self.log("ZMIANA", f"{summary} | odprawa: {text}")
                    DBG.log("handover_out", text=text, summary=summary)
                except Exception as e:
                    print(f"[zespół] odprawa: {e}")
        self.driving = drv
        if self._brief_due is not None and time.monotonic() > self._brief_due:
            self._brief_due = None
            try:
                from team.handover import incoming_brief
                b = incoming_brief(self.eng, snap)
                if b:
                    self.say(b, kind="odprawa")
            except Exception as e:
                print(f"[zespół] odprawa: {e}")

        if self.hub.targets:
            # Plan zespołu (stinty, opony, zużycie) jest pod długość wyścigu wpisaną na ścianie boksów. W wyścigu
            # innej długości inżynier liczy strategię sam z czasu do mety podanego przez grę i z prawdziwego zużycia.
            use_plan = True
            if snap.session == "race" and snap.time_remaining is not None:
                # plan zespołu działa, gdy wyścig ma długość z planu (ściana boksów → 1. Wyścig), np. 6 h, 24 h
                race_h = (snap.t + snap.time_remaining) / 3600
                plan_h = float(self.hub.targets.get("race_hours") or 24)
                use_plan = abs(race_h - plan_h) <= max(0.25, plan_h * 0.1)
                if use_plan != getattr(self, "_plan_mode", None):
                    self._plan_mode = use_plan
                    print("[zespół] " + (f"Wyścig {race_h:.1f} h: stinty i zużycie według planu zespołu." if use_plan else
                                         f"Wyścig {race_h:.1f} h: plan zespołu jest na {plan_h:g} h, strategię liczę sam "
                                         "z czasu do mety i zużycia."))
            self.eng.targets = {k: self.hub.targets.get(k) for k in
                                ("ve_per_lap", "fuel_per_lap", "wear", "stint_laps", "lap_time", "tyres", "stop_s",
                                 "stint", "tyre_budget")
                                if self.hub.targets.get(k) not in (None, "", [])} if use_plan else {}
            self.eng.pit_call_s = float(self.hub.targets.get("pit_call_s") or self.eng.pit_call_s)
            w = self.eng.weather
            w.slick_k = float(self.hub.targets.get("rain_slick_k") or w.slick_k)
            w.wet_base = float(self.hub.targets.get("rain_wet_base") or w.wet_base)
            w.pit_cost = float(self.hub.targets.get("rain_pit_cost_s") or w.pit_cost)

        msgs = self.eng.update(snap)
        if DBG.enabled:
            DBG.state(snap, self.eng, drv)
            for m in msgs:
                DBG.log("msg", text=m.text, prio=m.priority, urgent=m.urgent, team=m.team,
                        natural=getattr(m, "natural", None), driving=drv, quiet=self.eng.quiet or self.args.quiet,
                        muted=self.muted)
        if drv:
            for m in [m for m in msgs if m.urgent]:
                self.urgent(m.text, team=m.team)
            normal = [m for m in msgs if not m.urgent and m.priority > 0]
            if normal and not self.args.quiet and not self.eng.quiet:
                normal.sort(key=lambda m: -m.priority)
                team = [m for m in normal[:3] if m.team]
                local = [m for m in normal[:3] if not m.team]
                nat = lambda ms: "inżynier" if all(m.natural and m.priority <= 6 for m in ms) else "ważne"
                if team:
                    self.say(" ".join(m.text for m in team), team=True, kind=nat(team))
                if local:
                    self.say(" ".join(m.text for m in local), kind=nat(local))
        for m in [m for m in msgs if m.priority == 0]:
            print(f"[inżynier] {m.text}")
            self.log("INŻYNIER (bez głosu)", m.text)
            if self.hub.ok and drv:   # np. zmierzony postój: na ścianę boksów, bez mówienia
                self.hub._bg({"op": "log", "from": "inżynier", "text": m.text, "kind": "inżynier"})

        # okrążenia do arkusza
        if len(self.eng.laps) > self._laps_seen:
            ps = snap.player_scoring()
            for lap in self.eng.laps[self._laps_seen:]:
                DBG.log("lap", lap=lap.lap, time=round(lap.lap_time, 3), valid=lap.valid, pit=lap.pit, clean=lap.clean,
                        incomplete=lap.incomplete, fuel=round(lap.fuel_used, 2),
                        ve=round(lap.ve_used, 4) if lap.ve_used else None, off=lap.off_tracks, impact=lap.impact,
                        driver=lap.driver)
                self.hub.add_lap(team_state.lap_row(self.eng, lap, (ps.pit_stops + 1) if ps else None))
                if self.hub.ok and self.hub.backend is not None and lap.clean and not lap.pit:
                    try:   # zużycie opon w tym stincie → baza zespołu (plan opon na ścianie boksów)
                        from team.wearlog import sample
                        smp = sample(self.eng._stint_laps(), self._session_tag, ps.pit_stops if ps else 0)
                        if smp:
                            self.hub._bg({"op": "wear", "tc": smp[0], "key": smp[1], "rec": smp[2]})
                    except Exception as e:
                        print(f"[zużycie opon] {e}")
                tl = getattr(self.eng, "teamlaps", None)
                if tl is not None and self.hub.ok and lap.clean:
                    def _prep(l=lap):
                        try:
                            tl.prepare(l)
                            DBG.log("teamlaps", uploaded=tl.uploaded, match=(tl.match[0].get("driver"),
                                    tl.match[0].get("lap_time"), tl.match[2]) if tl.match else None, err=tl.errors)
                        except Exception as e:
                            print(f"[zespół-okrążenia] {e}")
                    threading.Thread(target=_prep, daemon=True).start()
            self._laps_seen = len(self.eng.laps)
        # mapa toru: kształt zbiera się z położenia aut (co 0,5 s), raz wysyłany do bazy zespołu
        if time.monotonic() - self._map_t > 0.5:
            self._map_t = time.monotonic()
            try:
                self.trackmap.update(snap)
                if self.trackmap.points and self.hub.enabled and self.hub.ok and \
                        time.monotonic() - (self.trackmap.uploaded or -1e9) > 1800:   # raz na sesję (i co 30 min)
                    self.trackmap.uploaded = time.monotonic()
                    self.hub._bg({"op": "trackmap", "key": self.trackmap.key, "track": self.trackmap.track,
                                  "points": self.trackmap.points})
            except Exception as e:
                print(f"[mapa] {e}")
        # stan auta co ok. 2 s do wątku wysyłającego (wysyła co 4 s)
        if time.monotonic() - self._last_push > 2.0:
            self._last_push = time.monotonic()
            try:
                st = team_state.build(self.eng, snap)
                if self.trackmap.points:
                    ps = snap.player_scoring()
                    st["map"] = dict(self.trackmap.live(snap, ps.car_class if ps else ""), key=self.trackmap.key)
                self.hub.push(st, drv)
                if GUI:
                    self._gui_status(st, drv)
            except Exception as e:
                print(f"[zespół] błąd stanu: {e}")

    def _gui_status(self, st: dict, drv: bool) -> None:
        """Skrót stanu dla okna aplikacji (linia „@@ {json}” na wyjściu programu)."""
        keys = ("session", "track", "car", "cls", "pos_class", "n_class", "laps_done", "last_lap", "avg_lap", "best_lap",
                "laps_left", "fuel_l", "ve_pct", "fuel_per_lap", "ve_per_lap", "time_remaining", "in_pits", "tyres",
                "stint_laps", "phase")
        out = {k: st.get(k) for k in keys if st.get(k) is not None}
        out.update(driving=bool(drv), hub=bool(self.hub.enabled), hub_ok=bool(self.hub.ok), muted=self.muted, solo=self.solo, who=self.hub.who,
                   groq=self.groq is not None, groq_status=(self._groq.status if self._groq else ""))
        try:
            print("@@ " + json.dumps(out, ensure_ascii=False), flush=True)
        except Exception:
            pass

    def team_inbox(self) -> None:
        with self.hub._lock:
            ev, self.hub.events = self.hub.events, []
        for e in ev:
            print(f"[zespół] {e}")
            self.log("ZESPÓŁ", e)
            DBG.log("team_event", text=e)
        h = self.hub.take_handover()
        if h:
            DBG.log("handover_in", data=h, driving=self.driving)
        if h and h.get("text") and self.driving:
            from engineer.plnum import genitive_name
            self.say(f"Odprawa od {genitive_name(h.get('from', 'zespołu'))}: {h['text']}", kind="odprawa")
        msgs = self.hub.take_inbox()
        for m in msgs:
            DBG.log("team_msg", frm=m.get("from"), text=m.get("text"), muted=self.muted)
            from engineer.plnum import genitive_name
            if self.muted:
                print(f"\n[wiadomość – inżynier wyciszony] {m['from']}: {m['text']}")
            else:
                self.speaker.say(f"Wiadomość od {genitive_name(m['from'])}: {m['text']}")
            self.log(m["from"], m["text"])
        self.hub.delivered([m["id"] for m in msgs], "tylko tekst (inżynier wyciszony)" if self.muted else "głos u kierowcy")
        for a in self.hub.take_asks():
            self.answer(a["text"], from_team=True, who=a.get("from", "zespół"), silent=bool(a.get("silent")))


# częste krótkie odpowiedzi – przygotowane z góry, odtwarzają się od razu
COMMON_REPLIES = ["Ok.", "Nie zrozumiałem, powtórz.", "Słyszę Cię dobrze.", "Radio sprawdzone.",
                  "Nie słyszę Cię. Sprawdź, czy mikrofon nie jest wyciszony.", "Przekażę następnemu kierowcy na odprawie.",
                  "Zapisałem w pamięci zespołu.", "Dobra, nie mówię o dublowaniu. Ostrzeżenia o wypadkach zostają.",
                  "Ok, tylko pilne i odpowiedzi.", "Wracam do komunikatów o zmianach.", "Box, box."]


def _stop_old_engineer(pid_file: str) -> None:
    """Gdy działa jeszcze poprzedni inżynier (np. drugie okno aplikacji albo stare okno konsoli), zamknij go."""
    if sys.platform != "win32":
        return
    try:
        with open(pid_file) as f:
            old = int(f.read().split()[0])
    except (OSError, ValueError, IndexError):
        return
    if old == os.getpid():
        return
    try:
        import ctypes
        from ctypes import wintypes
        k32 = ctypes.windll.kernel32
        k32.OpenProcess.restype = wintypes.HANDLE
        h = k32.OpenProcess(0x0001 | 0x1000, False, old)      # TERMINATE | QUERY_LIMITED_INFORMATION
        if not h:
            return
        try:
            buf = ctypes.create_unicode_buffer(1024)
            n = wintypes.DWORD(1024)
            name = buf.value.lower() if k32.QueryFullProcessImageNameW(h, 0, buf, ctypes.byref(n)) else ""
            code = wintypes.DWORD()
            alive = k32.GetExitCodeProcess(h, ctypes.byref(code)) and code.value == 259
            if alive and "python" in name:
                k32.TerminateProcess(h, 0)
                print(f"[start] Zamknąłem poprzedniego inżyniera (proces {old}) – działał jeszcze w tle.")
        finally:
            k32.CloseHandle(h)
    except Exception:
        pass


def _analytic(q: str) -> bool:
    """Pytanie wymagające analizy danych (porównanie, różnica, dlaczego, kto najszybszy…) – lepiej odpowie AI."""
    import re
    from engineer.intents import fold
    t = fold(q)
    return bool(re.search(r"porown|roznic|dlaczego|czemu|wyjasn|analiz|co sadzisz|jak myslisz|ocen|wszystk|"
                          r"srednio|srednia|kto ma|ktory ma|ktora ma|kto jest najszyb|najszybsz|najwoln|ranking|"
                          r"zestaw|w porownaniu|o ile|lepszy|gorszy|szybszy niz|wolniejszy niz|jakim autem|"
                          r"jakie auto|jakim samochod|czym jedzie|jaki model|grill|chlodzen|jak ustawic|"
                          r"jakie musze miec|ile musze|zeby zrobic|dam rade|starczy na \d+|okrazeniu wyjazdow|"
                          r"wyjazdowym|byl w boksie|zjezdzal|stal w boksie", t))


def _mentions_rival(q: str, snap) -> bool:
    """Pytanie wymienia nazwisko kierowcy innego auta (np. „czy Mateo był w boksie?”) – lepiej odpowie AI."""
    import re
    from engineer.intents import fold
    if snap is None:
        return False
    words = set(re.findall(r"[a-z]{4,}", fold(q)))
    for c in snap.cars:
        if c.is_player or not c.driver:
            continue
        for part in fold(c.driver).split():
            if len(part) >= 4 and any(w.startswith(part[:5]) for w in words):
                return True
    return False


def _is_mute_cmd(q: str, name: str = "") -> bool:
    """„Inżynier, cicho”, „inżynierze cicho”, „inżynier bądź cicho”, „inżynier cisza” (albo imię inżyniera)."""
    import re
    from engineer.intents import NEXT_DRIVER_RE, fold
    from team.notify_cmd import parse as parse_notify
    if NEXT_DRIVER_RE.search(q) or parse_notify(q) is not None:   # notatka / powiadomienie, nie wyciszenie
        return False
    t = re.sub(r"[^a-z ]", " ", fold(q))
    who = r"inzynier\w*"
    n = re.sub(r"[^a-z]", "", fold(name or ""))
    if len(n) >= 3:
        who = rf"(?:inzynier\w*|{n[:max(3, len(n) - 2)]}\w*)"
    if re.search(rf"\b{who}\b.*\b(cicho|cisza|zamilcz|wycisz\w*)\b", t):
        return True
    # samo „cisza”, „cicho”, „bądź cicho”, „zamilcz”, „nie gadaj” (krótka komenda bez imienia)
    words = t.split()
    return 0 < len(words) <= 3 and bool(re.fullmatch(
        r"(prosze )?(badz |teraz )?(cisza|cicho|zamilcz|wycisz( sie)?|nie gadaj|zamknij sie)( prosze| teraz)?", " ".join(words)))


def input_loop(q: queue.Queue, who: str) -> None:
    while True:
        try:
            line = input()
        except (EOFError, KeyboardInterrupt):
            q.put(("kb", who, "koniec"))
            return
        if line.strip():
            q.put(("kb", who, line.strip()))


def main() -> None:
    from engineer.listen import _sdl_safe_hints
    _sdl_safe_hints()   # zanim cokolwiek zaimportuje pygame: SDL nie przejmuje kierownicy z FFB
    from engineer.winicon import set_console_icon
    set_console_icon()
    from engineer.winaudio import set_mixer_name
    set_mixer_name()            # mikser głośności: „Pit Wall Crew” zamiast „Python”
    ap = argparse.ArgumentParser(description="Pit Wall Crew – program kierowcy")
    ap.add_argument("--config", default="config.toml")
    ap.add_argument("--demo", action="store_true")
    ap.add_argument("--replay")
    ap.add_argument("--speed", type=float, default=1.0)
    ap.add_argument("--no-voice", action="store_true")
    ap.add_argument("--quiet", action="store_true")
    ap.add_argument("--no-mic", action="store_true")
    ap.add_argument("--minutes", type=float, default=0, help="(test) zakończ po tylu minutach")
    ap.add_argument("--record", action="store_true", help="nagrywaj dane z gry (10 razy na sekundę) do folderu recordings")
    args = ap.parse_args()
    if args.demo and args.speed == 1.0:
        args.speed = 10.0
    cfg = load_config(args.config)
    pid_file = os.path.join(os.path.dirname(os.path.abspath(__file__)), "inzynier.pid")
    if not args.demo and not args.replay:
        _stop_old_engineer(pid_file)     # tylko jeden inżynier naraz (inaczej każdy komunikat słychać podwójnie)
        try:   # okno ustawień może zrestartować inżyniera (zamyka okno konsoli start.bat i otwiera nowe)
            with open(pid_file, "w") as f:
                f.write(f"{os.getpid()} {os.getppid()}")
        except OSError:
            pass
    if sys.platform == "win32" and not args.demo:
        try:   # inżynier ustępuje grze, gdy procesor nie nadąża (priorytet „poniżej normalnego”)
            import ctypes
            k32 = ctypes.windll.kernel32
            k32.GetCurrentProcess.restype = ctypes.c_void_p
            if k32.SetPriorityClass(ctypes.c_void_p(k32.GetCurrentProcess()), 0x00004000):
                print("Priorytet inżyniera: poniżej normalnego (gra ma pierwszeństwo).")
        except Exception:
            pass
    d = Driver(cfg, args)
    source = make_source(args)
    if not args.demo and not args.replay:
        try:   # prognoza pogody, hamulce, grill z wewnętrznego interfejsu gry (tylko odczyt)
            from engineer.sources.lmu_rest import LmuRest
            d.eng.rest = LmuRest()
            rc = cfg.get("rest", {})
            d.eng.rest.enabled = bool(rc.get("enabled", True))
            # Pytamy grę dopiero po 30 s jazdy – nigdy w trakcie wchodzenia na serwer / wczytywania
            delay = float(rc.get("start_delay_s", 30))
            d.eng.rest.allow = lambda: d._drive_since is not None and time.monotonic() - d._drive_since > delay
            d.eng.rest.start()
            if not d.eng.rest.enabled:
                print("[interfejs gry] wyłączony w config.toml ([rest] enabled = false)")
        except Exception as e:
            print(f"[interfejs gry] niedostępny: {e}")
    dc = cfg.get("diag", {})
    if not args.demo and not args.replay and dc.get("enabled", True):
        try:
            from engineer.diag import StutterLog
            d.diag = StutterLog(d.speaker, mark_key=str(dc.get("mark_key", "f9")))
            d.diag.start()
        except Exception as e:
            print(f"[diagnostyka] niedostępna: {e}")
    if d.hub.enabled:
        d.hub.start()
        if d.listen_team and hasattr(getattr(d.hub, "backend", None), "c"):
            from team.radio import TeamRadio
            TeamRadio(d.hub.backend.c, d.on_radio).start()
        print(f"[zespół] Ściana boksów: łączę jako {d.hub.who}...")
    else:
        print("[tryb solo] Jeden gracz, bez ściany boksów (brak kodu zespołu w ustawieniach)." if d.solo else
              "[zespół] Brak kodu i hasła zespołu w ustawieniach – działam sam (bez zespołu).")
    from engineer.version import version
    print(f"Pit Wall Crew, wersja {version()}. Głos: {d.speaker.engine}.")

    threading.Thread(target=input_loop, args=(d.questions, d.hub.who), daemon=True).start()
    rec = None  # noqa: F841
    lc = d.listen_cfg
    if not args.no_mic and lc.get("enabled", True):
        try:
            from engineer.listen import Microphone, PTTRecorder, PTTSource
            ptt = PTTSource(key=lc.get("ptt_key", "f8"), joystick_name=lc.get("joystick_name", ""),
                            joystick_button=int(lc.get("joystick_button", -1)))
            mic = Microphone(lc.get("mic_device") or None)
            d.mic = mic        # poziom mikrofonu do dziennika
            rec = PTTRecorder(mic, ptt, on_audio=d.on_audio, on_press=d.on_ptt)
            print("[mowa] Trzymaj przycisk, mów, puść. Mowę rozpoznaje Groq (albo Google, gdy Groq nie działa).")
        except Exception as e:
            print(f"[mowa] Rozmowa głosowa wyłączona: {e}")
    print("Możesz też wpisać pytanie i Enter. 'stan' = dane, 'koniec' = wyjście.")
    if sys.platform == "win32" and not args.demo and not args.replay:
        print("Czekam na LMU (Ustawienia -> Rozgrywka -> Enable Plugins musi być włączone)...")

    if cfg.get("debug", {}).get("full_log") and not args.demo and not args.replay:
        DBG.start()
        def _hide(x):      # klucze i hasła nigdy w dzienniku (pliki diagnostyczne bywają wysyłane dalej)
            if isinstance(x, dict):
                return {k: ("***" if any(w in k.lower() for w in ("key", "password", "token", "haslo")) and v
                            else _hide(v)) for k, v in x.items()}
            return x
        DBG.log("start", version=__import__("engineer.version", fromlist=["version"]).version(),
                cfg=_hide({k: v for k, v in cfg.items() if k != "team"}), solo=d.solo)
        args.record = bool(cfg["debug"].get("record", True))   # nagranie danych z gry do odtworzenia
        args.record_hz = float(cfg["debug"].get("record_hz", 2))   # 2 razy/s: ok. 60 MB na godzinę
    writer = None
    if args.record:
        from engineer.sources.replay import SnapshotWriter
        path = os.path.join("recordings", datetime.now().strftime("sesja_%Y%m%d_%H%M%S.jsonl.gz"))
        writer = SnapshotWriter(path, hz=getattr(args, "record_hz", 10))
        print(f"[nagrywanie] Zapisuję dane z gry do {path}")
    prerendered = False
    hub_state = None
    t_end = time.monotonic() + args.minutes * 60 if args.minutes else None
    try:
        while True:
            drain = getattr(source, "drain", False)
            for _ in range(10000 if drain else 1):
                snap = source.read()
                if snap is None:
                    break
                if writer:
                    writer.write(snap)
                d.tick(snap)
                if not prerendered and snap.cars and (args.demo or args.replay or (
                        d._drive_since is not None and time.monotonic() - d._drive_since > 20)):
                    # nagrywanie zdań w tle dopiero po chwili jazdy, nie w trakcie wchodzenia na serwer
                    prerendered = True
                    d.speaker.prerender(d.eng.hazards.phrases(sorted({c.car_class for c in snap.cars})))
                    d.speaker.prerender(COMMON_REPLIES)
            if getattr(source, "finished", False):
                break
            if d.hub.enabled and d.hub.ok != hub_state:
                hub_state = d.hub.ok
                print("[zespół] " + ("połączono ze ścianą boksów"
                                     if d.hub.ok else f"brak połączenia ze ścianą boksów ({d.hub.error})"))
            d.team_inbox()
            while not d.questions.empty():
                kind, who, q = d.questions.get()
                if kind == "kb" and q.lower() in ("koniec", "exit", "quit"):
                    raise KeyboardInterrupt
                if kind == "kb" and q.lower() == "stan":
                    print("\n" + d.eng.summary(setup=True))
                    continue
                d.answer(q)
            if t_end and time.monotonic() > t_end:
                break
            time.sleep(source.poll_interval)
    except KeyboardInterrupt:
        pass
    finally:
        if writer:
            writer.close()
        d.log_file.close()
        DBG.log("stop")
        DBG.close()
        source.close()
        print("Do usłyszenia.")


if __name__ == "__main__":
    main()
