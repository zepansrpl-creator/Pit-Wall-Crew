@echo off
chcp 65001 >nul
cd /d "%~dp0"
if exist ".venv\Scripts\python.exe" (set PY=.venv\Scripts\python.exe) else (set PY=python)
if exist ".venv\Scripts\pythonw.exe" (set PYW=.venv\Scripts\pythonw.exe) else (set PYW=pythonw)
%PY% -c "import tkinter" 2>nul
if errorlevel 1 (
  %PY% kierowca.py --demo
  pause
  exit /b
)
start "" "%PYW%" tools\okno_ustawien.py --demo
